import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  // These packages ship a native .node addon (better-sqlite3) or a WASM/native
  // engine (sharp, the Prisma client). If Next tries to bundle them into
  // .next, it emits a hashed copy whose companion .node binary is not always
  // traced -- which crashed every DB-backed page in the distributed build with
  // "Could not locate the bindings file". Marking them external makes the
  // server load them straight from node_modules at runtime, where the binary
  // already sits. It also keeps native binaries out of the update package, so
  // an auto-update can never ship a mismatched or missing .node file.
  serverExternalPackages: [
    "better-sqlite3",
    "@prisma/adapter-better-sqlite3",
    "@prisma/client",
    "sharp",
  ],
  experimental: {
    serverActions: {
      // Server Actions default to a 1MB request body limit -- too small for
      // batch-uploading several BKU PDFs (each ~0.5MB) in one submission.
      bodySizeLimit: "50mb",
    },
  },
};

export default nextConfig;
