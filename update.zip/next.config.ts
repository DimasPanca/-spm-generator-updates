import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  experimental: {
    serverActions: {
      // Server Actions default to a 1MB request body limit -- too small for
      // batch-uploading several BKU PDFs (each ~0.5MB) in one submission.
      bodySizeLimit: "50mb",
    },
  },
};

export default nextConfig;
