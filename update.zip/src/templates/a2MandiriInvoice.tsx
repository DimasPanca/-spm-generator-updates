import { Document, Page, View, Text, StyleSheet, Image } from "@react-pdf/renderer";
import { configurePdfFonts } from "./pdfFonts";
import type { A2MandiriInvoiceData } from "@/lib/invoice/buildA2MandiriInvoiceData";

configurePdfFonts();

export interface A2MandiriInvoiceTemplateData extends A2MandiriInvoiceData {
  logo: Buffer | null;
}

// Approximated from the reference Canva invoice -- the exact brand hex isn't
// known, so this is a close violet/purple stand-in for its accent bar.
const ACCENT = "#6D28D9";
const GRAY_HEADER = "#EAEAEE";
const GRAY_TEXT = "#6B7280";
const LINE = "#DDDDDD";

// A one- or two-line invoice otherwise leaves most of the A4 page blank.
// Padding the table out with blank ruled rows makes it read like a normal
// invoice pad instead of a mostly-empty certificate.
const MIN_TABLE_ROWS = 16;

function rupiah(n: number) {
  return `RP ${n.toLocaleString("id-ID")}`;
}

const styles = StyleSheet.create({
  page: {
    paddingTop: 42,
    paddingHorizontal: 48,
    paddingBottom: 42,
    fontFamily: "Helvetica",
    fontSize: 9,
    color: "#111111",
  },

  headerRow: { flexDirection: "row", justifyContent: "space-between", alignItems: "flex-start" },
  invoiceTitleRow: { flexDirection: "row", alignItems: "center" },
  accentMark: { width: 9, height: 25, backgroundColor: ACCENT, marginRight: 9 },
  invoiceTitle: { fontFamily: "Helvetica-Bold", fontSize: 25, letterSpacing: 1 },

  brandRow: { flexDirection: "row", alignItems: "center" },
  brandTextBlock: { alignItems: "flex-end", marginRight: 10 },
  brandName: { fontFamily: "Helvetica-Bold", fontSize: 14 },
  brandSubtitle: {
    fontSize: 6.3,
    color: GRAY_TEXT,
    textAlign: "right",
    width: 150,
    marginTop: 3,
  },
  logoImg: { width: 44, height: 44, objectFit: "contain" },

  divider: { height: 3, backgroundColor: ACCENT, marginTop: 14, marginBottom: 24 },

  infoRow: { flexDirection: "row", justifyContent: "space-between", marginBottom: 20 },
  infoLabel: { fontFamily: "Helvetica-Bold", fontSize: 8.5, marginBottom: 3 },
  infoValue: { fontSize: 9 },
  infoRight: { alignItems: "flex-end" },
  infoRightBlock: { alignItems: "flex-end", marginBottom: 10 },

  table: { marginTop: 4 },
  tableHeader: {
    flexDirection: "row",
    backgroundColor: GRAY_HEADER,
    paddingVertical: 7,
    paddingHorizontal: 8,
  },
  tableHeaderText: { fontFamily: "Helvetica-Bold", fontSize: 8 },
  tableRow: {
    flexDirection: "row",
    paddingVertical: 6,
    paddingHorizontal: 8,
    borderBottomWidth: 0.75,
    borderBottomColor: LINE,
  },
  colKeterangan: { flex: 1 },
  colHarga: { width: 76, textAlign: "right" },
  colJml: { width: 36, textAlign: "right" },
  colTotal: { width: 86, textAlign: "right" },

  summaryBlock: { alignSelf: "flex-end", width: 200, marginTop: 12 },
  summaryRow: { flexDirection: "row", justifyContent: "space-between", paddingVertical: 3 },
  summaryLabel: { fontSize: 8.5 },
  summaryValue: { fontSize: 8.5 },
  totalRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    paddingTop: 6,
    marginTop: 3,
    borderTopWidth: 1,
    borderTopColor: "#111111",
  },
  totalLabel: { fontFamily: "Helvetica-Bold", fontSize: 10 },
  totalValue: { fontFamily: "Helvetica-Bold", fontSize: 10 },

  footerRow: { flexDirection: "row", justifyContent: "space-between", alignItems: "flex-end", marginTop: 50 },
  thanks: { fontFamily: "Helvetica-Bold", fontSize: 9.5, width: 220, lineHeight: 1.4 },
  signatureBlock: { alignItems: "center", width: 150 },
  signatureLabel: { fontSize: 9, marginBottom: 40 },
  signatureLine: { borderTopWidth: 1, borderTopColor: "#111111", width: 140 },
});

function InvoicePage({ data }: { data: A2MandiriInvoiceTemplateData }) {
  return (
    <Page size="A4" style={styles.page}>
      <View style={styles.headerRow}>
        <View style={styles.invoiceTitleRow}>
          <View style={styles.accentMark} />
          <Text style={styles.invoiceTitle}>INVOICE</Text>
        </View>
        <View style={styles.brandRow}>
          <View style={styles.brandTextBlock}>
            <Text style={styles.brandName}>A2 MANDIRI</Text>
            <Text style={styles.brandSubtitle}>
              PERCETAKAN, JASA, SUPLIER, INTERIOR, DISTRIBUTOR
            </Text>
          </View>
          {data.logo && <Image src={data.logo} style={styles.logoImg} />}
        </View>
      </View>

      <View style={styles.divider} />

      <View style={styles.infoRow}>
        <View>
          <Text style={styles.infoLabel}>KEPADA :</Text>
          <Text style={styles.infoValue}>{data.schoolName}</Text>
        </View>
        <View style={styles.infoRight}>
          <View style={styles.infoRightBlock}>
            <Text style={styles.infoLabel}>TANGGAL :</Text>
            <Text style={styles.infoValue}>{data.tanggal}</Text>
          </View>
          <View>
            <Text style={styles.infoLabel}>NO INVOICE :</Text>
            <Text style={styles.infoValue}>{data.noInvoice}</Text>
          </View>
        </View>
      </View>

      <View style={styles.table}>
        <View style={styles.tableHeader} fixed>
          <Text style={[styles.tableHeaderText, styles.colKeterangan]}>KETERANGAN</Text>
          <Text style={[styles.tableHeaderText, styles.colHarga]}>HARGA</Text>
          <Text style={[styles.tableHeaderText, styles.colJml]}>JML</Text>
          <Text style={[styles.tableHeaderText, styles.colTotal]}>TOTAL (RP)</Text>
        </View>
        {data.lines.map((line, index) => (
          <View style={styles.tableRow} key={index} wrap={false}>
            <Text style={styles.colKeterangan}>{line.keterangan}</Text>
            <Text style={styles.colHarga}>{rupiah(line.harga)}</Text>
            <Text style={styles.colJml}>{line.jml}</Text>
            <Text style={styles.colTotal}>{rupiah(line.total)}</Text>
          </View>
        ))}
        {Array.from({ length: Math.max(0, MIN_TABLE_ROWS - data.lines.length) }).map((_, i) => (
          <View style={styles.tableRow} key={`blank-${i}`} wrap={false}>
            <Text style={styles.colKeterangan}> </Text>
            <Text style={styles.colHarga}> </Text>
            <Text style={styles.colJml}> </Text>
            <Text style={styles.colTotal}> </Text>
          </View>
        ))}
      </View>

      <View style={styles.summaryBlock} wrap={false}>
        <View style={styles.summaryRow}>
          <Text style={styles.summaryLabel}>SUB TOTAL :</Text>
          <Text style={styles.summaryValue}>{rupiah(data.subTotal)}</Text>
        </View>
        <View style={styles.summaryRow}>
          <Text style={styles.summaryLabel}>PAJAK :</Text>
          <Text style={styles.summaryValue}>-</Text>
        </View>
        <View style={styles.totalRow}>
          <Text style={styles.totalLabel}>TOTAL :</Text>
          <Text style={styles.totalValue}>{rupiah(data.total)}</Text>
        </View>
      </View>

      <View style={styles.footerRow} wrap={false}>
        <Text style={styles.thanks}>{"TERIMAKASIH ATAS\nPEMBELIAN ANDA"}</Text>
        <View style={styles.signatureBlock}>
          <Text style={styles.signatureLabel}>Hormat Kami,</Text>
          <View style={styles.signatureLine} />
        </View>
      </View>
    </Page>
  );
}

export function A2MandiriInvoiceDocument({ data }: { data: A2MandiriInvoiceTemplateData }) {
  return (
    <Document>
      <InvoicePage data={data} />
    </Document>
  );
}

/** Every month with a confirmed book purchase, one invoice per page. */
export function A2MandiriInvoiceBundleDocument({
  pages,
}: {
  pages: A2MandiriInvoiceTemplateData[];
}) {
  return (
    <Document>
      {pages.map((data) => (
        <InvoicePage key={data.noInvoice} data={data} />
      ))}
    </Document>
  );
}
