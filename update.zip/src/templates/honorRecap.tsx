import { Document, Page, View, Text, StyleSheet } from "@react-pdf/renderer";
import { KopHeader } from "./Kop";
import { configurePdfFonts } from "./pdfFonts";

configurePdfFonts();

export interface HonorRecapRowData {
  no: number;
  tanggal: string; // "16-02-2026"
  bulan: string; // "Februari" -- only shown when showMonthColumn
  nama: string;
  nominalFormatted: string; // "Rp 200.000"
}

export interface HonorRecapSheetData {
  title: string; // "DAFTAR PENERIMAAN HONOR TENAGA KEBERSIHAN"
  /** Overrides the document-wide periodLabel/showMonthColumn for this sheet
   *  only -- used by Transport Kegiatan, where every trip is its own sheet
   *  with its own date rather than a table shared across trips. */
  periodLabel?: string;
  showMonthColumn?: boolean;
  mengetahuiDate?: string;
  rows: HonorRecapRowData[];
  totalFormatted: string;
}

export interface HonorRecapTemplateData {
  schoolName: string;
  kopHeaderLine: string | null;
  schoolAddress: string;
  schoolContact: string | null;
  schoolNpsn: string | null;
  schoolLogo: Buffer | null;
  regionalLogo: Buffer | null;
  periodLabel: string; // "FEBRUARI 2026"
  showMonthColumn: boolean;
  kepalaJabatan: string;
  kepalaName: string;
  mengetahuiDate: string;
  sheets: HonorRecapSheetData[];
}

const BORDER = "#000";

const styles = StyleSheet.create({
  page: {
    paddingTop: 36,
    paddingBottom: 40,
    paddingHorizontal: 44,
    fontSize: 11,
    fontFamily: "Times-Roman",
  },
  title: {
    fontSize: 13,
    fontFamily: "Times-Bold",
    textAlign: "center",
    textDecoration: "underline",
  },
  subtitle: {
    fontSize: 11.5,
    fontFamily: "Times-Bold",
    textAlign: "center",
    marginTop: 3,
    marginBottom: 14,
  },

  // Full grid: the outer View draws the top/left edges, each cell draws its
  // own right/bottom edge, so lines never double up.
  table: {
    borderTopWidth: 1,
    borderLeftWidth: 1,
    borderColor: BORDER,
    marginBottom: 26,
  },
  row: {
    flexDirection: "row",
    minHeight: 26, // roomy rows -- there must be space to sign by hand
    alignItems: "stretch",
  },
  headerRow: {
    flexDirection: "row",
    minHeight: 28,
    alignItems: "stretch",
    backgroundColor: "#EDEDED",
  },
  cell: {
    borderRightWidth: 1,
    borderBottomWidth: 1,
    borderColor: BORDER,
    paddingVertical: 6,
    paddingHorizontal: 6,
    justifyContent: "center",
  },
  headerText: {
    fontFamily: "Times-Bold",
    fontSize: 11,
    textAlign: "center",
  },
  cNo: { width: 34 },
  cBulan: { width: 74 },
  cTanggal: { width: 82 },
  cNama: { flex: 1 },
  cNominal: { width: 104 },
  cTtd: { width: 104 },

  textCenter: { textAlign: "center" },
  textRight: { textAlign: "right" },
  totalLabel: { fontFamily: "Times-Bold", textAlign: "right" },
  totalValue: { fontFamily: "Times-Bold", textAlign: "right" },

  signatureBlock: {
    alignSelf: "flex-end",
    width: 250,
    textAlign: "center",
  },
  signatureGap: { height: 58 },
  signatureName: {
    fontFamily: "Times-Bold",
    textDecoration: "underline",
  },
});

function Sheet({
  sheet,
  data,
}: {
  sheet: HonorRecapSheetData;
  data: HonorRecapTemplateData;
}) {
  const showMonth = sheet.showMonthColumn ?? data.showMonthColumn;
  const periodLabel = sheet.periodLabel ?? data.periodLabel;

  return (
    <Page size="A4" style={styles.page}>
      <KopHeader
        schoolName={data.schoolName}
        kopHeaderLine={data.kopHeaderLine}
        schoolAddress={data.schoolAddress}
        schoolContact={data.schoolContact}
        schoolNpsn={data.schoolNpsn}
        schoolLogo={data.schoolLogo}
        regionalLogo={data.regionalLogo}
      />

      <Text style={styles.title}>{sheet.title}</Text>
      <Text style={styles.subtitle}>{periodLabel}</Text>

      <View style={styles.table}>
        <View style={styles.headerRow} fixed>
          <View style={[styles.cell, styles.cNo]}>
            <Text style={styles.headerText}>NO</Text>
          </View>
          <View style={[styles.cell, styles.cNama]}>
            <Text style={styles.headerText}>NAMA</Text>
          </View>
          {showMonth && (
            <View style={[styles.cell, styles.cBulan]}>
              <Text style={styles.headerText}>BULAN</Text>
            </View>
          )}
          <View style={[styles.cell, styles.cTanggal]}>
            <Text style={styles.headerText}>TANGGAL</Text>
          </View>
          <View style={[styles.cell, styles.cNominal]}>
            <Text style={styles.headerText}>JUMLAH</Text>
          </View>
          <View style={[styles.cell, styles.cTtd]}>
            <Text style={styles.headerText}>TANDA TANGAN</Text>
          </View>
        </View>

        {sheet.rows.map((row) => (
          <View style={styles.row} key={row.no} wrap={false}>
            <View style={[styles.cell, styles.cNo]}>
              <Text style={styles.textCenter}>{row.no}</Text>
            </View>
            <View style={[styles.cell, styles.cNama]}>
              <Text>{row.nama}</Text>
            </View>
            {showMonth && (
              <View style={[styles.cell, styles.cBulan]}>
                <Text style={styles.textCenter}>{row.bulan}</Text>
              </View>
            )}
            <View style={[styles.cell, styles.cTanggal]}>
              <Text style={styles.textCenter}>{row.tanggal}</Text>
            </View>
            <View style={[styles.cell, styles.cNominal]}>
              <Text style={styles.textRight}>{row.nominalFormatted}</Text>
            </View>
            {/* Left blank on purpose: signed by hand after printing. */}
            <View style={[styles.cell, styles.cTtd]} />
          </View>
        ))}

        <View style={styles.row}>
          <View
            style={[
              styles.cell,
              { flex: 1, borderRightWidth: 1 },
            ]}
          >
            <Text style={styles.totalLabel}>Jumlah</Text>
          </View>
          <View style={[styles.cell, styles.cNominal]}>
            <Text style={styles.totalValue}>{sheet.totalFormatted}</Text>
          </View>
          <View style={[styles.cell, styles.cTtd]} />
        </View>
      </View>

      <View style={styles.signatureBlock}>
        <Text>Mengetahui, {sheet.mengetahuiDate ?? data.mengetahuiDate}</Text>
        <Text>{data.kepalaJabatan}</Text>
        <View style={styles.signatureGap} />
        <Text style={styles.signatureName}>{data.kepalaName}</Text>
      </View>
    </Page>
  );
}

/** One page per honor category (tutor, administrasi, kebersihan, ...). */
export function HonorRecapDocumentTemplate(data: HonorRecapTemplateData) {
  return (
    <Document>
      {data.sheets.map((sheet, index) => (
        <Sheet key={`${sheet.title}-${sheet.periodLabel ?? index}`} sheet={sheet} data={data} />
      ))}
    </Document>
  );
}
