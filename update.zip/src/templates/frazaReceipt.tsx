import { Document, Page, StyleSheet, Text, View } from "@react-pdf/renderer";
import { configurePdfFonts } from "./pdfFonts";
import { formatReceiptRupiah, type FrazaReceiptData } from "@/lib/receipt/buildFrazaReceiptData";

configurePdfFonts();

const styles = StyleSheet.create({
  page: {
    paddingTop: 58,
    paddingHorizontal: 60,
    paddingBottom: 44,
    fontFamily: "Times-Roman",
  },
  grid: {
    flexDirection: "row",
    justifyContent: "space-between",
  },
  column: {
    width: 205,
  },
  receipt: {
    width: 205,
    minHeight: 270,
  },
  receiptWithGap: {
    marginBottom: 43,
  },
  brand: {
    fontFamily: "Times-Bold",
    fontSize: 17,
    marginBottom: 3,
  },
  businessLine: {
    fontFamily: "Helvetica",
    fontSize: 8.3,
    lineHeight: 1.25,
  },
  receiptTitle: {
    fontFamily: "Helvetica",
    fontSize: 8.3,
    lineHeight: 1.25,
    marginTop: 17,
    marginBottom: 15,
  },
  field: {
    flexDirection: "row",
    minHeight: 14,
    alignItems: "flex-start",
  },
  label: {
    width: 77,
    fontFamily: "Helvetica",
    fontSize: 8.3,
  },
  colon: {
    width: 10,
    fontFamily: "Helvetica",
    fontSize: 8.3,
  },
  value: {
    flex: 1,
    fontFamily: "Helvetica",
    fontSize: 8.3,
  },
  amount: {
    textDecoration: "underline",
  },
  total: {
    marginTop: 17,
  },
  thanks: {
    fontFamily: "Helvetica",
    fontSize: 8.3,
    marginTop: 18,
  },
});

function Field({ label, value, underline = false }: { label: string; value: string; underline?: boolean }) {
  return (
    <View style={styles.field}>
      <Text style={styles.label}>{label}</Text>
      <Text style={styles.colon}>:</Text>
      <Text style={underline ? [styles.value, styles.amount] : styles.value}>{value}</Text>
    </View>
  );
}

function Receipt({ data }: { data: FrazaReceiptData }) {
  return (
    <View style={styles.receipt}>
      <Text style={styles.brand}>Fraza Cell</Text>
      <Text style={styles.businessLine}>Green Walantaka Blok C15</Text>
      <Text style={styles.businessLine}>Kel. Pipitan-Walantaka</Text>
      <Text style={styles.businessLine}>Tlp. 081282114520</Text>

      <Text style={styles.receiptTitle}>{`STRUK PEMBAYARAN\n${data.paymentTitle}`}</Text>

      <Field label="Tanggal" value={data.transactionDate} />
      <Field label="ID Pel" value={data.customerId} />
      <Field label="Nama" value={data.schoolName} />
      <Field label="Tarif/Daya" value={data.tariff} />
      <Field label="Bln/Thn" value={data.billingPeriod} />
      <Field label="Rp. Tagihan" value={formatReceiptRupiah(data.billAmount)} underline />
      <Field label="Biaya Admin" value={formatReceiptRupiah(data.adminAmount)} underline />

      <View style={styles.total}>
        <Field label="TOTAL" value={formatReceiptRupiah(data.totalAmount)} />
      </View>
      <Text style={styles.thanks}>Terimakasih...</Text>
    </View>
  );
}

function ReceiptSlot({ data, withGap }: { data?: FrazaReceiptData; withGap: boolean }) {
  if (!data) {
    return <View style={withGap ? [styles.receipt, styles.receiptWithGap] : styles.receipt} />;
  }

  return withGap ? (
    <View style={styles.receiptWithGap}>
      <Receipt data={data} />
    </View>
  ) : (
    <Receipt data={data} />
  );
}

/** One printable A4 page with up to four distinct receipts, read down each column. */
function ReceiptPage({ data }: { data: FrazaReceiptData[] }) {
  const [topLeft, bottomLeft, topRight, bottomRight] = data;

  return (
    <Page size="A4" style={styles.page}>
      <View style={styles.grid}>
        <View style={styles.column}>
          <ReceiptSlot data={topLeft} withGap />
          <ReceiptSlot data={bottomLeft} withGap={false} />
        </View>
        <View style={styles.column}>
          <ReceiptSlot data={topRight} withGap />
          <ReceiptSlot data={bottomRight} withGap={false} />
        </View>
      </View>
    </Page>
  );
}

export function FrazaReceiptDocument({ data }: { data: FrazaReceiptData }) {
  return (
    <Document>
      <ReceiptPage data={[data]} />
    </Document>
  );
}

/** A semester PDF: every A4 page holds four different monthly service receipts. */
export function FrazaReceiptBundleDocument({ data }: { data: FrazaReceiptData[] }) {
  const pages = Array.from({ length: Math.ceil(data.length / 4) }, (_, index) =>
    data.slice(index * 4, index * 4 + 4)
  );

  return (
    <Document>
      {pages.map((pageData, index) => (
        <ReceiptPage key={`page-${index}`} data={pageData} />
      ))}
    </Document>
  );
}
