import { Font } from "@react-pdf/renderer";

/**
 * Disable automatic hyphenation.
 *
 * By default @react-pdf/renderer breaks long words across lines with a hyphen,
 * which turned recipient names into things like "GALIH WIGU-NAWATI" on the
 * honor sheets. On an official document a person's name must never be split,
 * so words wrap whole instead.
 */
let configured = false;

export function configurePdfFonts() {
  if (configured) return;
  Font.registerHyphenationCallback((word) => [word]);
  configured = true;
}
