import { Document, Page, View, Text, StyleSheet } from "@react-pdf/renderer";
import { configurePdfFonts } from "./pdfFonts";

configurePdfFonts();

export interface LampiranRowData {
  no: number;
  kegiatan: string;
  pekerjaan: string; // only carried on the first row, as in the reference sheet
  kodeRekeningBelanja: string; // "02. 03. 01."
  bulan: string; // "Juli"
  rincianBelanja: string;
  volume: string; // "2 rim"
  tarifHarga: string; // "65,000"
  jumlahBelanja: string; // "130,000"
  jumlahTarik: string; // "130,000"
  keterangan: string;
}

export interface LampiranTemplateData {
  namaPelaksana: string;
  programLabel: string;
  namaKegiatan: string;
  sumberDana: string;
  besarDana: string; // "6.726.500"
  waktuPelaksanaan: string; // "JULI 2026"
  bosPeriodLabel: string; // "BOSP JULI 2026"
  rows: LampiranRowData[];
  total: string; // "6,726,500.00"
  terbilang: string;
  kepalaName: string;
  bendaharaName: string;
}

const BORDER = "#000";
const FILL_HEADER = "#DCE6CB"; // pale green, as in the reference sheet
const FILL_TOTAL = "#F0DAF0"; // pale pink total band
const FILL_TERBILANG = "#DCEAF4"; // pale blue terbilang band

// Column widths in points. The page is A4 landscape (841.89pt) with 22pt
// side padding, so RINCIAN BELANJA absorbs whatever the fixed columns leave.
const W_NO = 24;
const W_KEGIATAN = 50;
const W_PEKERJAAN = 54;
const W_KODE = 64;
const W_BULAN = 42;
const W_VOLUME = 50;
const W_TARIF = 66;
const W_JUMLAH_BELANJA = 76;
const W_JUMLAH_TARIK = 72;
const W_KETERANGAN = 62; // wide enough for the un-wrapped "KETERANGAN" heading

const H_BAND_TOP = 13; // "BELANJA TUNAI"
const H_BAND_MID = 26; // "REKENING PENERIMA" / "JUMLAH BELANJA TUNAI"
const H_BAND_LEAF = 20; // "RINCIAN BELANJA" / "BOSP JULI 2026"

const styles = StyleSheet.create({
  page: {
    paddingTop: 26,
    paddingBottom: 26,
    paddingHorizontal: 22,
    fontSize: 8,
    fontFamily: "Times-Roman",
  },

  lampiranTitle: { fontSize: 9, marginBottom: 10 },
  metaBlock: { marginBottom: 10 },
  metaRow: { flexDirection: "row", marginBottom: 1 },
  metaLabel: { width: 150 },
  metaColon: { width: 8 },

  // Full grid: the table View draws the top/left edges and every cell draws
  // its own right/bottom edge, so adjacent borders never double up.
  table: {
    borderTopWidth: 1,
    borderLeftWidth: 1,
    borderColor: BORDER,
  },
  headerRow: { flexDirection: "row" },
  row: { flexDirection: "row", minHeight: 14 },

  cell: {
    borderRightWidth: 1,
    borderBottomWidth: 1,
    borderColor: BORDER,
    paddingVertical: 2,
    paddingHorizontal: 3,
    justifyContent: "center",
  },
  headerCell: {
    borderRightWidth: 1,
    borderBottomWidth: 1,
    borderColor: BORDER,
    backgroundColor: FILL_HEADER,
    paddingHorizontal: 2,
    paddingVertical: 1,
    justifyContent: "center",
    alignItems: "center",
  },
  headerText: {
    fontFamily: "Times-Bold",
    fontSize: 7,
    textAlign: "center",
  },
  // Vertical stack that owns its own right/bottom borders via its children.
  headerGroup: { flexDirection: "column" },

  body: { fontSize: 7 },
  textCenter: { textAlign: "center", fontSize: 7 },
  money: { flexDirection: "row", alignItems: "center" },
  moneyRp: { fontSize: 7 },
  moneyValue: { flex: 1, textAlign: "right", fontSize: 7 },

  totalText: { fontFamily: "Times-Bold", fontSize: 7, textAlign: "right" },
  terbilangLabel: { fontFamily: "Times-Bold", fontSize: 7, textAlign: "center" },
  terbilangValue: {
    fontFamily: "Times-BoldItalic",
    fontSize: 7,
    textAlign: "center",
  },

  signatureBlock: { flexDirection: "row", marginTop: 26 },
  signatureCol: { width: "50%" },
  signatureGap: { height: 46 },
  signatureName: { fontFamily: "Times-Bold" },
});

function MetaRow({ label, value }: { label: string; value: string }) {
  // The reference sheet prints the bare label when there is no value, so the
  // dangling colon that an empty field would leave behind is suppressed.
  if (value === "") {
    return (
      <View style={styles.metaRow}>
        <Text>{label}</Text>
      </View>
    );
  }
  return (
    <View style={styles.metaRow}>
      <Text style={styles.metaLabel}>{label}</Text>
      <Text style={styles.metaColon}>:</Text>
      <Text>{value}</Text>
    </View>
  );
}

function Money({ value }: { value: string }) {
  return (
    <View style={styles.money}>
      <Text style={styles.moneyRp}>Rp</Text>
      <Text style={styles.moneyValue}>{value}</Text>
    </View>
  );
}

/**
 * Three-band header:
 *
 *   NO | KEGIATAN | ... | BULAN |        BELANJA TUNAI                | KETERANGAN
 *                       |   REKENING PENERIMA    | JUMLAH  | JUMLAH   |
 *                       | RINCIAN | VOL | TARIF  | BELANJA | TARIK    |
 *
 * @react-pdf has no rowspan/colspan, so the spans are built out of nested
 * flex columns whose heights are pinned to add up to the same total.
 */
function TableHeader({ bosPeriodLabel }: { bosPeriodLabel: string }) {
  const fullHeight = H_BAND_TOP + H_BAND_MID + H_BAND_LEAF;

  return (
    <View style={styles.headerRow} fixed>
      {[
        { w: W_NO, text: "NO" },
        { w: W_KEGIATAN, text: "KEGIATAN" },
        { w: W_PEKERJAAN, text: "PEKERJAAN" },
        { w: W_KODE, text: "KODE REKENING BELANJA" },
        { w: W_BULAN, text: "BULAN" },
      ].map((col) => (
        <View
          key={col.text}
          style={[styles.headerCell, { width: col.w, height: fullHeight }]}
        >
          <Text style={styles.headerText}>{col.text}</Text>
        </View>
      ))}

      <View style={[styles.headerGroup, { flex: 1 }]}>
        <View style={[styles.headerCell, { height: H_BAND_TOP }]}>
          <Text style={styles.headerText}>BELANJA TUNAI</Text>
        </View>
        <View style={{ flexDirection: "row" }}>
          <View style={[styles.headerGroup, { flex: 1 }]}>
            <View style={[styles.headerCell, { height: H_BAND_MID }]}>
              <Text style={styles.headerText}>REKENING PENERIMA</Text>
            </View>
            <View style={{ flexDirection: "row" }}>
              <View style={[styles.headerCell, { flex: 1, height: H_BAND_LEAF }]}>
                <Text style={styles.headerText}>RINCIAN BELANJA</Text>
              </View>
              <View
                style={[styles.headerCell, { width: W_VOLUME, height: H_BAND_LEAF }]}
              >
                <Text style={styles.headerText}>VOLUME</Text>
              </View>
              <View
                style={[styles.headerCell, { width: W_TARIF, height: H_BAND_LEAF }]}
              >
                <Text style={styles.headerText}>TARIF HARGA</Text>
              </View>
            </View>
          </View>

          <View style={[styles.headerGroup, { width: W_JUMLAH_BELANJA }]}>
            <View style={[styles.headerCell, { height: H_BAND_MID }]}>
              <Text style={styles.headerText}>JUMLAH BELANJA TUNAI</Text>
            </View>
            <View style={[styles.headerCell, { height: H_BAND_LEAF }]}>
              <Text style={styles.headerText}>{bosPeriodLabel}</Text>
            </View>
          </View>

          <View
            style={[
              styles.headerCell,
              { width: W_JUMLAH_TARIK, height: H_BAND_MID + H_BAND_LEAF },
            ]}
          >
            <Text style={styles.headerText}>JUMLAH TARIK TUNAI</Text>
          </View>
        </View>
      </View>

      <View
        style={[styles.headerCell, { width: W_KETERANGAN, height: fullHeight }]}
      >
        <Text style={styles.headerText}>KETERANGAN</Text>
      </View>
    </View>
  );
}

export function LampiranDocument(data: LampiranTemplateData) {
  return (
    <Document>
      <Page size="A4" orientation="landscape" style={styles.page}>
        <Text style={styles.lampiranTitle}>Lampiran</Text>

        <View style={styles.metaBlock}>
          <MetaRow label="Nama Pelaksana Teknis Kegiatan" value={data.namaPelaksana} />
          <MetaRow label="Program" value={data.programLabel} />
          <MetaRow label="Nama Kegiatan" value={data.namaKegiatan} />
          <MetaRow label="Sumber Dana" value={data.sumberDana} />
          <MetaRow label="Besar Dana Yang di butuhkan" value={data.besarDana} />
          <MetaRow label="Waktu Pelaksanaan" value={data.waktuPelaksanaan} />
        </View>

        <View style={styles.table}>
          <TableHeader bosPeriodLabel={data.bosPeriodLabel} />

          {data.rows.map((row) => (
            <View style={styles.row} key={row.no} wrap={false}>
              <View style={[styles.cell, { width: W_NO }]}>
                <Text style={styles.textCenter}>{row.no}</Text>
              </View>
              <View style={[styles.cell, { width: W_KEGIATAN }]}>
                <Text style={styles.body}>{row.kegiatan}</Text>
              </View>
              <View style={[styles.cell, { width: W_PEKERJAAN }]}>
                <Text style={styles.body}>{row.pekerjaan}</Text>
              </View>
              <View style={[styles.cell, { width: W_KODE }]}>
                <Text style={styles.body}>{row.kodeRekeningBelanja}</Text>
              </View>
              <View style={[styles.cell, { width: W_BULAN }]}>
                <Text style={styles.body}>{row.bulan}</Text>
              </View>
              <View style={[styles.cell, { flex: 1 }]}>
                <Text style={styles.body}>{row.rincianBelanja}</Text>
              </View>
              <View style={[styles.cell, { width: W_VOLUME }]}>
                <Text style={styles.body}>{row.volume}</Text>
              </View>
              <View style={[styles.cell, { width: W_TARIF }]}>
                <Money value={row.tarifHarga} />
              </View>
              <View style={[styles.cell, { width: W_JUMLAH_BELANJA }]}>
                <Money value={row.jumlahBelanja} />
              </View>
              <View style={[styles.cell, { width: W_JUMLAH_TARIK }]}>
                <Money value={row.jumlahTarik} />
              </View>
              <View style={[styles.cell, { width: W_KETERANGAN }]}>
                <Text style={styles.body}>{row.keterangan}</Text>
              </View>
            </View>
          ))}

          {/* Total band: the descriptive columns stay blank, exactly as in the
              reference sheet, and only the two money columns carry a figure. */}
          <View style={[styles.row, { minHeight: 20 }]} wrap={false}>
            <View
              style={[
                styles.cell,
                {
                  flex: 1,
                  backgroundColor: FILL_TOTAL,
                },
              ]}
            />
            <View
              style={[
                styles.cell,
                { width: W_JUMLAH_BELANJA, backgroundColor: FILL_TOTAL },
              ]}
            >
              <Text style={styles.totalText}>{data.total}</Text>
            </View>
            <View
              style={[
                styles.cell,
                { width: W_JUMLAH_TARIK, backgroundColor: FILL_TOTAL },
              ]}
            >
              <Text style={styles.totalText}>{data.total}</Text>
            </View>
            <View
              style={[
                styles.cell,
                { width: W_KETERANGAN, backgroundColor: FILL_TOTAL },
              ]}
            >
              <Text style={styles.textCenter}>-</Text>
            </View>
          </View>

          <View style={[styles.row, { minHeight: 16 }]} wrap={false}>
            <View
              style={[styles.cell, { flex: 1, backgroundColor: FILL_TERBILANG }]}
            >
              <Text style={styles.terbilangLabel}>Terbilang</Text>
            </View>
            <View
              style={[
                styles.cell,
                {
                  width: W_JUMLAH_BELANJA + W_JUMLAH_TARIK + W_KETERANGAN,
                  backgroundColor: FILL_TERBILANG,
                },
              ]}
            >
              <Text style={styles.terbilangValue}>{data.terbilang}</Text>
            </View>
          </View>
        </View>

        <View style={styles.signatureBlock} wrap={false}>
          <View style={[styles.signatureCol, { paddingLeft: 110 }]}>
            <Text>KEPALA SEKOLAH</Text>
            <View style={styles.signatureGap} />
            <Text style={styles.signatureName}>{data.kepalaName}</Text>
            <Text>NIP.</Text>
          </View>
          <View style={[styles.signatureCol, { paddingLeft: 90 }]}>
            <Text>BENDAHARA BOSP</Text>
            <View style={styles.signatureGap} />
            <Text style={styles.signatureName}>{data.bendaharaName}</Text>
            <Text>NIP.</Text>
          </View>
        </View>
      </Page>
    </Document>
  );
}
