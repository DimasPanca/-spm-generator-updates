import { View, Text, Image, StyleSheet } from "@react-pdf/renderer";

export interface KopData {
  schoolName: string;
  kopHeaderLine: string | null; // small bold line above schoolName
  schoolAddress: string;
  schoolContact: string | null;
  schoolNpsn: string | null;
  // Raw image bytes, NOT a file path. @react-pdf/renderer's local-path
  // resolver runs paths through Node's legacy url.parse(), which misreads a
  // Windows drive letter (e.g. "J:") as a URL protocol and silently drops
  // the image. Passing a Buffer bypasses that broken path/URL resolution
  // entirely (see resolveImage in @react-pdf/image).
  schoolLogo: Buffer | null;
  regionalLogo: Buffer | null;
}

const LOGO_SIZE = 76;
// Both institution lines share one size: on an Indonesian kop surat the
// institution-type line ("SEKOLAH DASAR ISLAM TERPADU") and the institution
// name ("SDIT AL-HUSNA") are set as a matched pair -- same size, both bold,
// both uppercase -- so the header reads as a single unified block.
const INSTITUTION_FONT_SIZE = 14;

const styles = StyleSheet.create({
  kop: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 6,
  },
  logoSlot: {
    width: LOGO_SIZE,
    alignItems: "center",
    justifyContent: "center",
  },
  logo: {
    width: LOGO_SIZE,
    height: LOGO_SIZE,
    objectFit: "contain",
  },
  kopText: {
    flex: 1,
    alignItems: "center",
    paddingHorizontal: 8,
  },
  kopHeaderLine: {
    fontSize: INSTITUTION_FONT_SIZE,
    fontFamily: "Times-Bold",
    textAlign: "center",
    lineHeight: 1.2,
  },
  kopSchoolName: {
    fontSize: INSTITUTION_FONT_SIZE,
    fontFamily: "Times-Bold",
    textAlign: "center",
    lineHeight: 1.2,
  },
  kopLine: {
    fontSize: 9,
    textAlign: "center",
    lineHeight: 1.25,
    marginTop: 3,
  },
  divider: {
    borderBottomWidth: 2,
    borderBottomColor: "#000",
    marginBottom: 16,
  },
});

export function KopHeader(data: KopData) {
  return (
    <>
      <View style={styles.kop}>
        {/* Fixed-width slots on both sides, present whether or not an image
            is uploaded, so the centered text block is always truly centered
            on the page rather than skewed toward one side. */}
        <View style={styles.logoSlot}>
          {data.schoolLogo && (
            // eslint-disable-next-line jsx-a11y/alt-text
            <Image src={data.schoolLogo} style={styles.logo} />
          )}
        </View>

        <View style={styles.kopText}>
          {/* Uppercased at render time only -- the stored school name stays as
              typed so it still reads naturally in the letter body and the
              honor recap title. */}
          {data.kopHeaderLine && (
            <Text style={styles.kopHeaderLine}>
              {data.kopHeaderLine.toUpperCase()}
            </Text>
          )}
          <Text style={styles.kopSchoolName}>{data.schoolName.toUpperCase()}</Text>
          <Text style={styles.kopLine}>{data.schoolAddress}</Text>
          {(data.schoolNpsn || data.schoolContact) && (
            <Text style={styles.kopLine}>
              {[data.schoolNpsn ? `NPSN: ${data.schoolNpsn}` : null, data.schoolContact]
                .filter(Boolean)
                .join(" - ")}
            </Text>
          )}
        </View>

        <View style={styles.logoSlot}>
          {data.regionalLogo && (
            // eslint-disable-next-line jsx-a11y/alt-text
            <Image src={data.regionalLogo} style={styles.logo} />
          )}
        </View>
      </View>
      <View style={styles.divider} />
    </>
  );
}
