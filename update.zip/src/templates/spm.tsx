import { Document, Page, View, Text, StyleSheet } from "@react-pdf/renderer";
import { KopHeader } from "./Kop";
import { configurePdfFonts } from "./pdfFonts";

configurePdfFonts();

export interface SpmTemplateData {
  schoolName: string;
  kopHeaderLine: string | null; // small bold line above schoolName in the KOP
  schoolAddress: string;
  schoolContact: string | null;
  schoolNpsn: string | null;
  schoolLogo: Buffer | null;
  regionalLogo: Buffer | null;
  openingSentence: string; // {institutionName} already substituted
  atasDasarLine1: string;
  atasDasarLine2: string;
  kepalaJabatan: string;
  kepalaName: string;
  nomorSurat: string;
  amountFormatted: string; // "Rp. 200.000"
  terbilang: string;
  recipient: string;
  paymentFor: string;
  mengetahuiDate: string; // "30 Januari 2026"
}

const styles = StyleSheet.create({
  page: {
    paddingTop: 40,
    paddingBottom: 40,
    paddingHorizontal: 48,
    fontSize: 11,
    fontFamily: "Times-Roman",
    lineHeight: 1.4,
  },
  title: {
    fontSize: 12,
    fontFamily: "Times-Bold",
    textAlign: "center",
    textDecoration: "underline",
  },
  nomorSurat: {
    fontSize: 11,
    fontFamily: "Times-Bold",
    textAlign: "center",
    marginBottom: 16,
  },
  paragraph: {
    marginBottom: 14,
  },
  fieldRow: {
    flexDirection: "row",
    marginBottom: 2,
  },
  fieldLabel: {
    width: 130,
  },
  fieldColon: {
    width: 12,
  },
  fieldValue: {
    flex: 1,
  },
  terbilangRow: {
    flexDirection: "row",
    marginBottom: 10,
  },
  fieldsBlock: {
    marginBottom: 24,
  },
  atasDasarBlock: {
    marginBottom: 40,
  },
  atasDasarItem: {
    flexDirection: "row",
    marginBottom: 2,
  },
  atasDasarNumber: {
    width: 20,
  },
  signatureBlock: {
    alignSelf: "flex-end",
    width: 240,
    textAlign: "center",
  },
  signatureGap: {
    height: 60,
  },
  signatureName: {
    fontFamily: "Times-Bold",
    textDecoration: "underline",
  },
});

/** One SPM letter as a single A4 page. Exported separately so the combined
 *  "SPM Keseluruhan" document can stack many of these in one Document. */
export function SpmPage(data: SpmTemplateData) {
  return (
    <Page size="A4" style={styles.page}>
        <KopHeader
          schoolName={data.schoolName}
          kopHeaderLine={data.kopHeaderLine}
          schoolAddress={data.schoolAddress}
          schoolContact={data.schoolContact}
          schoolNpsn={data.schoolNpsn}
          schoolLogo={data.schoolLogo}
          regionalLogo={data.regionalLogo}
        />

        <Text style={styles.title}>SURAT PERINTAH MEMBAYAR</Text>
        <Text style={styles.nomorSurat}>{data.nomorSurat}</Text>

        <Text style={styles.paragraph}>
          {data.openingSentence}
          {"\n"}Memerintahkan Bendahara Untuk Melakukan Pembayaran
        </Text>

        <View style={styles.fieldsBlock}>
          <View style={styles.fieldRow}>
            <Text style={styles.fieldLabel}>Sejumlah</Text>
            <Text style={styles.fieldColon}>:</Text>
            <Text style={styles.fieldValue}>{data.amountFormatted}</Text>
          </View>
          <View style={styles.terbilangRow}>
            <Text style={styles.fieldLabel} />
            <Text style={styles.fieldColon} />
            <Text style={styles.fieldValue}>{data.terbilang}</Text>
          </View>
          <View style={styles.fieldRow}>
            <Text style={styles.fieldLabel}>Kepada</Text>
            <Text style={styles.fieldColon}>:</Text>
            <Text style={styles.fieldValue}>{data.recipient}</Text>
          </View>
          <View style={styles.fieldRow}>
            <Text style={styles.fieldLabel}>Untuk Pembayaran</Text>
            <Text style={styles.fieldColon}>:</Text>
            <Text style={styles.fieldValue}>{data.paymentFor}</Text>
          </View>
        </View>

        <View style={styles.atasDasarBlock}>
          <View style={styles.fieldRow}>
            <Text style={styles.fieldLabel}>Atas Dasar</Text>
            <Text style={styles.fieldColon} />
            <Text style={styles.fieldValue} />
          </View>
          <View style={styles.atasDasarItem}>
            <Text style={styles.fieldLabel} />
            <Text style={styles.atasDasarNumber}>1.</Text>
            <Text style={styles.fieldValue}>{data.atasDasarLine1}</Text>
          </View>
          <View style={styles.atasDasarItem}>
            <Text style={styles.fieldLabel} />
            <Text style={styles.atasDasarNumber}>2.</Text>
            <Text style={styles.fieldValue}>{data.atasDasarLine2}</Text>
          </View>
        </View>

        <View style={styles.signatureBlock}>
          <Text>Mengetahui, {data.mengetahuiDate}</Text>
          <Text>{data.kepalaJabatan}</Text>
          <View style={styles.signatureGap} />
          <Text style={styles.signatureName}>{data.kepalaName}</Text>
        </View>
    </Page>
  );
}

export function SpmDocument(data: SpmTemplateData) {
  return (
    <Document>
      <SpmPage {...data} />
    </Document>
  );
}

/** "SPM Keseluruhan": every confirmed SPM of the month in one printable file,
 *  one letter per page, ordered by BPU number by the caller. */
export function CombinedSpmDocument({ pages }: { pages: SpmTemplateData[] }) {
  return (
    <Document>
      {pages.map((data) => (
        <SpmPage key={data.nomorSurat} {...data} />
      ))}
    </Document>
  );
}
