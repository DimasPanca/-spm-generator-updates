import { Document, Page, StyleSheet, Text, View } from "@react-pdf/renderer";
import {
  formatStudentBirth,
  studentListTitle,
  type StudentListDocumentInput,
  type StudentListRow,
} from "@/lib/student-lists/report";
import { configurePdfFonts } from "./pdfFonts";

configurePdfFonts();

const BORDER = "#000000";
const FINAL_PAGE_MAX_ROWS = 16;
const OTHER_PAGE_MAX_ROWS = 21;

const styles = StyleSheet.create({
  page: {
    paddingTop: 18,
    paddingBottom: 22,
    paddingHorizontal: 18,
    fontFamily: "Helvetica",
    fontSize: 7,
  },
  title: {
    textAlign: "center",
    fontFamily: "Helvetica-Bold",
    fontSize: 14,
    marginBottom: 4,
  },
  schoolName: {
    textAlign: "center",
    fontFamily: "Helvetica-Bold",
    fontSize: 12,
    marginBottom: 4,
  },
  year: {
    textAlign: "center",
    fontFamily: "Helvetica-Bold",
    fontSize: 10,
    marginBottom: 12,
  },
  table: {
    borderTopWidth: 0.75,
    borderLeftWidth: 0.75,
    borderColor: BORDER,
  },
  row: {
    flexDirection: "row",
    minHeight: 20,
    alignItems: "stretch",
  },
  headerRow: {
    flexDirection: "row",
    minHeight: 30,
    alignItems: "stretch",
    backgroundColor: "#EFEFEF",
  },
  cell: {
    borderRightWidth: 0.75,
    borderBottomWidth: 0.75,
    borderColor: BORDER,
    paddingVertical: 3,
    paddingHorizontal: 3,
    justifyContent: "center",
  },
  headerText: {
    fontFamily: "Helvetica-Bold",
    fontSize: 7,
    textAlign: "center",
  },
  center: { textAlign: "center" },
  cNo: { width: 24 },
  cName: { width: 135 },
  cNik: { width: 86 },
  cGender: { width: 24 },
  cClass: { width: 35 },
  cBirth: { width: 112 },
  cParent: { width: 102 },
  cAddress: { width: 200 },
  cNote: { width: 84 },
  signature: {
    alignSelf: "flex-end",
    width: 260,
    marginTop: 14,
    textAlign: "center",
    fontSize: 8,
  },
  signatureGap: { height: 38 },
  signatureName: {
    fontFamily: "Helvetica-Bold",
    textDecoration: "underline",
  },
  pageNumber: {
    position: "absolute",
    right: 18,
    bottom: 8,
    fontSize: 6.5,
    color: "#555555",
  },
});

interface StudentPageChunk {
  startIndex: number;
  students: StudentListRow[];
}

function paginateStudents(students: StudentListRow[]): StudentPageChunk[] {
  if (students.length <= FINAL_PAGE_MAX_ROWS) {
    return [{ startIndex: 0, students }];
  }

  const pageCount =
    1 +
    Math.ceil(
      (students.length - FINAL_PAGE_MAX_ROWS) / OTHER_PAGE_MAX_ROWS
    );
  const sizes = Array.from({ length: pageCount }, (_, index) =>
    Math.floor(students.length / pageCount) +
    (index < students.length % pageCount ? 1 : 0)
  );

  while (sizes[sizes.length - 1] > FINAL_PAGE_MAX_ROWS) {
    const receiver = sizes.findIndex(
      (size, index) => index < sizes.length - 1 && size < OTHER_PAGE_MAX_ROWS
    );
    if (receiver === -1) break;
    sizes[receiver]++;
    sizes[sizes.length - 1]--;
  }

  let startIndex = 0;
  return sizes.map((size) => {
    const chunk = {
      startIndex,
      students: students.slice(startIndex, startIndex + size),
    };
    startIndex += size;
    return chunk;
  });
}

function HeaderRow() {
  return (
    <View style={styles.headerRow} wrap={false}>
      <View style={[styles.cell, styles.cNo]}><Text style={styles.headerText}>NO</Text></View>
      <View style={[styles.cell, styles.cName]}><Text style={styles.headerText}>NAMA</Text></View>
      <View style={[styles.cell, styles.cNik]}><Text style={styles.headerText}>NIK</Text></View>
      <View style={[styles.cell, styles.cGender]}><Text style={styles.headerText}>JK</Text></View>
      <View style={[styles.cell, styles.cClass]}><Text style={styles.headerText}>KELAS</Text></View>
      <View style={[styles.cell, styles.cBirth]}><Text style={styles.headerText}>TEMPAT, TANGGAL LAHIR</Text></View>
      <View style={[styles.cell, styles.cParent]}><Text style={styles.headerText}>NAMA ORANG TUA</Text></View>
      <View style={[styles.cell, styles.cAddress]}><Text style={styles.headerText}>ALAMAT</Text></View>
      <View style={[styles.cell, styles.cNote]}><Text style={styles.headerText}>KETERANGAN</Text></View>
    </View>
  );
}

function StudentRowView({
  student,
  number,
  keterangan,
}: {
  student: StudentListRow;
  number: number;
  keterangan: string;
}) {
  return (
    <View style={styles.row} wrap={false}>
      <View style={[styles.cell, styles.cNo]}><Text style={styles.center}>{number}</Text></View>
      <View style={[styles.cell, styles.cName]}><Text>{student.name}</Text></View>
      <View style={[styles.cell, styles.cNik]}><Text style={styles.center}>{student.nik ?? ""}</Text></View>
      <View style={[styles.cell, styles.cGender]}><Text style={styles.center}>{student.gender ?? ""}</Text></View>
      <View style={[styles.cell, styles.cClass]}><Text style={styles.center}>{student.className ?? ""}</Text></View>
      <View style={[styles.cell, styles.cBirth]}><Text>{formatStudentBirth(student.birthPlace, student.birthDate)}</Text></View>
      <View style={[styles.cell, styles.cParent]}><Text>{student.parentName ?? ""}</Text></View>
      <View style={[styles.cell, styles.cAddress]}><Text>{student.address ?? ""}</Text></View>
      <View style={[styles.cell, styles.cNote]}><Text>{keterangan}</Text></View>
    </View>
  );
}

export function StudentListDocumentTemplate(input: StudentListDocumentInput) {
  const chunks = paginateStudents(input.students);
  const title = studentListTitle(input.kind);

  return (
    <Document title={`${title} - ${input.schoolName}`} author="SPM Generator">
      {chunks.map((chunk, pageIndex) => {
        const isLastPage = pageIndex === chunks.length - 1;
        return (
          <Page
            key={`${title}-${pageIndex}`}
            size="A4"
            orientation="landscape"
            style={styles.page}
          >
            <Text style={styles.title}>{title}</Text>
            <Text style={styles.schoolName}>{input.schoolName.toUpperCase()}</Text>
            <Text style={styles.year}>TAHUN {input.year}</Text>

            <View style={styles.table}>
              <HeaderRow />
              {chunk.students.map((student, index) => (
                <StudentRowView
                  key={`${chunk.startIndex + index}-${student.name}`}
                  student={student}
                  number={chunk.startIndex + index + 1}
                  keterangan={input.keterangan}
                />
              ))}
            </View>

            {isLastPage && (
              <View style={styles.signature} wrap={false}>
                <Text>Mengetahui,</Text>
                <Text>{input.kepalaJabatan || "Kepala Sekolah"}</Text>
                <View style={styles.signatureGap} />
                <Text style={styles.signatureName}>{input.kepalaName}</Text>
              </View>
            )}

            <Text
              style={styles.pageNumber}
              fixed
              render={({ pageNumber, totalPages }) =>
                `Halaman ${pageNumber} dari ${totalPages}`
              }
            />
          </Page>
        );
      })}
    </Document>
  );
}

