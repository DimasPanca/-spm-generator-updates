
/**
 * Client
**/

import * as runtime from './runtime/client.js';
import $Types = runtime.Types // general types
import $Public = runtime.Types.Public
import $Utils = runtime.Types.Utils
import $Extensions = runtime.Types.Extensions
import $Result = runtime.Types.Result

export type PrismaPromise<T> = $Public.PrismaPromise<T>


/**
 * Model School
 * 
 */
export type School = $Result.DefaultSelection<Prisma.$SchoolPayload>
/**
 * Model VendorRule
 * 
 */
export type VendorRule = $Result.DefaultSelection<Prisma.$VendorRulePayload>
/**
 * Model BKUImport
 * 
 */
export type BKUImport = $Result.DefaultSelection<Prisma.$BKUImportPayload>
/**
 * Model BKURow
 * 
 */
export type BKURow = $Result.DefaultSelection<Prisma.$BKURowPayload>
/**
 * Model BPUGroup
 * 
 */
export type BPUGroup = $Result.DefaultSelection<Prisma.$BPUGroupPayload>
/**
 * Model SPMDocument
 * 
 */
export type SPMDocument = $Result.DefaultSelection<Prisma.$SPMDocumentPayload>
/**
 * Model RkasImport
 * 
 */
export type RkasImport = $Result.DefaultSelection<Prisma.$RkasImportPayload>
/**
 * Model RkasProgram
 * 
 */
export type RkasProgram = $Result.DefaultSelection<Prisma.$RkasProgramPayload>
/**
 * Model RkasItem
 * 
 */
export type RkasItem = $Result.DefaultSelection<Prisma.$RkasItemPayload>
/**
 * Model InstrumenBosp
 * 
 */
export type InstrumenBosp = $Result.DefaultSelection<Prisma.$InstrumenBospPayload>

/**
 * Enums
 */
export namespace $Enums {
  export const VendorRuleFormatType: {
  STANDARD: 'STANDARD',
  NAME_FROM_URAIAN: 'NAME_FROM_URAIAN'
};

export type VendorRuleFormatType = (typeof VendorRuleFormatType)[keyof typeof VendorRuleFormatType]


export const BKUImportStatus: {
  PARSED: 'PARSED',
  REVIEWED: 'REVIEWED',
  FINALIZED: 'FINALIZED'
};

export type BKUImportStatus = (typeof BKUImportStatus)[keyof typeof BKUImportStatus]


export const BPUGroupStatus: {
  SUGGESTED: 'SUGGESTED',
  CONFIRMED: 'CONFIRMED'
};

export type BPUGroupStatus = (typeof BPUGroupStatus)[keyof typeof BPUGroupStatus]

}

export type VendorRuleFormatType = $Enums.VendorRuleFormatType

export const VendorRuleFormatType: typeof $Enums.VendorRuleFormatType

export type BKUImportStatus = $Enums.BKUImportStatus

export const BKUImportStatus: typeof $Enums.BKUImportStatus

export type BPUGroupStatus = $Enums.BPUGroupStatus

export const BPUGroupStatus: typeof $Enums.BPUGroupStatus

/**
 * ##  Prisma Client ʲˢ
 *
 * Type-safe database client for TypeScript & Node.js
 * @example
 * ```
 * const prisma = new PrismaClient({
 *   adapter: new PrismaPg({ connectionString: process.env.DATABASE_URL })
 * })
 * // Fetch zero or more Schools
 * const schools = await prisma.school.findMany()
 * ```
 *
 *
 * Read more in our [docs](https://pris.ly/d/client).
 */
export class PrismaClient<
  ClientOptions extends Prisma.PrismaClientOptions = Prisma.PrismaClientOptions,
  const U = 'log' extends keyof ClientOptions ? ClientOptions['log'] extends Array<Prisma.LogLevel | Prisma.LogDefinition> ? Prisma.GetEvents<ClientOptions['log']> : never : never,
  ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs
> {
  [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['other'] }

    /**
   * ##  Prisma Client ʲˢ
   *
   * Type-safe database client for TypeScript & Node.js
   * @example
   * ```
   * const prisma = new PrismaClient({
   *   adapter: new PrismaPg({ connectionString: process.env.DATABASE_URL })
   * })
   * // Fetch zero or more Schools
   * const schools = await prisma.school.findMany()
   * ```
   *
   *
   * Read more in our [docs](https://pris.ly/d/client).
   */

  constructor(optionsArg ?: Prisma.Subset<ClientOptions, Prisma.PrismaClientOptions>);
  $on<V extends U>(eventType: V, callback: (event: V extends 'query' ? Prisma.QueryEvent : Prisma.LogEvent) => void): PrismaClient;

  /**
   * Connect with the database
   */
  $connect(): $Utils.JsPromise<void>;

  /**
   * Disconnect from the database
   */
  $disconnect(): $Utils.JsPromise<void>;

/**
   * Executes a prepared raw query and returns the number of affected rows.
   * @example
   * ```
   * const result = await prisma.$executeRaw`UPDATE User SET cool = ${true} WHERE email = ${'user@email.com'};`
   * ```
   *
   * Read more in our [docs](https://pris.ly/d/raw-queries).
   */
  $executeRaw<T = unknown>(query: TemplateStringsArray | Prisma.Sql, ...values: any[]): Prisma.PrismaPromise<number>;

  /**
   * Executes a raw query and returns the number of affected rows.
   * Susceptible to SQL injections, see documentation.
   * @example
   * ```
   * const result = await prisma.$executeRawUnsafe('UPDATE User SET cool = $1 WHERE email = $2 ;', true, 'user@email.com')
   * ```
   *
   * Read more in our [docs](https://pris.ly/d/raw-queries).
   */
  $executeRawUnsafe<T = unknown>(query: string, ...values: any[]): Prisma.PrismaPromise<number>;

  /**
   * Performs a prepared raw query and returns the `SELECT` data.
   * @example
   * ```
   * const result = await prisma.$queryRaw`SELECT * FROM User WHERE id = ${1} OR email = ${'user@email.com'};`
   * ```
   *
   * Read more in our [docs](https://pris.ly/d/raw-queries).
   */
  $queryRaw<T = unknown>(query: TemplateStringsArray | Prisma.Sql, ...values: any[]): Prisma.PrismaPromise<T>;

  /**
   * Performs a raw query and returns the `SELECT` data.
   * Susceptible to SQL injections, see documentation.
   * @example
   * ```
   * const result = await prisma.$queryRawUnsafe('SELECT * FROM User WHERE id = $1 OR email = $2;', 1, 'user@email.com')
   * ```
   *
   * Read more in our [docs](https://pris.ly/d/raw-queries).
   */
  $queryRawUnsafe<T = unknown>(query: string, ...values: any[]): Prisma.PrismaPromise<T>;


  /**
   * Allows the running of a sequence of read/write operations that are guaranteed to either succeed or fail as a whole.
   * @example
   * ```
   * const [george, bob, alice] = await prisma.$transaction([
   *   prisma.user.create({ data: { name: 'George' } }),
   *   prisma.user.create({ data: { name: 'Bob' } }),
   *   prisma.user.create({ data: { name: 'Alice' } }),
   * ])
   * ```
   * 
   * Read more in our [docs](https://www.prisma.io/docs/orm/prisma-client/queries/transactions).
   */
  $transaction<P extends Prisma.PrismaPromise<any>[]>(arg: [...P], options?: { maxWait?: number, timeout?: number, isolationLevel?: Prisma.TransactionIsolationLevel }): $Utils.JsPromise<runtime.Types.Utils.UnwrapTuple<P>>

  $transaction<R>(fn: (prisma: Omit<PrismaClient, runtime.ITXClientDenyList>) => $Utils.JsPromise<R>, options?: { maxWait?: number, timeout?: number, isolationLevel?: Prisma.TransactionIsolationLevel }): $Utils.JsPromise<R>

  $extends: $Extensions.ExtendsHook<"extends", Prisma.TypeMapCb<ClientOptions>, ExtArgs, $Utils.Call<Prisma.TypeMapCb<ClientOptions>, {
    extArgs: ExtArgs
  }>>

      /**
   * `prisma.school`: Exposes CRUD operations for the **School** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Schools
    * const schools = await prisma.school.findMany()
    * ```
    */
  get school(): Prisma.SchoolDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.vendorRule`: Exposes CRUD operations for the **VendorRule** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more VendorRules
    * const vendorRules = await prisma.vendorRule.findMany()
    * ```
    */
  get vendorRule(): Prisma.VendorRuleDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.bKUImport`: Exposes CRUD operations for the **BKUImport** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more BKUImports
    * const bKUImports = await prisma.bKUImport.findMany()
    * ```
    */
  get bKUImport(): Prisma.BKUImportDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.bKURow`: Exposes CRUD operations for the **BKURow** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more BKURows
    * const bKURows = await prisma.bKURow.findMany()
    * ```
    */
  get bKURow(): Prisma.BKURowDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.bPUGroup`: Exposes CRUD operations for the **BPUGroup** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more BPUGroups
    * const bPUGroups = await prisma.bPUGroup.findMany()
    * ```
    */
  get bPUGroup(): Prisma.BPUGroupDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.sPMDocument`: Exposes CRUD operations for the **SPMDocument** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more SPMDocuments
    * const sPMDocuments = await prisma.sPMDocument.findMany()
    * ```
    */
  get sPMDocument(): Prisma.SPMDocumentDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.rkasImport`: Exposes CRUD operations for the **RkasImport** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more RkasImports
    * const rkasImports = await prisma.rkasImport.findMany()
    * ```
    */
  get rkasImport(): Prisma.RkasImportDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.rkasProgram`: Exposes CRUD operations for the **RkasProgram** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more RkasPrograms
    * const rkasPrograms = await prisma.rkasProgram.findMany()
    * ```
    */
  get rkasProgram(): Prisma.RkasProgramDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.rkasItem`: Exposes CRUD operations for the **RkasItem** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more RkasItems
    * const rkasItems = await prisma.rkasItem.findMany()
    * ```
    */
  get rkasItem(): Prisma.RkasItemDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.instrumenBosp`: Exposes CRUD operations for the **InstrumenBosp** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more InstrumenBosps
    * const instrumenBosps = await prisma.instrumenBosp.findMany()
    * ```
    */
  get instrumenBosp(): Prisma.InstrumenBospDelegate<ExtArgs, ClientOptions>;
}

export namespace Prisma {
  export import DMMF = runtime.DMMF

  export type PrismaPromise<T> = $Public.PrismaPromise<T>

  /**
   * Validator
   */
  export import validator = runtime.Public.validator

  /**
   * Prisma Errors
   */
  export import PrismaClientKnownRequestError = runtime.PrismaClientKnownRequestError
  export import PrismaClientUnknownRequestError = runtime.PrismaClientUnknownRequestError
  export import PrismaClientRustPanicError = runtime.PrismaClientRustPanicError
  export import PrismaClientInitializationError = runtime.PrismaClientInitializationError
  export import PrismaClientValidationError = runtime.PrismaClientValidationError

  /**
   * Re-export of sql-template-tag
   */
  export import sql = runtime.sqltag
  export import empty = runtime.empty
  export import join = runtime.join
  export import raw = runtime.raw
  export import Sql = runtime.Sql



  /**
   * Decimal.js
   */
  export import Decimal = runtime.Decimal

  export type DecimalJsLike = runtime.DecimalJsLike

  /**
  * Extensions
  */
  export import Extension = $Extensions.UserArgs
  export import getExtensionContext = runtime.Extensions.getExtensionContext
  export import Args = $Public.Args
  export import Payload = $Public.Payload
  export import Result = $Public.Result
  export import Exact = $Public.Exact

  /**
   * Prisma Client JS version: 7.8.0
   * Query Engine version: 3c6e192761c0362d496ed980de936e2f3cebcd3a
   */
  export type PrismaVersion = {
    client: string
    engine: string
  }

  export const prismaVersion: PrismaVersion

  /**
   * Utility Types
   */


  export import Bytes = runtime.Bytes
  export import JsonObject = runtime.JsonObject
  export import JsonArray = runtime.JsonArray
  export import JsonValue = runtime.JsonValue
  export import InputJsonObject = runtime.InputJsonObject
  export import InputJsonArray = runtime.InputJsonArray
  export import InputJsonValue = runtime.InputJsonValue

  /**
   * Types of the values used to represent different kinds of `null` values when working with JSON fields.
   *
   * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
   */
  namespace NullTypes {
    /**
    * Type of `Prisma.DbNull`.
    *
    * You cannot use other instances of this class. Please use the `Prisma.DbNull` value.
    *
    * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
    */
    class DbNull {
      private DbNull: never
      private constructor()
    }

    /**
    * Type of `Prisma.JsonNull`.
    *
    * You cannot use other instances of this class. Please use the `Prisma.JsonNull` value.
    *
    * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
    */
    class JsonNull {
      private JsonNull: never
      private constructor()
    }

    /**
    * Type of `Prisma.AnyNull`.
    *
    * You cannot use other instances of this class. Please use the `Prisma.AnyNull` value.
    *
    * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
    */
    class AnyNull {
      private AnyNull: never
      private constructor()
    }
  }

  /**
   * Helper for filtering JSON entries that have `null` on the database (empty on the db)
   *
   * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
   */
  export const DbNull: NullTypes.DbNull

  /**
   * Helper for filtering JSON entries that have JSON `null` values (not empty on the db)
   *
   * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
   */
  export const JsonNull: NullTypes.JsonNull

  /**
   * Helper for filtering JSON entries that are `Prisma.DbNull` or `Prisma.JsonNull`
   *
   * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
   */
  export const AnyNull: NullTypes.AnyNull

  type SelectAndInclude = {
    select: any
    include: any
  }

  type SelectAndOmit = {
    select: any
    omit: any
  }

  /**
   * Get the type of the value, that the Promise holds.
   */
  export type PromiseType<T extends PromiseLike<any>> = T extends PromiseLike<infer U> ? U : T;

  /**
   * Get the return type of a function which returns a Promise.
   */
  export type PromiseReturnType<T extends (...args: any) => $Utils.JsPromise<any>> = PromiseType<ReturnType<T>>

  /**
   * From T, pick a set of properties whose keys are in the union K
   */
  type Prisma__Pick<T, K extends keyof T> = {
      [P in K]: T[P];
  };


  export type Enumerable<T> = T | Array<T>;

  export type RequiredKeys<T> = {
    [K in keyof T]-?: {} extends Prisma__Pick<T, K> ? never : K
  }[keyof T]

  export type TruthyKeys<T> = keyof {
    [K in keyof T as T[K] extends false | undefined | null ? never : K]: K
  }

  export type TrueKeys<T> = TruthyKeys<Prisma__Pick<T, RequiredKeys<T>>>

  /**
   * Subset
   * @desc From `T` pick properties that exist in `U`. Simple version of Intersection
   */
  export type Subset<T, U> = {
    [key in keyof T]: key extends keyof U ? T[key] : never;
  };

  /**
   * SelectSubset
   * @desc From `T` pick properties that exist in `U`. Simple version of Intersection.
   * Additionally, it validates, if both select and include are present. If the case, it errors.
   */
  export type SelectSubset<T, U> = {
    [key in keyof T]: key extends keyof U ? T[key] : never
  } &
    (T extends SelectAndInclude
      ? 'Please either choose `select` or `include`.'
      : T extends SelectAndOmit
        ? 'Please either choose `select` or `omit`.'
        : {})

  /**
   * Subset + Intersection
   * @desc From `T` pick properties that exist in `U` and intersect `K`
   */
  export type SubsetIntersection<T, U, K> = {
    [key in keyof T]: key extends keyof U ? T[key] : never
  } &
    K

  type Without<T, U> = { [P in Exclude<keyof T, keyof U>]?: never };

  /**
   * XOR is needed to have a real mutually exclusive union type
   * https://stackoverflow.com/questions/42123407/does-typescript-support-mutually-exclusive-types
   */
  type XOR<T, U> =
    T extends object ?
    U extends object ?
      (Without<T, U> & U) | (Without<U, T> & T)
    : U : T


  /**
   * Is T a Record?
   */
  type IsObject<T extends any> = T extends Array<any>
  ? False
  : T extends Date
  ? False
  : T extends Uint8Array
  ? False
  : T extends BigInt
  ? False
  : T extends object
  ? True
  : False


  /**
   * If it's T[], return T
   */
  export type UnEnumerate<T extends unknown> = T extends Array<infer U> ? U : T

  /**
   * From ts-toolbelt
   */

  type __Either<O extends object, K extends Key> = Omit<O, K> &
    {
      // Merge all but K
      [P in K]: Prisma__Pick<O, P & keyof O> // With K possibilities
    }[K]

  type EitherStrict<O extends object, K extends Key> = Strict<__Either<O, K>>

  type EitherLoose<O extends object, K extends Key> = ComputeRaw<__Either<O, K>>

  type _Either<
    O extends object,
    K extends Key,
    strict extends Boolean
  > = {
    1: EitherStrict<O, K>
    0: EitherLoose<O, K>
  }[strict]

  type Either<
    O extends object,
    K extends Key,
    strict extends Boolean = 1
  > = O extends unknown ? _Either<O, K, strict> : never

  export type Union = any

  type PatchUndefined<O extends object, O1 extends object> = {
    [K in keyof O]: O[K] extends undefined ? At<O1, K> : O[K]
  } & {}

  /** Helper Types for "Merge" **/
  export type IntersectOf<U extends Union> = (
    U extends unknown ? (k: U) => void : never
  ) extends (k: infer I) => void
    ? I
    : never

  export type Overwrite<O extends object, O1 extends object> = {
      [K in keyof O]: K extends keyof O1 ? O1[K] : O[K];
  } & {};

  type _Merge<U extends object> = IntersectOf<Overwrite<U, {
      [K in keyof U]-?: At<U, K>;
  }>>;

  type Key = string | number | symbol;
  type AtBasic<O extends object, K extends Key> = K extends keyof O ? O[K] : never;
  type AtStrict<O extends object, K extends Key> = O[K & keyof O];
  type AtLoose<O extends object, K extends Key> = O extends unknown ? AtStrict<O, K> : never;
  export type At<O extends object, K extends Key, strict extends Boolean = 1> = {
      1: AtStrict<O, K>;
      0: AtLoose<O, K>;
  }[strict];

  export type ComputeRaw<A extends any> = A extends Function ? A : {
    [K in keyof A]: A[K];
  } & {};

  export type OptionalFlat<O> = {
    [K in keyof O]?: O[K];
  } & {};

  type _Record<K extends keyof any, T> = {
    [P in K]: T;
  };

  // cause typescript not to expand types and preserve names
  type NoExpand<T> = T extends unknown ? T : never;

  // this type assumes the passed object is entirely optional
  type AtLeast<O extends object, K extends string> = NoExpand<
    O extends unknown
    ? | (K extends keyof O ? { [P in K]: O[P] } & O : O)
      | {[P in keyof O as P extends K ? P : never]-?: O[P]} & O
    : never>;

  type _Strict<U, _U = U> = U extends unknown ? U & OptionalFlat<_Record<Exclude<Keys<_U>, keyof U>, never>> : never;

  export type Strict<U extends object> = ComputeRaw<_Strict<U>>;
  /** End Helper Types for "Merge" **/

  export type Merge<U extends object> = ComputeRaw<_Merge<Strict<U>>>;

  /**
  A [[Boolean]]
  */
  export type Boolean = True | False

  // /**
  // 1
  // */
  export type True = 1

  /**
  0
  */
  export type False = 0

  export type Not<B extends Boolean> = {
    0: 1
    1: 0
  }[B]

  export type Extends<A1 extends any, A2 extends any> = [A1] extends [never]
    ? 0 // anything `never` is false
    : A1 extends A2
    ? 1
    : 0

  export type Has<U extends Union, U1 extends Union> = Not<
    Extends<Exclude<U1, U>, U1>
  >

  export type Or<B1 extends Boolean, B2 extends Boolean> = {
    0: {
      0: 0
      1: 1
    }
    1: {
      0: 1
      1: 1
    }
  }[B1][B2]

  export type Keys<U extends Union> = U extends unknown ? keyof U : never

  type Cast<A, B> = A extends B ? A : B;

  export const type: unique symbol;



  /**
   * Used by group by
   */

  export type GetScalarType<T, O> = O extends object ? {
    [P in keyof T]: P extends keyof O
      ? O[P]
      : never
  } : never

  type FieldPaths<
    T,
    U = Omit<T, '_avg' | '_sum' | '_count' | '_min' | '_max'>
  > = IsObject<T> extends True ? U : T

  type GetHavingFields<T> = {
    [K in keyof T]: Or<
      Or<Extends<'OR', K>, Extends<'AND', K>>,
      Extends<'NOT', K>
    > extends True
      ? // infer is only needed to not hit TS limit
        // based on the brilliant idea of Pierre-Antoine Mills
        // https://github.com/microsoft/TypeScript/issues/30188#issuecomment-478938437
        T[K] extends infer TK
        ? GetHavingFields<UnEnumerate<TK> extends object ? Merge<UnEnumerate<TK>> : never>
        : never
      : {} extends FieldPaths<T[K]>
      ? never
      : K
  }[keyof T]

  /**
   * Convert tuple to union
   */
  type _TupleToUnion<T> = T extends (infer E)[] ? E : never
  type TupleToUnion<K extends readonly any[]> = _TupleToUnion<K>
  type MaybeTupleToUnion<T> = T extends any[] ? TupleToUnion<T> : T

  /**
   * Like `Pick`, but additionally can also accept an array of keys
   */
  type PickEnumerable<T, K extends Enumerable<keyof T> | keyof T> = Prisma__Pick<T, MaybeTupleToUnion<K>>

  /**
   * Exclude all keys with underscores
   */
  type ExcludeUnderscoreKeys<T extends string> = T extends `_${string}` ? never : T


  export type FieldRef<Model, FieldType> = runtime.FieldRef<Model, FieldType>

  type FieldRefInputType<Model, FieldType> = Model extends never ? never : FieldRef<Model, FieldType>


  export const ModelName: {
    School: 'School',
    VendorRule: 'VendorRule',
    BKUImport: 'BKUImport',
    BKURow: 'BKURow',
    BPUGroup: 'BPUGroup',
    SPMDocument: 'SPMDocument',
    RkasImport: 'RkasImport',
    RkasProgram: 'RkasProgram',
    RkasItem: 'RkasItem',
    InstrumenBosp: 'InstrumenBosp'
  };

  export type ModelName = (typeof ModelName)[keyof typeof ModelName]



  interface TypeMapCb<ClientOptions = {}> extends $Utils.Fn<{extArgs: $Extensions.InternalArgs }, $Utils.Record<string, any>> {
    returns: Prisma.TypeMap<this['params']['extArgs'], ClientOptions extends { omit: infer OmitOptions } ? OmitOptions : {}>
  }

  export type TypeMap<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> = {
    globalOmitOptions: {
      omit: GlobalOmitOptions
    }
    meta: {
      modelProps: "school" | "vendorRule" | "bKUImport" | "bKURow" | "bPUGroup" | "sPMDocument" | "rkasImport" | "rkasProgram" | "rkasItem" | "instrumenBosp"
      txIsolationLevel: Prisma.TransactionIsolationLevel
    }
    model: {
      School: {
        payload: Prisma.$SchoolPayload<ExtArgs>
        fields: Prisma.SchoolFieldRefs
        operations: {
          findUnique: {
            args: Prisma.SchoolFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SchoolPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.SchoolFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SchoolPayload>
          }
          findFirst: {
            args: Prisma.SchoolFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SchoolPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.SchoolFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SchoolPayload>
          }
          findMany: {
            args: Prisma.SchoolFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SchoolPayload>[]
          }
          create: {
            args: Prisma.SchoolCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SchoolPayload>
          }
          createMany: {
            args: Prisma.SchoolCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.SchoolCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SchoolPayload>[]
          }
          delete: {
            args: Prisma.SchoolDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SchoolPayload>
          }
          update: {
            args: Prisma.SchoolUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SchoolPayload>
          }
          deleteMany: {
            args: Prisma.SchoolDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.SchoolUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.SchoolUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SchoolPayload>[]
          }
          upsert: {
            args: Prisma.SchoolUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SchoolPayload>
          }
          aggregate: {
            args: Prisma.SchoolAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateSchool>
          }
          groupBy: {
            args: Prisma.SchoolGroupByArgs<ExtArgs>
            result: $Utils.Optional<SchoolGroupByOutputType>[]
          }
          count: {
            args: Prisma.SchoolCountArgs<ExtArgs>
            result: $Utils.Optional<SchoolCountAggregateOutputType> | number
          }
        }
      }
      VendorRule: {
        payload: Prisma.$VendorRulePayload<ExtArgs>
        fields: Prisma.VendorRuleFieldRefs
        operations: {
          findUnique: {
            args: Prisma.VendorRuleFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$VendorRulePayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.VendorRuleFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$VendorRulePayload>
          }
          findFirst: {
            args: Prisma.VendorRuleFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$VendorRulePayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.VendorRuleFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$VendorRulePayload>
          }
          findMany: {
            args: Prisma.VendorRuleFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$VendorRulePayload>[]
          }
          create: {
            args: Prisma.VendorRuleCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$VendorRulePayload>
          }
          createMany: {
            args: Prisma.VendorRuleCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.VendorRuleCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$VendorRulePayload>[]
          }
          delete: {
            args: Prisma.VendorRuleDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$VendorRulePayload>
          }
          update: {
            args: Prisma.VendorRuleUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$VendorRulePayload>
          }
          deleteMany: {
            args: Prisma.VendorRuleDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.VendorRuleUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.VendorRuleUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$VendorRulePayload>[]
          }
          upsert: {
            args: Prisma.VendorRuleUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$VendorRulePayload>
          }
          aggregate: {
            args: Prisma.VendorRuleAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateVendorRule>
          }
          groupBy: {
            args: Prisma.VendorRuleGroupByArgs<ExtArgs>
            result: $Utils.Optional<VendorRuleGroupByOutputType>[]
          }
          count: {
            args: Prisma.VendorRuleCountArgs<ExtArgs>
            result: $Utils.Optional<VendorRuleCountAggregateOutputType> | number
          }
        }
      }
      BKUImport: {
        payload: Prisma.$BKUImportPayload<ExtArgs>
        fields: Prisma.BKUImportFieldRefs
        operations: {
          findUnique: {
            args: Prisma.BKUImportFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$BKUImportPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.BKUImportFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$BKUImportPayload>
          }
          findFirst: {
            args: Prisma.BKUImportFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$BKUImportPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.BKUImportFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$BKUImportPayload>
          }
          findMany: {
            args: Prisma.BKUImportFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$BKUImportPayload>[]
          }
          create: {
            args: Prisma.BKUImportCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$BKUImportPayload>
          }
          createMany: {
            args: Prisma.BKUImportCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.BKUImportCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$BKUImportPayload>[]
          }
          delete: {
            args: Prisma.BKUImportDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$BKUImportPayload>
          }
          update: {
            args: Prisma.BKUImportUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$BKUImportPayload>
          }
          deleteMany: {
            args: Prisma.BKUImportDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.BKUImportUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.BKUImportUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$BKUImportPayload>[]
          }
          upsert: {
            args: Prisma.BKUImportUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$BKUImportPayload>
          }
          aggregate: {
            args: Prisma.BKUImportAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateBKUImport>
          }
          groupBy: {
            args: Prisma.BKUImportGroupByArgs<ExtArgs>
            result: $Utils.Optional<BKUImportGroupByOutputType>[]
          }
          count: {
            args: Prisma.BKUImportCountArgs<ExtArgs>
            result: $Utils.Optional<BKUImportCountAggregateOutputType> | number
          }
        }
      }
      BKURow: {
        payload: Prisma.$BKURowPayload<ExtArgs>
        fields: Prisma.BKURowFieldRefs
        operations: {
          findUnique: {
            args: Prisma.BKURowFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$BKURowPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.BKURowFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$BKURowPayload>
          }
          findFirst: {
            args: Prisma.BKURowFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$BKURowPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.BKURowFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$BKURowPayload>
          }
          findMany: {
            args: Prisma.BKURowFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$BKURowPayload>[]
          }
          create: {
            args: Prisma.BKURowCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$BKURowPayload>
          }
          createMany: {
            args: Prisma.BKURowCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.BKURowCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$BKURowPayload>[]
          }
          delete: {
            args: Prisma.BKURowDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$BKURowPayload>
          }
          update: {
            args: Prisma.BKURowUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$BKURowPayload>
          }
          deleteMany: {
            args: Prisma.BKURowDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.BKURowUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.BKURowUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$BKURowPayload>[]
          }
          upsert: {
            args: Prisma.BKURowUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$BKURowPayload>
          }
          aggregate: {
            args: Prisma.BKURowAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateBKURow>
          }
          groupBy: {
            args: Prisma.BKURowGroupByArgs<ExtArgs>
            result: $Utils.Optional<BKURowGroupByOutputType>[]
          }
          count: {
            args: Prisma.BKURowCountArgs<ExtArgs>
            result: $Utils.Optional<BKURowCountAggregateOutputType> | number
          }
        }
      }
      BPUGroup: {
        payload: Prisma.$BPUGroupPayload<ExtArgs>
        fields: Prisma.BPUGroupFieldRefs
        operations: {
          findUnique: {
            args: Prisma.BPUGroupFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$BPUGroupPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.BPUGroupFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$BPUGroupPayload>
          }
          findFirst: {
            args: Prisma.BPUGroupFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$BPUGroupPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.BPUGroupFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$BPUGroupPayload>
          }
          findMany: {
            args: Prisma.BPUGroupFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$BPUGroupPayload>[]
          }
          create: {
            args: Prisma.BPUGroupCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$BPUGroupPayload>
          }
          createMany: {
            args: Prisma.BPUGroupCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.BPUGroupCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$BPUGroupPayload>[]
          }
          delete: {
            args: Prisma.BPUGroupDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$BPUGroupPayload>
          }
          update: {
            args: Prisma.BPUGroupUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$BPUGroupPayload>
          }
          deleteMany: {
            args: Prisma.BPUGroupDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.BPUGroupUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.BPUGroupUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$BPUGroupPayload>[]
          }
          upsert: {
            args: Prisma.BPUGroupUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$BPUGroupPayload>
          }
          aggregate: {
            args: Prisma.BPUGroupAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateBPUGroup>
          }
          groupBy: {
            args: Prisma.BPUGroupGroupByArgs<ExtArgs>
            result: $Utils.Optional<BPUGroupGroupByOutputType>[]
          }
          count: {
            args: Prisma.BPUGroupCountArgs<ExtArgs>
            result: $Utils.Optional<BPUGroupCountAggregateOutputType> | number
          }
        }
      }
      SPMDocument: {
        payload: Prisma.$SPMDocumentPayload<ExtArgs>
        fields: Prisma.SPMDocumentFieldRefs
        operations: {
          findUnique: {
            args: Prisma.SPMDocumentFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SPMDocumentPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.SPMDocumentFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SPMDocumentPayload>
          }
          findFirst: {
            args: Prisma.SPMDocumentFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SPMDocumentPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.SPMDocumentFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SPMDocumentPayload>
          }
          findMany: {
            args: Prisma.SPMDocumentFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SPMDocumentPayload>[]
          }
          create: {
            args: Prisma.SPMDocumentCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SPMDocumentPayload>
          }
          createMany: {
            args: Prisma.SPMDocumentCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.SPMDocumentCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SPMDocumentPayload>[]
          }
          delete: {
            args: Prisma.SPMDocumentDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SPMDocumentPayload>
          }
          update: {
            args: Prisma.SPMDocumentUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SPMDocumentPayload>
          }
          deleteMany: {
            args: Prisma.SPMDocumentDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.SPMDocumentUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.SPMDocumentUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SPMDocumentPayload>[]
          }
          upsert: {
            args: Prisma.SPMDocumentUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SPMDocumentPayload>
          }
          aggregate: {
            args: Prisma.SPMDocumentAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateSPMDocument>
          }
          groupBy: {
            args: Prisma.SPMDocumentGroupByArgs<ExtArgs>
            result: $Utils.Optional<SPMDocumentGroupByOutputType>[]
          }
          count: {
            args: Prisma.SPMDocumentCountArgs<ExtArgs>
            result: $Utils.Optional<SPMDocumentCountAggregateOutputType> | number
          }
        }
      }
      RkasImport: {
        payload: Prisma.$RkasImportPayload<ExtArgs>
        fields: Prisma.RkasImportFieldRefs
        operations: {
          findUnique: {
            args: Prisma.RkasImportFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$RkasImportPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.RkasImportFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$RkasImportPayload>
          }
          findFirst: {
            args: Prisma.RkasImportFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$RkasImportPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.RkasImportFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$RkasImportPayload>
          }
          findMany: {
            args: Prisma.RkasImportFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$RkasImportPayload>[]
          }
          create: {
            args: Prisma.RkasImportCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$RkasImportPayload>
          }
          createMany: {
            args: Prisma.RkasImportCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.RkasImportCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$RkasImportPayload>[]
          }
          delete: {
            args: Prisma.RkasImportDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$RkasImportPayload>
          }
          update: {
            args: Prisma.RkasImportUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$RkasImportPayload>
          }
          deleteMany: {
            args: Prisma.RkasImportDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.RkasImportUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.RkasImportUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$RkasImportPayload>[]
          }
          upsert: {
            args: Prisma.RkasImportUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$RkasImportPayload>
          }
          aggregate: {
            args: Prisma.RkasImportAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateRkasImport>
          }
          groupBy: {
            args: Prisma.RkasImportGroupByArgs<ExtArgs>
            result: $Utils.Optional<RkasImportGroupByOutputType>[]
          }
          count: {
            args: Prisma.RkasImportCountArgs<ExtArgs>
            result: $Utils.Optional<RkasImportCountAggregateOutputType> | number
          }
        }
      }
      RkasProgram: {
        payload: Prisma.$RkasProgramPayload<ExtArgs>
        fields: Prisma.RkasProgramFieldRefs
        operations: {
          findUnique: {
            args: Prisma.RkasProgramFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$RkasProgramPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.RkasProgramFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$RkasProgramPayload>
          }
          findFirst: {
            args: Prisma.RkasProgramFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$RkasProgramPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.RkasProgramFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$RkasProgramPayload>
          }
          findMany: {
            args: Prisma.RkasProgramFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$RkasProgramPayload>[]
          }
          create: {
            args: Prisma.RkasProgramCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$RkasProgramPayload>
          }
          createMany: {
            args: Prisma.RkasProgramCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.RkasProgramCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$RkasProgramPayload>[]
          }
          delete: {
            args: Prisma.RkasProgramDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$RkasProgramPayload>
          }
          update: {
            args: Prisma.RkasProgramUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$RkasProgramPayload>
          }
          deleteMany: {
            args: Prisma.RkasProgramDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.RkasProgramUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.RkasProgramUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$RkasProgramPayload>[]
          }
          upsert: {
            args: Prisma.RkasProgramUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$RkasProgramPayload>
          }
          aggregate: {
            args: Prisma.RkasProgramAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateRkasProgram>
          }
          groupBy: {
            args: Prisma.RkasProgramGroupByArgs<ExtArgs>
            result: $Utils.Optional<RkasProgramGroupByOutputType>[]
          }
          count: {
            args: Prisma.RkasProgramCountArgs<ExtArgs>
            result: $Utils.Optional<RkasProgramCountAggregateOutputType> | number
          }
        }
      }
      RkasItem: {
        payload: Prisma.$RkasItemPayload<ExtArgs>
        fields: Prisma.RkasItemFieldRefs
        operations: {
          findUnique: {
            args: Prisma.RkasItemFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$RkasItemPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.RkasItemFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$RkasItemPayload>
          }
          findFirst: {
            args: Prisma.RkasItemFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$RkasItemPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.RkasItemFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$RkasItemPayload>
          }
          findMany: {
            args: Prisma.RkasItemFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$RkasItemPayload>[]
          }
          create: {
            args: Prisma.RkasItemCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$RkasItemPayload>
          }
          createMany: {
            args: Prisma.RkasItemCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.RkasItemCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$RkasItemPayload>[]
          }
          delete: {
            args: Prisma.RkasItemDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$RkasItemPayload>
          }
          update: {
            args: Prisma.RkasItemUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$RkasItemPayload>
          }
          deleteMany: {
            args: Prisma.RkasItemDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.RkasItemUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.RkasItemUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$RkasItemPayload>[]
          }
          upsert: {
            args: Prisma.RkasItemUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$RkasItemPayload>
          }
          aggregate: {
            args: Prisma.RkasItemAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateRkasItem>
          }
          groupBy: {
            args: Prisma.RkasItemGroupByArgs<ExtArgs>
            result: $Utils.Optional<RkasItemGroupByOutputType>[]
          }
          count: {
            args: Prisma.RkasItemCountArgs<ExtArgs>
            result: $Utils.Optional<RkasItemCountAggregateOutputType> | number
          }
        }
      }
      InstrumenBosp: {
        payload: Prisma.$InstrumenBospPayload<ExtArgs>
        fields: Prisma.InstrumenBospFieldRefs
        operations: {
          findUnique: {
            args: Prisma.InstrumenBospFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$InstrumenBospPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.InstrumenBospFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$InstrumenBospPayload>
          }
          findFirst: {
            args: Prisma.InstrumenBospFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$InstrumenBospPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.InstrumenBospFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$InstrumenBospPayload>
          }
          findMany: {
            args: Prisma.InstrumenBospFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$InstrumenBospPayload>[]
          }
          create: {
            args: Prisma.InstrumenBospCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$InstrumenBospPayload>
          }
          createMany: {
            args: Prisma.InstrumenBospCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.InstrumenBospCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$InstrumenBospPayload>[]
          }
          delete: {
            args: Prisma.InstrumenBospDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$InstrumenBospPayload>
          }
          update: {
            args: Prisma.InstrumenBospUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$InstrumenBospPayload>
          }
          deleteMany: {
            args: Prisma.InstrumenBospDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.InstrumenBospUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.InstrumenBospUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$InstrumenBospPayload>[]
          }
          upsert: {
            args: Prisma.InstrumenBospUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$InstrumenBospPayload>
          }
          aggregate: {
            args: Prisma.InstrumenBospAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateInstrumenBosp>
          }
          groupBy: {
            args: Prisma.InstrumenBospGroupByArgs<ExtArgs>
            result: $Utils.Optional<InstrumenBospGroupByOutputType>[]
          }
          count: {
            args: Prisma.InstrumenBospCountArgs<ExtArgs>
            result: $Utils.Optional<InstrumenBospCountAggregateOutputType> | number
          }
        }
      }
    }
  } & {
    other: {
      payload: any
      operations: {
        $executeRaw: {
          args: [query: TemplateStringsArray | Prisma.Sql, ...values: any[]],
          result: any
        }
        $executeRawUnsafe: {
          args: [query: string, ...values: any[]],
          result: any
        }
        $queryRaw: {
          args: [query: TemplateStringsArray | Prisma.Sql, ...values: any[]],
          result: any
        }
        $queryRawUnsafe: {
          args: [query: string, ...values: any[]],
          result: any
        }
      }
    }
  }
  export const defineExtension: $Extensions.ExtendsHook<"define", Prisma.TypeMapCb, $Extensions.DefaultArgs>
  export type DefaultPrismaClient = PrismaClient
  export type ErrorFormat = 'pretty' | 'colorless' | 'minimal'
  export interface PrismaClientOptions {
    /**
     * @default "colorless"
     */
    errorFormat?: ErrorFormat
    /**
     * @example
     * ```
     * // Shorthand for `emit: 'stdout'`
     * log: ['query', 'info', 'warn', 'error']
     * 
     * // Emit as events only
     * log: [
     *   { emit: 'event', level: 'query' },
     *   { emit: 'event', level: 'info' },
     *   { emit: 'event', level: 'warn' }
     *   { emit: 'event', level: 'error' }
     * ]
     * 
     * / Emit as events and log to stdout
     * og: [
     *  { emit: 'stdout', level: 'query' },
     *  { emit: 'stdout', level: 'info' },
     *  { emit: 'stdout', level: 'warn' }
     *  { emit: 'stdout', level: 'error' }
     * 
     * ```
     * Read more in our [docs](https://pris.ly/d/logging).
     */
    log?: (LogLevel | LogDefinition)[]
    /**
     * The default values for transactionOptions
     * maxWait ?= 2000
     * timeout ?= 5000
     */
    transactionOptions?: {
      maxWait?: number
      timeout?: number
      isolationLevel?: Prisma.TransactionIsolationLevel
    }
    /**
     * Instance of a Driver Adapter, e.g., like one provided by `@prisma/adapter-planetscale`
     */
    adapter?: runtime.SqlDriverAdapterFactory
    /**
     * Prisma Accelerate URL allowing the client to connect through Accelerate instead of a direct database.
     */
    accelerateUrl?: string
    /**
     * Global configuration for omitting model fields by default.
     * 
     * @example
     * ```
     * const prisma = new PrismaClient({
     *   omit: {
     *     user: {
     *       password: true
     *     }
     *   }
     * })
     * ```
     */
    omit?: Prisma.GlobalOmitConfig
    /**
     * SQL commenter plugins that add metadata to SQL queries as comments.
     * Comments follow the sqlcommenter format: https://google.github.io/sqlcommenter/
     * 
     * @example
     * ```
     * const prisma = new PrismaClient({
     *   adapter,
     *   comments: [
     *     traceContext(),
     *     queryInsights(),
     *   ],
     * })
     * ```
     */
    comments?: runtime.SqlCommenterPlugin[]
  }
  export type GlobalOmitConfig = {
    school?: SchoolOmit
    vendorRule?: VendorRuleOmit
    bKUImport?: BKUImportOmit
    bKURow?: BKURowOmit
    bPUGroup?: BPUGroupOmit
    sPMDocument?: SPMDocumentOmit
    rkasImport?: RkasImportOmit
    rkasProgram?: RkasProgramOmit
    rkasItem?: RkasItemOmit
    instrumenBosp?: InstrumenBospOmit
  }

  /* Types for Logging */
  export type LogLevel = 'info' | 'query' | 'warn' | 'error'
  export type LogDefinition = {
    level: LogLevel
    emit: 'stdout' | 'event'
  }

  export type CheckIsLogLevel<T> = T extends LogLevel ? T : never;

  export type GetLogType<T> = CheckIsLogLevel<
    T extends LogDefinition ? T['level'] : T
  >;

  export type GetEvents<T extends any[]> = T extends Array<LogLevel | LogDefinition>
    ? GetLogType<T[number]>
    : never;

  export type QueryEvent = {
    timestamp: Date
    query: string
    params: string
    duration: number
    target: string
  }

  export type LogEvent = {
    timestamp: Date
    message: string
    target: string
  }
  /* End Types for Logging */


  export type PrismaAction =
    | 'findUnique'
    | 'findUniqueOrThrow'
    | 'findMany'
    | 'findFirst'
    | 'findFirstOrThrow'
    | 'create'
    | 'createMany'
    | 'createManyAndReturn'
    | 'update'
    | 'updateMany'
    | 'updateManyAndReturn'
    | 'upsert'
    | 'delete'
    | 'deleteMany'
    | 'executeRaw'
    | 'queryRaw'
    | 'aggregate'
    | 'count'
    | 'runCommandRaw'
    | 'findRaw'
    | 'groupBy'

  // tested in getLogLevel.test.ts
  export function getLogLevel(log: Array<LogLevel | LogDefinition>): LogLevel | undefined;

  /**
   * `PrismaClient` proxy available in interactive transactions.
   */
  export type TransactionClient = Omit<Prisma.DefaultPrismaClient, runtime.ITXClientDenyList>

  export type Datasource = {
    url?: string
  }

  /**
   * Count Types
   */


  /**
   * Count Type SchoolCountOutputType
   */

  export type SchoolCountOutputType = {
    vendorRules: number
    bkuImports: number
    rkasImports: number
    instrumenBosp: number
  }

  export type SchoolCountOutputTypeSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    vendorRules?: boolean | SchoolCountOutputTypeCountVendorRulesArgs
    bkuImports?: boolean | SchoolCountOutputTypeCountBkuImportsArgs
    rkasImports?: boolean | SchoolCountOutputTypeCountRkasImportsArgs
    instrumenBosp?: boolean | SchoolCountOutputTypeCountInstrumenBospArgs
  }

  // Custom InputTypes
  /**
   * SchoolCountOutputType without action
   */
  export type SchoolCountOutputTypeDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SchoolCountOutputType
     */
    select?: SchoolCountOutputTypeSelect<ExtArgs> | null
  }

  /**
   * SchoolCountOutputType without action
   */
  export type SchoolCountOutputTypeCountVendorRulesArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: VendorRuleWhereInput
  }

  /**
   * SchoolCountOutputType without action
   */
  export type SchoolCountOutputTypeCountBkuImportsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: BKUImportWhereInput
  }

  /**
   * SchoolCountOutputType without action
   */
  export type SchoolCountOutputTypeCountRkasImportsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: RkasImportWhereInput
  }

  /**
   * SchoolCountOutputType without action
   */
  export type SchoolCountOutputTypeCountInstrumenBospArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: InstrumenBospWhereInput
  }


  /**
   * Count Type VendorRuleCountOutputType
   */

  export type VendorRuleCountOutputType = {
    bpuGroups: number
  }

  export type VendorRuleCountOutputTypeSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    bpuGroups?: boolean | VendorRuleCountOutputTypeCountBpuGroupsArgs
  }

  // Custom InputTypes
  /**
   * VendorRuleCountOutputType without action
   */
  export type VendorRuleCountOutputTypeDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the VendorRuleCountOutputType
     */
    select?: VendorRuleCountOutputTypeSelect<ExtArgs> | null
  }

  /**
   * VendorRuleCountOutputType without action
   */
  export type VendorRuleCountOutputTypeCountBpuGroupsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: BPUGroupWhereInput
  }


  /**
   * Count Type BKUImportCountOutputType
   */

  export type BKUImportCountOutputType = {
    rows: number
    bpuGroups: number
  }

  export type BKUImportCountOutputTypeSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    rows?: boolean | BKUImportCountOutputTypeCountRowsArgs
    bpuGroups?: boolean | BKUImportCountOutputTypeCountBpuGroupsArgs
  }

  // Custom InputTypes
  /**
   * BKUImportCountOutputType without action
   */
  export type BKUImportCountOutputTypeDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the BKUImportCountOutputType
     */
    select?: BKUImportCountOutputTypeSelect<ExtArgs> | null
  }

  /**
   * BKUImportCountOutputType without action
   */
  export type BKUImportCountOutputTypeCountRowsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: BKURowWhereInput
  }

  /**
   * BKUImportCountOutputType without action
   */
  export type BKUImportCountOutputTypeCountBpuGroupsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: BPUGroupWhereInput
  }


  /**
   * Count Type RkasImportCountOutputType
   */

  export type RkasImportCountOutputType = {
    programs: number
  }

  export type RkasImportCountOutputTypeSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    programs?: boolean | RkasImportCountOutputTypeCountProgramsArgs
  }

  // Custom InputTypes
  /**
   * RkasImportCountOutputType without action
   */
  export type RkasImportCountOutputTypeDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the RkasImportCountOutputType
     */
    select?: RkasImportCountOutputTypeSelect<ExtArgs> | null
  }

  /**
   * RkasImportCountOutputType without action
   */
  export type RkasImportCountOutputTypeCountProgramsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: RkasProgramWhereInput
  }


  /**
   * Count Type RkasProgramCountOutputType
   */

  export type RkasProgramCountOutputType = {
    items: number
  }

  export type RkasProgramCountOutputTypeSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    items?: boolean | RkasProgramCountOutputTypeCountItemsArgs
  }

  // Custom InputTypes
  /**
   * RkasProgramCountOutputType without action
   */
  export type RkasProgramCountOutputTypeDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the RkasProgramCountOutputType
     */
    select?: RkasProgramCountOutputTypeSelect<ExtArgs> | null
  }

  /**
   * RkasProgramCountOutputType without action
   */
  export type RkasProgramCountOutputTypeCountItemsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: RkasItemWhereInput
  }


  /**
   * Models
   */

  /**
   * Model School
   */

  export type AggregateSchool = {
    _count: SchoolCountAggregateOutputType | null
    _min: SchoolMinAggregateOutputType | null
    _max: SchoolMaxAggregateOutputType | null
  }

  export type SchoolMinAggregateOutputType = {
    id: string | null
    name: string | null
    kopHeaderLine: string | null
    npsn: string | null
    address: string | null
    contact: string | null
    formatCode: string | null
    kepalaName: string | null
    kepalaJabatan: string | null
    openingSentenceTemplate: string | null
    atasDasarLine1: string | null
    atasDasarLine2: string | null
    honorRecapTitle: string | null
    frazaListrikCustomerId: string | null
    frazaInternetCustomerId: string | null
    logoPath: string | null
    regionalLogoPath: string | null
    createdAt: Date | null
    updatedAt: Date | null
  }

  export type SchoolMaxAggregateOutputType = {
    id: string | null
    name: string | null
    kopHeaderLine: string | null
    npsn: string | null
    address: string | null
    contact: string | null
    formatCode: string | null
    kepalaName: string | null
    kepalaJabatan: string | null
    openingSentenceTemplate: string | null
    atasDasarLine1: string | null
    atasDasarLine2: string | null
    honorRecapTitle: string | null
    frazaListrikCustomerId: string | null
    frazaInternetCustomerId: string | null
    logoPath: string | null
    regionalLogoPath: string | null
    createdAt: Date | null
    updatedAt: Date | null
  }

  export type SchoolCountAggregateOutputType = {
    id: number
    name: number
    kopHeaderLine: number
    npsn: number
    address: number
    contact: number
    formatCode: number
    kepalaName: number
    kepalaJabatan: number
    openingSentenceTemplate: number
    atasDasarLine1: number
    atasDasarLine2: number
    honorRecapTitle: number
    frazaListrikCustomerId: number
    frazaInternetCustomerId: number
    logoPath: number
    regionalLogoPath: number
    createdAt: number
    updatedAt: number
    _all: number
  }


  export type SchoolMinAggregateInputType = {
    id?: true
    name?: true
    kopHeaderLine?: true
    npsn?: true
    address?: true
    contact?: true
    formatCode?: true
    kepalaName?: true
    kepalaJabatan?: true
    openingSentenceTemplate?: true
    atasDasarLine1?: true
    atasDasarLine2?: true
    honorRecapTitle?: true
    frazaListrikCustomerId?: true
    frazaInternetCustomerId?: true
    logoPath?: true
    regionalLogoPath?: true
    createdAt?: true
    updatedAt?: true
  }

  export type SchoolMaxAggregateInputType = {
    id?: true
    name?: true
    kopHeaderLine?: true
    npsn?: true
    address?: true
    contact?: true
    formatCode?: true
    kepalaName?: true
    kepalaJabatan?: true
    openingSentenceTemplate?: true
    atasDasarLine1?: true
    atasDasarLine2?: true
    honorRecapTitle?: true
    frazaListrikCustomerId?: true
    frazaInternetCustomerId?: true
    logoPath?: true
    regionalLogoPath?: true
    createdAt?: true
    updatedAt?: true
  }

  export type SchoolCountAggregateInputType = {
    id?: true
    name?: true
    kopHeaderLine?: true
    npsn?: true
    address?: true
    contact?: true
    formatCode?: true
    kepalaName?: true
    kepalaJabatan?: true
    openingSentenceTemplate?: true
    atasDasarLine1?: true
    atasDasarLine2?: true
    honorRecapTitle?: true
    frazaListrikCustomerId?: true
    frazaInternetCustomerId?: true
    logoPath?: true
    regionalLogoPath?: true
    createdAt?: true
    updatedAt?: true
    _all?: true
  }

  export type SchoolAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which School to aggregate.
     */
    where?: SchoolWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Schools to fetch.
     */
    orderBy?: SchoolOrderByWithRelationInput | SchoolOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: SchoolWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Schools from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Schools.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned Schools
    **/
    _count?: true | SchoolCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: SchoolMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: SchoolMaxAggregateInputType
  }

  export type GetSchoolAggregateType<T extends SchoolAggregateArgs> = {
        [P in keyof T & keyof AggregateSchool]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateSchool[P]>
      : GetScalarType<T[P], AggregateSchool[P]>
  }




  export type SchoolGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: SchoolWhereInput
    orderBy?: SchoolOrderByWithAggregationInput | SchoolOrderByWithAggregationInput[]
    by: SchoolScalarFieldEnum[] | SchoolScalarFieldEnum
    having?: SchoolScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: SchoolCountAggregateInputType | true
    _min?: SchoolMinAggregateInputType
    _max?: SchoolMaxAggregateInputType
  }

  export type SchoolGroupByOutputType = {
    id: string
    name: string
    kopHeaderLine: string | null
    npsn: string | null
    address: string
    contact: string | null
    formatCode: string
    kepalaName: string
    kepalaJabatan: string
    openingSentenceTemplate: string
    atasDasarLine1: string
    atasDasarLine2: string
    honorRecapTitle: string | null
    frazaListrikCustomerId: string | null
    frazaInternetCustomerId: string | null
    logoPath: string | null
    regionalLogoPath: string | null
    createdAt: Date
    updatedAt: Date
    _count: SchoolCountAggregateOutputType | null
    _min: SchoolMinAggregateOutputType | null
    _max: SchoolMaxAggregateOutputType | null
  }

  type GetSchoolGroupByPayload<T extends SchoolGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<SchoolGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof SchoolGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], SchoolGroupByOutputType[P]>
            : GetScalarType<T[P], SchoolGroupByOutputType[P]>
        }
      >
    >


  export type SchoolSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    name?: boolean
    kopHeaderLine?: boolean
    npsn?: boolean
    address?: boolean
    contact?: boolean
    formatCode?: boolean
    kepalaName?: boolean
    kepalaJabatan?: boolean
    openingSentenceTemplate?: boolean
    atasDasarLine1?: boolean
    atasDasarLine2?: boolean
    honorRecapTitle?: boolean
    frazaListrikCustomerId?: boolean
    frazaInternetCustomerId?: boolean
    logoPath?: boolean
    regionalLogoPath?: boolean
    createdAt?: boolean
    updatedAt?: boolean
    vendorRules?: boolean | School$vendorRulesArgs<ExtArgs>
    bkuImports?: boolean | School$bkuImportsArgs<ExtArgs>
    rkasImports?: boolean | School$rkasImportsArgs<ExtArgs>
    instrumenBosp?: boolean | School$instrumenBospArgs<ExtArgs>
    _count?: boolean | SchoolCountOutputTypeDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["school"]>

  export type SchoolSelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    name?: boolean
    kopHeaderLine?: boolean
    npsn?: boolean
    address?: boolean
    contact?: boolean
    formatCode?: boolean
    kepalaName?: boolean
    kepalaJabatan?: boolean
    openingSentenceTemplate?: boolean
    atasDasarLine1?: boolean
    atasDasarLine2?: boolean
    honorRecapTitle?: boolean
    frazaListrikCustomerId?: boolean
    frazaInternetCustomerId?: boolean
    logoPath?: boolean
    regionalLogoPath?: boolean
    createdAt?: boolean
    updatedAt?: boolean
  }, ExtArgs["result"]["school"]>

  export type SchoolSelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    name?: boolean
    kopHeaderLine?: boolean
    npsn?: boolean
    address?: boolean
    contact?: boolean
    formatCode?: boolean
    kepalaName?: boolean
    kepalaJabatan?: boolean
    openingSentenceTemplate?: boolean
    atasDasarLine1?: boolean
    atasDasarLine2?: boolean
    honorRecapTitle?: boolean
    frazaListrikCustomerId?: boolean
    frazaInternetCustomerId?: boolean
    logoPath?: boolean
    regionalLogoPath?: boolean
    createdAt?: boolean
    updatedAt?: boolean
  }, ExtArgs["result"]["school"]>

  export type SchoolSelectScalar = {
    id?: boolean
    name?: boolean
    kopHeaderLine?: boolean
    npsn?: boolean
    address?: boolean
    contact?: boolean
    formatCode?: boolean
    kepalaName?: boolean
    kepalaJabatan?: boolean
    openingSentenceTemplate?: boolean
    atasDasarLine1?: boolean
    atasDasarLine2?: boolean
    honorRecapTitle?: boolean
    frazaListrikCustomerId?: boolean
    frazaInternetCustomerId?: boolean
    logoPath?: boolean
    regionalLogoPath?: boolean
    createdAt?: boolean
    updatedAt?: boolean
  }

  export type SchoolOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "name" | "kopHeaderLine" | "npsn" | "address" | "contact" | "formatCode" | "kepalaName" | "kepalaJabatan" | "openingSentenceTemplate" | "atasDasarLine1" | "atasDasarLine2" | "honorRecapTitle" | "frazaListrikCustomerId" | "frazaInternetCustomerId" | "logoPath" | "regionalLogoPath" | "createdAt" | "updatedAt", ExtArgs["result"]["school"]>
  export type SchoolInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    vendorRules?: boolean | School$vendorRulesArgs<ExtArgs>
    bkuImports?: boolean | School$bkuImportsArgs<ExtArgs>
    rkasImports?: boolean | School$rkasImportsArgs<ExtArgs>
    instrumenBosp?: boolean | School$instrumenBospArgs<ExtArgs>
    _count?: boolean | SchoolCountOutputTypeDefaultArgs<ExtArgs>
  }
  export type SchoolIncludeCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {}
  export type SchoolIncludeUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {}

  export type $SchoolPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "School"
    objects: {
      vendorRules: Prisma.$VendorRulePayload<ExtArgs>[]
      bkuImports: Prisma.$BKUImportPayload<ExtArgs>[]
      rkasImports: Prisma.$RkasImportPayload<ExtArgs>[]
      instrumenBosp: Prisma.$InstrumenBospPayload<ExtArgs>[]
    }
    scalars: $Extensions.GetPayloadResult<{
      id: string
      name: string
      kopHeaderLine: string | null
      npsn: string | null
      address: string
      contact: string | null
      formatCode: string
      kepalaName: string
      kepalaJabatan: string
      openingSentenceTemplate: string
      atasDasarLine1: string
      atasDasarLine2: string
      honorRecapTitle: string | null
      frazaListrikCustomerId: string | null
      frazaInternetCustomerId: string | null
      logoPath: string | null
      regionalLogoPath: string | null
      createdAt: Date
      updatedAt: Date
    }, ExtArgs["result"]["school"]>
    composites: {}
  }

  type SchoolGetPayload<S extends boolean | null | undefined | SchoolDefaultArgs> = $Result.GetResult<Prisma.$SchoolPayload, S>

  type SchoolCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<SchoolFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: SchoolCountAggregateInputType | true
    }

  export interface SchoolDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['School'], meta: { name: 'School' } }
    /**
     * Find zero or one School that matches the filter.
     * @param {SchoolFindUniqueArgs} args - Arguments to find a School
     * @example
     * // Get one School
     * const school = await prisma.school.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends SchoolFindUniqueArgs>(args: SelectSubset<T, SchoolFindUniqueArgs<ExtArgs>>): Prisma__SchoolClient<$Result.GetResult<Prisma.$SchoolPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one School that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {SchoolFindUniqueOrThrowArgs} args - Arguments to find a School
     * @example
     * // Get one School
     * const school = await prisma.school.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends SchoolFindUniqueOrThrowArgs>(args: SelectSubset<T, SchoolFindUniqueOrThrowArgs<ExtArgs>>): Prisma__SchoolClient<$Result.GetResult<Prisma.$SchoolPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first School that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SchoolFindFirstArgs} args - Arguments to find a School
     * @example
     * // Get one School
     * const school = await prisma.school.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends SchoolFindFirstArgs>(args?: SelectSubset<T, SchoolFindFirstArgs<ExtArgs>>): Prisma__SchoolClient<$Result.GetResult<Prisma.$SchoolPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first School that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SchoolFindFirstOrThrowArgs} args - Arguments to find a School
     * @example
     * // Get one School
     * const school = await prisma.school.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends SchoolFindFirstOrThrowArgs>(args?: SelectSubset<T, SchoolFindFirstOrThrowArgs<ExtArgs>>): Prisma__SchoolClient<$Result.GetResult<Prisma.$SchoolPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more Schools that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SchoolFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Schools
     * const schools = await prisma.school.findMany()
     * 
     * // Get first 10 Schools
     * const schools = await prisma.school.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const schoolWithIdOnly = await prisma.school.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends SchoolFindManyArgs>(args?: SelectSubset<T, SchoolFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$SchoolPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a School.
     * @param {SchoolCreateArgs} args - Arguments to create a School.
     * @example
     * // Create one School
     * const School = await prisma.school.create({
     *   data: {
     *     // ... data to create a School
     *   }
     * })
     * 
     */
    create<T extends SchoolCreateArgs>(args: SelectSubset<T, SchoolCreateArgs<ExtArgs>>): Prisma__SchoolClient<$Result.GetResult<Prisma.$SchoolPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many Schools.
     * @param {SchoolCreateManyArgs} args - Arguments to create many Schools.
     * @example
     * // Create many Schools
     * const school = await prisma.school.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends SchoolCreateManyArgs>(args?: SelectSubset<T, SchoolCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many Schools and returns the data saved in the database.
     * @param {SchoolCreateManyAndReturnArgs} args - Arguments to create many Schools.
     * @example
     * // Create many Schools
     * const school = await prisma.school.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many Schools and only return the `id`
     * const schoolWithIdOnly = await prisma.school.createManyAndReturn({
     *   select: { id: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends SchoolCreateManyAndReturnArgs>(args?: SelectSubset<T, SchoolCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$SchoolPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a School.
     * @param {SchoolDeleteArgs} args - Arguments to delete one School.
     * @example
     * // Delete one School
     * const School = await prisma.school.delete({
     *   where: {
     *     // ... filter to delete one School
     *   }
     * })
     * 
     */
    delete<T extends SchoolDeleteArgs>(args: SelectSubset<T, SchoolDeleteArgs<ExtArgs>>): Prisma__SchoolClient<$Result.GetResult<Prisma.$SchoolPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one School.
     * @param {SchoolUpdateArgs} args - Arguments to update one School.
     * @example
     * // Update one School
     * const school = await prisma.school.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends SchoolUpdateArgs>(args: SelectSubset<T, SchoolUpdateArgs<ExtArgs>>): Prisma__SchoolClient<$Result.GetResult<Prisma.$SchoolPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more Schools.
     * @param {SchoolDeleteManyArgs} args - Arguments to filter Schools to delete.
     * @example
     * // Delete a few Schools
     * const { count } = await prisma.school.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends SchoolDeleteManyArgs>(args?: SelectSubset<T, SchoolDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Schools.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SchoolUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Schools
     * const school = await prisma.school.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends SchoolUpdateManyArgs>(args: SelectSubset<T, SchoolUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Schools and returns the data updated in the database.
     * @param {SchoolUpdateManyAndReturnArgs} args - Arguments to update many Schools.
     * @example
     * // Update many Schools
     * const school = await prisma.school.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more Schools and only return the `id`
     * const schoolWithIdOnly = await prisma.school.updateManyAndReturn({
     *   select: { id: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends SchoolUpdateManyAndReturnArgs>(args: SelectSubset<T, SchoolUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$SchoolPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one School.
     * @param {SchoolUpsertArgs} args - Arguments to update or create a School.
     * @example
     * // Update or create a School
     * const school = await prisma.school.upsert({
     *   create: {
     *     // ... data to create a School
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the School we want to update
     *   }
     * })
     */
    upsert<T extends SchoolUpsertArgs>(args: SelectSubset<T, SchoolUpsertArgs<ExtArgs>>): Prisma__SchoolClient<$Result.GetResult<Prisma.$SchoolPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of Schools.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SchoolCountArgs} args - Arguments to filter Schools to count.
     * @example
     * // Count the number of Schools
     * const count = await prisma.school.count({
     *   where: {
     *     // ... the filter for the Schools we want to count
     *   }
     * })
    **/
    count<T extends SchoolCountArgs>(
      args?: Subset<T, SchoolCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], SchoolCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a School.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SchoolAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends SchoolAggregateArgs>(args: Subset<T, SchoolAggregateArgs>): Prisma.PrismaPromise<GetSchoolAggregateType<T>>

    /**
     * Group by School.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SchoolGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends SchoolGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: SchoolGroupByArgs['orderBy'] }
        : { orderBy?: SchoolGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, SchoolGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetSchoolGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the School model
   */
  readonly fields: SchoolFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for School.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__SchoolClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    vendorRules<T extends School$vendorRulesArgs<ExtArgs> = {}>(args?: Subset<T, School$vendorRulesArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$VendorRulePayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    bkuImports<T extends School$bkuImportsArgs<ExtArgs> = {}>(args?: Subset<T, School$bkuImportsArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$BKUImportPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    rkasImports<T extends School$rkasImportsArgs<ExtArgs> = {}>(args?: Subset<T, School$rkasImportsArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$RkasImportPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    instrumenBosp<T extends School$instrumenBospArgs<ExtArgs> = {}>(args?: Subset<T, School$instrumenBospArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$InstrumenBospPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the School model
   */
  interface SchoolFieldRefs {
    readonly id: FieldRef<"School", 'String'>
    readonly name: FieldRef<"School", 'String'>
    readonly kopHeaderLine: FieldRef<"School", 'String'>
    readonly npsn: FieldRef<"School", 'String'>
    readonly address: FieldRef<"School", 'String'>
    readonly contact: FieldRef<"School", 'String'>
    readonly formatCode: FieldRef<"School", 'String'>
    readonly kepalaName: FieldRef<"School", 'String'>
    readonly kepalaJabatan: FieldRef<"School", 'String'>
    readonly openingSentenceTemplate: FieldRef<"School", 'String'>
    readonly atasDasarLine1: FieldRef<"School", 'String'>
    readonly atasDasarLine2: FieldRef<"School", 'String'>
    readonly honorRecapTitle: FieldRef<"School", 'String'>
    readonly frazaListrikCustomerId: FieldRef<"School", 'String'>
    readonly frazaInternetCustomerId: FieldRef<"School", 'String'>
    readonly logoPath: FieldRef<"School", 'String'>
    readonly regionalLogoPath: FieldRef<"School", 'String'>
    readonly createdAt: FieldRef<"School", 'DateTime'>
    readonly updatedAt: FieldRef<"School", 'DateTime'>
  }
    

  // Custom InputTypes
  /**
   * School findUnique
   */
  export type SchoolFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the School
     */
    select?: SchoolSelect<ExtArgs> | null
    /**
     * Omit specific fields from the School
     */
    omit?: SchoolOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SchoolInclude<ExtArgs> | null
    /**
     * Filter, which School to fetch.
     */
    where: SchoolWhereUniqueInput
  }

  /**
   * School findUniqueOrThrow
   */
  export type SchoolFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the School
     */
    select?: SchoolSelect<ExtArgs> | null
    /**
     * Omit specific fields from the School
     */
    omit?: SchoolOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SchoolInclude<ExtArgs> | null
    /**
     * Filter, which School to fetch.
     */
    where: SchoolWhereUniqueInput
  }

  /**
   * School findFirst
   */
  export type SchoolFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the School
     */
    select?: SchoolSelect<ExtArgs> | null
    /**
     * Omit specific fields from the School
     */
    omit?: SchoolOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SchoolInclude<ExtArgs> | null
    /**
     * Filter, which School to fetch.
     */
    where?: SchoolWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Schools to fetch.
     */
    orderBy?: SchoolOrderByWithRelationInput | SchoolOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Schools.
     */
    cursor?: SchoolWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Schools from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Schools.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Schools.
     */
    distinct?: SchoolScalarFieldEnum | SchoolScalarFieldEnum[]
  }

  /**
   * School findFirstOrThrow
   */
  export type SchoolFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the School
     */
    select?: SchoolSelect<ExtArgs> | null
    /**
     * Omit specific fields from the School
     */
    omit?: SchoolOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SchoolInclude<ExtArgs> | null
    /**
     * Filter, which School to fetch.
     */
    where?: SchoolWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Schools to fetch.
     */
    orderBy?: SchoolOrderByWithRelationInput | SchoolOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Schools.
     */
    cursor?: SchoolWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Schools from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Schools.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Schools.
     */
    distinct?: SchoolScalarFieldEnum | SchoolScalarFieldEnum[]
  }

  /**
   * School findMany
   */
  export type SchoolFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the School
     */
    select?: SchoolSelect<ExtArgs> | null
    /**
     * Omit specific fields from the School
     */
    omit?: SchoolOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SchoolInclude<ExtArgs> | null
    /**
     * Filter, which Schools to fetch.
     */
    where?: SchoolWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Schools to fetch.
     */
    orderBy?: SchoolOrderByWithRelationInput | SchoolOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing Schools.
     */
    cursor?: SchoolWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Schools from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Schools.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Schools.
     */
    distinct?: SchoolScalarFieldEnum | SchoolScalarFieldEnum[]
  }

  /**
   * School create
   */
  export type SchoolCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the School
     */
    select?: SchoolSelect<ExtArgs> | null
    /**
     * Omit specific fields from the School
     */
    omit?: SchoolOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SchoolInclude<ExtArgs> | null
    /**
     * The data needed to create a School.
     */
    data: XOR<SchoolCreateInput, SchoolUncheckedCreateInput>
  }

  /**
   * School createMany
   */
  export type SchoolCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many Schools.
     */
    data: SchoolCreateManyInput | SchoolCreateManyInput[]
  }

  /**
   * School createManyAndReturn
   */
  export type SchoolCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the School
     */
    select?: SchoolSelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the School
     */
    omit?: SchoolOmit<ExtArgs> | null
    /**
     * The data used to create many Schools.
     */
    data: SchoolCreateManyInput | SchoolCreateManyInput[]
  }

  /**
   * School update
   */
  export type SchoolUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the School
     */
    select?: SchoolSelect<ExtArgs> | null
    /**
     * Omit specific fields from the School
     */
    omit?: SchoolOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SchoolInclude<ExtArgs> | null
    /**
     * The data needed to update a School.
     */
    data: XOR<SchoolUpdateInput, SchoolUncheckedUpdateInput>
    /**
     * Choose, which School to update.
     */
    where: SchoolWhereUniqueInput
  }

  /**
   * School updateMany
   */
  export type SchoolUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update Schools.
     */
    data: XOR<SchoolUpdateManyMutationInput, SchoolUncheckedUpdateManyInput>
    /**
     * Filter which Schools to update
     */
    where?: SchoolWhereInput
    /**
     * Limit how many Schools to update.
     */
    limit?: number
  }

  /**
   * School updateManyAndReturn
   */
  export type SchoolUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the School
     */
    select?: SchoolSelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the School
     */
    omit?: SchoolOmit<ExtArgs> | null
    /**
     * The data used to update Schools.
     */
    data: XOR<SchoolUpdateManyMutationInput, SchoolUncheckedUpdateManyInput>
    /**
     * Filter which Schools to update
     */
    where?: SchoolWhereInput
    /**
     * Limit how many Schools to update.
     */
    limit?: number
  }

  /**
   * School upsert
   */
  export type SchoolUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the School
     */
    select?: SchoolSelect<ExtArgs> | null
    /**
     * Omit specific fields from the School
     */
    omit?: SchoolOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SchoolInclude<ExtArgs> | null
    /**
     * The filter to search for the School to update in case it exists.
     */
    where: SchoolWhereUniqueInput
    /**
     * In case the School found by the `where` argument doesn't exist, create a new School with this data.
     */
    create: XOR<SchoolCreateInput, SchoolUncheckedCreateInput>
    /**
     * In case the School was found with the provided `where` argument, update it with this data.
     */
    update: XOR<SchoolUpdateInput, SchoolUncheckedUpdateInput>
  }

  /**
   * School delete
   */
  export type SchoolDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the School
     */
    select?: SchoolSelect<ExtArgs> | null
    /**
     * Omit specific fields from the School
     */
    omit?: SchoolOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SchoolInclude<ExtArgs> | null
    /**
     * Filter which School to delete.
     */
    where: SchoolWhereUniqueInput
  }

  /**
   * School deleteMany
   */
  export type SchoolDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Schools to delete
     */
    where?: SchoolWhereInput
    /**
     * Limit how many Schools to delete.
     */
    limit?: number
  }

  /**
   * School.vendorRules
   */
  export type School$vendorRulesArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the VendorRule
     */
    select?: VendorRuleSelect<ExtArgs> | null
    /**
     * Omit specific fields from the VendorRule
     */
    omit?: VendorRuleOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: VendorRuleInclude<ExtArgs> | null
    where?: VendorRuleWhereInput
    orderBy?: VendorRuleOrderByWithRelationInput | VendorRuleOrderByWithRelationInput[]
    cursor?: VendorRuleWhereUniqueInput
    take?: number
    skip?: number
    distinct?: VendorRuleScalarFieldEnum | VendorRuleScalarFieldEnum[]
  }

  /**
   * School.bkuImports
   */
  export type School$bkuImportsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the BKUImport
     */
    select?: BKUImportSelect<ExtArgs> | null
    /**
     * Omit specific fields from the BKUImport
     */
    omit?: BKUImportOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: BKUImportInclude<ExtArgs> | null
    where?: BKUImportWhereInput
    orderBy?: BKUImportOrderByWithRelationInput | BKUImportOrderByWithRelationInput[]
    cursor?: BKUImportWhereUniqueInput
    take?: number
    skip?: number
    distinct?: BKUImportScalarFieldEnum | BKUImportScalarFieldEnum[]
  }

  /**
   * School.rkasImports
   */
  export type School$rkasImportsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the RkasImport
     */
    select?: RkasImportSelect<ExtArgs> | null
    /**
     * Omit specific fields from the RkasImport
     */
    omit?: RkasImportOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: RkasImportInclude<ExtArgs> | null
    where?: RkasImportWhereInput
    orderBy?: RkasImportOrderByWithRelationInput | RkasImportOrderByWithRelationInput[]
    cursor?: RkasImportWhereUniqueInput
    take?: number
    skip?: number
    distinct?: RkasImportScalarFieldEnum | RkasImportScalarFieldEnum[]
  }

  /**
   * School.instrumenBosp
   */
  export type School$instrumenBospArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the InstrumenBosp
     */
    select?: InstrumenBospSelect<ExtArgs> | null
    /**
     * Omit specific fields from the InstrumenBosp
     */
    omit?: InstrumenBospOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: InstrumenBospInclude<ExtArgs> | null
    where?: InstrumenBospWhereInput
    orderBy?: InstrumenBospOrderByWithRelationInput | InstrumenBospOrderByWithRelationInput[]
    cursor?: InstrumenBospWhereUniqueInput
    take?: number
    skip?: number
    distinct?: InstrumenBospScalarFieldEnum | InstrumenBospScalarFieldEnum[]
  }

  /**
   * School without action
   */
  export type SchoolDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the School
     */
    select?: SchoolSelect<ExtArgs> | null
    /**
     * Omit specific fields from the School
     */
    omit?: SchoolOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SchoolInclude<ExtArgs> | null
  }


  /**
   * Model VendorRule
   */

  export type AggregateVendorRule = {
    _count: VendorRuleCountAggregateOutputType | null
    _avg: VendorRuleAvgAggregateOutputType | null
    _sum: VendorRuleSumAggregateOutputType | null
    _min: VendorRuleMinAggregateOutputType | null
    _max: VendorRuleMaxAggregateOutputType | null
  }

  export type VendorRuleAvgAggregateOutputType = {
    priority: number | null
  }

  export type VendorRuleSumAggregateOutputType = {
    priority: number | null
  }

  export type VendorRuleMinAggregateOutputType = {
    id: string | null
    schoolId: string | null
    keyword: string | null
    recipient: string | null
    paymentPrefix: string | null
    matchKodeKegiatan: string | null
    formatType: $Enums.VendorRuleFormatType | null
    isHonor: boolean | null
    isTransport: boolean | null
    priority: number | null
    isActive: boolean | null
    createdAt: Date | null
    updatedAt: Date | null
  }

  export type VendorRuleMaxAggregateOutputType = {
    id: string | null
    schoolId: string | null
    keyword: string | null
    recipient: string | null
    paymentPrefix: string | null
    matchKodeKegiatan: string | null
    formatType: $Enums.VendorRuleFormatType | null
    isHonor: boolean | null
    isTransport: boolean | null
    priority: number | null
    isActive: boolean | null
    createdAt: Date | null
    updatedAt: Date | null
  }

  export type VendorRuleCountAggregateOutputType = {
    id: number
    schoolId: number
    keyword: number
    recipient: number
    paymentPrefix: number
    matchKodeKegiatan: number
    formatType: number
    isHonor: number
    isTransport: number
    priority: number
    isActive: number
    createdAt: number
    updatedAt: number
    _all: number
  }


  export type VendorRuleAvgAggregateInputType = {
    priority?: true
  }

  export type VendorRuleSumAggregateInputType = {
    priority?: true
  }

  export type VendorRuleMinAggregateInputType = {
    id?: true
    schoolId?: true
    keyword?: true
    recipient?: true
    paymentPrefix?: true
    matchKodeKegiatan?: true
    formatType?: true
    isHonor?: true
    isTransport?: true
    priority?: true
    isActive?: true
    createdAt?: true
    updatedAt?: true
  }

  export type VendorRuleMaxAggregateInputType = {
    id?: true
    schoolId?: true
    keyword?: true
    recipient?: true
    paymentPrefix?: true
    matchKodeKegiatan?: true
    formatType?: true
    isHonor?: true
    isTransport?: true
    priority?: true
    isActive?: true
    createdAt?: true
    updatedAt?: true
  }

  export type VendorRuleCountAggregateInputType = {
    id?: true
    schoolId?: true
    keyword?: true
    recipient?: true
    paymentPrefix?: true
    matchKodeKegiatan?: true
    formatType?: true
    isHonor?: true
    isTransport?: true
    priority?: true
    isActive?: true
    createdAt?: true
    updatedAt?: true
    _all?: true
  }

  export type VendorRuleAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which VendorRule to aggregate.
     */
    where?: VendorRuleWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of VendorRules to fetch.
     */
    orderBy?: VendorRuleOrderByWithRelationInput | VendorRuleOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: VendorRuleWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` VendorRules from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` VendorRules.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned VendorRules
    **/
    _count?: true | VendorRuleCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: VendorRuleAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: VendorRuleSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: VendorRuleMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: VendorRuleMaxAggregateInputType
  }

  export type GetVendorRuleAggregateType<T extends VendorRuleAggregateArgs> = {
        [P in keyof T & keyof AggregateVendorRule]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateVendorRule[P]>
      : GetScalarType<T[P], AggregateVendorRule[P]>
  }




  export type VendorRuleGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: VendorRuleWhereInput
    orderBy?: VendorRuleOrderByWithAggregationInput | VendorRuleOrderByWithAggregationInput[]
    by: VendorRuleScalarFieldEnum[] | VendorRuleScalarFieldEnum
    having?: VendorRuleScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: VendorRuleCountAggregateInputType | true
    _avg?: VendorRuleAvgAggregateInputType
    _sum?: VendorRuleSumAggregateInputType
    _min?: VendorRuleMinAggregateInputType
    _max?: VendorRuleMaxAggregateInputType
  }

  export type VendorRuleGroupByOutputType = {
    id: string
    schoolId: string
    keyword: string
    recipient: string
    paymentPrefix: string
    matchKodeKegiatan: string | null
    formatType: $Enums.VendorRuleFormatType
    isHonor: boolean
    isTransport: boolean
    priority: number
    isActive: boolean
    createdAt: Date
    updatedAt: Date
    _count: VendorRuleCountAggregateOutputType | null
    _avg: VendorRuleAvgAggregateOutputType | null
    _sum: VendorRuleSumAggregateOutputType | null
    _min: VendorRuleMinAggregateOutputType | null
    _max: VendorRuleMaxAggregateOutputType | null
  }

  type GetVendorRuleGroupByPayload<T extends VendorRuleGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<VendorRuleGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof VendorRuleGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], VendorRuleGroupByOutputType[P]>
            : GetScalarType<T[P], VendorRuleGroupByOutputType[P]>
        }
      >
    >


  export type VendorRuleSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    schoolId?: boolean
    keyword?: boolean
    recipient?: boolean
    paymentPrefix?: boolean
    matchKodeKegiatan?: boolean
    formatType?: boolean
    isHonor?: boolean
    isTransport?: boolean
    priority?: boolean
    isActive?: boolean
    createdAt?: boolean
    updatedAt?: boolean
    school?: boolean | SchoolDefaultArgs<ExtArgs>
    bpuGroups?: boolean | VendorRule$bpuGroupsArgs<ExtArgs>
    _count?: boolean | VendorRuleCountOutputTypeDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["vendorRule"]>

  export type VendorRuleSelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    schoolId?: boolean
    keyword?: boolean
    recipient?: boolean
    paymentPrefix?: boolean
    matchKodeKegiatan?: boolean
    formatType?: boolean
    isHonor?: boolean
    isTransport?: boolean
    priority?: boolean
    isActive?: boolean
    createdAt?: boolean
    updatedAt?: boolean
    school?: boolean | SchoolDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["vendorRule"]>

  export type VendorRuleSelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    schoolId?: boolean
    keyword?: boolean
    recipient?: boolean
    paymentPrefix?: boolean
    matchKodeKegiatan?: boolean
    formatType?: boolean
    isHonor?: boolean
    isTransport?: boolean
    priority?: boolean
    isActive?: boolean
    createdAt?: boolean
    updatedAt?: boolean
    school?: boolean | SchoolDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["vendorRule"]>

  export type VendorRuleSelectScalar = {
    id?: boolean
    schoolId?: boolean
    keyword?: boolean
    recipient?: boolean
    paymentPrefix?: boolean
    matchKodeKegiatan?: boolean
    formatType?: boolean
    isHonor?: boolean
    isTransport?: boolean
    priority?: boolean
    isActive?: boolean
    createdAt?: boolean
    updatedAt?: boolean
  }

  export type VendorRuleOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "schoolId" | "keyword" | "recipient" | "paymentPrefix" | "matchKodeKegiatan" | "formatType" | "isHonor" | "isTransport" | "priority" | "isActive" | "createdAt" | "updatedAt", ExtArgs["result"]["vendorRule"]>
  export type VendorRuleInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    school?: boolean | SchoolDefaultArgs<ExtArgs>
    bpuGroups?: boolean | VendorRule$bpuGroupsArgs<ExtArgs>
    _count?: boolean | VendorRuleCountOutputTypeDefaultArgs<ExtArgs>
  }
  export type VendorRuleIncludeCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    school?: boolean | SchoolDefaultArgs<ExtArgs>
  }
  export type VendorRuleIncludeUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    school?: boolean | SchoolDefaultArgs<ExtArgs>
  }

  export type $VendorRulePayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "VendorRule"
    objects: {
      school: Prisma.$SchoolPayload<ExtArgs>
      bpuGroups: Prisma.$BPUGroupPayload<ExtArgs>[]
    }
    scalars: $Extensions.GetPayloadResult<{
      id: string
      schoolId: string
      keyword: string
      recipient: string
      paymentPrefix: string
      matchKodeKegiatan: string | null
      formatType: $Enums.VendorRuleFormatType
      isHonor: boolean
      isTransport: boolean
      priority: number
      isActive: boolean
      createdAt: Date
      updatedAt: Date
    }, ExtArgs["result"]["vendorRule"]>
    composites: {}
  }

  type VendorRuleGetPayload<S extends boolean | null | undefined | VendorRuleDefaultArgs> = $Result.GetResult<Prisma.$VendorRulePayload, S>

  type VendorRuleCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<VendorRuleFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: VendorRuleCountAggregateInputType | true
    }

  export interface VendorRuleDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['VendorRule'], meta: { name: 'VendorRule' } }
    /**
     * Find zero or one VendorRule that matches the filter.
     * @param {VendorRuleFindUniqueArgs} args - Arguments to find a VendorRule
     * @example
     * // Get one VendorRule
     * const vendorRule = await prisma.vendorRule.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends VendorRuleFindUniqueArgs>(args: SelectSubset<T, VendorRuleFindUniqueArgs<ExtArgs>>): Prisma__VendorRuleClient<$Result.GetResult<Prisma.$VendorRulePayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one VendorRule that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {VendorRuleFindUniqueOrThrowArgs} args - Arguments to find a VendorRule
     * @example
     * // Get one VendorRule
     * const vendorRule = await prisma.vendorRule.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends VendorRuleFindUniqueOrThrowArgs>(args: SelectSubset<T, VendorRuleFindUniqueOrThrowArgs<ExtArgs>>): Prisma__VendorRuleClient<$Result.GetResult<Prisma.$VendorRulePayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first VendorRule that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {VendorRuleFindFirstArgs} args - Arguments to find a VendorRule
     * @example
     * // Get one VendorRule
     * const vendorRule = await prisma.vendorRule.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends VendorRuleFindFirstArgs>(args?: SelectSubset<T, VendorRuleFindFirstArgs<ExtArgs>>): Prisma__VendorRuleClient<$Result.GetResult<Prisma.$VendorRulePayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first VendorRule that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {VendorRuleFindFirstOrThrowArgs} args - Arguments to find a VendorRule
     * @example
     * // Get one VendorRule
     * const vendorRule = await prisma.vendorRule.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends VendorRuleFindFirstOrThrowArgs>(args?: SelectSubset<T, VendorRuleFindFirstOrThrowArgs<ExtArgs>>): Prisma__VendorRuleClient<$Result.GetResult<Prisma.$VendorRulePayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more VendorRules that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {VendorRuleFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all VendorRules
     * const vendorRules = await prisma.vendorRule.findMany()
     * 
     * // Get first 10 VendorRules
     * const vendorRules = await prisma.vendorRule.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const vendorRuleWithIdOnly = await prisma.vendorRule.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends VendorRuleFindManyArgs>(args?: SelectSubset<T, VendorRuleFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$VendorRulePayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a VendorRule.
     * @param {VendorRuleCreateArgs} args - Arguments to create a VendorRule.
     * @example
     * // Create one VendorRule
     * const VendorRule = await prisma.vendorRule.create({
     *   data: {
     *     // ... data to create a VendorRule
     *   }
     * })
     * 
     */
    create<T extends VendorRuleCreateArgs>(args: SelectSubset<T, VendorRuleCreateArgs<ExtArgs>>): Prisma__VendorRuleClient<$Result.GetResult<Prisma.$VendorRulePayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many VendorRules.
     * @param {VendorRuleCreateManyArgs} args - Arguments to create many VendorRules.
     * @example
     * // Create many VendorRules
     * const vendorRule = await prisma.vendorRule.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends VendorRuleCreateManyArgs>(args?: SelectSubset<T, VendorRuleCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many VendorRules and returns the data saved in the database.
     * @param {VendorRuleCreateManyAndReturnArgs} args - Arguments to create many VendorRules.
     * @example
     * // Create many VendorRules
     * const vendorRule = await prisma.vendorRule.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many VendorRules and only return the `id`
     * const vendorRuleWithIdOnly = await prisma.vendorRule.createManyAndReturn({
     *   select: { id: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends VendorRuleCreateManyAndReturnArgs>(args?: SelectSubset<T, VendorRuleCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$VendorRulePayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a VendorRule.
     * @param {VendorRuleDeleteArgs} args - Arguments to delete one VendorRule.
     * @example
     * // Delete one VendorRule
     * const VendorRule = await prisma.vendorRule.delete({
     *   where: {
     *     // ... filter to delete one VendorRule
     *   }
     * })
     * 
     */
    delete<T extends VendorRuleDeleteArgs>(args: SelectSubset<T, VendorRuleDeleteArgs<ExtArgs>>): Prisma__VendorRuleClient<$Result.GetResult<Prisma.$VendorRulePayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one VendorRule.
     * @param {VendorRuleUpdateArgs} args - Arguments to update one VendorRule.
     * @example
     * // Update one VendorRule
     * const vendorRule = await prisma.vendorRule.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends VendorRuleUpdateArgs>(args: SelectSubset<T, VendorRuleUpdateArgs<ExtArgs>>): Prisma__VendorRuleClient<$Result.GetResult<Prisma.$VendorRulePayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more VendorRules.
     * @param {VendorRuleDeleteManyArgs} args - Arguments to filter VendorRules to delete.
     * @example
     * // Delete a few VendorRules
     * const { count } = await prisma.vendorRule.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends VendorRuleDeleteManyArgs>(args?: SelectSubset<T, VendorRuleDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more VendorRules.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {VendorRuleUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many VendorRules
     * const vendorRule = await prisma.vendorRule.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends VendorRuleUpdateManyArgs>(args: SelectSubset<T, VendorRuleUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more VendorRules and returns the data updated in the database.
     * @param {VendorRuleUpdateManyAndReturnArgs} args - Arguments to update many VendorRules.
     * @example
     * // Update many VendorRules
     * const vendorRule = await prisma.vendorRule.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more VendorRules and only return the `id`
     * const vendorRuleWithIdOnly = await prisma.vendorRule.updateManyAndReturn({
     *   select: { id: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends VendorRuleUpdateManyAndReturnArgs>(args: SelectSubset<T, VendorRuleUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$VendorRulePayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one VendorRule.
     * @param {VendorRuleUpsertArgs} args - Arguments to update or create a VendorRule.
     * @example
     * // Update or create a VendorRule
     * const vendorRule = await prisma.vendorRule.upsert({
     *   create: {
     *     // ... data to create a VendorRule
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the VendorRule we want to update
     *   }
     * })
     */
    upsert<T extends VendorRuleUpsertArgs>(args: SelectSubset<T, VendorRuleUpsertArgs<ExtArgs>>): Prisma__VendorRuleClient<$Result.GetResult<Prisma.$VendorRulePayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of VendorRules.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {VendorRuleCountArgs} args - Arguments to filter VendorRules to count.
     * @example
     * // Count the number of VendorRules
     * const count = await prisma.vendorRule.count({
     *   where: {
     *     // ... the filter for the VendorRules we want to count
     *   }
     * })
    **/
    count<T extends VendorRuleCountArgs>(
      args?: Subset<T, VendorRuleCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], VendorRuleCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a VendorRule.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {VendorRuleAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends VendorRuleAggregateArgs>(args: Subset<T, VendorRuleAggregateArgs>): Prisma.PrismaPromise<GetVendorRuleAggregateType<T>>

    /**
     * Group by VendorRule.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {VendorRuleGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends VendorRuleGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: VendorRuleGroupByArgs['orderBy'] }
        : { orderBy?: VendorRuleGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, VendorRuleGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetVendorRuleGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the VendorRule model
   */
  readonly fields: VendorRuleFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for VendorRule.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__VendorRuleClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    school<T extends SchoolDefaultArgs<ExtArgs> = {}>(args?: Subset<T, SchoolDefaultArgs<ExtArgs>>): Prisma__SchoolClient<$Result.GetResult<Prisma.$SchoolPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    bpuGroups<T extends VendorRule$bpuGroupsArgs<ExtArgs> = {}>(args?: Subset<T, VendorRule$bpuGroupsArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$BPUGroupPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the VendorRule model
   */
  interface VendorRuleFieldRefs {
    readonly id: FieldRef<"VendorRule", 'String'>
    readonly schoolId: FieldRef<"VendorRule", 'String'>
    readonly keyword: FieldRef<"VendorRule", 'String'>
    readonly recipient: FieldRef<"VendorRule", 'String'>
    readonly paymentPrefix: FieldRef<"VendorRule", 'String'>
    readonly matchKodeKegiatan: FieldRef<"VendorRule", 'String'>
    readonly formatType: FieldRef<"VendorRule", 'VendorRuleFormatType'>
    readonly isHonor: FieldRef<"VendorRule", 'Boolean'>
    readonly isTransport: FieldRef<"VendorRule", 'Boolean'>
    readonly priority: FieldRef<"VendorRule", 'Int'>
    readonly isActive: FieldRef<"VendorRule", 'Boolean'>
    readonly createdAt: FieldRef<"VendorRule", 'DateTime'>
    readonly updatedAt: FieldRef<"VendorRule", 'DateTime'>
  }
    

  // Custom InputTypes
  /**
   * VendorRule findUnique
   */
  export type VendorRuleFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the VendorRule
     */
    select?: VendorRuleSelect<ExtArgs> | null
    /**
     * Omit specific fields from the VendorRule
     */
    omit?: VendorRuleOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: VendorRuleInclude<ExtArgs> | null
    /**
     * Filter, which VendorRule to fetch.
     */
    where: VendorRuleWhereUniqueInput
  }

  /**
   * VendorRule findUniqueOrThrow
   */
  export type VendorRuleFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the VendorRule
     */
    select?: VendorRuleSelect<ExtArgs> | null
    /**
     * Omit specific fields from the VendorRule
     */
    omit?: VendorRuleOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: VendorRuleInclude<ExtArgs> | null
    /**
     * Filter, which VendorRule to fetch.
     */
    where: VendorRuleWhereUniqueInput
  }

  /**
   * VendorRule findFirst
   */
  export type VendorRuleFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the VendorRule
     */
    select?: VendorRuleSelect<ExtArgs> | null
    /**
     * Omit specific fields from the VendorRule
     */
    omit?: VendorRuleOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: VendorRuleInclude<ExtArgs> | null
    /**
     * Filter, which VendorRule to fetch.
     */
    where?: VendorRuleWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of VendorRules to fetch.
     */
    orderBy?: VendorRuleOrderByWithRelationInput | VendorRuleOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for VendorRules.
     */
    cursor?: VendorRuleWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` VendorRules from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` VendorRules.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of VendorRules.
     */
    distinct?: VendorRuleScalarFieldEnum | VendorRuleScalarFieldEnum[]
  }

  /**
   * VendorRule findFirstOrThrow
   */
  export type VendorRuleFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the VendorRule
     */
    select?: VendorRuleSelect<ExtArgs> | null
    /**
     * Omit specific fields from the VendorRule
     */
    omit?: VendorRuleOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: VendorRuleInclude<ExtArgs> | null
    /**
     * Filter, which VendorRule to fetch.
     */
    where?: VendorRuleWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of VendorRules to fetch.
     */
    orderBy?: VendorRuleOrderByWithRelationInput | VendorRuleOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for VendorRules.
     */
    cursor?: VendorRuleWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` VendorRules from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` VendorRules.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of VendorRules.
     */
    distinct?: VendorRuleScalarFieldEnum | VendorRuleScalarFieldEnum[]
  }

  /**
   * VendorRule findMany
   */
  export type VendorRuleFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the VendorRule
     */
    select?: VendorRuleSelect<ExtArgs> | null
    /**
     * Omit specific fields from the VendorRule
     */
    omit?: VendorRuleOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: VendorRuleInclude<ExtArgs> | null
    /**
     * Filter, which VendorRules to fetch.
     */
    where?: VendorRuleWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of VendorRules to fetch.
     */
    orderBy?: VendorRuleOrderByWithRelationInput | VendorRuleOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing VendorRules.
     */
    cursor?: VendorRuleWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` VendorRules from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` VendorRules.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of VendorRules.
     */
    distinct?: VendorRuleScalarFieldEnum | VendorRuleScalarFieldEnum[]
  }

  /**
   * VendorRule create
   */
  export type VendorRuleCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the VendorRule
     */
    select?: VendorRuleSelect<ExtArgs> | null
    /**
     * Omit specific fields from the VendorRule
     */
    omit?: VendorRuleOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: VendorRuleInclude<ExtArgs> | null
    /**
     * The data needed to create a VendorRule.
     */
    data: XOR<VendorRuleCreateInput, VendorRuleUncheckedCreateInput>
  }

  /**
   * VendorRule createMany
   */
  export type VendorRuleCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many VendorRules.
     */
    data: VendorRuleCreateManyInput | VendorRuleCreateManyInput[]
  }

  /**
   * VendorRule createManyAndReturn
   */
  export type VendorRuleCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the VendorRule
     */
    select?: VendorRuleSelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the VendorRule
     */
    omit?: VendorRuleOmit<ExtArgs> | null
    /**
     * The data used to create many VendorRules.
     */
    data: VendorRuleCreateManyInput | VendorRuleCreateManyInput[]
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: VendorRuleIncludeCreateManyAndReturn<ExtArgs> | null
  }

  /**
   * VendorRule update
   */
  export type VendorRuleUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the VendorRule
     */
    select?: VendorRuleSelect<ExtArgs> | null
    /**
     * Omit specific fields from the VendorRule
     */
    omit?: VendorRuleOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: VendorRuleInclude<ExtArgs> | null
    /**
     * The data needed to update a VendorRule.
     */
    data: XOR<VendorRuleUpdateInput, VendorRuleUncheckedUpdateInput>
    /**
     * Choose, which VendorRule to update.
     */
    where: VendorRuleWhereUniqueInput
  }

  /**
   * VendorRule updateMany
   */
  export type VendorRuleUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update VendorRules.
     */
    data: XOR<VendorRuleUpdateManyMutationInput, VendorRuleUncheckedUpdateManyInput>
    /**
     * Filter which VendorRules to update
     */
    where?: VendorRuleWhereInput
    /**
     * Limit how many VendorRules to update.
     */
    limit?: number
  }

  /**
   * VendorRule updateManyAndReturn
   */
  export type VendorRuleUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the VendorRule
     */
    select?: VendorRuleSelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the VendorRule
     */
    omit?: VendorRuleOmit<ExtArgs> | null
    /**
     * The data used to update VendorRules.
     */
    data: XOR<VendorRuleUpdateManyMutationInput, VendorRuleUncheckedUpdateManyInput>
    /**
     * Filter which VendorRules to update
     */
    where?: VendorRuleWhereInput
    /**
     * Limit how many VendorRules to update.
     */
    limit?: number
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: VendorRuleIncludeUpdateManyAndReturn<ExtArgs> | null
  }

  /**
   * VendorRule upsert
   */
  export type VendorRuleUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the VendorRule
     */
    select?: VendorRuleSelect<ExtArgs> | null
    /**
     * Omit specific fields from the VendorRule
     */
    omit?: VendorRuleOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: VendorRuleInclude<ExtArgs> | null
    /**
     * The filter to search for the VendorRule to update in case it exists.
     */
    where: VendorRuleWhereUniqueInput
    /**
     * In case the VendorRule found by the `where` argument doesn't exist, create a new VendorRule with this data.
     */
    create: XOR<VendorRuleCreateInput, VendorRuleUncheckedCreateInput>
    /**
     * In case the VendorRule was found with the provided `where` argument, update it with this data.
     */
    update: XOR<VendorRuleUpdateInput, VendorRuleUncheckedUpdateInput>
  }

  /**
   * VendorRule delete
   */
  export type VendorRuleDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the VendorRule
     */
    select?: VendorRuleSelect<ExtArgs> | null
    /**
     * Omit specific fields from the VendorRule
     */
    omit?: VendorRuleOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: VendorRuleInclude<ExtArgs> | null
    /**
     * Filter which VendorRule to delete.
     */
    where: VendorRuleWhereUniqueInput
  }

  /**
   * VendorRule deleteMany
   */
  export type VendorRuleDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which VendorRules to delete
     */
    where?: VendorRuleWhereInput
    /**
     * Limit how many VendorRules to delete.
     */
    limit?: number
  }

  /**
   * VendorRule.bpuGroups
   */
  export type VendorRule$bpuGroupsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the BPUGroup
     */
    select?: BPUGroupSelect<ExtArgs> | null
    /**
     * Omit specific fields from the BPUGroup
     */
    omit?: BPUGroupOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: BPUGroupInclude<ExtArgs> | null
    where?: BPUGroupWhereInput
    orderBy?: BPUGroupOrderByWithRelationInput | BPUGroupOrderByWithRelationInput[]
    cursor?: BPUGroupWhereUniqueInput
    take?: number
    skip?: number
    distinct?: BPUGroupScalarFieldEnum | BPUGroupScalarFieldEnum[]
  }

  /**
   * VendorRule without action
   */
  export type VendorRuleDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the VendorRule
     */
    select?: VendorRuleSelect<ExtArgs> | null
    /**
     * Omit specific fields from the VendorRule
     */
    omit?: VendorRuleOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: VendorRuleInclude<ExtArgs> | null
  }


  /**
   * Model BKUImport
   */

  export type AggregateBKUImport = {
    _count: BKUImportCountAggregateOutputType | null
    _avg: BKUImportAvgAggregateOutputType | null
    _sum: BKUImportSumAggregateOutputType | null
    _min: BKUImportMinAggregateOutputType | null
    _max: BKUImportMaxAggregateOutputType | null
  }

  export type BKUImportAvgAggregateOutputType = {
    month: number | null
    year: number | null
  }

  export type BKUImportSumAggregateOutputType = {
    month: number | null
    year: number | null
  }

  export type BKUImportMinAggregateOutputType = {
    id: string | null
    schoolId: string | null
    month: number | null
    year: number | null
    sourceFileName: string | null
    status: $Enums.BKUImportStatus | null
    importedAt: Date | null
  }

  export type BKUImportMaxAggregateOutputType = {
    id: string | null
    schoolId: string | null
    month: number | null
    year: number | null
    sourceFileName: string | null
    status: $Enums.BKUImportStatus | null
    importedAt: Date | null
  }

  export type BKUImportCountAggregateOutputType = {
    id: number
    schoolId: number
    month: number
    year: number
    sourceFileName: number
    status: number
    importedAt: number
    _all: number
  }


  export type BKUImportAvgAggregateInputType = {
    month?: true
    year?: true
  }

  export type BKUImportSumAggregateInputType = {
    month?: true
    year?: true
  }

  export type BKUImportMinAggregateInputType = {
    id?: true
    schoolId?: true
    month?: true
    year?: true
    sourceFileName?: true
    status?: true
    importedAt?: true
  }

  export type BKUImportMaxAggregateInputType = {
    id?: true
    schoolId?: true
    month?: true
    year?: true
    sourceFileName?: true
    status?: true
    importedAt?: true
  }

  export type BKUImportCountAggregateInputType = {
    id?: true
    schoolId?: true
    month?: true
    year?: true
    sourceFileName?: true
    status?: true
    importedAt?: true
    _all?: true
  }

  export type BKUImportAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which BKUImport to aggregate.
     */
    where?: BKUImportWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of BKUImports to fetch.
     */
    orderBy?: BKUImportOrderByWithRelationInput | BKUImportOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: BKUImportWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` BKUImports from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` BKUImports.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned BKUImports
    **/
    _count?: true | BKUImportCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: BKUImportAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: BKUImportSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: BKUImportMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: BKUImportMaxAggregateInputType
  }

  export type GetBKUImportAggregateType<T extends BKUImportAggregateArgs> = {
        [P in keyof T & keyof AggregateBKUImport]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateBKUImport[P]>
      : GetScalarType<T[P], AggregateBKUImport[P]>
  }




  export type BKUImportGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: BKUImportWhereInput
    orderBy?: BKUImportOrderByWithAggregationInput | BKUImportOrderByWithAggregationInput[]
    by: BKUImportScalarFieldEnum[] | BKUImportScalarFieldEnum
    having?: BKUImportScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: BKUImportCountAggregateInputType | true
    _avg?: BKUImportAvgAggregateInputType
    _sum?: BKUImportSumAggregateInputType
    _min?: BKUImportMinAggregateInputType
    _max?: BKUImportMaxAggregateInputType
  }

  export type BKUImportGroupByOutputType = {
    id: string
    schoolId: string
    month: number
    year: number
    sourceFileName: string
    status: $Enums.BKUImportStatus
    importedAt: Date
    _count: BKUImportCountAggregateOutputType | null
    _avg: BKUImportAvgAggregateOutputType | null
    _sum: BKUImportSumAggregateOutputType | null
    _min: BKUImportMinAggregateOutputType | null
    _max: BKUImportMaxAggregateOutputType | null
  }

  type GetBKUImportGroupByPayload<T extends BKUImportGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<BKUImportGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof BKUImportGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], BKUImportGroupByOutputType[P]>
            : GetScalarType<T[P], BKUImportGroupByOutputType[P]>
        }
      >
    >


  export type BKUImportSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    schoolId?: boolean
    month?: boolean
    year?: boolean
    sourceFileName?: boolean
    status?: boolean
    importedAt?: boolean
    school?: boolean | SchoolDefaultArgs<ExtArgs>
    rows?: boolean | BKUImport$rowsArgs<ExtArgs>
    bpuGroups?: boolean | BKUImport$bpuGroupsArgs<ExtArgs>
    _count?: boolean | BKUImportCountOutputTypeDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["bKUImport"]>

  export type BKUImportSelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    schoolId?: boolean
    month?: boolean
    year?: boolean
    sourceFileName?: boolean
    status?: boolean
    importedAt?: boolean
    school?: boolean | SchoolDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["bKUImport"]>

  export type BKUImportSelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    schoolId?: boolean
    month?: boolean
    year?: boolean
    sourceFileName?: boolean
    status?: boolean
    importedAt?: boolean
    school?: boolean | SchoolDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["bKUImport"]>

  export type BKUImportSelectScalar = {
    id?: boolean
    schoolId?: boolean
    month?: boolean
    year?: boolean
    sourceFileName?: boolean
    status?: boolean
    importedAt?: boolean
  }

  export type BKUImportOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "schoolId" | "month" | "year" | "sourceFileName" | "status" | "importedAt", ExtArgs["result"]["bKUImport"]>
  export type BKUImportInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    school?: boolean | SchoolDefaultArgs<ExtArgs>
    rows?: boolean | BKUImport$rowsArgs<ExtArgs>
    bpuGroups?: boolean | BKUImport$bpuGroupsArgs<ExtArgs>
    _count?: boolean | BKUImportCountOutputTypeDefaultArgs<ExtArgs>
  }
  export type BKUImportIncludeCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    school?: boolean | SchoolDefaultArgs<ExtArgs>
  }
  export type BKUImportIncludeUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    school?: boolean | SchoolDefaultArgs<ExtArgs>
  }

  export type $BKUImportPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "BKUImport"
    objects: {
      school: Prisma.$SchoolPayload<ExtArgs>
      rows: Prisma.$BKURowPayload<ExtArgs>[]
      bpuGroups: Prisma.$BPUGroupPayload<ExtArgs>[]
    }
    scalars: $Extensions.GetPayloadResult<{
      id: string
      schoolId: string
      month: number
      year: number
      sourceFileName: string
      status: $Enums.BKUImportStatus
      importedAt: Date
    }, ExtArgs["result"]["bKUImport"]>
    composites: {}
  }

  type BKUImportGetPayload<S extends boolean | null | undefined | BKUImportDefaultArgs> = $Result.GetResult<Prisma.$BKUImportPayload, S>

  type BKUImportCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<BKUImportFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: BKUImportCountAggregateInputType | true
    }

  export interface BKUImportDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['BKUImport'], meta: { name: 'BKUImport' } }
    /**
     * Find zero or one BKUImport that matches the filter.
     * @param {BKUImportFindUniqueArgs} args - Arguments to find a BKUImport
     * @example
     * // Get one BKUImport
     * const bKUImport = await prisma.bKUImport.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends BKUImportFindUniqueArgs>(args: SelectSubset<T, BKUImportFindUniqueArgs<ExtArgs>>): Prisma__BKUImportClient<$Result.GetResult<Prisma.$BKUImportPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one BKUImport that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {BKUImportFindUniqueOrThrowArgs} args - Arguments to find a BKUImport
     * @example
     * // Get one BKUImport
     * const bKUImport = await prisma.bKUImport.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends BKUImportFindUniqueOrThrowArgs>(args: SelectSubset<T, BKUImportFindUniqueOrThrowArgs<ExtArgs>>): Prisma__BKUImportClient<$Result.GetResult<Prisma.$BKUImportPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first BKUImport that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {BKUImportFindFirstArgs} args - Arguments to find a BKUImport
     * @example
     * // Get one BKUImport
     * const bKUImport = await prisma.bKUImport.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends BKUImportFindFirstArgs>(args?: SelectSubset<T, BKUImportFindFirstArgs<ExtArgs>>): Prisma__BKUImportClient<$Result.GetResult<Prisma.$BKUImportPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first BKUImport that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {BKUImportFindFirstOrThrowArgs} args - Arguments to find a BKUImport
     * @example
     * // Get one BKUImport
     * const bKUImport = await prisma.bKUImport.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends BKUImportFindFirstOrThrowArgs>(args?: SelectSubset<T, BKUImportFindFirstOrThrowArgs<ExtArgs>>): Prisma__BKUImportClient<$Result.GetResult<Prisma.$BKUImportPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more BKUImports that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {BKUImportFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all BKUImports
     * const bKUImports = await prisma.bKUImport.findMany()
     * 
     * // Get first 10 BKUImports
     * const bKUImports = await prisma.bKUImport.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const bKUImportWithIdOnly = await prisma.bKUImport.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends BKUImportFindManyArgs>(args?: SelectSubset<T, BKUImportFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$BKUImportPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a BKUImport.
     * @param {BKUImportCreateArgs} args - Arguments to create a BKUImport.
     * @example
     * // Create one BKUImport
     * const BKUImport = await prisma.bKUImport.create({
     *   data: {
     *     // ... data to create a BKUImport
     *   }
     * })
     * 
     */
    create<T extends BKUImportCreateArgs>(args: SelectSubset<T, BKUImportCreateArgs<ExtArgs>>): Prisma__BKUImportClient<$Result.GetResult<Prisma.$BKUImportPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many BKUImports.
     * @param {BKUImportCreateManyArgs} args - Arguments to create many BKUImports.
     * @example
     * // Create many BKUImports
     * const bKUImport = await prisma.bKUImport.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends BKUImportCreateManyArgs>(args?: SelectSubset<T, BKUImportCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many BKUImports and returns the data saved in the database.
     * @param {BKUImportCreateManyAndReturnArgs} args - Arguments to create many BKUImports.
     * @example
     * // Create many BKUImports
     * const bKUImport = await prisma.bKUImport.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many BKUImports and only return the `id`
     * const bKUImportWithIdOnly = await prisma.bKUImport.createManyAndReturn({
     *   select: { id: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends BKUImportCreateManyAndReturnArgs>(args?: SelectSubset<T, BKUImportCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$BKUImportPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a BKUImport.
     * @param {BKUImportDeleteArgs} args - Arguments to delete one BKUImport.
     * @example
     * // Delete one BKUImport
     * const BKUImport = await prisma.bKUImport.delete({
     *   where: {
     *     // ... filter to delete one BKUImport
     *   }
     * })
     * 
     */
    delete<T extends BKUImportDeleteArgs>(args: SelectSubset<T, BKUImportDeleteArgs<ExtArgs>>): Prisma__BKUImportClient<$Result.GetResult<Prisma.$BKUImportPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one BKUImport.
     * @param {BKUImportUpdateArgs} args - Arguments to update one BKUImport.
     * @example
     * // Update one BKUImport
     * const bKUImport = await prisma.bKUImport.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends BKUImportUpdateArgs>(args: SelectSubset<T, BKUImportUpdateArgs<ExtArgs>>): Prisma__BKUImportClient<$Result.GetResult<Prisma.$BKUImportPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more BKUImports.
     * @param {BKUImportDeleteManyArgs} args - Arguments to filter BKUImports to delete.
     * @example
     * // Delete a few BKUImports
     * const { count } = await prisma.bKUImport.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends BKUImportDeleteManyArgs>(args?: SelectSubset<T, BKUImportDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more BKUImports.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {BKUImportUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many BKUImports
     * const bKUImport = await prisma.bKUImport.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends BKUImportUpdateManyArgs>(args: SelectSubset<T, BKUImportUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more BKUImports and returns the data updated in the database.
     * @param {BKUImportUpdateManyAndReturnArgs} args - Arguments to update many BKUImports.
     * @example
     * // Update many BKUImports
     * const bKUImport = await prisma.bKUImport.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more BKUImports and only return the `id`
     * const bKUImportWithIdOnly = await prisma.bKUImport.updateManyAndReturn({
     *   select: { id: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends BKUImportUpdateManyAndReturnArgs>(args: SelectSubset<T, BKUImportUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$BKUImportPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one BKUImport.
     * @param {BKUImportUpsertArgs} args - Arguments to update or create a BKUImport.
     * @example
     * // Update or create a BKUImport
     * const bKUImport = await prisma.bKUImport.upsert({
     *   create: {
     *     // ... data to create a BKUImport
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the BKUImport we want to update
     *   }
     * })
     */
    upsert<T extends BKUImportUpsertArgs>(args: SelectSubset<T, BKUImportUpsertArgs<ExtArgs>>): Prisma__BKUImportClient<$Result.GetResult<Prisma.$BKUImportPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of BKUImports.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {BKUImportCountArgs} args - Arguments to filter BKUImports to count.
     * @example
     * // Count the number of BKUImports
     * const count = await prisma.bKUImport.count({
     *   where: {
     *     // ... the filter for the BKUImports we want to count
     *   }
     * })
    **/
    count<T extends BKUImportCountArgs>(
      args?: Subset<T, BKUImportCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], BKUImportCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a BKUImport.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {BKUImportAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends BKUImportAggregateArgs>(args: Subset<T, BKUImportAggregateArgs>): Prisma.PrismaPromise<GetBKUImportAggregateType<T>>

    /**
     * Group by BKUImport.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {BKUImportGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends BKUImportGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: BKUImportGroupByArgs['orderBy'] }
        : { orderBy?: BKUImportGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, BKUImportGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetBKUImportGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the BKUImport model
   */
  readonly fields: BKUImportFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for BKUImport.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__BKUImportClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    school<T extends SchoolDefaultArgs<ExtArgs> = {}>(args?: Subset<T, SchoolDefaultArgs<ExtArgs>>): Prisma__SchoolClient<$Result.GetResult<Prisma.$SchoolPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    rows<T extends BKUImport$rowsArgs<ExtArgs> = {}>(args?: Subset<T, BKUImport$rowsArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$BKURowPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    bpuGroups<T extends BKUImport$bpuGroupsArgs<ExtArgs> = {}>(args?: Subset<T, BKUImport$bpuGroupsArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$BPUGroupPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the BKUImport model
   */
  interface BKUImportFieldRefs {
    readonly id: FieldRef<"BKUImport", 'String'>
    readonly schoolId: FieldRef<"BKUImport", 'String'>
    readonly month: FieldRef<"BKUImport", 'Int'>
    readonly year: FieldRef<"BKUImport", 'Int'>
    readonly sourceFileName: FieldRef<"BKUImport", 'String'>
    readonly status: FieldRef<"BKUImport", 'BKUImportStatus'>
    readonly importedAt: FieldRef<"BKUImport", 'DateTime'>
  }
    

  // Custom InputTypes
  /**
   * BKUImport findUnique
   */
  export type BKUImportFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the BKUImport
     */
    select?: BKUImportSelect<ExtArgs> | null
    /**
     * Omit specific fields from the BKUImport
     */
    omit?: BKUImportOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: BKUImportInclude<ExtArgs> | null
    /**
     * Filter, which BKUImport to fetch.
     */
    where: BKUImportWhereUniqueInput
  }

  /**
   * BKUImport findUniqueOrThrow
   */
  export type BKUImportFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the BKUImport
     */
    select?: BKUImportSelect<ExtArgs> | null
    /**
     * Omit specific fields from the BKUImport
     */
    omit?: BKUImportOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: BKUImportInclude<ExtArgs> | null
    /**
     * Filter, which BKUImport to fetch.
     */
    where: BKUImportWhereUniqueInput
  }

  /**
   * BKUImport findFirst
   */
  export type BKUImportFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the BKUImport
     */
    select?: BKUImportSelect<ExtArgs> | null
    /**
     * Omit specific fields from the BKUImport
     */
    omit?: BKUImportOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: BKUImportInclude<ExtArgs> | null
    /**
     * Filter, which BKUImport to fetch.
     */
    where?: BKUImportWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of BKUImports to fetch.
     */
    orderBy?: BKUImportOrderByWithRelationInput | BKUImportOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for BKUImports.
     */
    cursor?: BKUImportWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` BKUImports from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` BKUImports.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of BKUImports.
     */
    distinct?: BKUImportScalarFieldEnum | BKUImportScalarFieldEnum[]
  }

  /**
   * BKUImport findFirstOrThrow
   */
  export type BKUImportFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the BKUImport
     */
    select?: BKUImportSelect<ExtArgs> | null
    /**
     * Omit specific fields from the BKUImport
     */
    omit?: BKUImportOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: BKUImportInclude<ExtArgs> | null
    /**
     * Filter, which BKUImport to fetch.
     */
    where?: BKUImportWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of BKUImports to fetch.
     */
    orderBy?: BKUImportOrderByWithRelationInput | BKUImportOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for BKUImports.
     */
    cursor?: BKUImportWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` BKUImports from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` BKUImports.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of BKUImports.
     */
    distinct?: BKUImportScalarFieldEnum | BKUImportScalarFieldEnum[]
  }

  /**
   * BKUImport findMany
   */
  export type BKUImportFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the BKUImport
     */
    select?: BKUImportSelect<ExtArgs> | null
    /**
     * Omit specific fields from the BKUImport
     */
    omit?: BKUImportOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: BKUImportInclude<ExtArgs> | null
    /**
     * Filter, which BKUImports to fetch.
     */
    where?: BKUImportWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of BKUImports to fetch.
     */
    orderBy?: BKUImportOrderByWithRelationInput | BKUImportOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing BKUImports.
     */
    cursor?: BKUImportWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` BKUImports from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` BKUImports.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of BKUImports.
     */
    distinct?: BKUImportScalarFieldEnum | BKUImportScalarFieldEnum[]
  }

  /**
   * BKUImport create
   */
  export type BKUImportCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the BKUImport
     */
    select?: BKUImportSelect<ExtArgs> | null
    /**
     * Omit specific fields from the BKUImport
     */
    omit?: BKUImportOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: BKUImportInclude<ExtArgs> | null
    /**
     * The data needed to create a BKUImport.
     */
    data: XOR<BKUImportCreateInput, BKUImportUncheckedCreateInput>
  }

  /**
   * BKUImport createMany
   */
  export type BKUImportCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many BKUImports.
     */
    data: BKUImportCreateManyInput | BKUImportCreateManyInput[]
  }

  /**
   * BKUImport createManyAndReturn
   */
  export type BKUImportCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the BKUImport
     */
    select?: BKUImportSelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the BKUImport
     */
    omit?: BKUImportOmit<ExtArgs> | null
    /**
     * The data used to create many BKUImports.
     */
    data: BKUImportCreateManyInput | BKUImportCreateManyInput[]
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: BKUImportIncludeCreateManyAndReturn<ExtArgs> | null
  }

  /**
   * BKUImport update
   */
  export type BKUImportUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the BKUImport
     */
    select?: BKUImportSelect<ExtArgs> | null
    /**
     * Omit specific fields from the BKUImport
     */
    omit?: BKUImportOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: BKUImportInclude<ExtArgs> | null
    /**
     * The data needed to update a BKUImport.
     */
    data: XOR<BKUImportUpdateInput, BKUImportUncheckedUpdateInput>
    /**
     * Choose, which BKUImport to update.
     */
    where: BKUImportWhereUniqueInput
  }

  /**
   * BKUImport updateMany
   */
  export type BKUImportUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update BKUImports.
     */
    data: XOR<BKUImportUpdateManyMutationInput, BKUImportUncheckedUpdateManyInput>
    /**
     * Filter which BKUImports to update
     */
    where?: BKUImportWhereInput
    /**
     * Limit how many BKUImports to update.
     */
    limit?: number
  }

  /**
   * BKUImport updateManyAndReturn
   */
  export type BKUImportUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the BKUImport
     */
    select?: BKUImportSelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the BKUImport
     */
    omit?: BKUImportOmit<ExtArgs> | null
    /**
     * The data used to update BKUImports.
     */
    data: XOR<BKUImportUpdateManyMutationInput, BKUImportUncheckedUpdateManyInput>
    /**
     * Filter which BKUImports to update
     */
    where?: BKUImportWhereInput
    /**
     * Limit how many BKUImports to update.
     */
    limit?: number
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: BKUImportIncludeUpdateManyAndReturn<ExtArgs> | null
  }

  /**
   * BKUImport upsert
   */
  export type BKUImportUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the BKUImport
     */
    select?: BKUImportSelect<ExtArgs> | null
    /**
     * Omit specific fields from the BKUImport
     */
    omit?: BKUImportOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: BKUImportInclude<ExtArgs> | null
    /**
     * The filter to search for the BKUImport to update in case it exists.
     */
    where: BKUImportWhereUniqueInput
    /**
     * In case the BKUImport found by the `where` argument doesn't exist, create a new BKUImport with this data.
     */
    create: XOR<BKUImportCreateInput, BKUImportUncheckedCreateInput>
    /**
     * In case the BKUImport was found with the provided `where` argument, update it with this data.
     */
    update: XOR<BKUImportUpdateInput, BKUImportUncheckedUpdateInput>
  }

  /**
   * BKUImport delete
   */
  export type BKUImportDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the BKUImport
     */
    select?: BKUImportSelect<ExtArgs> | null
    /**
     * Omit specific fields from the BKUImport
     */
    omit?: BKUImportOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: BKUImportInclude<ExtArgs> | null
    /**
     * Filter which BKUImport to delete.
     */
    where: BKUImportWhereUniqueInput
  }

  /**
   * BKUImport deleteMany
   */
  export type BKUImportDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which BKUImports to delete
     */
    where?: BKUImportWhereInput
    /**
     * Limit how many BKUImports to delete.
     */
    limit?: number
  }

  /**
   * BKUImport.rows
   */
  export type BKUImport$rowsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the BKURow
     */
    select?: BKURowSelect<ExtArgs> | null
    /**
     * Omit specific fields from the BKURow
     */
    omit?: BKURowOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: BKURowInclude<ExtArgs> | null
    where?: BKURowWhereInput
    orderBy?: BKURowOrderByWithRelationInput | BKURowOrderByWithRelationInput[]
    cursor?: BKURowWhereUniqueInput
    take?: number
    skip?: number
    distinct?: BKURowScalarFieldEnum | BKURowScalarFieldEnum[]
  }

  /**
   * BKUImport.bpuGroups
   */
  export type BKUImport$bpuGroupsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the BPUGroup
     */
    select?: BPUGroupSelect<ExtArgs> | null
    /**
     * Omit specific fields from the BPUGroup
     */
    omit?: BPUGroupOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: BPUGroupInclude<ExtArgs> | null
    where?: BPUGroupWhereInput
    orderBy?: BPUGroupOrderByWithRelationInput | BPUGroupOrderByWithRelationInput[]
    cursor?: BPUGroupWhereUniqueInput
    take?: number
    skip?: number
    distinct?: BPUGroupScalarFieldEnum | BPUGroupScalarFieldEnum[]
  }

  /**
   * BKUImport without action
   */
  export type BKUImportDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the BKUImport
     */
    select?: BKUImportSelect<ExtArgs> | null
    /**
     * Omit specific fields from the BKUImport
     */
    omit?: BKUImportOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: BKUImportInclude<ExtArgs> | null
  }


  /**
   * Model BKURow
   */

  export type AggregateBKURow = {
    _count: BKURowCountAggregateOutputType | null
    _avg: BKURowAvgAggregateOutputType | null
    _sum: BKURowSumAggregateOutputType | null
    _min: BKURowMinAggregateOutputType | null
    _max: BKURowMaxAggregateOutputType | null
  }

  export type BKURowAvgAggregateOutputType = {
    bpuNumber: number | null
    penerimaan: number | null
    pengeluaran: number | null
    saldo: number | null
    pageIndex: number | null
  }

  export type BKURowSumAggregateOutputType = {
    bpuNumber: number | null
    penerimaan: number | null
    pengeluaran: number | null
    saldo: number | null
    pageIndex: number | null
  }

  export type BKURowMinAggregateOutputType = {
    id: string | null
    bkuImportId: string | null
    tanggal: Date | null
    kodeKegiatan: string | null
    kodeRekening: string | null
    bpuCode: string | null
    bpuNumber: number | null
    uraian: string | null
    penerimaan: number | null
    pengeluaran: number | null
    saldo: number | null
    pageIndex: number | null
    createdAt: Date | null
  }

  export type BKURowMaxAggregateOutputType = {
    id: string | null
    bkuImportId: string | null
    tanggal: Date | null
    kodeKegiatan: string | null
    kodeRekening: string | null
    bpuCode: string | null
    bpuNumber: number | null
    uraian: string | null
    penerimaan: number | null
    pengeluaran: number | null
    saldo: number | null
    pageIndex: number | null
    createdAt: Date | null
  }

  export type BKURowCountAggregateOutputType = {
    id: number
    bkuImportId: number
    tanggal: number
    kodeKegiatan: number
    kodeRekening: number
    bpuCode: number
    bpuNumber: number
    uraian: number
    penerimaan: number
    pengeluaran: number
    saldo: number
    pageIndex: number
    createdAt: number
    _all: number
  }


  export type BKURowAvgAggregateInputType = {
    bpuNumber?: true
    penerimaan?: true
    pengeluaran?: true
    saldo?: true
    pageIndex?: true
  }

  export type BKURowSumAggregateInputType = {
    bpuNumber?: true
    penerimaan?: true
    pengeluaran?: true
    saldo?: true
    pageIndex?: true
  }

  export type BKURowMinAggregateInputType = {
    id?: true
    bkuImportId?: true
    tanggal?: true
    kodeKegiatan?: true
    kodeRekening?: true
    bpuCode?: true
    bpuNumber?: true
    uraian?: true
    penerimaan?: true
    pengeluaran?: true
    saldo?: true
    pageIndex?: true
    createdAt?: true
  }

  export type BKURowMaxAggregateInputType = {
    id?: true
    bkuImportId?: true
    tanggal?: true
    kodeKegiatan?: true
    kodeRekening?: true
    bpuCode?: true
    bpuNumber?: true
    uraian?: true
    penerimaan?: true
    pengeluaran?: true
    saldo?: true
    pageIndex?: true
    createdAt?: true
  }

  export type BKURowCountAggregateInputType = {
    id?: true
    bkuImportId?: true
    tanggal?: true
    kodeKegiatan?: true
    kodeRekening?: true
    bpuCode?: true
    bpuNumber?: true
    uraian?: true
    penerimaan?: true
    pengeluaran?: true
    saldo?: true
    pageIndex?: true
    createdAt?: true
    _all?: true
  }

  export type BKURowAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which BKURow to aggregate.
     */
    where?: BKURowWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of BKURows to fetch.
     */
    orderBy?: BKURowOrderByWithRelationInput | BKURowOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: BKURowWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` BKURows from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` BKURows.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned BKURows
    **/
    _count?: true | BKURowCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: BKURowAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: BKURowSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: BKURowMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: BKURowMaxAggregateInputType
  }

  export type GetBKURowAggregateType<T extends BKURowAggregateArgs> = {
        [P in keyof T & keyof AggregateBKURow]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateBKURow[P]>
      : GetScalarType<T[P], AggregateBKURow[P]>
  }




  export type BKURowGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: BKURowWhereInput
    orderBy?: BKURowOrderByWithAggregationInput | BKURowOrderByWithAggregationInput[]
    by: BKURowScalarFieldEnum[] | BKURowScalarFieldEnum
    having?: BKURowScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: BKURowCountAggregateInputType | true
    _avg?: BKURowAvgAggregateInputType
    _sum?: BKURowSumAggregateInputType
    _min?: BKURowMinAggregateInputType
    _max?: BKURowMaxAggregateInputType
  }

  export type BKURowGroupByOutputType = {
    id: string
    bkuImportId: string
    tanggal: Date
    kodeKegiatan: string | null
    kodeRekening: string | null
    bpuCode: string | null
    bpuNumber: number | null
    uraian: string
    penerimaan: number
    pengeluaran: number
    saldo: number
    pageIndex: number | null
    createdAt: Date
    _count: BKURowCountAggregateOutputType | null
    _avg: BKURowAvgAggregateOutputType | null
    _sum: BKURowSumAggregateOutputType | null
    _min: BKURowMinAggregateOutputType | null
    _max: BKURowMaxAggregateOutputType | null
  }

  type GetBKURowGroupByPayload<T extends BKURowGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<BKURowGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof BKURowGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], BKURowGroupByOutputType[P]>
            : GetScalarType<T[P], BKURowGroupByOutputType[P]>
        }
      >
    >


  export type BKURowSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    bkuImportId?: boolean
    tanggal?: boolean
    kodeKegiatan?: boolean
    kodeRekening?: boolean
    bpuCode?: boolean
    bpuNumber?: boolean
    uraian?: boolean
    penerimaan?: boolean
    pengeluaran?: boolean
    saldo?: boolean
    pageIndex?: boolean
    createdAt?: boolean
    bkuImport?: boolean | BKUImportDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["bKURow"]>

  export type BKURowSelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    bkuImportId?: boolean
    tanggal?: boolean
    kodeKegiatan?: boolean
    kodeRekening?: boolean
    bpuCode?: boolean
    bpuNumber?: boolean
    uraian?: boolean
    penerimaan?: boolean
    pengeluaran?: boolean
    saldo?: boolean
    pageIndex?: boolean
    createdAt?: boolean
    bkuImport?: boolean | BKUImportDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["bKURow"]>

  export type BKURowSelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    bkuImportId?: boolean
    tanggal?: boolean
    kodeKegiatan?: boolean
    kodeRekening?: boolean
    bpuCode?: boolean
    bpuNumber?: boolean
    uraian?: boolean
    penerimaan?: boolean
    pengeluaran?: boolean
    saldo?: boolean
    pageIndex?: boolean
    createdAt?: boolean
    bkuImport?: boolean | BKUImportDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["bKURow"]>

  export type BKURowSelectScalar = {
    id?: boolean
    bkuImportId?: boolean
    tanggal?: boolean
    kodeKegiatan?: boolean
    kodeRekening?: boolean
    bpuCode?: boolean
    bpuNumber?: boolean
    uraian?: boolean
    penerimaan?: boolean
    pengeluaran?: boolean
    saldo?: boolean
    pageIndex?: boolean
    createdAt?: boolean
  }

  export type BKURowOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "bkuImportId" | "tanggal" | "kodeKegiatan" | "kodeRekening" | "bpuCode" | "bpuNumber" | "uraian" | "penerimaan" | "pengeluaran" | "saldo" | "pageIndex" | "createdAt", ExtArgs["result"]["bKURow"]>
  export type BKURowInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    bkuImport?: boolean | BKUImportDefaultArgs<ExtArgs>
  }
  export type BKURowIncludeCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    bkuImport?: boolean | BKUImportDefaultArgs<ExtArgs>
  }
  export type BKURowIncludeUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    bkuImport?: boolean | BKUImportDefaultArgs<ExtArgs>
  }

  export type $BKURowPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "BKURow"
    objects: {
      bkuImport: Prisma.$BKUImportPayload<ExtArgs>
    }
    scalars: $Extensions.GetPayloadResult<{
      id: string
      bkuImportId: string
      tanggal: Date
      kodeKegiatan: string | null
      kodeRekening: string | null
      bpuCode: string | null
      bpuNumber: number | null
      uraian: string
      penerimaan: number
      pengeluaran: number
      saldo: number
      pageIndex: number | null
      createdAt: Date
    }, ExtArgs["result"]["bKURow"]>
    composites: {}
  }

  type BKURowGetPayload<S extends boolean | null | undefined | BKURowDefaultArgs> = $Result.GetResult<Prisma.$BKURowPayload, S>

  type BKURowCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<BKURowFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: BKURowCountAggregateInputType | true
    }

  export interface BKURowDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['BKURow'], meta: { name: 'BKURow' } }
    /**
     * Find zero or one BKURow that matches the filter.
     * @param {BKURowFindUniqueArgs} args - Arguments to find a BKURow
     * @example
     * // Get one BKURow
     * const bKURow = await prisma.bKURow.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends BKURowFindUniqueArgs>(args: SelectSubset<T, BKURowFindUniqueArgs<ExtArgs>>): Prisma__BKURowClient<$Result.GetResult<Prisma.$BKURowPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one BKURow that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {BKURowFindUniqueOrThrowArgs} args - Arguments to find a BKURow
     * @example
     * // Get one BKURow
     * const bKURow = await prisma.bKURow.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends BKURowFindUniqueOrThrowArgs>(args: SelectSubset<T, BKURowFindUniqueOrThrowArgs<ExtArgs>>): Prisma__BKURowClient<$Result.GetResult<Prisma.$BKURowPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first BKURow that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {BKURowFindFirstArgs} args - Arguments to find a BKURow
     * @example
     * // Get one BKURow
     * const bKURow = await prisma.bKURow.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends BKURowFindFirstArgs>(args?: SelectSubset<T, BKURowFindFirstArgs<ExtArgs>>): Prisma__BKURowClient<$Result.GetResult<Prisma.$BKURowPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first BKURow that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {BKURowFindFirstOrThrowArgs} args - Arguments to find a BKURow
     * @example
     * // Get one BKURow
     * const bKURow = await prisma.bKURow.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends BKURowFindFirstOrThrowArgs>(args?: SelectSubset<T, BKURowFindFirstOrThrowArgs<ExtArgs>>): Prisma__BKURowClient<$Result.GetResult<Prisma.$BKURowPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more BKURows that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {BKURowFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all BKURows
     * const bKURows = await prisma.bKURow.findMany()
     * 
     * // Get first 10 BKURows
     * const bKURows = await prisma.bKURow.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const bKURowWithIdOnly = await prisma.bKURow.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends BKURowFindManyArgs>(args?: SelectSubset<T, BKURowFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$BKURowPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a BKURow.
     * @param {BKURowCreateArgs} args - Arguments to create a BKURow.
     * @example
     * // Create one BKURow
     * const BKURow = await prisma.bKURow.create({
     *   data: {
     *     // ... data to create a BKURow
     *   }
     * })
     * 
     */
    create<T extends BKURowCreateArgs>(args: SelectSubset<T, BKURowCreateArgs<ExtArgs>>): Prisma__BKURowClient<$Result.GetResult<Prisma.$BKURowPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many BKURows.
     * @param {BKURowCreateManyArgs} args - Arguments to create many BKURows.
     * @example
     * // Create many BKURows
     * const bKURow = await prisma.bKURow.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends BKURowCreateManyArgs>(args?: SelectSubset<T, BKURowCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many BKURows and returns the data saved in the database.
     * @param {BKURowCreateManyAndReturnArgs} args - Arguments to create many BKURows.
     * @example
     * // Create many BKURows
     * const bKURow = await prisma.bKURow.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many BKURows and only return the `id`
     * const bKURowWithIdOnly = await prisma.bKURow.createManyAndReturn({
     *   select: { id: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends BKURowCreateManyAndReturnArgs>(args?: SelectSubset<T, BKURowCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$BKURowPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a BKURow.
     * @param {BKURowDeleteArgs} args - Arguments to delete one BKURow.
     * @example
     * // Delete one BKURow
     * const BKURow = await prisma.bKURow.delete({
     *   where: {
     *     // ... filter to delete one BKURow
     *   }
     * })
     * 
     */
    delete<T extends BKURowDeleteArgs>(args: SelectSubset<T, BKURowDeleteArgs<ExtArgs>>): Prisma__BKURowClient<$Result.GetResult<Prisma.$BKURowPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one BKURow.
     * @param {BKURowUpdateArgs} args - Arguments to update one BKURow.
     * @example
     * // Update one BKURow
     * const bKURow = await prisma.bKURow.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends BKURowUpdateArgs>(args: SelectSubset<T, BKURowUpdateArgs<ExtArgs>>): Prisma__BKURowClient<$Result.GetResult<Prisma.$BKURowPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more BKURows.
     * @param {BKURowDeleteManyArgs} args - Arguments to filter BKURows to delete.
     * @example
     * // Delete a few BKURows
     * const { count } = await prisma.bKURow.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends BKURowDeleteManyArgs>(args?: SelectSubset<T, BKURowDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more BKURows.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {BKURowUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many BKURows
     * const bKURow = await prisma.bKURow.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends BKURowUpdateManyArgs>(args: SelectSubset<T, BKURowUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more BKURows and returns the data updated in the database.
     * @param {BKURowUpdateManyAndReturnArgs} args - Arguments to update many BKURows.
     * @example
     * // Update many BKURows
     * const bKURow = await prisma.bKURow.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more BKURows and only return the `id`
     * const bKURowWithIdOnly = await prisma.bKURow.updateManyAndReturn({
     *   select: { id: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends BKURowUpdateManyAndReturnArgs>(args: SelectSubset<T, BKURowUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$BKURowPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one BKURow.
     * @param {BKURowUpsertArgs} args - Arguments to update or create a BKURow.
     * @example
     * // Update or create a BKURow
     * const bKURow = await prisma.bKURow.upsert({
     *   create: {
     *     // ... data to create a BKURow
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the BKURow we want to update
     *   }
     * })
     */
    upsert<T extends BKURowUpsertArgs>(args: SelectSubset<T, BKURowUpsertArgs<ExtArgs>>): Prisma__BKURowClient<$Result.GetResult<Prisma.$BKURowPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of BKURows.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {BKURowCountArgs} args - Arguments to filter BKURows to count.
     * @example
     * // Count the number of BKURows
     * const count = await prisma.bKURow.count({
     *   where: {
     *     // ... the filter for the BKURows we want to count
     *   }
     * })
    **/
    count<T extends BKURowCountArgs>(
      args?: Subset<T, BKURowCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], BKURowCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a BKURow.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {BKURowAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends BKURowAggregateArgs>(args: Subset<T, BKURowAggregateArgs>): Prisma.PrismaPromise<GetBKURowAggregateType<T>>

    /**
     * Group by BKURow.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {BKURowGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends BKURowGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: BKURowGroupByArgs['orderBy'] }
        : { orderBy?: BKURowGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, BKURowGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetBKURowGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the BKURow model
   */
  readonly fields: BKURowFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for BKURow.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__BKURowClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    bkuImport<T extends BKUImportDefaultArgs<ExtArgs> = {}>(args?: Subset<T, BKUImportDefaultArgs<ExtArgs>>): Prisma__BKUImportClient<$Result.GetResult<Prisma.$BKUImportPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the BKURow model
   */
  interface BKURowFieldRefs {
    readonly id: FieldRef<"BKURow", 'String'>
    readonly bkuImportId: FieldRef<"BKURow", 'String'>
    readonly tanggal: FieldRef<"BKURow", 'DateTime'>
    readonly kodeKegiatan: FieldRef<"BKURow", 'String'>
    readonly kodeRekening: FieldRef<"BKURow", 'String'>
    readonly bpuCode: FieldRef<"BKURow", 'String'>
    readonly bpuNumber: FieldRef<"BKURow", 'Int'>
    readonly uraian: FieldRef<"BKURow", 'String'>
    readonly penerimaan: FieldRef<"BKURow", 'Int'>
    readonly pengeluaran: FieldRef<"BKURow", 'Int'>
    readonly saldo: FieldRef<"BKURow", 'Int'>
    readonly pageIndex: FieldRef<"BKURow", 'Int'>
    readonly createdAt: FieldRef<"BKURow", 'DateTime'>
  }
    

  // Custom InputTypes
  /**
   * BKURow findUnique
   */
  export type BKURowFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the BKURow
     */
    select?: BKURowSelect<ExtArgs> | null
    /**
     * Omit specific fields from the BKURow
     */
    omit?: BKURowOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: BKURowInclude<ExtArgs> | null
    /**
     * Filter, which BKURow to fetch.
     */
    where: BKURowWhereUniqueInput
  }

  /**
   * BKURow findUniqueOrThrow
   */
  export type BKURowFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the BKURow
     */
    select?: BKURowSelect<ExtArgs> | null
    /**
     * Omit specific fields from the BKURow
     */
    omit?: BKURowOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: BKURowInclude<ExtArgs> | null
    /**
     * Filter, which BKURow to fetch.
     */
    where: BKURowWhereUniqueInput
  }

  /**
   * BKURow findFirst
   */
  export type BKURowFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the BKURow
     */
    select?: BKURowSelect<ExtArgs> | null
    /**
     * Omit specific fields from the BKURow
     */
    omit?: BKURowOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: BKURowInclude<ExtArgs> | null
    /**
     * Filter, which BKURow to fetch.
     */
    where?: BKURowWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of BKURows to fetch.
     */
    orderBy?: BKURowOrderByWithRelationInput | BKURowOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for BKURows.
     */
    cursor?: BKURowWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` BKURows from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` BKURows.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of BKURows.
     */
    distinct?: BKURowScalarFieldEnum | BKURowScalarFieldEnum[]
  }

  /**
   * BKURow findFirstOrThrow
   */
  export type BKURowFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the BKURow
     */
    select?: BKURowSelect<ExtArgs> | null
    /**
     * Omit specific fields from the BKURow
     */
    omit?: BKURowOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: BKURowInclude<ExtArgs> | null
    /**
     * Filter, which BKURow to fetch.
     */
    where?: BKURowWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of BKURows to fetch.
     */
    orderBy?: BKURowOrderByWithRelationInput | BKURowOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for BKURows.
     */
    cursor?: BKURowWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` BKURows from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` BKURows.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of BKURows.
     */
    distinct?: BKURowScalarFieldEnum | BKURowScalarFieldEnum[]
  }

  /**
   * BKURow findMany
   */
  export type BKURowFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the BKURow
     */
    select?: BKURowSelect<ExtArgs> | null
    /**
     * Omit specific fields from the BKURow
     */
    omit?: BKURowOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: BKURowInclude<ExtArgs> | null
    /**
     * Filter, which BKURows to fetch.
     */
    where?: BKURowWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of BKURows to fetch.
     */
    orderBy?: BKURowOrderByWithRelationInput | BKURowOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing BKURows.
     */
    cursor?: BKURowWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` BKURows from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` BKURows.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of BKURows.
     */
    distinct?: BKURowScalarFieldEnum | BKURowScalarFieldEnum[]
  }

  /**
   * BKURow create
   */
  export type BKURowCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the BKURow
     */
    select?: BKURowSelect<ExtArgs> | null
    /**
     * Omit specific fields from the BKURow
     */
    omit?: BKURowOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: BKURowInclude<ExtArgs> | null
    /**
     * The data needed to create a BKURow.
     */
    data: XOR<BKURowCreateInput, BKURowUncheckedCreateInput>
  }

  /**
   * BKURow createMany
   */
  export type BKURowCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many BKURows.
     */
    data: BKURowCreateManyInput | BKURowCreateManyInput[]
  }

  /**
   * BKURow createManyAndReturn
   */
  export type BKURowCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the BKURow
     */
    select?: BKURowSelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the BKURow
     */
    omit?: BKURowOmit<ExtArgs> | null
    /**
     * The data used to create many BKURows.
     */
    data: BKURowCreateManyInput | BKURowCreateManyInput[]
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: BKURowIncludeCreateManyAndReturn<ExtArgs> | null
  }

  /**
   * BKURow update
   */
  export type BKURowUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the BKURow
     */
    select?: BKURowSelect<ExtArgs> | null
    /**
     * Omit specific fields from the BKURow
     */
    omit?: BKURowOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: BKURowInclude<ExtArgs> | null
    /**
     * The data needed to update a BKURow.
     */
    data: XOR<BKURowUpdateInput, BKURowUncheckedUpdateInput>
    /**
     * Choose, which BKURow to update.
     */
    where: BKURowWhereUniqueInput
  }

  /**
   * BKURow updateMany
   */
  export type BKURowUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update BKURows.
     */
    data: XOR<BKURowUpdateManyMutationInput, BKURowUncheckedUpdateManyInput>
    /**
     * Filter which BKURows to update
     */
    where?: BKURowWhereInput
    /**
     * Limit how many BKURows to update.
     */
    limit?: number
  }

  /**
   * BKURow updateManyAndReturn
   */
  export type BKURowUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the BKURow
     */
    select?: BKURowSelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the BKURow
     */
    omit?: BKURowOmit<ExtArgs> | null
    /**
     * The data used to update BKURows.
     */
    data: XOR<BKURowUpdateManyMutationInput, BKURowUncheckedUpdateManyInput>
    /**
     * Filter which BKURows to update
     */
    where?: BKURowWhereInput
    /**
     * Limit how many BKURows to update.
     */
    limit?: number
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: BKURowIncludeUpdateManyAndReturn<ExtArgs> | null
  }

  /**
   * BKURow upsert
   */
  export type BKURowUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the BKURow
     */
    select?: BKURowSelect<ExtArgs> | null
    /**
     * Omit specific fields from the BKURow
     */
    omit?: BKURowOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: BKURowInclude<ExtArgs> | null
    /**
     * The filter to search for the BKURow to update in case it exists.
     */
    where: BKURowWhereUniqueInput
    /**
     * In case the BKURow found by the `where` argument doesn't exist, create a new BKURow with this data.
     */
    create: XOR<BKURowCreateInput, BKURowUncheckedCreateInput>
    /**
     * In case the BKURow was found with the provided `where` argument, update it with this data.
     */
    update: XOR<BKURowUpdateInput, BKURowUncheckedUpdateInput>
  }

  /**
   * BKURow delete
   */
  export type BKURowDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the BKURow
     */
    select?: BKURowSelect<ExtArgs> | null
    /**
     * Omit specific fields from the BKURow
     */
    omit?: BKURowOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: BKURowInclude<ExtArgs> | null
    /**
     * Filter which BKURow to delete.
     */
    where: BKURowWhereUniqueInput
  }

  /**
   * BKURow deleteMany
   */
  export type BKURowDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which BKURows to delete
     */
    where?: BKURowWhereInput
    /**
     * Limit how many BKURows to delete.
     */
    limit?: number
  }

  /**
   * BKURow without action
   */
  export type BKURowDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the BKURow
     */
    select?: BKURowSelect<ExtArgs> | null
    /**
     * Omit specific fields from the BKURow
     */
    omit?: BKURowOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: BKURowInclude<ExtArgs> | null
  }


  /**
   * Model BPUGroup
   */

  export type AggregateBPUGroup = {
    _count: BPUGroupCountAggregateOutputType | null
    _avg: BPUGroupAvgAggregateOutputType | null
    _sum: BPUGroupSumAggregateOutputType | null
    _min: BPUGroupMinAggregateOutputType | null
    _max: BPUGroupMaxAggregateOutputType | null
  }

  export type BPUGroupAvgAggregateOutputType = {
    bpuNumber: number | null
    totalAmount: number | null
  }

  export type BPUGroupSumAggregateOutputType = {
    bpuNumber: number | null
    totalAmount: number | null
  }

  export type BPUGroupMinAggregateOutputType = {
    id: string | null
    bkuImportId: string | null
    bpuCode: string | null
    bpuNumber: number | null
    tanggal: Date | null
    totalAmount: number | null
    matchedVendorRuleId: string | null
    overrideRecipient: string | null
    overridePaymentFor: string | null
    status: $Enums.BPUGroupStatus | null
    createdAt: Date | null
    updatedAt: Date | null
  }

  export type BPUGroupMaxAggregateOutputType = {
    id: string | null
    bkuImportId: string | null
    bpuCode: string | null
    bpuNumber: number | null
    tanggal: Date | null
    totalAmount: number | null
    matchedVendorRuleId: string | null
    overrideRecipient: string | null
    overridePaymentFor: string | null
    status: $Enums.BPUGroupStatus | null
    createdAt: Date | null
    updatedAt: Date | null
  }

  export type BPUGroupCountAggregateOutputType = {
    id: number
    bkuImportId: number
    bpuCode: number
    bpuNumber: number
    tanggal: number
    totalAmount: number
    matchedVendorRuleId: number
    overrideRecipient: number
    overridePaymentFor: number
    status: number
    createdAt: number
    updatedAt: number
    _all: number
  }


  export type BPUGroupAvgAggregateInputType = {
    bpuNumber?: true
    totalAmount?: true
  }

  export type BPUGroupSumAggregateInputType = {
    bpuNumber?: true
    totalAmount?: true
  }

  export type BPUGroupMinAggregateInputType = {
    id?: true
    bkuImportId?: true
    bpuCode?: true
    bpuNumber?: true
    tanggal?: true
    totalAmount?: true
    matchedVendorRuleId?: true
    overrideRecipient?: true
    overridePaymentFor?: true
    status?: true
    createdAt?: true
    updatedAt?: true
  }

  export type BPUGroupMaxAggregateInputType = {
    id?: true
    bkuImportId?: true
    bpuCode?: true
    bpuNumber?: true
    tanggal?: true
    totalAmount?: true
    matchedVendorRuleId?: true
    overrideRecipient?: true
    overridePaymentFor?: true
    status?: true
    createdAt?: true
    updatedAt?: true
  }

  export type BPUGroupCountAggregateInputType = {
    id?: true
    bkuImportId?: true
    bpuCode?: true
    bpuNumber?: true
    tanggal?: true
    totalAmount?: true
    matchedVendorRuleId?: true
    overrideRecipient?: true
    overridePaymentFor?: true
    status?: true
    createdAt?: true
    updatedAt?: true
    _all?: true
  }

  export type BPUGroupAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which BPUGroup to aggregate.
     */
    where?: BPUGroupWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of BPUGroups to fetch.
     */
    orderBy?: BPUGroupOrderByWithRelationInput | BPUGroupOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: BPUGroupWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` BPUGroups from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` BPUGroups.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned BPUGroups
    **/
    _count?: true | BPUGroupCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: BPUGroupAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: BPUGroupSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: BPUGroupMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: BPUGroupMaxAggregateInputType
  }

  export type GetBPUGroupAggregateType<T extends BPUGroupAggregateArgs> = {
        [P in keyof T & keyof AggregateBPUGroup]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateBPUGroup[P]>
      : GetScalarType<T[P], AggregateBPUGroup[P]>
  }




  export type BPUGroupGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: BPUGroupWhereInput
    orderBy?: BPUGroupOrderByWithAggregationInput | BPUGroupOrderByWithAggregationInput[]
    by: BPUGroupScalarFieldEnum[] | BPUGroupScalarFieldEnum
    having?: BPUGroupScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: BPUGroupCountAggregateInputType | true
    _avg?: BPUGroupAvgAggregateInputType
    _sum?: BPUGroupSumAggregateInputType
    _min?: BPUGroupMinAggregateInputType
    _max?: BPUGroupMaxAggregateInputType
  }

  export type BPUGroupGroupByOutputType = {
    id: string
    bkuImportId: string
    bpuCode: string
    bpuNumber: number
    tanggal: Date
    totalAmount: number
    matchedVendorRuleId: string | null
    overrideRecipient: string | null
    overridePaymentFor: string | null
    status: $Enums.BPUGroupStatus
    createdAt: Date
    updatedAt: Date
    _count: BPUGroupCountAggregateOutputType | null
    _avg: BPUGroupAvgAggregateOutputType | null
    _sum: BPUGroupSumAggregateOutputType | null
    _min: BPUGroupMinAggregateOutputType | null
    _max: BPUGroupMaxAggregateOutputType | null
  }

  type GetBPUGroupGroupByPayload<T extends BPUGroupGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<BPUGroupGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof BPUGroupGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], BPUGroupGroupByOutputType[P]>
            : GetScalarType<T[P], BPUGroupGroupByOutputType[P]>
        }
      >
    >


  export type BPUGroupSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    bkuImportId?: boolean
    bpuCode?: boolean
    bpuNumber?: boolean
    tanggal?: boolean
    totalAmount?: boolean
    matchedVendorRuleId?: boolean
    overrideRecipient?: boolean
    overridePaymentFor?: boolean
    status?: boolean
    createdAt?: boolean
    updatedAt?: boolean
    bkuImport?: boolean | BKUImportDefaultArgs<ExtArgs>
    matchedVendorRule?: boolean | BPUGroup$matchedVendorRuleArgs<ExtArgs>
    spmDocument?: boolean | BPUGroup$spmDocumentArgs<ExtArgs>
  }, ExtArgs["result"]["bPUGroup"]>

  export type BPUGroupSelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    bkuImportId?: boolean
    bpuCode?: boolean
    bpuNumber?: boolean
    tanggal?: boolean
    totalAmount?: boolean
    matchedVendorRuleId?: boolean
    overrideRecipient?: boolean
    overridePaymentFor?: boolean
    status?: boolean
    createdAt?: boolean
    updatedAt?: boolean
    bkuImport?: boolean | BKUImportDefaultArgs<ExtArgs>
    matchedVendorRule?: boolean | BPUGroup$matchedVendorRuleArgs<ExtArgs>
  }, ExtArgs["result"]["bPUGroup"]>

  export type BPUGroupSelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    bkuImportId?: boolean
    bpuCode?: boolean
    bpuNumber?: boolean
    tanggal?: boolean
    totalAmount?: boolean
    matchedVendorRuleId?: boolean
    overrideRecipient?: boolean
    overridePaymentFor?: boolean
    status?: boolean
    createdAt?: boolean
    updatedAt?: boolean
    bkuImport?: boolean | BKUImportDefaultArgs<ExtArgs>
    matchedVendorRule?: boolean | BPUGroup$matchedVendorRuleArgs<ExtArgs>
  }, ExtArgs["result"]["bPUGroup"]>

  export type BPUGroupSelectScalar = {
    id?: boolean
    bkuImportId?: boolean
    bpuCode?: boolean
    bpuNumber?: boolean
    tanggal?: boolean
    totalAmount?: boolean
    matchedVendorRuleId?: boolean
    overrideRecipient?: boolean
    overridePaymentFor?: boolean
    status?: boolean
    createdAt?: boolean
    updatedAt?: boolean
  }

  export type BPUGroupOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "bkuImportId" | "bpuCode" | "bpuNumber" | "tanggal" | "totalAmount" | "matchedVendorRuleId" | "overrideRecipient" | "overridePaymentFor" | "status" | "createdAt" | "updatedAt", ExtArgs["result"]["bPUGroup"]>
  export type BPUGroupInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    bkuImport?: boolean | BKUImportDefaultArgs<ExtArgs>
    matchedVendorRule?: boolean | BPUGroup$matchedVendorRuleArgs<ExtArgs>
    spmDocument?: boolean | BPUGroup$spmDocumentArgs<ExtArgs>
  }
  export type BPUGroupIncludeCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    bkuImport?: boolean | BKUImportDefaultArgs<ExtArgs>
    matchedVendorRule?: boolean | BPUGroup$matchedVendorRuleArgs<ExtArgs>
  }
  export type BPUGroupIncludeUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    bkuImport?: boolean | BKUImportDefaultArgs<ExtArgs>
    matchedVendorRule?: boolean | BPUGroup$matchedVendorRuleArgs<ExtArgs>
  }

  export type $BPUGroupPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "BPUGroup"
    objects: {
      bkuImport: Prisma.$BKUImportPayload<ExtArgs>
      matchedVendorRule: Prisma.$VendorRulePayload<ExtArgs> | null
      spmDocument: Prisma.$SPMDocumentPayload<ExtArgs> | null
    }
    scalars: $Extensions.GetPayloadResult<{
      id: string
      bkuImportId: string
      bpuCode: string
      bpuNumber: number
      tanggal: Date
      totalAmount: number
      matchedVendorRuleId: string | null
      overrideRecipient: string | null
      overridePaymentFor: string | null
      status: $Enums.BPUGroupStatus
      createdAt: Date
      updatedAt: Date
    }, ExtArgs["result"]["bPUGroup"]>
    composites: {}
  }

  type BPUGroupGetPayload<S extends boolean | null | undefined | BPUGroupDefaultArgs> = $Result.GetResult<Prisma.$BPUGroupPayload, S>

  type BPUGroupCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<BPUGroupFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: BPUGroupCountAggregateInputType | true
    }

  export interface BPUGroupDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['BPUGroup'], meta: { name: 'BPUGroup' } }
    /**
     * Find zero or one BPUGroup that matches the filter.
     * @param {BPUGroupFindUniqueArgs} args - Arguments to find a BPUGroup
     * @example
     * // Get one BPUGroup
     * const bPUGroup = await prisma.bPUGroup.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends BPUGroupFindUniqueArgs>(args: SelectSubset<T, BPUGroupFindUniqueArgs<ExtArgs>>): Prisma__BPUGroupClient<$Result.GetResult<Prisma.$BPUGroupPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one BPUGroup that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {BPUGroupFindUniqueOrThrowArgs} args - Arguments to find a BPUGroup
     * @example
     * // Get one BPUGroup
     * const bPUGroup = await prisma.bPUGroup.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends BPUGroupFindUniqueOrThrowArgs>(args: SelectSubset<T, BPUGroupFindUniqueOrThrowArgs<ExtArgs>>): Prisma__BPUGroupClient<$Result.GetResult<Prisma.$BPUGroupPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first BPUGroup that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {BPUGroupFindFirstArgs} args - Arguments to find a BPUGroup
     * @example
     * // Get one BPUGroup
     * const bPUGroup = await prisma.bPUGroup.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends BPUGroupFindFirstArgs>(args?: SelectSubset<T, BPUGroupFindFirstArgs<ExtArgs>>): Prisma__BPUGroupClient<$Result.GetResult<Prisma.$BPUGroupPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first BPUGroup that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {BPUGroupFindFirstOrThrowArgs} args - Arguments to find a BPUGroup
     * @example
     * // Get one BPUGroup
     * const bPUGroup = await prisma.bPUGroup.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends BPUGroupFindFirstOrThrowArgs>(args?: SelectSubset<T, BPUGroupFindFirstOrThrowArgs<ExtArgs>>): Prisma__BPUGroupClient<$Result.GetResult<Prisma.$BPUGroupPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more BPUGroups that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {BPUGroupFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all BPUGroups
     * const bPUGroups = await prisma.bPUGroup.findMany()
     * 
     * // Get first 10 BPUGroups
     * const bPUGroups = await prisma.bPUGroup.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const bPUGroupWithIdOnly = await prisma.bPUGroup.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends BPUGroupFindManyArgs>(args?: SelectSubset<T, BPUGroupFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$BPUGroupPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a BPUGroup.
     * @param {BPUGroupCreateArgs} args - Arguments to create a BPUGroup.
     * @example
     * // Create one BPUGroup
     * const BPUGroup = await prisma.bPUGroup.create({
     *   data: {
     *     // ... data to create a BPUGroup
     *   }
     * })
     * 
     */
    create<T extends BPUGroupCreateArgs>(args: SelectSubset<T, BPUGroupCreateArgs<ExtArgs>>): Prisma__BPUGroupClient<$Result.GetResult<Prisma.$BPUGroupPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many BPUGroups.
     * @param {BPUGroupCreateManyArgs} args - Arguments to create many BPUGroups.
     * @example
     * // Create many BPUGroups
     * const bPUGroup = await prisma.bPUGroup.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends BPUGroupCreateManyArgs>(args?: SelectSubset<T, BPUGroupCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many BPUGroups and returns the data saved in the database.
     * @param {BPUGroupCreateManyAndReturnArgs} args - Arguments to create many BPUGroups.
     * @example
     * // Create many BPUGroups
     * const bPUGroup = await prisma.bPUGroup.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many BPUGroups and only return the `id`
     * const bPUGroupWithIdOnly = await prisma.bPUGroup.createManyAndReturn({
     *   select: { id: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends BPUGroupCreateManyAndReturnArgs>(args?: SelectSubset<T, BPUGroupCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$BPUGroupPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a BPUGroup.
     * @param {BPUGroupDeleteArgs} args - Arguments to delete one BPUGroup.
     * @example
     * // Delete one BPUGroup
     * const BPUGroup = await prisma.bPUGroup.delete({
     *   where: {
     *     // ... filter to delete one BPUGroup
     *   }
     * })
     * 
     */
    delete<T extends BPUGroupDeleteArgs>(args: SelectSubset<T, BPUGroupDeleteArgs<ExtArgs>>): Prisma__BPUGroupClient<$Result.GetResult<Prisma.$BPUGroupPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one BPUGroup.
     * @param {BPUGroupUpdateArgs} args - Arguments to update one BPUGroup.
     * @example
     * // Update one BPUGroup
     * const bPUGroup = await prisma.bPUGroup.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends BPUGroupUpdateArgs>(args: SelectSubset<T, BPUGroupUpdateArgs<ExtArgs>>): Prisma__BPUGroupClient<$Result.GetResult<Prisma.$BPUGroupPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more BPUGroups.
     * @param {BPUGroupDeleteManyArgs} args - Arguments to filter BPUGroups to delete.
     * @example
     * // Delete a few BPUGroups
     * const { count } = await prisma.bPUGroup.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends BPUGroupDeleteManyArgs>(args?: SelectSubset<T, BPUGroupDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more BPUGroups.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {BPUGroupUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many BPUGroups
     * const bPUGroup = await prisma.bPUGroup.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends BPUGroupUpdateManyArgs>(args: SelectSubset<T, BPUGroupUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more BPUGroups and returns the data updated in the database.
     * @param {BPUGroupUpdateManyAndReturnArgs} args - Arguments to update many BPUGroups.
     * @example
     * // Update many BPUGroups
     * const bPUGroup = await prisma.bPUGroup.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more BPUGroups and only return the `id`
     * const bPUGroupWithIdOnly = await prisma.bPUGroup.updateManyAndReturn({
     *   select: { id: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends BPUGroupUpdateManyAndReturnArgs>(args: SelectSubset<T, BPUGroupUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$BPUGroupPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one BPUGroup.
     * @param {BPUGroupUpsertArgs} args - Arguments to update or create a BPUGroup.
     * @example
     * // Update or create a BPUGroup
     * const bPUGroup = await prisma.bPUGroup.upsert({
     *   create: {
     *     // ... data to create a BPUGroup
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the BPUGroup we want to update
     *   }
     * })
     */
    upsert<T extends BPUGroupUpsertArgs>(args: SelectSubset<T, BPUGroupUpsertArgs<ExtArgs>>): Prisma__BPUGroupClient<$Result.GetResult<Prisma.$BPUGroupPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of BPUGroups.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {BPUGroupCountArgs} args - Arguments to filter BPUGroups to count.
     * @example
     * // Count the number of BPUGroups
     * const count = await prisma.bPUGroup.count({
     *   where: {
     *     // ... the filter for the BPUGroups we want to count
     *   }
     * })
    **/
    count<T extends BPUGroupCountArgs>(
      args?: Subset<T, BPUGroupCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], BPUGroupCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a BPUGroup.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {BPUGroupAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends BPUGroupAggregateArgs>(args: Subset<T, BPUGroupAggregateArgs>): Prisma.PrismaPromise<GetBPUGroupAggregateType<T>>

    /**
     * Group by BPUGroup.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {BPUGroupGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends BPUGroupGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: BPUGroupGroupByArgs['orderBy'] }
        : { orderBy?: BPUGroupGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, BPUGroupGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetBPUGroupGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the BPUGroup model
   */
  readonly fields: BPUGroupFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for BPUGroup.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__BPUGroupClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    bkuImport<T extends BKUImportDefaultArgs<ExtArgs> = {}>(args?: Subset<T, BKUImportDefaultArgs<ExtArgs>>): Prisma__BKUImportClient<$Result.GetResult<Prisma.$BKUImportPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    matchedVendorRule<T extends BPUGroup$matchedVendorRuleArgs<ExtArgs> = {}>(args?: Subset<T, BPUGroup$matchedVendorRuleArgs<ExtArgs>>): Prisma__VendorRuleClient<$Result.GetResult<Prisma.$VendorRulePayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>
    spmDocument<T extends BPUGroup$spmDocumentArgs<ExtArgs> = {}>(args?: Subset<T, BPUGroup$spmDocumentArgs<ExtArgs>>): Prisma__SPMDocumentClient<$Result.GetResult<Prisma.$SPMDocumentPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the BPUGroup model
   */
  interface BPUGroupFieldRefs {
    readonly id: FieldRef<"BPUGroup", 'String'>
    readonly bkuImportId: FieldRef<"BPUGroup", 'String'>
    readonly bpuCode: FieldRef<"BPUGroup", 'String'>
    readonly bpuNumber: FieldRef<"BPUGroup", 'Int'>
    readonly tanggal: FieldRef<"BPUGroup", 'DateTime'>
    readonly totalAmount: FieldRef<"BPUGroup", 'Int'>
    readonly matchedVendorRuleId: FieldRef<"BPUGroup", 'String'>
    readonly overrideRecipient: FieldRef<"BPUGroup", 'String'>
    readonly overridePaymentFor: FieldRef<"BPUGroup", 'String'>
    readonly status: FieldRef<"BPUGroup", 'BPUGroupStatus'>
    readonly createdAt: FieldRef<"BPUGroup", 'DateTime'>
    readonly updatedAt: FieldRef<"BPUGroup", 'DateTime'>
  }
    

  // Custom InputTypes
  /**
   * BPUGroup findUnique
   */
  export type BPUGroupFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the BPUGroup
     */
    select?: BPUGroupSelect<ExtArgs> | null
    /**
     * Omit specific fields from the BPUGroup
     */
    omit?: BPUGroupOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: BPUGroupInclude<ExtArgs> | null
    /**
     * Filter, which BPUGroup to fetch.
     */
    where: BPUGroupWhereUniqueInput
  }

  /**
   * BPUGroup findUniqueOrThrow
   */
  export type BPUGroupFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the BPUGroup
     */
    select?: BPUGroupSelect<ExtArgs> | null
    /**
     * Omit specific fields from the BPUGroup
     */
    omit?: BPUGroupOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: BPUGroupInclude<ExtArgs> | null
    /**
     * Filter, which BPUGroup to fetch.
     */
    where: BPUGroupWhereUniqueInput
  }

  /**
   * BPUGroup findFirst
   */
  export type BPUGroupFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the BPUGroup
     */
    select?: BPUGroupSelect<ExtArgs> | null
    /**
     * Omit specific fields from the BPUGroup
     */
    omit?: BPUGroupOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: BPUGroupInclude<ExtArgs> | null
    /**
     * Filter, which BPUGroup to fetch.
     */
    where?: BPUGroupWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of BPUGroups to fetch.
     */
    orderBy?: BPUGroupOrderByWithRelationInput | BPUGroupOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for BPUGroups.
     */
    cursor?: BPUGroupWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` BPUGroups from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` BPUGroups.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of BPUGroups.
     */
    distinct?: BPUGroupScalarFieldEnum | BPUGroupScalarFieldEnum[]
  }

  /**
   * BPUGroup findFirstOrThrow
   */
  export type BPUGroupFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the BPUGroup
     */
    select?: BPUGroupSelect<ExtArgs> | null
    /**
     * Omit specific fields from the BPUGroup
     */
    omit?: BPUGroupOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: BPUGroupInclude<ExtArgs> | null
    /**
     * Filter, which BPUGroup to fetch.
     */
    where?: BPUGroupWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of BPUGroups to fetch.
     */
    orderBy?: BPUGroupOrderByWithRelationInput | BPUGroupOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for BPUGroups.
     */
    cursor?: BPUGroupWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` BPUGroups from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` BPUGroups.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of BPUGroups.
     */
    distinct?: BPUGroupScalarFieldEnum | BPUGroupScalarFieldEnum[]
  }

  /**
   * BPUGroup findMany
   */
  export type BPUGroupFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the BPUGroup
     */
    select?: BPUGroupSelect<ExtArgs> | null
    /**
     * Omit specific fields from the BPUGroup
     */
    omit?: BPUGroupOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: BPUGroupInclude<ExtArgs> | null
    /**
     * Filter, which BPUGroups to fetch.
     */
    where?: BPUGroupWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of BPUGroups to fetch.
     */
    orderBy?: BPUGroupOrderByWithRelationInput | BPUGroupOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing BPUGroups.
     */
    cursor?: BPUGroupWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` BPUGroups from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` BPUGroups.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of BPUGroups.
     */
    distinct?: BPUGroupScalarFieldEnum | BPUGroupScalarFieldEnum[]
  }

  /**
   * BPUGroup create
   */
  export type BPUGroupCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the BPUGroup
     */
    select?: BPUGroupSelect<ExtArgs> | null
    /**
     * Omit specific fields from the BPUGroup
     */
    omit?: BPUGroupOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: BPUGroupInclude<ExtArgs> | null
    /**
     * The data needed to create a BPUGroup.
     */
    data: XOR<BPUGroupCreateInput, BPUGroupUncheckedCreateInput>
  }

  /**
   * BPUGroup createMany
   */
  export type BPUGroupCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many BPUGroups.
     */
    data: BPUGroupCreateManyInput | BPUGroupCreateManyInput[]
  }

  /**
   * BPUGroup createManyAndReturn
   */
  export type BPUGroupCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the BPUGroup
     */
    select?: BPUGroupSelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the BPUGroup
     */
    omit?: BPUGroupOmit<ExtArgs> | null
    /**
     * The data used to create many BPUGroups.
     */
    data: BPUGroupCreateManyInput | BPUGroupCreateManyInput[]
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: BPUGroupIncludeCreateManyAndReturn<ExtArgs> | null
  }

  /**
   * BPUGroup update
   */
  export type BPUGroupUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the BPUGroup
     */
    select?: BPUGroupSelect<ExtArgs> | null
    /**
     * Omit specific fields from the BPUGroup
     */
    omit?: BPUGroupOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: BPUGroupInclude<ExtArgs> | null
    /**
     * The data needed to update a BPUGroup.
     */
    data: XOR<BPUGroupUpdateInput, BPUGroupUncheckedUpdateInput>
    /**
     * Choose, which BPUGroup to update.
     */
    where: BPUGroupWhereUniqueInput
  }

  /**
   * BPUGroup updateMany
   */
  export type BPUGroupUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update BPUGroups.
     */
    data: XOR<BPUGroupUpdateManyMutationInput, BPUGroupUncheckedUpdateManyInput>
    /**
     * Filter which BPUGroups to update
     */
    where?: BPUGroupWhereInput
    /**
     * Limit how many BPUGroups to update.
     */
    limit?: number
  }

  /**
   * BPUGroup updateManyAndReturn
   */
  export type BPUGroupUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the BPUGroup
     */
    select?: BPUGroupSelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the BPUGroup
     */
    omit?: BPUGroupOmit<ExtArgs> | null
    /**
     * The data used to update BPUGroups.
     */
    data: XOR<BPUGroupUpdateManyMutationInput, BPUGroupUncheckedUpdateManyInput>
    /**
     * Filter which BPUGroups to update
     */
    where?: BPUGroupWhereInput
    /**
     * Limit how many BPUGroups to update.
     */
    limit?: number
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: BPUGroupIncludeUpdateManyAndReturn<ExtArgs> | null
  }

  /**
   * BPUGroup upsert
   */
  export type BPUGroupUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the BPUGroup
     */
    select?: BPUGroupSelect<ExtArgs> | null
    /**
     * Omit specific fields from the BPUGroup
     */
    omit?: BPUGroupOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: BPUGroupInclude<ExtArgs> | null
    /**
     * The filter to search for the BPUGroup to update in case it exists.
     */
    where: BPUGroupWhereUniqueInput
    /**
     * In case the BPUGroup found by the `where` argument doesn't exist, create a new BPUGroup with this data.
     */
    create: XOR<BPUGroupCreateInput, BPUGroupUncheckedCreateInput>
    /**
     * In case the BPUGroup was found with the provided `where` argument, update it with this data.
     */
    update: XOR<BPUGroupUpdateInput, BPUGroupUncheckedUpdateInput>
  }

  /**
   * BPUGroup delete
   */
  export type BPUGroupDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the BPUGroup
     */
    select?: BPUGroupSelect<ExtArgs> | null
    /**
     * Omit specific fields from the BPUGroup
     */
    omit?: BPUGroupOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: BPUGroupInclude<ExtArgs> | null
    /**
     * Filter which BPUGroup to delete.
     */
    where: BPUGroupWhereUniqueInput
  }

  /**
   * BPUGroup deleteMany
   */
  export type BPUGroupDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which BPUGroups to delete
     */
    where?: BPUGroupWhereInput
    /**
     * Limit how many BPUGroups to delete.
     */
    limit?: number
  }

  /**
   * BPUGroup.matchedVendorRule
   */
  export type BPUGroup$matchedVendorRuleArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the VendorRule
     */
    select?: VendorRuleSelect<ExtArgs> | null
    /**
     * Omit specific fields from the VendorRule
     */
    omit?: VendorRuleOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: VendorRuleInclude<ExtArgs> | null
    where?: VendorRuleWhereInput
  }

  /**
   * BPUGroup.spmDocument
   */
  export type BPUGroup$spmDocumentArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SPMDocument
     */
    select?: SPMDocumentSelect<ExtArgs> | null
    /**
     * Omit specific fields from the SPMDocument
     */
    omit?: SPMDocumentOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SPMDocumentInclude<ExtArgs> | null
    where?: SPMDocumentWhereInput
  }

  /**
   * BPUGroup without action
   */
  export type BPUGroupDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the BPUGroup
     */
    select?: BPUGroupSelect<ExtArgs> | null
    /**
     * Omit specific fields from the BPUGroup
     */
    omit?: BPUGroupOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: BPUGroupInclude<ExtArgs> | null
  }


  /**
   * Model SPMDocument
   */

  export type AggregateSPMDocument = {
    _count: SPMDocumentCountAggregateOutputType | null
    _avg: SPMDocumentAvgAggregateOutputType | null
    _sum: SPMDocumentSumAggregateOutputType | null
    _min: SPMDocumentMinAggregateOutputType | null
    _max: SPMDocumentMaxAggregateOutputType | null
  }

  export type SPMDocumentAvgAggregateOutputType = {
    amount: number | null
  }

  export type SPMDocumentSumAggregateOutputType = {
    amount: number | null
  }

  export type SPMDocumentMinAggregateOutputType = {
    id: string | null
    bpuGroupId: string | null
    nomorSurat: string | null
    recipient: string | null
    amount: number | null
    terbilang: string | null
    paymentFor: string | null
    filePath: string | null
    generatedAt: Date | null
  }

  export type SPMDocumentMaxAggregateOutputType = {
    id: string | null
    bpuGroupId: string | null
    nomorSurat: string | null
    recipient: string | null
    amount: number | null
    terbilang: string | null
    paymentFor: string | null
    filePath: string | null
    generatedAt: Date | null
  }

  export type SPMDocumentCountAggregateOutputType = {
    id: number
    bpuGroupId: number
    nomorSurat: number
    recipient: number
    amount: number
    terbilang: number
    paymentFor: number
    filePath: number
    generatedAt: number
    _all: number
  }


  export type SPMDocumentAvgAggregateInputType = {
    amount?: true
  }

  export type SPMDocumentSumAggregateInputType = {
    amount?: true
  }

  export type SPMDocumentMinAggregateInputType = {
    id?: true
    bpuGroupId?: true
    nomorSurat?: true
    recipient?: true
    amount?: true
    terbilang?: true
    paymentFor?: true
    filePath?: true
    generatedAt?: true
  }

  export type SPMDocumentMaxAggregateInputType = {
    id?: true
    bpuGroupId?: true
    nomorSurat?: true
    recipient?: true
    amount?: true
    terbilang?: true
    paymentFor?: true
    filePath?: true
    generatedAt?: true
  }

  export type SPMDocumentCountAggregateInputType = {
    id?: true
    bpuGroupId?: true
    nomorSurat?: true
    recipient?: true
    amount?: true
    terbilang?: true
    paymentFor?: true
    filePath?: true
    generatedAt?: true
    _all?: true
  }

  export type SPMDocumentAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which SPMDocument to aggregate.
     */
    where?: SPMDocumentWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of SPMDocuments to fetch.
     */
    orderBy?: SPMDocumentOrderByWithRelationInput | SPMDocumentOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: SPMDocumentWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` SPMDocuments from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` SPMDocuments.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned SPMDocuments
    **/
    _count?: true | SPMDocumentCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: SPMDocumentAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: SPMDocumentSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: SPMDocumentMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: SPMDocumentMaxAggregateInputType
  }

  export type GetSPMDocumentAggregateType<T extends SPMDocumentAggregateArgs> = {
        [P in keyof T & keyof AggregateSPMDocument]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateSPMDocument[P]>
      : GetScalarType<T[P], AggregateSPMDocument[P]>
  }




  export type SPMDocumentGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: SPMDocumentWhereInput
    orderBy?: SPMDocumentOrderByWithAggregationInput | SPMDocumentOrderByWithAggregationInput[]
    by: SPMDocumentScalarFieldEnum[] | SPMDocumentScalarFieldEnum
    having?: SPMDocumentScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: SPMDocumentCountAggregateInputType | true
    _avg?: SPMDocumentAvgAggregateInputType
    _sum?: SPMDocumentSumAggregateInputType
    _min?: SPMDocumentMinAggregateInputType
    _max?: SPMDocumentMaxAggregateInputType
  }

  export type SPMDocumentGroupByOutputType = {
    id: string
    bpuGroupId: string
    nomorSurat: string
    recipient: string
    amount: number
    terbilang: string
    paymentFor: string
    filePath: string
    generatedAt: Date
    _count: SPMDocumentCountAggregateOutputType | null
    _avg: SPMDocumentAvgAggregateOutputType | null
    _sum: SPMDocumentSumAggregateOutputType | null
    _min: SPMDocumentMinAggregateOutputType | null
    _max: SPMDocumentMaxAggregateOutputType | null
  }

  type GetSPMDocumentGroupByPayload<T extends SPMDocumentGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<SPMDocumentGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof SPMDocumentGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], SPMDocumentGroupByOutputType[P]>
            : GetScalarType<T[P], SPMDocumentGroupByOutputType[P]>
        }
      >
    >


  export type SPMDocumentSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    bpuGroupId?: boolean
    nomorSurat?: boolean
    recipient?: boolean
    amount?: boolean
    terbilang?: boolean
    paymentFor?: boolean
    filePath?: boolean
    generatedAt?: boolean
    bpuGroup?: boolean | BPUGroupDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["sPMDocument"]>

  export type SPMDocumentSelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    bpuGroupId?: boolean
    nomorSurat?: boolean
    recipient?: boolean
    amount?: boolean
    terbilang?: boolean
    paymentFor?: boolean
    filePath?: boolean
    generatedAt?: boolean
    bpuGroup?: boolean | BPUGroupDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["sPMDocument"]>

  export type SPMDocumentSelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    bpuGroupId?: boolean
    nomorSurat?: boolean
    recipient?: boolean
    amount?: boolean
    terbilang?: boolean
    paymentFor?: boolean
    filePath?: boolean
    generatedAt?: boolean
    bpuGroup?: boolean | BPUGroupDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["sPMDocument"]>

  export type SPMDocumentSelectScalar = {
    id?: boolean
    bpuGroupId?: boolean
    nomorSurat?: boolean
    recipient?: boolean
    amount?: boolean
    terbilang?: boolean
    paymentFor?: boolean
    filePath?: boolean
    generatedAt?: boolean
  }

  export type SPMDocumentOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "bpuGroupId" | "nomorSurat" | "recipient" | "amount" | "terbilang" | "paymentFor" | "filePath" | "generatedAt", ExtArgs["result"]["sPMDocument"]>
  export type SPMDocumentInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    bpuGroup?: boolean | BPUGroupDefaultArgs<ExtArgs>
  }
  export type SPMDocumentIncludeCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    bpuGroup?: boolean | BPUGroupDefaultArgs<ExtArgs>
  }
  export type SPMDocumentIncludeUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    bpuGroup?: boolean | BPUGroupDefaultArgs<ExtArgs>
  }

  export type $SPMDocumentPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "SPMDocument"
    objects: {
      bpuGroup: Prisma.$BPUGroupPayload<ExtArgs>
    }
    scalars: $Extensions.GetPayloadResult<{
      id: string
      bpuGroupId: string
      nomorSurat: string
      recipient: string
      amount: number
      terbilang: string
      paymentFor: string
      filePath: string
      generatedAt: Date
    }, ExtArgs["result"]["sPMDocument"]>
    composites: {}
  }

  type SPMDocumentGetPayload<S extends boolean | null | undefined | SPMDocumentDefaultArgs> = $Result.GetResult<Prisma.$SPMDocumentPayload, S>

  type SPMDocumentCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<SPMDocumentFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: SPMDocumentCountAggregateInputType | true
    }

  export interface SPMDocumentDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['SPMDocument'], meta: { name: 'SPMDocument' } }
    /**
     * Find zero or one SPMDocument that matches the filter.
     * @param {SPMDocumentFindUniqueArgs} args - Arguments to find a SPMDocument
     * @example
     * // Get one SPMDocument
     * const sPMDocument = await prisma.sPMDocument.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends SPMDocumentFindUniqueArgs>(args: SelectSubset<T, SPMDocumentFindUniqueArgs<ExtArgs>>): Prisma__SPMDocumentClient<$Result.GetResult<Prisma.$SPMDocumentPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one SPMDocument that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {SPMDocumentFindUniqueOrThrowArgs} args - Arguments to find a SPMDocument
     * @example
     * // Get one SPMDocument
     * const sPMDocument = await prisma.sPMDocument.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends SPMDocumentFindUniqueOrThrowArgs>(args: SelectSubset<T, SPMDocumentFindUniqueOrThrowArgs<ExtArgs>>): Prisma__SPMDocumentClient<$Result.GetResult<Prisma.$SPMDocumentPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first SPMDocument that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SPMDocumentFindFirstArgs} args - Arguments to find a SPMDocument
     * @example
     * // Get one SPMDocument
     * const sPMDocument = await prisma.sPMDocument.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends SPMDocumentFindFirstArgs>(args?: SelectSubset<T, SPMDocumentFindFirstArgs<ExtArgs>>): Prisma__SPMDocumentClient<$Result.GetResult<Prisma.$SPMDocumentPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first SPMDocument that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SPMDocumentFindFirstOrThrowArgs} args - Arguments to find a SPMDocument
     * @example
     * // Get one SPMDocument
     * const sPMDocument = await prisma.sPMDocument.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends SPMDocumentFindFirstOrThrowArgs>(args?: SelectSubset<T, SPMDocumentFindFirstOrThrowArgs<ExtArgs>>): Prisma__SPMDocumentClient<$Result.GetResult<Prisma.$SPMDocumentPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more SPMDocuments that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SPMDocumentFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all SPMDocuments
     * const sPMDocuments = await prisma.sPMDocument.findMany()
     * 
     * // Get first 10 SPMDocuments
     * const sPMDocuments = await prisma.sPMDocument.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const sPMDocumentWithIdOnly = await prisma.sPMDocument.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends SPMDocumentFindManyArgs>(args?: SelectSubset<T, SPMDocumentFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$SPMDocumentPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a SPMDocument.
     * @param {SPMDocumentCreateArgs} args - Arguments to create a SPMDocument.
     * @example
     * // Create one SPMDocument
     * const SPMDocument = await prisma.sPMDocument.create({
     *   data: {
     *     // ... data to create a SPMDocument
     *   }
     * })
     * 
     */
    create<T extends SPMDocumentCreateArgs>(args: SelectSubset<T, SPMDocumentCreateArgs<ExtArgs>>): Prisma__SPMDocumentClient<$Result.GetResult<Prisma.$SPMDocumentPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many SPMDocuments.
     * @param {SPMDocumentCreateManyArgs} args - Arguments to create many SPMDocuments.
     * @example
     * // Create many SPMDocuments
     * const sPMDocument = await prisma.sPMDocument.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends SPMDocumentCreateManyArgs>(args?: SelectSubset<T, SPMDocumentCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many SPMDocuments and returns the data saved in the database.
     * @param {SPMDocumentCreateManyAndReturnArgs} args - Arguments to create many SPMDocuments.
     * @example
     * // Create many SPMDocuments
     * const sPMDocument = await prisma.sPMDocument.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many SPMDocuments and only return the `id`
     * const sPMDocumentWithIdOnly = await prisma.sPMDocument.createManyAndReturn({
     *   select: { id: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends SPMDocumentCreateManyAndReturnArgs>(args?: SelectSubset<T, SPMDocumentCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$SPMDocumentPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a SPMDocument.
     * @param {SPMDocumentDeleteArgs} args - Arguments to delete one SPMDocument.
     * @example
     * // Delete one SPMDocument
     * const SPMDocument = await prisma.sPMDocument.delete({
     *   where: {
     *     // ... filter to delete one SPMDocument
     *   }
     * })
     * 
     */
    delete<T extends SPMDocumentDeleteArgs>(args: SelectSubset<T, SPMDocumentDeleteArgs<ExtArgs>>): Prisma__SPMDocumentClient<$Result.GetResult<Prisma.$SPMDocumentPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one SPMDocument.
     * @param {SPMDocumentUpdateArgs} args - Arguments to update one SPMDocument.
     * @example
     * // Update one SPMDocument
     * const sPMDocument = await prisma.sPMDocument.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends SPMDocumentUpdateArgs>(args: SelectSubset<T, SPMDocumentUpdateArgs<ExtArgs>>): Prisma__SPMDocumentClient<$Result.GetResult<Prisma.$SPMDocumentPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more SPMDocuments.
     * @param {SPMDocumentDeleteManyArgs} args - Arguments to filter SPMDocuments to delete.
     * @example
     * // Delete a few SPMDocuments
     * const { count } = await prisma.sPMDocument.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends SPMDocumentDeleteManyArgs>(args?: SelectSubset<T, SPMDocumentDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more SPMDocuments.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SPMDocumentUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many SPMDocuments
     * const sPMDocument = await prisma.sPMDocument.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends SPMDocumentUpdateManyArgs>(args: SelectSubset<T, SPMDocumentUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more SPMDocuments and returns the data updated in the database.
     * @param {SPMDocumentUpdateManyAndReturnArgs} args - Arguments to update many SPMDocuments.
     * @example
     * // Update many SPMDocuments
     * const sPMDocument = await prisma.sPMDocument.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more SPMDocuments and only return the `id`
     * const sPMDocumentWithIdOnly = await prisma.sPMDocument.updateManyAndReturn({
     *   select: { id: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends SPMDocumentUpdateManyAndReturnArgs>(args: SelectSubset<T, SPMDocumentUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$SPMDocumentPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one SPMDocument.
     * @param {SPMDocumentUpsertArgs} args - Arguments to update or create a SPMDocument.
     * @example
     * // Update or create a SPMDocument
     * const sPMDocument = await prisma.sPMDocument.upsert({
     *   create: {
     *     // ... data to create a SPMDocument
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the SPMDocument we want to update
     *   }
     * })
     */
    upsert<T extends SPMDocumentUpsertArgs>(args: SelectSubset<T, SPMDocumentUpsertArgs<ExtArgs>>): Prisma__SPMDocumentClient<$Result.GetResult<Prisma.$SPMDocumentPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of SPMDocuments.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SPMDocumentCountArgs} args - Arguments to filter SPMDocuments to count.
     * @example
     * // Count the number of SPMDocuments
     * const count = await prisma.sPMDocument.count({
     *   where: {
     *     // ... the filter for the SPMDocuments we want to count
     *   }
     * })
    **/
    count<T extends SPMDocumentCountArgs>(
      args?: Subset<T, SPMDocumentCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], SPMDocumentCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a SPMDocument.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SPMDocumentAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends SPMDocumentAggregateArgs>(args: Subset<T, SPMDocumentAggregateArgs>): Prisma.PrismaPromise<GetSPMDocumentAggregateType<T>>

    /**
     * Group by SPMDocument.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SPMDocumentGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends SPMDocumentGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: SPMDocumentGroupByArgs['orderBy'] }
        : { orderBy?: SPMDocumentGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, SPMDocumentGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetSPMDocumentGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the SPMDocument model
   */
  readonly fields: SPMDocumentFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for SPMDocument.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__SPMDocumentClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    bpuGroup<T extends BPUGroupDefaultArgs<ExtArgs> = {}>(args?: Subset<T, BPUGroupDefaultArgs<ExtArgs>>): Prisma__BPUGroupClient<$Result.GetResult<Prisma.$BPUGroupPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the SPMDocument model
   */
  interface SPMDocumentFieldRefs {
    readonly id: FieldRef<"SPMDocument", 'String'>
    readonly bpuGroupId: FieldRef<"SPMDocument", 'String'>
    readonly nomorSurat: FieldRef<"SPMDocument", 'String'>
    readonly recipient: FieldRef<"SPMDocument", 'String'>
    readonly amount: FieldRef<"SPMDocument", 'Int'>
    readonly terbilang: FieldRef<"SPMDocument", 'String'>
    readonly paymentFor: FieldRef<"SPMDocument", 'String'>
    readonly filePath: FieldRef<"SPMDocument", 'String'>
    readonly generatedAt: FieldRef<"SPMDocument", 'DateTime'>
  }
    

  // Custom InputTypes
  /**
   * SPMDocument findUnique
   */
  export type SPMDocumentFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SPMDocument
     */
    select?: SPMDocumentSelect<ExtArgs> | null
    /**
     * Omit specific fields from the SPMDocument
     */
    omit?: SPMDocumentOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SPMDocumentInclude<ExtArgs> | null
    /**
     * Filter, which SPMDocument to fetch.
     */
    where: SPMDocumentWhereUniqueInput
  }

  /**
   * SPMDocument findUniqueOrThrow
   */
  export type SPMDocumentFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SPMDocument
     */
    select?: SPMDocumentSelect<ExtArgs> | null
    /**
     * Omit specific fields from the SPMDocument
     */
    omit?: SPMDocumentOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SPMDocumentInclude<ExtArgs> | null
    /**
     * Filter, which SPMDocument to fetch.
     */
    where: SPMDocumentWhereUniqueInput
  }

  /**
   * SPMDocument findFirst
   */
  export type SPMDocumentFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SPMDocument
     */
    select?: SPMDocumentSelect<ExtArgs> | null
    /**
     * Omit specific fields from the SPMDocument
     */
    omit?: SPMDocumentOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SPMDocumentInclude<ExtArgs> | null
    /**
     * Filter, which SPMDocument to fetch.
     */
    where?: SPMDocumentWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of SPMDocuments to fetch.
     */
    orderBy?: SPMDocumentOrderByWithRelationInput | SPMDocumentOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for SPMDocuments.
     */
    cursor?: SPMDocumentWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` SPMDocuments from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` SPMDocuments.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of SPMDocuments.
     */
    distinct?: SPMDocumentScalarFieldEnum | SPMDocumentScalarFieldEnum[]
  }

  /**
   * SPMDocument findFirstOrThrow
   */
  export type SPMDocumentFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SPMDocument
     */
    select?: SPMDocumentSelect<ExtArgs> | null
    /**
     * Omit specific fields from the SPMDocument
     */
    omit?: SPMDocumentOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SPMDocumentInclude<ExtArgs> | null
    /**
     * Filter, which SPMDocument to fetch.
     */
    where?: SPMDocumentWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of SPMDocuments to fetch.
     */
    orderBy?: SPMDocumentOrderByWithRelationInput | SPMDocumentOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for SPMDocuments.
     */
    cursor?: SPMDocumentWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` SPMDocuments from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` SPMDocuments.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of SPMDocuments.
     */
    distinct?: SPMDocumentScalarFieldEnum | SPMDocumentScalarFieldEnum[]
  }

  /**
   * SPMDocument findMany
   */
  export type SPMDocumentFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SPMDocument
     */
    select?: SPMDocumentSelect<ExtArgs> | null
    /**
     * Omit specific fields from the SPMDocument
     */
    omit?: SPMDocumentOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SPMDocumentInclude<ExtArgs> | null
    /**
     * Filter, which SPMDocuments to fetch.
     */
    where?: SPMDocumentWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of SPMDocuments to fetch.
     */
    orderBy?: SPMDocumentOrderByWithRelationInput | SPMDocumentOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing SPMDocuments.
     */
    cursor?: SPMDocumentWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` SPMDocuments from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` SPMDocuments.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of SPMDocuments.
     */
    distinct?: SPMDocumentScalarFieldEnum | SPMDocumentScalarFieldEnum[]
  }

  /**
   * SPMDocument create
   */
  export type SPMDocumentCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SPMDocument
     */
    select?: SPMDocumentSelect<ExtArgs> | null
    /**
     * Omit specific fields from the SPMDocument
     */
    omit?: SPMDocumentOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SPMDocumentInclude<ExtArgs> | null
    /**
     * The data needed to create a SPMDocument.
     */
    data: XOR<SPMDocumentCreateInput, SPMDocumentUncheckedCreateInput>
  }

  /**
   * SPMDocument createMany
   */
  export type SPMDocumentCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many SPMDocuments.
     */
    data: SPMDocumentCreateManyInput | SPMDocumentCreateManyInput[]
  }

  /**
   * SPMDocument createManyAndReturn
   */
  export type SPMDocumentCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SPMDocument
     */
    select?: SPMDocumentSelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the SPMDocument
     */
    omit?: SPMDocumentOmit<ExtArgs> | null
    /**
     * The data used to create many SPMDocuments.
     */
    data: SPMDocumentCreateManyInput | SPMDocumentCreateManyInput[]
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SPMDocumentIncludeCreateManyAndReturn<ExtArgs> | null
  }

  /**
   * SPMDocument update
   */
  export type SPMDocumentUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SPMDocument
     */
    select?: SPMDocumentSelect<ExtArgs> | null
    /**
     * Omit specific fields from the SPMDocument
     */
    omit?: SPMDocumentOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SPMDocumentInclude<ExtArgs> | null
    /**
     * The data needed to update a SPMDocument.
     */
    data: XOR<SPMDocumentUpdateInput, SPMDocumentUncheckedUpdateInput>
    /**
     * Choose, which SPMDocument to update.
     */
    where: SPMDocumentWhereUniqueInput
  }

  /**
   * SPMDocument updateMany
   */
  export type SPMDocumentUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update SPMDocuments.
     */
    data: XOR<SPMDocumentUpdateManyMutationInput, SPMDocumentUncheckedUpdateManyInput>
    /**
     * Filter which SPMDocuments to update
     */
    where?: SPMDocumentWhereInput
    /**
     * Limit how many SPMDocuments to update.
     */
    limit?: number
  }

  /**
   * SPMDocument updateManyAndReturn
   */
  export type SPMDocumentUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SPMDocument
     */
    select?: SPMDocumentSelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the SPMDocument
     */
    omit?: SPMDocumentOmit<ExtArgs> | null
    /**
     * The data used to update SPMDocuments.
     */
    data: XOR<SPMDocumentUpdateManyMutationInput, SPMDocumentUncheckedUpdateManyInput>
    /**
     * Filter which SPMDocuments to update
     */
    where?: SPMDocumentWhereInput
    /**
     * Limit how many SPMDocuments to update.
     */
    limit?: number
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SPMDocumentIncludeUpdateManyAndReturn<ExtArgs> | null
  }

  /**
   * SPMDocument upsert
   */
  export type SPMDocumentUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SPMDocument
     */
    select?: SPMDocumentSelect<ExtArgs> | null
    /**
     * Omit specific fields from the SPMDocument
     */
    omit?: SPMDocumentOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SPMDocumentInclude<ExtArgs> | null
    /**
     * The filter to search for the SPMDocument to update in case it exists.
     */
    where: SPMDocumentWhereUniqueInput
    /**
     * In case the SPMDocument found by the `where` argument doesn't exist, create a new SPMDocument with this data.
     */
    create: XOR<SPMDocumentCreateInput, SPMDocumentUncheckedCreateInput>
    /**
     * In case the SPMDocument was found with the provided `where` argument, update it with this data.
     */
    update: XOR<SPMDocumentUpdateInput, SPMDocumentUncheckedUpdateInput>
  }

  /**
   * SPMDocument delete
   */
  export type SPMDocumentDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SPMDocument
     */
    select?: SPMDocumentSelect<ExtArgs> | null
    /**
     * Omit specific fields from the SPMDocument
     */
    omit?: SPMDocumentOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SPMDocumentInclude<ExtArgs> | null
    /**
     * Filter which SPMDocument to delete.
     */
    where: SPMDocumentWhereUniqueInput
  }

  /**
   * SPMDocument deleteMany
   */
  export type SPMDocumentDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which SPMDocuments to delete
     */
    where?: SPMDocumentWhereInput
    /**
     * Limit how many SPMDocuments to delete.
     */
    limit?: number
  }

  /**
   * SPMDocument without action
   */
  export type SPMDocumentDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SPMDocument
     */
    select?: SPMDocumentSelect<ExtArgs> | null
    /**
     * Omit specific fields from the SPMDocument
     */
    omit?: SPMDocumentOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SPMDocumentInclude<ExtArgs> | null
  }


  /**
   * Model RkasImport
   */

  export type AggregateRkasImport = {
    _count: RkasImportCountAggregateOutputType | null
    _avg: RkasImportAvgAggregateOutputType | null
    _sum: RkasImportSumAggregateOutputType | null
    _min: RkasImportMinAggregateOutputType | null
    _max: RkasImportMaxAggregateOutputType | null
  }

  export type RkasImportAvgAggregateOutputType = {
    month: number | null
    year: number | null
  }

  export type RkasImportSumAggregateOutputType = {
    month: number | null
    year: number | null
  }

  export type RkasImportMinAggregateOutputType = {
    id: string | null
    schoolId: string | null
    month: number | null
    year: number | null
    sourceFileName: string | null
    sourceSchoolName: string | null
    npsn: string | null
    namaPelaksana: string | null
    programLabel: string | null
    namaKegiatan: string | null
    sumberDana: string | null
    pekerjaanLabel: string | null
    kepalaName: string | null
    bendaharaName: string | null
    importedAt: Date | null
    updatedAt: Date | null
  }

  export type RkasImportMaxAggregateOutputType = {
    id: string | null
    schoolId: string | null
    month: number | null
    year: number | null
    sourceFileName: string | null
    sourceSchoolName: string | null
    npsn: string | null
    namaPelaksana: string | null
    programLabel: string | null
    namaKegiatan: string | null
    sumberDana: string | null
    pekerjaanLabel: string | null
    kepalaName: string | null
    bendaharaName: string | null
    importedAt: Date | null
    updatedAt: Date | null
  }

  export type RkasImportCountAggregateOutputType = {
    id: number
    schoolId: number
    month: number
    year: number
    sourceFileName: number
    sourceSchoolName: number
    npsn: number
    namaPelaksana: number
    programLabel: number
    namaKegiatan: number
    sumberDana: number
    pekerjaanLabel: number
    kepalaName: number
    bendaharaName: number
    importedAt: number
    updatedAt: number
    _all: number
  }


  export type RkasImportAvgAggregateInputType = {
    month?: true
    year?: true
  }

  export type RkasImportSumAggregateInputType = {
    month?: true
    year?: true
  }

  export type RkasImportMinAggregateInputType = {
    id?: true
    schoolId?: true
    month?: true
    year?: true
    sourceFileName?: true
    sourceSchoolName?: true
    npsn?: true
    namaPelaksana?: true
    programLabel?: true
    namaKegiatan?: true
    sumberDana?: true
    pekerjaanLabel?: true
    kepalaName?: true
    bendaharaName?: true
    importedAt?: true
    updatedAt?: true
  }

  export type RkasImportMaxAggregateInputType = {
    id?: true
    schoolId?: true
    month?: true
    year?: true
    sourceFileName?: true
    sourceSchoolName?: true
    npsn?: true
    namaPelaksana?: true
    programLabel?: true
    namaKegiatan?: true
    sumberDana?: true
    pekerjaanLabel?: true
    kepalaName?: true
    bendaharaName?: true
    importedAt?: true
    updatedAt?: true
  }

  export type RkasImportCountAggregateInputType = {
    id?: true
    schoolId?: true
    month?: true
    year?: true
    sourceFileName?: true
    sourceSchoolName?: true
    npsn?: true
    namaPelaksana?: true
    programLabel?: true
    namaKegiatan?: true
    sumberDana?: true
    pekerjaanLabel?: true
    kepalaName?: true
    bendaharaName?: true
    importedAt?: true
    updatedAt?: true
    _all?: true
  }

  export type RkasImportAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which RkasImport to aggregate.
     */
    where?: RkasImportWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of RkasImports to fetch.
     */
    orderBy?: RkasImportOrderByWithRelationInput | RkasImportOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: RkasImportWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` RkasImports from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` RkasImports.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned RkasImports
    **/
    _count?: true | RkasImportCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: RkasImportAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: RkasImportSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: RkasImportMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: RkasImportMaxAggregateInputType
  }

  export type GetRkasImportAggregateType<T extends RkasImportAggregateArgs> = {
        [P in keyof T & keyof AggregateRkasImport]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateRkasImport[P]>
      : GetScalarType<T[P], AggregateRkasImport[P]>
  }




  export type RkasImportGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: RkasImportWhereInput
    orderBy?: RkasImportOrderByWithAggregationInput | RkasImportOrderByWithAggregationInput[]
    by: RkasImportScalarFieldEnum[] | RkasImportScalarFieldEnum
    having?: RkasImportScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: RkasImportCountAggregateInputType | true
    _avg?: RkasImportAvgAggregateInputType
    _sum?: RkasImportSumAggregateInputType
    _min?: RkasImportMinAggregateInputType
    _max?: RkasImportMaxAggregateInputType
  }

  export type RkasImportGroupByOutputType = {
    id: string
    schoolId: string
    month: number
    year: number
    sourceFileName: string
    sourceSchoolName: string | null
    npsn: string | null
    namaPelaksana: string
    programLabel: string
    namaKegiatan: string
    sumberDana: string
    pekerjaanLabel: string
    kepalaName: string
    bendaharaName: string
    importedAt: Date
    updatedAt: Date
    _count: RkasImportCountAggregateOutputType | null
    _avg: RkasImportAvgAggregateOutputType | null
    _sum: RkasImportSumAggregateOutputType | null
    _min: RkasImportMinAggregateOutputType | null
    _max: RkasImportMaxAggregateOutputType | null
  }

  type GetRkasImportGroupByPayload<T extends RkasImportGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<RkasImportGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof RkasImportGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], RkasImportGroupByOutputType[P]>
            : GetScalarType<T[P], RkasImportGroupByOutputType[P]>
        }
      >
    >


  export type RkasImportSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    schoolId?: boolean
    month?: boolean
    year?: boolean
    sourceFileName?: boolean
    sourceSchoolName?: boolean
    npsn?: boolean
    namaPelaksana?: boolean
    programLabel?: boolean
    namaKegiatan?: boolean
    sumberDana?: boolean
    pekerjaanLabel?: boolean
    kepalaName?: boolean
    bendaharaName?: boolean
    importedAt?: boolean
    updatedAt?: boolean
    school?: boolean | SchoolDefaultArgs<ExtArgs>
    programs?: boolean | RkasImport$programsArgs<ExtArgs>
    _count?: boolean | RkasImportCountOutputTypeDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["rkasImport"]>

  export type RkasImportSelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    schoolId?: boolean
    month?: boolean
    year?: boolean
    sourceFileName?: boolean
    sourceSchoolName?: boolean
    npsn?: boolean
    namaPelaksana?: boolean
    programLabel?: boolean
    namaKegiatan?: boolean
    sumberDana?: boolean
    pekerjaanLabel?: boolean
    kepalaName?: boolean
    bendaharaName?: boolean
    importedAt?: boolean
    updatedAt?: boolean
    school?: boolean | SchoolDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["rkasImport"]>

  export type RkasImportSelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    schoolId?: boolean
    month?: boolean
    year?: boolean
    sourceFileName?: boolean
    sourceSchoolName?: boolean
    npsn?: boolean
    namaPelaksana?: boolean
    programLabel?: boolean
    namaKegiatan?: boolean
    sumberDana?: boolean
    pekerjaanLabel?: boolean
    kepalaName?: boolean
    bendaharaName?: boolean
    importedAt?: boolean
    updatedAt?: boolean
    school?: boolean | SchoolDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["rkasImport"]>

  export type RkasImportSelectScalar = {
    id?: boolean
    schoolId?: boolean
    month?: boolean
    year?: boolean
    sourceFileName?: boolean
    sourceSchoolName?: boolean
    npsn?: boolean
    namaPelaksana?: boolean
    programLabel?: boolean
    namaKegiatan?: boolean
    sumberDana?: boolean
    pekerjaanLabel?: boolean
    kepalaName?: boolean
    bendaharaName?: boolean
    importedAt?: boolean
    updatedAt?: boolean
  }

  export type RkasImportOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "schoolId" | "month" | "year" | "sourceFileName" | "sourceSchoolName" | "npsn" | "namaPelaksana" | "programLabel" | "namaKegiatan" | "sumberDana" | "pekerjaanLabel" | "kepalaName" | "bendaharaName" | "importedAt" | "updatedAt", ExtArgs["result"]["rkasImport"]>
  export type RkasImportInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    school?: boolean | SchoolDefaultArgs<ExtArgs>
    programs?: boolean | RkasImport$programsArgs<ExtArgs>
    _count?: boolean | RkasImportCountOutputTypeDefaultArgs<ExtArgs>
  }
  export type RkasImportIncludeCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    school?: boolean | SchoolDefaultArgs<ExtArgs>
  }
  export type RkasImportIncludeUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    school?: boolean | SchoolDefaultArgs<ExtArgs>
  }

  export type $RkasImportPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "RkasImport"
    objects: {
      school: Prisma.$SchoolPayload<ExtArgs>
      programs: Prisma.$RkasProgramPayload<ExtArgs>[]
    }
    scalars: $Extensions.GetPayloadResult<{
      id: string
      schoolId: string
      month: number
      year: number
      sourceFileName: string
      sourceSchoolName: string | null
      npsn: string | null
      namaPelaksana: string
      programLabel: string
      namaKegiatan: string
      sumberDana: string
      pekerjaanLabel: string
      kepalaName: string
      bendaharaName: string
      importedAt: Date
      updatedAt: Date
    }, ExtArgs["result"]["rkasImport"]>
    composites: {}
  }

  type RkasImportGetPayload<S extends boolean | null | undefined | RkasImportDefaultArgs> = $Result.GetResult<Prisma.$RkasImportPayload, S>

  type RkasImportCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<RkasImportFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: RkasImportCountAggregateInputType | true
    }

  export interface RkasImportDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['RkasImport'], meta: { name: 'RkasImport' } }
    /**
     * Find zero or one RkasImport that matches the filter.
     * @param {RkasImportFindUniqueArgs} args - Arguments to find a RkasImport
     * @example
     * // Get one RkasImport
     * const rkasImport = await prisma.rkasImport.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends RkasImportFindUniqueArgs>(args: SelectSubset<T, RkasImportFindUniqueArgs<ExtArgs>>): Prisma__RkasImportClient<$Result.GetResult<Prisma.$RkasImportPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one RkasImport that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {RkasImportFindUniqueOrThrowArgs} args - Arguments to find a RkasImport
     * @example
     * // Get one RkasImport
     * const rkasImport = await prisma.rkasImport.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends RkasImportFindUniqueOrThrowArgs>(args: SelectSubset<T, RkasImportFindUniqueOrThrowArgs<ExtArgs>>): Prisma__RkasImportClient<$Result.GetResult<Prisma.$RkasImportPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first RkasImport that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {RkasImportFindFirstArgs} args - Arguments to find a RkasImport
     * @example
     * // Get one RkasImport
     * const rkasImport = await prisma.rkasImport.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends RkasImportFindFirstArgs>(args?: SelectSubset<T, RkasImportFindFirstArgs<ExtArgs>>): Prisma__RkasImportClient<$Result.GetResult<Prisma.$RkasImportPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first RkasImport that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {RkasImportFindFirstOrThrowArgs} args - Arguments to find a RkasImport
     * @example
     * // Get one RkasImport
     * const rkasImport = await prisma.rkasImport.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends RkasImportFindFirstOrThrowArgs>(args?: SelectSubset<T, RkasImportFindFirstOrThrowArgs<ExtArgs>>): Prisma__RkasImportClient<$Result.GetResult<Prisma.$RkasImportPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more RkasImports that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {RkasImportFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all RkasImports
     * const rkasImports = await prisma.rkasImport.findMany()
     * 
     * // Get first 10 RkasImports
     * const rkasImports = await prisma.rkasImport.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const rkasImportWithIdOnly = await prisma.rkasImport.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends RkasImportFindManyArgs>(args?: SelectSubset<T, RkasImportFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$RkasImportPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a RkasImport.
     * @param {RkasImportCreateArgs} args - Arguments to create a RkasImport.
     * @example
     * // Create one RkasImport
     * const RkasImport = await prisma.rkasImport.create({
     *   data: {
     *     // ... data to create a RkasImport
     *   }
     * })
     * 
     */
    create<T extends RkasImportCreateArgs>(args: SelectSubset<T, RkasImportCreateArgs<ExtArgs>>): Prisma__RkasImportClient<$Result.GetResult<Prisma.$RkasImportPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many RkasImports.
     * @param {RkasImportCreateManyArgs} args - Arguments to create many RkasImports.
     * @example
     * // Create many RkasImports
     * const rkasImport = await prisma.rkasImport.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends RkasImportCreateManyArgs>(args?: SelectSubset<T, RkasImportCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many RkasImports and returns the data saved in the database.
     * @param {RkasImportCreateManyAndReturnArgs} args - Arguments to create many RkasImports.
     * @example
     * // Create many RkasImports
     * const rkasImport = await prisma.rkasImport.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many RkasImports and only return the `id`
     * const rkasImportWithIdOnly = await prisma.rkasImport.createManyAndReturn({
     *   select: { id: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends RkasImportCreateManyAndReturnArgs>(args?: SelectSubset<T, RkasImportCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$RkasImportPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a RkasImport.
     * @param {RkasImportDeleteArgs} args - Arguments to delete one RkasImport.
     * @example
     * // Delete one RkasImport
     * const RkasImport = await prisma.rkasImport.delete({
     *   where: {
     *     // ... filter to delete one RkasImport
     *   }
     * })
     * 
     */
    delete<T extends RkasImportDeleteArgs>(args: SelectSubset<T, RkasImportDeleteArgs<ExtArgs>>): Prisma__RkasImportClient<$Result.GetResult<Prisma.$RkasImportPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one RkasImport.
     * @param {RkasImportUpdateArgs} args - Arguments to update one RkasImport.
     * @example
     * // Update one RkasImport
     * const rkasImport = await prisma.rkasImport.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends RkasImportUpdateArgs>(args: SelectSubset<T, RkasImportUpdateArgs<ExtArgs>>): Prisma__RkasImportClient<$Result.GetResult<Prisma.$RkasImportPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more RkasImports.
     * @param {RkasImportDeleteManyArgs} args - Arguments to filter RkasImports to delete.
     * @example
     * // Delete a few RkasImports
     * const { count } = await prisma.rkasImport.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends RkasImportDeleteManyArgs>(args?: SelectSubset<T, RkasImportDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more RkasImports.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {RkasImportUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many RkasImports
     * const rkasImport = await prisma.rkasImport.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends RkasImportUpdateManyArgs>(args: SelectSubset<T, RkasImportUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more RkasImports and returns the data updated in the database.
     * @param {RkasImportUpdateManyAndReturnArgs} args - Arguments to update many RkasImports.
     * @example
     * // Update many RkasImports
     * const rkasImport = await prisma.rkasImport.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more RkasImports and only return the `id`
     * const rkasImportWithIdOnly = await prisma.rkasImport.updateManyAndReturn({
     *   select: { id: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends RkasImportUpdateManyAndReturnArgs>(args: SelectSubset<T, RkasImportUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$RkasImportPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one RkasImport.
     * @param {RkasImportUpsertArgs} args - Arguments to update or create a RkasImport.
     * @example
     * // Update or create a RkasImport
     * const rkasImport = await prisma.rkasImport.upsert({
     *   create: {
     *     // ... data to create a RkasImport
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the RkasImport we want to update
     *   }
     * })
     */
    upsert<T extends RkasImportUpsertArgs>(args: SelectSubset<T, RkasImportUpsertArgs<ExtArgs>>): Prisma__RkasImportClient<$Result.GetResult<Prisma.$RkasImportPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of RkasImports.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {RkasImportCountArgs} args - Arguments to filter RkasImports to count.
     * @example
     * // Count the number of RkasImports
     * const count = await prisma.rkasImport.count({
     *   where: {
     *     // ... the filter for the RkasImports we want to count
     *   }
     * })
    **/
    count<T extends RkasImportCountArgs>(
      args?: Subset<T, RkasImportCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], RkasImportCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a RkasImport.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {RkasImportAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends RkasImportAggregateArgs>(args: Subset<T, RkasImportAggregateArgs>): Prisma.PrismaPromise<GetRkasImportAggregateType<T>>

    /**
     * Group by RkasImport.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {RkasImportGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends RkasImportGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: RkasImportGroupByArgs['orderBy'] }
        : { orderBy?: RkasImportGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, RkasImportGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetRkasImportGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the RkasImport model
   */
  readonly fields: RkasImportFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for RkasImport.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__RkasImportClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    school<T extends SchoolDefaultArgs<ExtArgs> = {}>(args?: Subset<T, SchoolDefaultArgs<ExtArgs>>): Prisma__SchoolClient<$Result.GetResult<Prisma.$SchoolPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    programs<T extends RkasImport$programsArgs<ExtArgs> = {}>(args?: Subset<T, RkasImport$programsArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$RkasProgramPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the RkasImport model
   */
  interface RkasImportFieldRefs {
    readonly id: FieldRef<"RkasImport", 'String'>
    readonly schoolId: FieldRef<"RkasImport", 'String'>
    readonly month: FieldRef<"RkasImport", 'Int'>
    readonly year: FieldRef<"RkasImport", 'Int'>
    readonly sourceFileName: FieldRef<"RkasImport", 'String'>
    readonly sourceSchoolName: FieldRef<"RkasImport", 'String'>
    readonly npsn: FieldRef<"RkasImport", 'String'>
    readonly namaPelaksana: FieldRef<"RkasImport", 'String'>
    readonly programLabel: FieldRef<"RkasImport", 'String'>
    readonly namaKegiatan: FieldRef<"RkasImport", 'String'>
    readonly sumberDana: FieldRef<"RkasImport", 'String'>
    readonly pekerjaanLabel: FieldRef<"RkasImport", 'String'>
    readonly kepalaName: FieldRef<"RkasImport", 'String'>
    readonly bendaharaName: FieldRef<"RkasImport", 'String'>
    readonly importedAt: FieldRef<"RkasImport", 'DateTime'>
    readonly updatedAt: FieldRef<"RkasImport", 'DateTime'>
  }
    

  // Custom InputTypes
  /**
   * RkasImport findUnique
   */
  export type RkasImportFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the RkasImport
     */
    select?: RkasImportSelect<ExtArgs> | null
    /**
     * Omit specific fields from the RkasImport
     */
    omit?: RkasImportOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: RkasImportInclude<ExtArgs> | null
    /**
     * Filter, which RkasImport to fetch.
     */
    where: RkasImportWhereUniqueInput
  }

  /**
   * RkasImport findUniqueOrThrow
   */
  export type RkasImportFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the RkasImport
     */
    select?: RkasImportSelect<ExtArgs> | null
    /**
     * Omit specific fields from the RkasImport
     */
    omit?: RkasImportOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: RkasImportInclude<ExtArgs> | null
    /**
     * Filter, which RkasImport to fetch.
     */
    where: RkasImportWhereUniqueInput
  }

  /**
   * RkasImport findFirst
   */
  export type RkasImportFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the RkasImport
     */
    select?: RkasImportSelect<ExtArgs> | null
    /**
     * Omit specific fields from the RkasImport
     */
    omit?: RkasImportOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: RkasImportInclude<ExtArgs> | null
    /**
     * Filter, which RkasImport to fetch.
     */
    where?: RkasImportWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of RkasImports to fetch.
     */
    orderBy?: RkasImportOrderByWithRelationInput | RkasImportOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for RkasImports.
     */
    cursor?: RkasImportWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` RkasImports from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` RkasImports.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of RkasImports.
     */
    distinct?: RkasImportScalarFieldEnum | RkasImportScalarFieldEnum[]
  }

  /**
   * RkasImport findFirstOrThrow
   */
  export type RkasImportFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the RkasImport
     */
    select?: RkasImportSelect<ExtArgs> | null
    /**
     * Omit specific fields from the RkasImport
     */
    omit?: RkasImportOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: RkasImportInclude<ExtArgs> | null
    /**
     * Filter, which RkasImport to fetch.
     */
    where?: RkasImportWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of RkasImports to fetch.
     */
    orderBy?: RkasImportOrderByWithRelationInput | RkasImportOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for RkasImports.
     */
    cursor?: RkasImportWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` RkasImports from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` RkasImports.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of RkasImports.
     */
    distinct?: RkasImportScalarFieldEnum | RkasImportScalarFieldEnum[]
  }

  /**
   * RkasImport findMany
   */
  export type RkasImportFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the RkasImport
     */
    select?: RkasImportSelect<ExtArgs> | null
    /**
     * Omit specific fields from the RkasImport
     */
    omit?: RkasImportOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: RkasImportInclude<ExtArgs> | null
    /**
     * Filter, which RkasImports to fetch.
     */
    where?: RkasImportWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of RkasImports to fetch.
     */
    orderBy?: RkasImportOrderByWithRelationInput | RkasImportOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing RkasImports.
     */
    cursor?: RkasImportWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` RkasImports from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` RkasImports.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of RkasImports.
     */
    distinct?: RkasImportScalarFieldEnum | RkasImportScalarFieldEnum[]
  }

  /**
   * RkasImport create
   */
  export type RkasImportCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the RkasImport
     */
    select?: RkasImportSelect<ExtArgs> | null
    /**
     * Omit specific fields from the RkasImport
     */
    omit?: RkasImportOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: RkasImportInclude<ExtArgs> | null
    /**
     * The data needed to create a RkasImport.
     */
    data: XOR<RkasImportCreateInput, RkasImportUncheckedCreateInput>
  }

  /**
   * RkasImport createMany
   */
  export type RkasImportCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many RkasImports.
     */
    data: RkasImportCreateManyInput | RkasImportCreateManyInput[]
  }

  /**
   * RkasImport createManyAndReturn
   */
  export type RkasImportCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the RkasImport
     */
    select?: RkasImportSelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the RkasImport
     */
    omit?: RkasImportOmit<ExtArgs> | null
    /**
     * The data used to create many RkasImports.
     */
    data: RkasImportCreateManyInput | RkasImportCreateManyInput[]
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: RkasImportIncludeCreateManyAndReturn<ExtArgs> | null
  }

  /**
   * RkasImport update
   */
  export type RkasImportUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the RkasImport
     */
    select?: RkasImportSelect<ExtArgs> | null
    /**
     * Omit specific fields from the RkasImport
     */
    omit?: RkasImportOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: RkasImportInclude<ExtArgs> | null
    /**
     * The data needed to update a RkasImport.
     */
    data: XOR<RkasImportUpdateInput, RkasImportUncheckedUpdateInput>
    /**
     * Choose, which RkasImport to update.
     */
    where: RkasImportWhereUniqueInput
  }

  /**
   * RkasImport updateMany
   */
  export type RkasImportUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update RkasImports.
     */
    data: XOR<RkasImportUpdateManyMutationInput, RkasImportUncheckedUpdateManyInput>
    /**
     * Filter which RkasImports to update
     */
    where?: RkasImportWhereInput
    /**
     * Limit how many RkasImports to update.
     */
    limit?: number
  }

  /**
   * RkasImport updateManyAndReturn
   */
  export type RkasImportUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the RkasImport
     */
    select?: RkasImportSelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the RkasImport
     */
    omit?: RkasImportOmit<ExtArgs> | null
    /**
     * The data used to update RkasImports.
     */
    data: XOR<RkasImportUpdateManyMutationInput, RkasImportUncheckedUpdateManyInput>
    /**
     * Filter which RkasImports to update
     */
    where?: RkasImportWhereInput
    /**
     * Limit how many RkasImports to update.
     */
    limit?: number
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: RkasImportIncludeUpdateManyAndReturn<ExtArgs> | null
  }

  /**
   * RkasImport upsert
   */
  export type RkasImportUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the RkasImport
     */
    select?: RkasImportSelect<ExtArgs> | null
    /**
     * Omit specific fields from the RkasImport
     */
    omit?: RkasImportOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: RkasImportInclude<ExtArgs> | null
    /**
     * The filter to search for the RkasImport to update in case it exists.
     */
    where: RkasImportWhereUniqueInput
    /**
     * In case the RkasImport found by the `where` argument doesn't exist, create a new RkasImport with this data.
     */
    create: XOR<RkasImportCreateInput, RkasImportUncheckedCreateInput>
    /**
     * In case the RkasImport was found with the provided `where` argument, update it with this data.
     */
    update: XOR<RkasImportUpdateInput, RkasImportUncheckedUpdateInput>
  }

  /**
   * RkasImport delete
   */
  export type RkasImportDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the RkasImport
     */
    select?: RkasImportSelect<ExtArgs> | null
    /**
     * Omit specific fields from the RkasImport
     */
    omit?: RkasImportOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: RkasImportInclude<ExtArgs> | null
    /**
     * Filter which RkasImport to delete.
     */
    where: RkasImportWhereUniqueInput
  }

  /**
   * RkasImport deleteMany
   */
  export type RkasImportDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which RkasImports to delete
     */
    where?: RkasImportWhereInput
    /**
     * Limit how many RkasImports to delete.
     */
    limit?: number
  }

  /**
   * RkasImport.programs
   */
  export type RkasImport$programsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the RkasProgram
     */
    select?: RkasProgramSelect<ExtArgs> | null
    /**
     * Omit specific fields from the RkasProgram
     */
    omit?: RkasProgramOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: RkasProgramInclude<ExtArgs> | null
    where?: RkasProgramWhereInput
    orderBy?: RkasProgramOrderByWithRelationInput | RkasProgramOrderByWithRelationInput[]
    cursor?: RkasProgramWhereUniqueInput
    take?: number
    skip?: number
    distinct?: RkasProgramScalarFieldEnum | RkasProgramScalarFieldEnum[]
  }

  /**
   * RkasImport without action
   */
  export type RkasImportDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the RkasImport
     */
    select?: RkasImportSelect<ExtArgs> | null
    /**
     * Omit specific fields from the RkasImport
     */
    omit?: RkasImportOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: RkasImportInclude<ExtArgs> | null
  }


  /**
   * Model RkasProgram
   */

  export type AggregateRkasProgram = {
    _count: RkasProgramCountAggregateOutputType | null
    _avg: RkasProgramAvgAggregateOutputType | null
    _sum: RkasProgramSumAggregateOutputType | null
    _min: RkasProgramMinAggregateOutputType | null
    _max: RkasProgramMaxAggregateOutputType | null
  }

  export type RkasProgramAvgAggregateOutputType = {
    urutan: number | null
  }

  export type RkasProgramSumAggregateOutputType = {
    urutan: number | null
  }

  export type RkasProgramMinAggregateOutputType = {
    id: string | null
    rkasImportId: string | null
    urutan: number | null
    kodeProgram: string | null
    nama: string | null
    standarName: string | null
    kegiatanName: string | null
    included: boolean | null
  }

  export type RkasProgramMaxAggregateOutputType = {
    id: string | null
    rkasImportId: string | null
    urutan: number | null
    kodeProgram: string | null
    nama: string | null
    standarName: string | null
    kegiatanName: string | null
    included: boolean | null
  }

  export type RkasProgramCountAggregateOutputType = {
    id: number
    rkasImportId: number
    urutan: number
    kodeProgram: number
    nama: number
    standarName: number
    kegiatanName: number
    included: number
    _all: number
  }


  export type RkasProgramAvgAggregateInputType = {
    urutan?: true
  }

  export type RkasProgramSumAggregateInputType = {
    urutan?: true
  }

  export type RkasProgramMinAggregateInputType = {
    id?: true
    rkasImportId?: true
    urutan?: true
    kodeProgram?: true
    nama?: true
    standarName?: true
    kegiatanName?: true
    included?: true
  }

  export type RkasProgramMaxAggregateInputType = {
    id?: true
    rkasImportId?: true
    urutan?: true
    kodeProgram?: true
    nama?: true
    standarName?: true
    kegiatanName?: true
    included?: true
  }

  export type RkasProgramCountAggregateInputType = {
    id?: true
    rkasImportId?: true
    urutan?: true
    kodeProgram?: true
    nama?: true
    standarName?: true
    kegiatanName?: true
    included?: true
    _all?: true
  }

  export type RkasProgramAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which RkasProgram to aggregate.
     */
    where?: RkasProgramWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of RkasPrograms to fetch.
     */
    orderBy?: RkasProgramOrderByWithRelationInput | RkasProgramOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: RkasProgramWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` RkasPrograms from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` RkasPrograms.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned RkasPrograms
    **/
    _count?: true | RkasProgramCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: RkasProgramAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: RkasProgramSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: RkasProgramMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: RkasProgramMaxAggregateInputType
  }

  export type GetRkasProgramAggregateType<T extends RkasProgramAggregateArgs> = {
        [P in keyof T & keyof AggregateRkasProgram]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateRkasProgram[P]>
      : GetScalarType<T[P], AggregateRkasProgram[P]>
  }




  export type RkasProgramGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: RkasProgramWhereInput
    orderBy?: RkasProgramOrderByWithAggregationInput | RkasProgramOrderByWithAggregationInput[]
    by: RkasProgramScalarFieldEnum[] | RkasProgramScalarFieldEnum
    having?: RkasProgramScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: RkasProgramCountAggregateInputType | true
    _avg?: RkasProgramAvgAggregateInputType
    _sum?: RkasProgramSumAggregateInputType
    _min?: RkasProgramMinAggregateInputType
    _max?: RkasProgramMaxAggregateInputType
  }

  export type RkasProgramGroupByOutputType = {
    id: string
    rkasImportId: string
    urutan: number
    kodeProgram: string
    nama: string
    standarName: string
    kegiatanName: string
    included: boolean
    _count: RkasProgramCountAggregateOutputType | null
    _avg: RkasProgramAvgAggregateOutputType | null
    _sum: RkasProgramSumAggregateOutputType | null
    _min: RkasProgramMinAggregateOutputType | null
    _max: RkasProgramMaxAggregateOutputType | null
  }

  type GetRkasProgramGroupByPayload<T extends RkasProgramGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<RkasProgramGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof RkasProgramGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], RkasProgramGroupByOutputType[P]>
            : GetScalarType<T[P], RkasProgramGroupByOutputType[P]>
        }
      >
    >


  export type RkasProgramSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    rkasImportId?: boolean
    urutan?: boolean
    kodeProgram?: boolean
    nama?: boolean
    standarName?: boolean
    kegiatanName?: boolean
    included?: boolean
    rkasImport?: boolean | RkasImportDefaultArgs<ExtArgs>
    items?: boolean | RkasProgram$itemsArgs<ExtArgs>
    _count?: boolean | RkasProgramCountOutputTypeDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["rkasProgram"]>

  export type RkasProgramSelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    rkasImportId?: boolean
    urutan?: boolean
    kodeProgram?: boolean
    nama?: boolean
    standarName?: boolean
    kegiatanName?: boolean
    included?: boolean
    rkasImport?: boolean | RkasImportDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["rkasProgram"]>

  export type RkasProgramSelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    rkasImportId?: boolean
    urutan?: boolean
    kodeProgram?: boolean
    nama?: boolean
    standarName?: boolean
    kegiatanName?: boolean
    included?: boolean
    rkasImport?: boolean | RkasImportDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["rkasProgram"]>

  export type RkasProgramSelectScalar = {
    id?: boolean
    rkasImportId?: boolean
    urutan?: boolean
    kodeProgram?: boolean
    nama?: boolean
    standarName?: boolean
    kegiatanName?: boolean
    included?: boolean
  }

  export type RkasProgramOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "rkasImportId" | "urutan" | "kodeProgram" | "nama" | "standarName" | "kegiatanName" | "included", ExtArgs["result"]["rkasProgram"]>
  export type RkasProgramInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    rkasImport?: boolean | RkasImportDefaultArgs<ExtArgs>
    items?: boolean | RkasProgram$itemsArgs<ExtArgs>
    _count?: boolean | RkasProgramCountOutputTypeDefaultArgs<ExtArgs>
  }
  export type RkasProgramIncludeCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    rkasImport?: boolean | RkasImportDefaultArgs<ExtArgs>
  }
  export type RkasProgramIncludeUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    rkasImport?: boolean | RkasImportDefaultArgs<ExtArgs>
  }

  export type $RkasProgramPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "RkasProgram"
    objects: {
      rkasImport: Prisma.$RkasImportPayload<ExtArgs>
      items: Prisma.$RkasItemPayload<ExtArgs>[]
    }
    scalars: $Extensions.GetPayloadResult<{
      id: string
      rkasImportId: string
      urutan: number
      kodeProgram: string
      nama: string
      standarName: string
      kegiatanName: string
      included: boolean
    }, ExtArgs["result"]["rkasProgram"]>
    composites: {}
  }

  type RkasProgramGetPayload<S extends boolean | null | undefined | RkasProgramDefaultArgs> = $Result.GetResult<Prisma.$RkasProgramPayload, S>

  type RkasProgramCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<RkasProgramFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: RkasProgramCountAggregateInputType | true
    }

  export interface RkasProgramDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['RkasProgram'], meta: { name: 'RkasProgram' } }
    /**
     * Find zero or one RkasProgram that matches the filter.
     * @param {RkasProgramFindUniqueArgs} args - Arguments to find a RkasProgram
     * @example
     * // Get one RkasProgram
     * const rkasProgram = await prisma.rkasProgram.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends RkasProgramFindUniqueArgs>(args: SelectSubset<T, RkasProgramFindUniqueArgs<ExtArgs>>): Prisma__RkasProgramClient<$Result.GetResult<Prisma.$RkasProgramPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one RkasProgram that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {RkasProgramFindUniqueOrThrowArgs} args - Arguments to find a RkasProgram
     * @example
     * // Get one RkasProgram
     * const rkasProgram = await prisma.rkasProgram.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends RkasProgramFindUniqueOrThrowArgs>(args: SelectSubset<T, RkasProgramFindUniqueOrThrowArgs<ExtArgs>>): Prisma__RkasProgramClient<$Result.GetResult<Prisma.$RkasProgramPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first RkasProgram that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {RkasProgramFindFirstArgs} args - Arguments to find a RkasProgram
     * @example
     * // Get one RkasProgram
     * const rkasProgram = await prisma.rkasProgram.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends RkasProgramFindFirstArgs>(args?: SelectSubset<T, RkasProgramFindFirstArgs<ExtArgs>>): Prisma__RkasProgramClient<$Result.GetResult<Prisma.$RkasProgramPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first RkasProgram that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {RkasProgramFindFirstOrThrowArgs} args - Arguments to find a RkasProgram
     * @example
     * // Get one RkasProgram
     * const rkasProgram = await prisma.rkasProgram.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends RkasProgramFindFirstOrThrowArgs>(args?: SelectSubset<T, RkasProgramFindFirstOrThrowArgs<ExtArgs>>): Prisma__RkasProgramClient<$Result.GetResult<Prisma.$RkasProgramPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more RkasPrograms that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {RkasProgramFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all RkasPrograms
     * const rkasPrograms = await prisma.rkasProgram.findMany()
     * 
     * // Get first 10 RkasPrograms
     * const rkasPrograms = await prisma.rkasProgram.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const rkasProgramWithIdOnly = await prisma.rkasProgram.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends RkasProgramFindManyArgs>(args?: SelectSubset<T, RkasProgramFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$RkasProgramPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a RkasProgram.
     * @param {RkasProgramCreateArgs} args - Arguments to create a RkasProgram.
     * @example
     * // Create one RkasProgram
     * const RkasProgram = await prisma.rkasProgram.create({
     *   data: {
     *     // ... data to create a RkasProgram
     *   }
     * })
     * 
     */
    create<T extends RkasProgramCreateArgs>(args: SelectSubset<T, RkasProgramCreateArgs<ExtArgs>>): Prisma__RkasProgramClient<$Result.GetResult<Prisma.$RkasProgramPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many RkasPrograms.
     * @param {RkasProgramCreateManyArgs} args - Arguments to create many RkasPrograms.
     * @example
     * // Create many RkasPrograms
     * const rkasProgram = await prisma.rkasProgram.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends RkasProgramCreateManyArgs>(args?: SelectSubset<T, RkasProgramCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many RkasPrograms and returns the data saved in the database.
     * @param {RkasProgramCreateManyAndReturnArgs} args - Arguments to create many RkasPrograms.
     * @example
     * // Create many RkasPrograms
     * const rkasProgram = await prisma.rkasProgram.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many RkasPrograms and only return the `id`
     * const rkasProgramWithIdOnly = await prisma.rkasProgram.createManyAndReturn({
     *   select: { id: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends RkasProgramCreateManyAndReturnArgs>(args?: SelectSubset<T, RkasProgramCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$RkasProgramPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a RkasProgram.
     * @param {RkasProgramDeleteArgs} args - Arguments to delete one RkasProgram.
     * @example
     * // Delete one RkasProgram
     * const RkasProgram = await prisma.rkasProgram.delete({
     *   where: {
     *     // ... filter to delete one RkasProgram
     *   }
     * })
     * 
     */
    delete<T extends RkasProgramDeleteArgs>(args: SelectSubset<T, RkasProgramDeleteArgs<ExtArgs>>): Prisma__RkasProgramClient<$Result.GetResult<Prisma.$RkasProgramPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one RkasProgram.
     * @param {RkasProgramUpdateArgs} args - Arguments to update one RkasProgram.
     * @example
     * // Update one RkasProgram
     * const rkasProgram = await prisma.rkasProgram.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends RkasProgramUpdateArgs>(args: SelectSubset<T, RkasProgramUpdateArgs<ExtArgs>>): Prisma__RkasProgramClient<$Result.GetResult<Prisma.$RkasProgramPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more RkasPrograms.
     * @param {RkasProgramDeleteManyArgs} args - Arguments to filter RkasPrograms to delete.
     * @example
     * // Delete a few RkasPrograms
     * const { count } = await prisma.rkasProgram.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends RkasProgramDeleteManyArgs>(args?: SelectSubset<T, RkasProgramDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more RkasPrograms.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {RkasProgramUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many RkasPrograms
     * const rkasProgram = await prisma.rkasProgram.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends RkasProgramUpdateManyArgs>(args: SelectSubset<T, RkasProgramUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more RkasPrograms and returns the data updated in the database.
     * @param {RkasProgramUpdateManyAndReturnArgs} args - Arguments to update many RkasPrograms.
     * @example
     * // Update many RkasPrograms
     * const rkasProgram = await prisma.rkasProgram.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more RkasPrograms and only return the `id`
     * const rkasProgramWithIdOnly = await prisma.rkasProgram.updateManyAndReturn({
     *   select: { id: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends RkasProgramUpdateManyAndReturnArgs>(args: SelectSubset<T, RkasProgramUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$RkasProgramPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one RkasProgram.
     * @param {RkasProgramUpsertArgs} args - Arguments to update or create a RkasProgram.
     * @example
     * // Update or create a RkasProgram
     * const rkasProgram = await prisma.rkasProgram.upsert({
     *   create: {
     *     // ... data to create a RkasProgram
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the RkasProgram we want to update
     *   }
     * })
     */
    upsert<T extends RkasProgramUpsertArgs>(args: SelectSubset<T, RkasProgramUpsertArgs<ExtArgs>>): Prisma__RkasProgramClient<$Result.GetResult<Prisma.$RkasProgramPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of RkasPrograms.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {RkasProgramCountArgs} args - Arguments to filter RkasPrograms to count.
     * @example
     * // Count the number of RkasPrograms
     * const count = await prisma.rkasProgram.count({
     *   where: {
     *     // ... the filter for the RkasPrograms we want to count
     *   }
     * })
    **/
    count<T extends RkasProgramCountArgs>(
      args?: Subset<T, RkasProgramCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], RkasProgramCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a RkasProgram.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {RkasProgramAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends RkasProgramAggregateArgs>(args: Subset<T, RkasProgramAggregateArgs>): Prisma.PrismaPromise<GetRkasProgramAggregateType<T>>

    /**
     * Group by RkasProgram.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {RkasProgramGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends RkasProgramGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: RkasProgramGroupByArgs['orderBy'] }
        : { orderBy?: RkasProgramGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, RkasProgramGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetRkasProgramGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the RkasProgram model
   */
  readonly fields: RkasProgramFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for RkasProgram.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__RkasProgramClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    rkasImport<T extends RkasImportDefaultArgs<ExtArgs> = {}>(args?: Subset<T, RkasImportDefaultArgs<ExtArgs>>): Prisma__RkasImportClient<$Result.GetResult<Prisma.$RkasImportPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    items<T extends RkasProgram$itemsArgs<ExtArgs> = {}>(args?: Subset<T, RkasProgram$itemsArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$RkasItemPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the RkasProgram model
   */
  interface RkasProgramFieldRefs {
    readonly id: FieldRef<"RkasProgram", 'String'>
    readonly rkasImportId: FieldRef<"RkasProgram", 'String'>
    readonly urutan: FieldRef<"RkasProgram", 'Int'>
    readonly kodeProgram: FieldRef<"RkasProgram", 'String'>
    readonly nama: FieldRef<"RkasProgram", 'String'>
    readonly standarName: FieldRef<"RkasProgram", 'String'>
    readonly kegiatanName: FieldRef<"RkasProgram", 'String'>
    readonly included: FieldRef<"RkasProgram", 'Boolean'>
  }
    

  // Custom InputTypes
  /**
   * RkasProgram findUnique
   */
  export type RkasProgramFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the RkasProgram
     */
    select?: RkasProgramSelect<ExtArgs> | null
    /**
     * Omit specific fields from the RkasProgram
     */
    omit?: RkasProgramOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: RkasProgramInclude<ExtArgs> | null
    /**
     * Filter, which RkasProgram to fetch.
     */
    where: RkasProgramWhereUniqueInput
  }

  /**
   * RkasProgram findUniqueOrThrow
   */
  export type RkasProgramFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the RkasProgram
     */
    select?: RkasProgramSelect<ExtArgs> | null
    /**
     * Omit specific fields from the RkasProgram
     */
    omit?: RkasProgramOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: RkasProgramInclude<ExtArgs> | null
    /**
     * Filter, which RkasProgram to fetch.
     */
    where: RkasProgramWhereUniqueInput
  }

  /**
   * RkasProgram findFirst
   */
  export type RkasProgramFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the RkasProgram
     */
    select?: RkasProgramSelect<ExtArgs> | null
    /**
     * Omit specific fields from the RkasProgram
     */
    omit?: RkasProgramOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: RkasProgramInclude<ExtArgs> | null
    /**
     * Filter, which RkasProgram to fetch.
     */
    where?: RkasProgramWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of RkasPrograms to fetch.
     */
    orderBy?: RkasProgramOrderByWithRelationInput | RkasProgramOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for RkasPrograms.
     */
    cursor?: RkasProgramWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` RkasPrograms from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` RkasPrograms.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of RkasPrograms.
     */
    distinct?: RkasProgramScalarFieldEnum | RkasProgramScalarFieldEnum[]
  }

  /**
   * RkasProgram findFirstOrThrow
   */
  export type RkasProgramFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the RkasProgram
     */
    select?: RkasProgramSelect<ExtArgs> | null
    /**
     * Omit specific fields from the RkasProgram
     */
    omit?: RkasProgramOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: RkasProgramInclude<ExtArgs> | null
    /**
     * Filter, which RkasProgram to fetch.
     */
    where?: RkasProgramWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of RkasPrograms to fetch.
     */
    orderBy?: RkasProgramOrderByWithRelationInput | RkasProgramOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for RkasPrograms.
     */
    cursor?: RkasProgramWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` RkasPrograms from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` RkasPrograms.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of RkasPrograms.
     */
    distinct?: RkasProgramScalarFieldEnum | RkasProgramScalarFieldEnum[]
  }

  /**
   * RkasProgram findMany
   */
  export type RkasProgramFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the RkasProgram
     */
    select?: RkasProgramSelect<ExtArgs> | null
    /**
     * Omit specific fields from the RkasProgram
     */
    omit?: RkasProgramOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: RkasProgramInclude<ExtArgs> | null
    /**
     * Filter, which RkasPrograms to fetch.
     */
    where?: RkasProgramWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of RkasPrograms to fetch.
     */
    orderBy?: RkasProgramOrderByWithRelationInput | RkasProgramOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing RkasPrograms.
     */
    cursor?: RkasProgramWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` RkasPrograms from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` RkasPrograms.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of RkasPrograms.
     */
    distinct?: RkasProgramScalarFieldEnum | RkasProgramScalarFieldEnum[]
  }

  /**
   * RkasProgram create
   */
  export type RkasProgramCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the RkasProgram
     */
    select?: RkasProgramSelect<ExtArgs> | null
    /**
     * Omit specific fields from the RkasProgram
     */
    omit?: RkasProgramOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: RkasProgramInclude<ExtArgs> | null
    /**
     * The data needed to create a RkasProgram.
     */
    data: XOR<RkasProgramCreateInput, RkasProgramUncheckedCreateInput>
  }

  /**
   * RkasProgram createMany
   */
  export type RkasProgramCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many RkasPrograms.
     */
    data: RkasProgramCreateManyInput | RkasProgramCreateManyInput[]
  }

  /**
   * RkasProgram createManyAndReturn
   */
  export type RkasProgramCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the RkasProgram
     */
    select?: RkasProgramSelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the RkasProgram
     */
    omit?: RkasProgramOmit<ExtArgs> | null
    /**
     * The data used to create many RkasPrograms.
     */
    data: RkasProgramCreateManyInput | RkasProgramCreateManyInput[]
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: RkasProgramIncludeCreateManyAndReturn<ExtArgs> | null
  }

  /**
   * RkasProgram update
   */
  export type RkasProgramUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the RkasProgram
     */
    select?: RkasProgramSelect<ExtArgs> | null
    /**
     * Omit specific fields from the RkasProgram
     */
    omit?: RkasProgramOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: RkasProgramInclude<ExtArgs> | null
    /**
     * The data needed to update a RkasProgram.
     */
    data: XOR<RkasProgramUpdateInput, RkasProgramUncheckedUpdateInput>
    /**
     * Choose, which RkasProgram to update.
     */
    where: RkasProgramWhereUniqueInput
  }

  /**
   * RkasProgram updateMany
   */
  export type RkasProgramUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update RkasPrograms.
     */
    data: XOR<RkasProgramUpdateManyMutationInput, RkasProgramUncheckedUpdateManyInput>
    /**
     * Filter which RkasPrograms to update
     */
    where?: RkasProgramWhereInput
    /**
     * Limit how many RkasPrograms to update.
     */
    limit?: number
  }

  /**
   * RkasProgram updateManyAndReturn
   */
  export type RkasProgramUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the RkasProgram
     */
    select?: RkasProgramSelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the RkasProgram
     */
    omit?: RkasProgramOmit<ExtArgs> | null
    /**
     * The data used to update RkasPrograms.
     */
    data: XOR<RkasProgramUpdateManyMutationInput, RkasProgramUncheckedUpdateManyInput>
    /**
     * Filter which RkasPrograms to update
     */
    where?: RkasProgramWhereInput
    /**
     * Limit how many RkasPrograms to update.
     */
    limit?: number
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: RkasProgramIncludeUpdateManyAndReturn<ExtArgs> | null
  }

  /**
   * RkasProgram upsert
   */
  export type RkasProgramUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the RkasProgram
     */
    select?: RkasProgramSelect<ExtArgs> | null
    /**
     * Omit specific fields from the RkasProgram
     */
    omit?: RkasProgramOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: RkasProgramInclude<ExtArgs> | null
    /**
     * The filter to search for the RkasProgram to update in case it exists.
     */
    where: RkasProgramWhereUniqueInput
    /**
     * In case the RkasProgram found by the `where` argument doesn't exist, create a new RkasProgram with this data.
     */
    create: XOR<RkasProgramCreateInput, RkasProgramUncheckedCreateInput>
    /**
     * In case the RkasProgram was found with the provided `where` argument, update it with this data.
     */
    update: XOR<RkasProgramUpdateInput, RkasProgramUncheckedUpdateInput>
  }

  /**
   * RkasProgram delete
   */
  export type RkasProgramDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the RkasProgram
     */
    select?: RkasProgramSelect<ExtArgs> | null
    /**
     * Omit specific fields from the RkasProgram
     */
    omit?: RkasProgramOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: RkasProgramInclude<ExtArgs> | null
    /**
     * Filter which RkasProgram to delete.
     */
    where: RkasProgramWhereUniqueInput
  }

  /**
   * RkasProgram deleteMany
   */
  export type RkasProgramDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which RkasPrograms to delete
     */
    where?: RkasProgramWhereInput
    /**
     * Limit how many RkasPrograms to delete.
     */
    limit?: number
  }

  /**
   * RkasProgram.items
   */
  export type RkasProgram$itemsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the RkasItem
     */
    select?: RkasItemSelect<ExtArgs> | null
    /**
     * Omit specific fields from the RkasItem
     */
    omit?: RkasItemOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: RkasItemInclude<ExtArgs> | null
    where?: RkasItemWhereInput
    orderBy?: RkasItemOrderByWithRelationInput | RkasItemOrderByWithRelationInput[]
    cursor?: RkasItemWhereUniqueInput
    take?: number
    skip?: number
    distinct?: RkasItemScalarFieldEnum | RkasItemScalarFieldEnum[]
  }

  /**
   * RkasProgram without action
   */
  export type RkasProgramDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the RkasProgram
     */
    select?: RkasProgramSelect<ExtArgs> | null
    /**
     * Omit specific fields from the RkasProgram
     */
    omit?: RkasProgramOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: RkasProgramInclude<ExtArgs> | null
  }


  /**
   * Model RkasItem
   */

  export type AggregateRkasItem = {
    _count: RkasItemCountAggregateOutputType | null
    _avg: RkasItemAvgAggregateOutputType | null
    _sum: RkasItemSumAggregateOutputType | null
    _min: RkasItemMinAggregateOutputType | null
    _max: RkasItemMaxAggregateOutputType | null
  }

  export type RkasItemAvgAggregateOutputType = {
    urutan: number | null
    noUrut: number | null
    tarifHarga: number | null
    jumlah: number | null
  }

  export type RkasItemSumAggregateOutputType = {
    urutan: number | null
    noUrut: number | null
    tarifHarga: number | null
    jumlah: number | null
  }

  export type RkasItemMinAggregateOutputType = {
    id: string | null
    rkasProgramId: string | null
    urutan: number | null
    noUrut: number | null
    kodeRekening: string | null
    uraian: string | null
    volumeText: string | null
    tarifHarga: number | null
    jumlah: number | null
    excluded: boolean | null
  }

  export type RkasItemMaxAggregateOutputType = {
    id: string | null
    rkasProgramId: string | null
    urutan: number | null
    noUrut: number | null
    kodeRekening: string | null
    uraian: string | null
    volumeText: string | null
    tarifHarga: number | null
    jumlah: number | null
    excluded: boolean | null
  }

  export type RkasItemCountAggregateOutputType = {
    id: number
    rkasProgramId: number
    urutan: number
    noUrut: number
    kodeRekening: number
    uraian: number
    volumeText: number
    tarifHarga: number
    jumlah: number
    excluded: number
    _all: number
  }


  export type RkasItemAvgAggregateInputType = {
    urutan?: true
    noUrut?: true
    tarifHarga?: true
    jumlah?: true
  }

  export type RkasItemSumAggregateInputType = {
    urutan?: true
    noUrut?: true
    tarifHarga?: true
    jumlah?: true
  }

  export type RkasItemMinAggregateInputType = {
    id?: true
    rkasProgramId?: true
    urutan?: true
    noUrut?: true
    kodeRekening?: true
    uraian?: true
    volumeText?: true
    tarifHarga?: true
    jumlah?: true
    excluded?: true
  }

  export type RkasItemMaxAggregateInputType = {
    id?: true
    rkasProgramId?: true
    urutan?: true
    noUrut?: true
    kodeRekening?: true
    uraian?: true
    volumeText?: true
    tarifHarga?: true
    jumlah?: true
    excluded?: true
  }

  export type RkasItemCountAggregateInputType = {
    id?: true
    rkasProgramId?: true
    urutan?: true
    noUrut?: true
    kodeRekening?: true
    uraian?: true
    volumeText?: true
    tarifHarga?: true
    jumlah?: true
    excluded?: true
    _all?: true
  }

  export type RkasItemAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which RkasItem to aggregate.
     */
    where?: RkasItemWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of RkasItems to fetch.
     */
    orderBy?: RkasItemOrderByWithRelationInput | RkasItemOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: RkasItemWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` RkasItems from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` RkasItems.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned RkasItems
    **/
    _count?: true | RkasItemCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: RkasItemAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: RkasItemSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: RkasItemMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: RkasItemMaxAggregateInputType
  }

  export type GetRkasItemAggregateType<T extends RkasItemAggregateArgs> = {
        [P in keyof T & keyof AggregateRkasItem]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateRkasItem[P]>
      : GetScalarType<T[P], AggregateRkasItem[P]>
  }




  export type RkasItemGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: RkasItemWhereInput
    orderBy?: RkasItemOrderByWithAggregationInput | RkasItemOrderByWithAggregationInput[]
    by: RkasItemScalarFieldEnum[] | RkasItemScalarFieldEnum
    having?: RkasItemScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: RkasItemCountAggregateInputType | true
    _avg?: RkasItemAvgAggregateInputType
    _sum?: RkasItemSumAggregateInputType
    _min?: RkasItemMinAggregateInputType
    _max?: RkasItemMaxAggregateInputType
  }

  export type RkasItemGroupByOutputType = {
    id: string
    rkasProgramId: string
    urutan: number
    noUrut: number
    kodeRekening: string
    uraian: string
    volumeText: string
    tarifHarga: number
    jumlah: number
    excluded: boolean
    _count: RkasItemCountAggregateOutputType | null
    _avg: RkasItemAvgAggregateOutputType | null
    _sum: RkasItemSumAggregateOutputType | null
    _min: RkasItemMinAggregateOutputType | null
    _max: RkasItemMaxAggregateOutputType | null
  }

  type GetRkasItemGroupByPayload<T extends RkasItemGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<RkasItemGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof RkasItemGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], RkasItemGroupByOutputType[P]>
            : GetScalarType<T[P], RkasItemGroupByOutputType[P]>
        }
      >
    >


  export type RkasItemSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    rkasProgramId?: boolean
    urutan?: boolean
    noUrut?: boolean
    kodeRekening?: boolean
    uraian?: boolean
    volumeText?: boolean
    tarifHarga?: boolean
    jumlah?: boolean
    excluded?: boolean
    rkasProgram?: boolean | RkasProgramDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["rkasItem"]>

  export type RkasItemSelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    rkasProgramId?: boolean
    urutan?: boolean
    noUrut?: boolean
    kodeRekening?: boolean
    uraian?: boolean
    volumeText?: boolean
    tarifHarga?: boolean
    jumlah?: boolean
    excluded?: boolean
    rkasProgram?: boolean | RkasProgramDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["rkasItem"]>

  export type RkasItemSelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    rkasProgramId?: boolean
    urutan?: boolean
    noUrut?: boolean
    kodeRekening?: boolean
    uraian?: boolean
    volumeText?: boolean
    tarifHarga?: boolean
    jumlah?: boolean
    excluded?: boolean
    rkasProgram?: boolean | RkasProgramDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["rkasItem"]>

  export type RkasItemSelectScalar = {
    id?: boolean
    rkasProgramId?: boolean
    urutan?: boolean
    noUrut?: boolean
    kodeRekening?: boolean
    uraian?: boolean
    volumeText?: boolean
    tarifHarga?: boolean
    jumlah?: boolean
    excluded?: boolean
  }

  export type RkasItemOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "rkasProgramId" | "urutan" | "noUrut" | "kodeRekening" | "uraian" | "volumeText" | "tarifHarga" | "jumlah" | "excluded", ExtArgs["result"]["rkasItem"]>
  export type RkasItemInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    rkasProgram?: boolean | RkasProgramDefaultArgs<ExtArgs>
  }
  export type RkasItemIncludeCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    rkasProgram?: boolean | RkasProgramDefaultArgs<ExtArgs>
  }
  export type RkasItemIncludeUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    rkasProgram?: boolean | RkasProgramDefaultArgs<ExtArgs>
  }

  export type $RkasItemPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "RkasItem"
    objects: {
      rkasProgram: Prisma.$RkasProgramPayload<ExtArgs>
    }
    scalars: $Extensions.GetPayloadResult<{
      id: string
      rkasProgramId: string
      urutan: number
      noUrut: number
      kodeRekening: string
      uraian: string
      volumeText: string
      tarifHarga: number
      jumlah: number
      excluded: boolean
    }, ExtArgs["result"]["rkasItem"]>
    composites: {}
  }

  type RkasItemGetPayload<S extends boolean | null | undefined | RkasItemDefaultArgs> = $Result.GetResult<Prisma.$RkasItemPayload, S>

  type RkasItemCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<RkasItemFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: RkasItemCountAggregateInputType | true
    }

  export interface RkasItemDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['RkasItem'], meta: { name: 'RkasItem' } }
    /**
     * Find zero or one RkasItem that matches the filter.
     * @param {RkasItemFindUniqueArgs} args - Arguments to find a RkasItem
     * @example
     * // Get one RkasItem
     * const rkasItem = await prisma.rkasItem.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends RkasItemFindUniqueArgs>(args: SelectSubset<T, RkasItemFindUniqueArgs<ExtArgs>>): Prisma__RkasItemClient<$Result.GetResult<Prisma.$RkasItemPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one RkasItem that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {RkasItemFindUniqueOrThrowArgs} args - Arguments to find a RkasItem
     * @example
     * // Get one RkasItem
     * const rkasItem = await prisma.rkasItem.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends RkasItemFindUniqueOrThrowArgs>(args: SelectSubset<T, RkasItemFindUniqueOrThrowArgs<ExtArgs>>): Prisma__RkasItemClient<$Result.GetResult<Prisma.$RkasItemPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first RkasItem that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {RkasItemFindFirstArgs} args - Arguments to find a RkasItem
     * @example
     * // Get one RkasItem
     * const rkasItem = await prisma.rkasItem.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends RkasItemFindFirstArgs>(args?: SelectSubset<T, RkasItemFindFirstArgs<ExtArgs>>): Prisma__RkasItemClient<$Result.GetResult<Prisma.$RkasItemPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first RkasItem that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {RkasItemFindFirstOrThrowArgs} args - Arguments to find a RkasItem
     * @example
     * // Get one RkasItem
     * const rkasItem = await prisma.rkasItem.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends RkasItemFindFirstOrThrowArgs>(args?: SelectSubset<T, RkasItemFindFirstOrThrowArgs<ExtArgs>>): Prisma__RkasItemClient<$Result.GetResult<Prisma.$RkasItemPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more RkasItems that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {RkasItemFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all RkasItems
     * const rkasItems = await prisma.rkasItem.findMany()
     * 
     * // Get first 10 RkasItems
     * const rkasItems = await prisma.rkasItem.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const rkasItemWithIdOnly = await prisma.rkasItem.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends RkasItemFindManyArgs>(args?: SelectSubset<T, RkasItemFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$RkasItemPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a RkasItem.
     * @param {RkasItemCreateArgs} args - Arguments to create a RkasItem.
     * @example
     * // Create one RkasItem
     * const RkasItem = await prisma.rkasItem.create({
     *   data: {
     *     // ... data to create a RkasItem
     *   }
     * })
     * 
     */
    create<T extends RkasItemCreateArgs>(args: SelectSubset<T, RkasItemCreateArgs<ExtArgs>>): Prisma__RkasItemClient<$Result.GetResult<Prisma.$RkasItemPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many RkasItems.
     * @param {RkasItemCreateManyArgs} args - Arguments to create many RkasItems.
     * @example
     * // Create many RkasItems
     * const rkasItem = await prisma.rkasItem.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends RkasItemCreateManyArgs>(args?: SelectSubset<T, RkasItemCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many RkasItems and returns the data saved in the database.
     * @param {RkasItemCreateManyAndReturnArgs} args - Arguments to create many RkasItems.
     * @example
     * // Create many RkasItems
     * const rkasItem = await prisma.rkasItem.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many RkasItems and only return the `id`
     * const rkasItemWithIdOnly = await prisma.rkasItem.createManyAndReturn({
     *   select: { id: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends RkasItemCreateManyAndReturnArgs>(args?: SelectSubset<T, RkasItemCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$RkasItemPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a RkasItem.
     * @param {RkasItemDeleteArgs} args - Arguments to delete one RkasItem.
     * @example
     * // Delete one RkasItem
     * const RkasItem = await prisma.rkasItem.delete({
     *   where: {
     *     // ... filter to delete one RkasItem
     *   }
     * })
     * 
     */
    delete<T extends RkasItemDeleteArgs>(args: SelectSubset<T, RkasItemDeleteArgs<ExtArgs>>): Prisma__RkasItemClient<$Result.GetResult<Prisma.$RkasItemPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one RkasItem.
     * @param {RkasItemUpdateArgs} args - Arguments to update one RkasItem.
     * @example
     * // Update one RkasItem
     * const rkasItem = await prisma.rkasItem.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends RkasItemUpdateArgs>(args: SelectSubset<T, RkasItemUpdateArgs<ExtArgs>>): Prisma__RkasItemClient<$Result.GetResult<Prisma.$RkasItemPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more RkasItems.
     * @param {RkasItemDeleteManyArgs} args - Arguments to filter RkasItems to delete.
     * @example
     * // Delete a few RkasItems
     * const { count } = await prisma.rkasItem.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends RkasItemDeleteManyArgs>(args?: SelectSubset<T, RkasItemDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more RkasItems.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {RkasItemUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many RkasItems
     * const rkasItem = await prisma.rkasItem.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends RkasItemUpdateManyArgs>(args: SelectSubset<T, RkasItemUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more RkasItems and returns the data updated in the database.
     * @param {RkasItemUpdateManyAndReturnArgs} args - Arguments to update many RkasItems.
     * @example
     * // Update many RkasItems
     * const rkasItem = await prisma.rkasItem.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more RkasItems and only return the `id`
     * const rkasItemWithIdOnly = await prisma.rkasItem.updateManyAndReturn({
     *   select: { id: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends RkasItemUpdateManyAndReturnArgs>(args: SelectSubset<T, RkasItemUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$RkasItemPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one RkasItem.
     * @param {RkasItemUpsertArgs} args - Arguments to update or create a RkasItem.
     * @example
     * // Update or create a RkasItem
     * const rkasItem = await prisma.rkasItem.upsert({
     *   create: {
     *     // ... data to create a RkasItem
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the RkasItem we want to update
     *   }
     * })
     */
    upsert<T extends RkasItemUpsertArgs>(args: SelectSubset<T, RkasItemUpsertArgs<ExtArgs>>): Prisma__RkasItemClient<$Result.GetResult<Prisma.$RkasItemPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of RkasItems.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {RkasItemCountArgs} args - Arguments to filter RkasItems to count.
     * @example
     * // Count the number of RkasItems
     * const count = await prisma.rkasItem.count({
     *   where: {
     *     // ... the filter for the RkasItems we want to count
     *   }
     * })
    **/
    count<T extends RkasItemCountArgs>(
      args?: Subset<T, RkasItemCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], RkasItemCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a RkasItem.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {RkasItemAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends RkasItemAggregateArgs>(args: Subset<T, RkasItemAggregateArgs>): Prisma.PrismaPromise<GetRkasItemAggregateType<T>>

    /**
     * Group by RkasItem.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {RkasItemGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends RkasItemGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: RkasItemGroupByArgs['orderBy'] }
        : { orderBy?: RkasItemGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, RkasItemGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetRkasItemGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the RkasItem model
   */
  readonly fields: RkasItemFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for RkasItem.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__RkasItemClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    rkasProgram<T extends RkasProgramDefaultArgs<ExtArgs> = {}>(args?: Subset<T, RkasProgramDefaultArgs<ExtArgs>>): Prisma__RkasProgramClient<$Result.GetResult<Prisma.$RkasProgramPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the RkasItem model
   */
  interface RkasItemFieldRefs {
    readonly id: FieldRef<"RkasItem", 'String'>
    readonly rkasProgramId: FieldRef<"RkasItem", 'String'>
    readonly urutan: FieldRef<"RkasItem", 'Int'>
    readonly noUrut: FieldRef<"RkasItem", 'Int'>
    readonly kodeRekening: FieldRef<"RkasItem", 'String'>
    readonly uraian: FieldRef<"RkasItem", 'String'>
    readonly volumeText: FieldRef<"RkasItem", 'String'>
    readonly tarifHarga: FieldRef<"RkasItem", 'Int'>
    readonly jumlah: FieldRef<"RkasItem", 'Int'>
    readonly excluded: FieldRef<"RkasItem", 'Boolean'>
  }
    

  // Custom InputTypes
  /**
   * RkasItem findUnique
   */
  export type RkasItemFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the RkasItem
     */
    select?: RkasItemSelect<ExtArgs> | null
    /**
     * Omit specific fields from the RkasItem
     */
    omit?: RkasItemOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: RkasItemInclude<ExtArgs> | null
    /**
     * Filter, which RkasItem to fetch.
     */
    where: RkasItemWhereUniqueInput
  }

  /**
   * RkasItem findUniqueOrThrow
   */
  export type RkasItemFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the RkasItem
     */
    select?: RkasItemSelect<ExtArgs> | null
    /**
     * Omit specific fields from the RkasItem
     */
    omit?: RkasItemOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: RkasItemInclude<ExtArgs> | null
    /**
     * Filter, which RkasItem to fetch.
     */
    where: RkasItemWhereUniqueInput
  }

  /**
   * RkasItem findFirst
   */
  export type RkasItemFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the RkasItem
     */
    select?: RkasItemSelect<ExtArgs> | null
    /**
     * Omit specific fields from the RkasItem
     */
    omit?: RkasItemOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: RkasItemInclude<ExtArgs> | null
    /**
     * Filter, which RkasItem to fetch.
     */
    where?: RkasItemWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of RkasItems to fetch.
     */
    orderBy?: RkasItemOrderByWithRelationInput | RkasItemOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for RkasItems.
     */
    cursor?: RkasItemWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` RkasItems from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` RkasItems.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of RkasItems.
     */
    distinct?: RkasItemScalarFieldEnum | RkasItemScalarFieldEnum[]
  }

  /**
   * RkasItem findFirstOrThrow
   */
  export type RkasItemFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the RkasItem
     */
    select?: RkasItemSelect<ExtArgs> | null
    /**
     * Omit specific fields from the RkasItem
     */
    omit?: RkasItemOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: RkasItemInclude<ExtArgs> | null
    /**
     * Filter, which RkasItem to fetch.
     */
    where?: RkasItemWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of RkasItems to fetch.
     */
    orderBy?: RkasItemOrderByWithRelationInput | RkasItemOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for RkasItems.
     */
    cursor?: RkasItemWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` RkasItems from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` RkasItems.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of RkasItems.
     */
    distinct?: RkasItemScalarFieldEnum | RkasItemScalarFieldEnum[]
  }

  /**
   * RkasItem findMany
   */
  export type RkasItemFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the RkasItem
     */
    select?: RkasItemSelect<ExtArgs> | null
    /**
     * Omit specific fields from the RkasItem
     */
    omit?: RkasItemOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: RkasItemInclude<ExtArgs> | null
    /**
     * Filter, which RkasItems to fetch.
     */
    where?: RkasItemWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of RkasItems to fetch.
     */
    orderBy?: RkasItemOrderByWithRelationInput | RkasItemOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing RkasItems.
     */
    cursor?: RkasItemWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` RkasItems from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` RkasItems.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of RkasItems.
     */
    distinct?: RkasItemScalarFieldEnum | RkasItemScalarFieldEnum[]
  }

  /**
   * RkasItem create
   */
  export type RkasItemCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the RkasItem
     */
    select?: RkasItemSelect<ExtArgs> | null
    /**
     * Omit specific fields from the RkasItem
     */
    omit?: RkasItemOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: RkasItemInclude<ExtArgs> | null
    /**
     * The data needed to create a RkasItem.
     */
    data: XOR<RkasItemCreateInput, RkasItemUncheckedCreateInput>
  }

  /**
   * RkasItem createMany
   */
  export type RkasItemCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many RkasItems.
     */
    data: RkasItemCreateManyInput | RkasItemCreateManyInput[]
  }

  /**
   * RkasItem createManyAndReturn
   */
  export type RkasItemCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the RkasItem
     */
    select?: RkasItemSelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the RkasItem
     */
    omit?: RkasItemOmit<ExtArgs> | null
    /**
     * The data used to create many RkasItems.
     */
    data: RkasItemCreateManyInput | RkasItemCreateManyInput[]
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: RkasItemIncludeCreateManyAndReturn<ExtArgs> | null
  }

  /**
   * RkasItem update
   */
  export type RkasItemUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the RkasItem
     */
    select?: RkasItemSelect<ExtArgs> | null
    /**
     * Omit specific fields from the RkasItem
     */
    omit?: RkasItemOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: RkasItemInclude<ExtArgs> | null
    /**
     * The data needed to update a RkasItem.
     */
    data: XOR<RkasItemUpdateInput, RkasItemUncheckedUpdateInput>
    /**
     * Choose, which RkasItem to update.
     */
    where: RkasItemWhereUniqueInput
  }

  /**
   * RkasItem updateMany
   */
  export type RkasItemUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update RkasItems.
     */
    data: XOR<RkasItemUpdateManyMutationInput, RkasItemUncheckedUpdateManyInput>
    /**
     * Filter which RkasItems to update
     */
    where?: RkasItemWhereInput
    /**
     * Limit how many RkasItems to update.
     */
    limit?: number
  }

  /**
   * RkasItem updateManyAndReturn
   */
  export type RkasItemUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the RkasItem
     */
    select?: RkasItemSelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the RkasItem
     */
    omit?: RkasItemOmit<ExtArgs> | null
    /**
     * The data used to update RkasItems.
     */
    data: XOR<RkasItemUpdateManyMutationInput, RkasItemUncheckedUpdateManyInput>
    /**
     * Filter which RkasItems to update
     */
    where?: RkasItemWhereInput
    /**
     * Limit how many RkasItems to update.
     */
    limit?: number
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: RkasItemIncludeUpdateManyAndReturn<ExtArgs> | null
  }

  /**
   * RkasItem upsert
   */
  export type RkasItemUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the RkasItem
     */
    select?: RkasItemSelect<ExtArgs> | null
    /**
     * Omit specific fields from the RkasItem
     */
    omit?: RkasItemOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: RkasItemInclude<ExtArgs> | null
    /**
     * The filter to search for the RkasItem to update in case it exists.
     */
    where: RkasItemWhereUniqueInput
    /**
     * In case the RkasItem found by the `where` argument doesn't exist, create a new RkasItem with this data.
     */
    create: XOR<RkasItemCreateInput, RkasItemUncheckedCreateInput>
    /**
     * In case the RkasItem was found with the provided `where` argument, update it with this data.
     */
    update: XOR<RkasItemUpdateInput, RkasItemUncheckedUpdateInput>
  }

  /**
   * RkasItem delete
   */
  export type RkasItemDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the RkasItem
     */
    select?: RkasItemSelect<ExtArgs> | null
    /**
     * Omit specific fields from the RkasItem
     */
    omit?: RkasItemOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: RkasItemInclude<ExtArgs> | null
    /**
     * Filter which RkasItem to delete.
     */
    where: RkasItemWhereUniqueInput
  }

  /**
   * RkasItem deleteMany
   */
  export type RkasItemDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which RkasItems to delete
     */
    where?: RkasItemWhereInput
    /**
     * Limit how many RkasItems to delete.
     */
    limit?: number
  }

  /**
   * RkasItem without action
   */
  export type RkasItemDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the RkasItem
     */
    select?: RkasItemSelect<ExtArgs> | null
    /**
     * Omit specific fields from the RkasItem
     */
    omit?: RkasItemOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: RkasItemInclude<ExtArgs> | null
  }


  /**
   * Model InstrumenBosp
   */

  export type AggregateInstrumenBosp = {
    _count: InstrumenBospCountAggregateOutputType | null
    _avg: InstrumenBospAvgAggregateOutputType | null
    _sum: InstrumenBospSumAggregateOutputType | null
    _min: InstrumenBospMinAggregateOutputType | null
    _max: InstrumenBospMaxAggregateOutputType | null
  }

  export type InstrumenBospAvgAggregateOutputType = {
    year: number | null
    tahap: number | null
    totalAlokasiTahunan: number | null
    saldoAwalOverride: number | null
    operasionalOverride: number | null
  }

  export type InstrumenBospSumAggregateOutputType = {
    year: number | null
    tahap: number | null
    totalAlokasiTahunan: number | null
    saldoAwalOverride: number | null
    operasionalOverride: number | null
  }

  export type InstrumenBospMinAggregateOutputType = {
    id: string | null
    schoolId: string | null
    year: number | null
    tahap: number | null
    jenisSatuan: string | null
    statusSatuan: string | null
    kelurahan: string | null
    kecamatan: string | null
    jenisDanaBosp: string | null
    skNomor: string | null
    skTanggal: string | null
    kepalaName: string | null
    bendaharaName: string | null
    komiteName: string | null
    adaBku: boolean | null
    adaBukuPembantuKas: boolean | null
    adaBukuPembantuPajak: boolean | null
    adaBukuPembantuBank: boolean | null
    adaLaporanRealisasi: boolean | null
    totalAlokasiTahunan: number | null
    saldoAwalOverride: number | null
    operasionalOverride: number | null
    honorSesuaiRkas: boolean | null
    honorBuktiLengkap: boolean | null
    honorPenerimaSesuai: boolean | null
    metodePengadaanBuku: string | null
    metodePengadaanLain: string | null
    belanjaModalJson: string | null
    pemeliharaanJson: string | null
    bukuOverrideJson: string | null
    tanggalDokumen: string | null
    createdAt: Date | null
    updatedAt: Date | null
  }

  export type InstrumenBospMaxAggregateOutputType = {
    id: string | null
    schoolId: string | null
    year: number | null
    tahap: number | null
    jenisSatuan: string | null
    statusSatuan: string | null
    kelurahan: string | null
    kecamatan: string | null
    jenisDanaBosp: string | null
    skNomor: string | null
    skTanggal: string | null
    kepalaName: string | null
    bendaharaName: string | null
    komiteName: string | null
    adaBku: boolean | null
    adaBukuPembantuKas: boolean | null
    adaBukuPembantuPajak: boolean | null
    adaBukuPembantuBank: boolean | null
    adaLaporanRealisasi: boolean | null
    totalAlokasiTahunan: number | null
    saldoAwalOverride: number | null
    operasionalOverride: number | null
    honorSesuaiRkas: boolean | null
    honorBuktiLengkap: boolean | null
    honorPenerimaSesuai: boolean | null
    metodePengadaanBuku: string | null
    metodePengadaanLain: string | null
    belanjaModalJson: string | null
    pemeliharaanJson: string | null
    bukuOverrideJson: string | null
    tanggalDokumen: string | null
    createdAt: Date | null
    updatedAt: Date | null
  }

  export type InstrumenBospCountAggregateOutputType = {
    id: number
    schoolId: number
    year: number
    tahap: number
    jenisSatuan: number
    statusSatuan: number
    kelurahan: number
    kecamatan: number
    jenisDanaBosp: number
    skNomor: number
    skTanggal: number
    kepalaName: number
    bendaharaName: number
    komiteName: number
    adaBku: number
    adaBukuPembantuKas: number
    adaBukuPembantuPajak: number
    adaBukuPembantuBank: number
    adaLaporanRealisasi: number
    totalAlokasiTahunan: number
    saldoAwalOverride: number
    operasionalOverride: number
    honorSesuaiRkas: number
    honorBuktiLengkap: number
    honorPenerimaSesuai: number
    metodePengadaanBuku: number
    metodePengadaanLain: number
    belanjaModalJson: number
    pemeliharaanJson: number
    bukuOverrideJson: number
    tanggalDokumen: number
    createdAt: number
    updatedAt: number
    _all: number
  }


  export type InstrumenBospAvgAggregateInputType = {
    year?: true
    tahap?: true
    totalAlokasiTahunan?: true
    saldoAwalOverride?: true
    operasionalOverride?: true
  }

  export type InstrumenBospSumAggregateInputType = {
    year?: true
    tahap?: true
    totalAlokasiTahunan?: true
    saldoAwalOverride?: true
    operasionalOverride?: true
  }

  export type InstrumenBospMinAggregateInputType = {
    id?: true
    schoolId?: true
    year?: true
    tahap?: true
    jenisSatuan?: true
    statusSatuan?: true
    kelurahan?: true
    kecamatan?: true
    jenisDanaBosp?: true
    skNomor?: true
    skTanggal?: true
    kepalaName?: true
    bendaharaName?: true
    komiteName?: true
    adaBku?: true
    adaBukuPembantuKas?: true
    adaBukuPembantuPajak?: true
    adaBukuPembantuBank?: true
    adaLaporanRealisasi?: true
    totalAlokasiTahunan?: true
    saldoAwalOverride?: true
    operasionalOverride?: true
    honorSesuaiRkas?: true
    honorBuktiLengkap?: true
    honorPenerimaSesuai?: true
    metodePengadaanBuku?: true
    metodePengadaanLain?: true
    belanjaModalJson?: true
    pemeliharaanJson?: true
    bukuOverrideJson?: true
    tanggalDokumen?: true
    createdAt?: true
    updatedAt?: true
  }

  export type InstrumenBospMaxAggregateInputType = {
    id?: true
    schoolId?: true
    year?: true
    tahap?: true
    jenisSatuan?: true
    statusSatuan?: true
    kelurahan?: true
    kecamatan?: true
    jenisDanaBosp?: true
    skNomor?: true
    skTanggal?: true
    kepalaName?: true
    bendaharaName?: true
    komiteName?: true
    adaBku?: true
    adaBukuPembantuKas?: true
    adaBukuPembantuPajak?: true
    adaBukuPembantuBank?: true
    adaLaporanRealisasi?: true
    totalAlokasiTahunan?: true
    saldoAwalOverride?: true
    operasionalOverride?: true
    honorSesuaiRkas?: true
    honorBuktiLengkap?: true
    honorPenerimaSesuai?: true
    metodePengadaanBuku?: true
    metodePengadaanLain?: true
    belanjaModalJson?: true
    pemeliharaanJson?: true
    bukuOverrideJson?: true
    tanggalDokumen?: true
    createdAt?: true
    updatedAt?: true
  }

  export type InstrumenBospCountAggregateInputType = {
    id?: true
    schoolId?: true
    year?: true
    tahap?: true
    jenisSatuan?: true
    statusSatuan?: true
    kelurahan?: true
    kecamatan?: true
    jenisDanaBosp?: true
    skNomor?: true
    skTanggal?: true
    kepalaName?: true
    bendaharaName?: true
    komiteName?: true
    adaBku?: true
    adaBukuPembantuKas?: true
    adaBukuPembantuPajak?: true
    adaBukuPembantuBank?: true
    adaLaporanRealisasi?: true
    totalAlokasiTahunan?: true
    saldoAwalOverride?: true
    operasionalOverride?: true
    honorSesuaiRkas?: true
    honorBuktiLengkap?: true
    honorPenerimaSesuai?: true
    metodePengadaanBuku?: true
    metodePengadaanLain?: true
    belanjaModalJson?: true
    pemeliharaanJson?: true
    bukuOverrideJson?: true
    tanggalDokumen?: true
    createdAt?: true
    updatedAt?: true
    _all?: true
  }

  export type InstrumenBospAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which InstrumenBosp to aggregate.
     */
    where?: InstrumenBospWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of InstrumenBosps to fetch.
     */
    orderBy?: InstrumenBospOrderByWithRelationInput | InstrumenBospOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: InstrumenBospWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` InstrumenBosps from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` InstrumenBosps.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned InstrumenBosps
    **/
    _count?: true | InstrumenBospCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: InstrumenBospAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: InstrumenBospSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: InstrumenBospMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: InstrumenBospMaxAggregateInputType
  }

  export type GetInstrumenBospAggregateType<T extends InstrumenBospAggregateArgs> = {
        [P in keyof T & keyof AggregateInstrumenBosp]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateInstrumenBosp[P]>
      : GetScalarType<T[P], AggregateInstrumenBosp[P]>
  }




  export type InstrumenBospGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: InstrumenBospWhereInput
    orderBy?: InstrumenBospOrderByWithAggregationInput | InstrumenBospOrderByWithAggregationInput[]
    by: InstrumenBospScalarFieldEnum[] | InstrumenBospScalarFieldEnum
    having?: InstrumenBospScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: InstrumenBospCountAggregateInputType | true
    _avg?: InstrumenBospAvgAggregateInputType
    _sum?: InstrumenBospSumAggregateInputType
    _min?: InstrumenBospMinAggregateInputType
    _max?: InstrumenBospMaxAggregateInputType
  }

  export type InstrumenBospGroupByOutputType = {
    id: string
    schoolId: string
    year: number
    tahap: number
    jenisSatuan: string
    statusSatuan: string
    kelurahan: string
    kecamatan: string
    jenisDanaBosp: string
    skNomor: string
    skTanggal: string
    kepalaName: string
    bendaharaName: string
    komiteName: string
    adaBku: boolean
    adaBukuPembantuKas: boolean
    adaBukuPembantuPajak: boolean
    adaBukuPembantuBank: boolean
    adaLaporanRealisasi: boolean
    totalAlokasiTahunan: number
    saldoAwalOverride: number | null
    operasionalOverride: number | null
    honorSesuaiRkas: boolean
    honorBuktiLengkap: boolean
    honorPenerimaSesuai: boolean
    metodePengadaanBuku: string
    metodePengadaanLain: string
    belanjaModalJson: string
    pemeliharaanJson: string
    bukuOverrideJson: string
    tanggalDokumen: string
    createdAt: Date
    updatedAt: Date
    _count: InstrumenBospCountAggregateOutputType | null
    _avg: InstrumenBospAvgAggregateOutputType | null
    _sum: InstrumenBospSumAggregateOutputType | null
    _min: InstrumenBospMinAggregateOutputType | null
    _max: InstrumenBospMaxAggregateOutputType | null
  }

  type GetInstrumenBospGroupByPayload<T extends InstrumenBospGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<InstrumenBospGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof InstrumenBospGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], InstrumenBospGroupByOutputType[P]>
            : GetScalarType<T[P], InstrumenBospGroupByOutputType[P]>
        }
      >
    >


  export type InstrumenBospSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    schoolId?: boolean
    year?: boolean
    tahap?: boolean
    jenisSatuan?: boolean
    statusSatuan?: boolean
    kelurahan?: boolean
    kecamatan?: boolean
    jenisDanaBosp?: boolean
    skNomor?: boolean
    skTanggal?: boolean
    kepalaName?: boolean
    bendaharaName?: boolean
    komiteName?: boolean
    adaBku?: boolean
    adaBukuPembantuKas?: boolean
    adaBukuPembantuPajak?: boolean
    adaBukuPembantuBank?: boolean
    adaLaporanRealisasi?: boolean
    totalAlokasiTahunan?: boolean
    saldoAwalOverride?: boolean
    operasionalOverride?: boolean
    honorSesuaiRkas?: boolean
    honorBuktiLengkap?: boolean
    honorPenerimaSesuai?: boolean
    metodePengadaanBuku?: boolean
    metodePengadaanLain?: boolean
    belanjaModalJson?: boolean
    pemeliharaanJson?: boolean
    bukuOverrideJson?: boolean
    tanggalDokumen?: boolean
    createdAt?: boolean
    updatedAt?: boolean
    school?: boolean | SchoolDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["instrumenBosp"]>

  export type InstrumenBospSelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    schoolId?: boolean
    year?: boolean
    tahap?: boolean
    jenisSatuan?: boolean
    statusSatuan?: boolean
    kelurahan?: boolean
    kecamatan?: boolean
    jenisDanaBosp?: boolean
    skNomor?: boolean
    skTanggal?: boolean
    kepalaName?: boolean
    bendaharaName?: boolean
    komiteName?: boolean
    adaBku?: boolean
    adaBukuPembantuKas?: boolean
    adaBukuPembantuPajak?: boolean
    adaBukuPembantuBank?: boolean
    adaLaporanRealisasi?: boolean
    totalAlokasiTahunan?: boolean
    saldoAwalOverride?: boolean
    operasionalOverride?: boolean
    honorSesuaiRkas?: boolean
    honorBuktiLengkap?: boolean
    honorPenerimaSesuai?: boolean
    metodePengadaanBuku?: boolean
    metodePengadaanLain?: boolean
    belanjaModalJson?: boolean
    pemeliharaanJson?: boolean
    bukuOverrideJson?: boolean
    tanggalDokumen?: boolean
    createdAt?: boolean
    updatedAt?: boolean
    school?: boolean | SchoolDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["instrumenBosp"]>

  export type InstrumenBospSelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    schoolId?: boolean
    year?: boolean
    tahap?: boolean
    jenisSatuan?: boolean
    statusSatuan?: boolean
    kelurahan?: boolean
    kecamatan?: boolean
    jenisDanaBosp?: boolean
    skNomor?: boolean
    skTanggal?: boolean
    kepalaName?: boolean
    bendaharaName?: boolean
    komiteName?: boolean
    adaBku?: boolean
    adaBukuPembantuKas?: boolean
    adaBukuPembantuPajak?: boolean
    adaBukuPembantuBank?: boolean
    adaLaporanRealisasi?: boolean
    totalAlokasiTahunan?: boolean
    saldoAwalOverride?: boolean
    operasionalOverride?: boolean
    honorSesuaiRkas?: boolean
    honorBuktiLengkap?: boolean
    honorPenerimaSesuai?: boolean
    metodePengadaanBuku?: boolean
    metodePengadaanLain?: boolean
    belanjaModalJson?: boolean
    pemeliharaanJson?: boolean
    bukuOverrideJson?: boolean
    tanggalDokumen?: boolean
    createdAt?: boolean
    updatedAt?: boolean
    school?: boolean | SchoolDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["instrumenBosp"]>

  export type InstrumenBospSelectScalar = {
    id?: boolean
    schoolId?: boolean
    year?: boolean
    tahap?: boolean
    jenisSatuan?: boolean
    statusSatuan?: boolean
    kelurahan?: boolean
    kecamatan?: boolean
    jenisDanaBosp?: boolean
    skNomor?: boolean
    skTanggal?: boolean
    kepalaName?: boolean
    bendaharaName?: boolean
    komiteName?: boolean
    adaBku?: boolean
    adaBukuPembantuKas?: boolean
    adaBukuPembantuPajak?: boolean
    adaBukuPembantuBank?: boolean
    adaLaporanRealisasi?: boolean
    totalAlokasiTahunan?: boolean
    saldoAwalOverride?: boolean
    operasionalOverride?: boolean
    honorSesuaiRkas?: boolean
    honorBuktiLengkap?: boolean
    honorPenerimaSesuai?: boolean
    metodePengadaanBuku?: boolean
    metodePengadaanLain?: boolean
    belanjaModalJson?: boolean
    pemeliharaanJson?: boolean
    bukuOverrideJson?: boolean
    tanggalDokumen?: boolean
    createdAt?: boolean
    updatedAt?: boolean
  }

  export type InstrumenBospOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "schoolId" | "year" | "tahap" | "jenisSatuan" | "statusSatuan" | "kelurahan" | "kecamatan" | "jenisDanaBosp" | "skNomor" | "skTanggal" | "kepalaName" | "bendaharaName" | "komiteName" | "adaBku" | "adaBukuPembantuKas" | "adaBukuPembantuPajak" | "adaBukuPembantuBank" | "adaLaporanRealisasi" | "totalAlokasiTahunan" | "saldoAwalOverride" | "operasionalOverride" | "honorSesuaiRkas" | "honorBuktiLengkap" | "honorPenerimaSesuai" | "metodePengadaanBuku" | "metodePengadaanLain" | "belanjaModalJson" | "pemeliharaanJson" | "bukuOverrideJson" | "tanggalDokumen" | "createdAt" | "updatedAt", ExtArgs["result"]["instrumenBosp"]>
  export type InstrumenBospInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    school?: boolean | SchoolDefaultArgs<ExtArgs>
  }
  export type InstrumenBospIncludeCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    school?: boolean | SchoolDefaultArgs<ExtArgs>
  }
  export type InstrumenBospIncludeUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    school?: boolean | SchoolDefaultArgs<ExtArgs>
  }

  export type $InstrumenBospPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "InstrumenBosp"
    objects: {
      school: Prisma.$SchoolPayload<ExtArgs>
    }
    scalars: $Extensions.GetPayloadResult<{
      id: string
      schoolId: string
      year: number
      tahap: number
      jenisSatuan: string
      statusSatuan: string
      kelurahan: string
      kecamatan: string
      jenisDanaBosp: string
      skNomor: string
      skTanggal: string
      kepalaName: string
      bendaharaName: string
      komiteName: string
      adaBku: boolean
      adaBukuPembantuKas: boolean
      adaBukuPembantuPajak: boolean
      adaBukuPembantuBank: boolean
      adaLaporanRealisasi: boolean
      totalAlokasiTahunan: number
      saldoAwalOverride: number | null
      operasionalOverride: number | null
      honorSesuaiRkas: boolean
      honorBuktiLengkap: boolean
      honorPenerimaSesuai: boolean
      metodePengadaanBuku: string
      metodePengadaanLain: string
      belanjaModalJson: string
      pemeliharaanJson: string
      bukuOverrideJson: string
      tanggalDokumen: string
      createdAt: Date
      updatedAt: Date
    }, ExtArgs["result"]["instrumenBosp"]>
    composites: {}
  }

  type InstrumenBospGetPayload<S extends boolean | null | undefined | InstrumenBospDefaultArgs> = $Result.GetResult<Prisma.$InstrumenBospPayload, S>

  type InstrumenBospCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<InstrumenBospFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: InstrumenBospCountAggregateInputType | true
    }

  export interface InstrumenBospDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['InstrumenBosp'], meta: { name: 'InstrumenBosp' } }
    /**
     * Find zero or one InstrumenBosp that matches the filter.
     * @param {InstrumenBospFindUniqueArgs} args - Arguments to find a InstrumenBosp
     * @example
     * // Get one InstrumenBosp
     * const instrumenBosp = await prisma.instrumenBosp.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends InstrumenBospFindUniqueArgs>(args: SelectSubset<T, InstrumenBospFindUniqueArgs<ExtArgs>>): Prisma__InstrumenBospClient<$Result.GetResult<Prisma.$InstrumenBospPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one InstrumenBosp that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {InstrumenBospFindUniqueOrThrowArgs} args - Arguments to find a InstrumenBosp
     * @example
     * // Get one InstrumenBosp
     * const instrumenBosp = await prisma.instrumenBosp.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends InstrumenBospFindUniqueOrThrowArgs>(args: SelectSubset<T, InstrumenBospFindUniqueOrThrowArgs<ExtArgs>>): Prisma__InstrumenBospClient<$Result.GetResult<Prisma.$InstrumenBospPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first InstrumenBosp that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {InstrumenBospFindFirstArgs} args - Arguments to find a InstrumenBosp
     * @example
     * // Get one InstrumenBosp
     * const instrumenBosp = await prisma.instrumenBosp.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends InstrumenBospFindFirstArgs>(args?: SelectSubset<T, InstrumenBospFindFirstArgs<ExtArgs>>): Prisma__InstrumenBospClient<$Result.GetResult<Prisma.$InstrumenBospPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first InstrumenBosp that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {InstrumenBospFindFirstOrThrowArgs} args - Arguments to find a InstrumenBosp
     * @example
     * // Get one InstrumenBosp
     * const instrumenBosp = await prisma.instrumenBosp.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends InstrumenBospFindFirstOrThrowArgs>(args?: SelectSubset<T, InstrumenBospFindFirstOrThrowArgs<ExtArgs>>): Prisma__InstrumenBospClient<$Result.GetResult<Prisma.$InstrumenBospPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more InstrumenBosps that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {InstrumenBospFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all InstrumenBosps
     * const instrumenBosps = await prisma.instrumenBosp.findMany()
     * 
     * // Get first 10 InstrumenBosps
     * const instrumenBosps = await prisma.instrumenBosp.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const instrumenBospWithIdOnly = await prisma.instrumenBosp.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends InstrumenBospFindManyArgs>(args?: SelectSubset<T, InstrumenBospFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$InstrumenBospPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a InstrumenBosp.
     * @param {InstrumenBospCreateArgs} args - Arguments to create a InstrumenBosp.
     * @example
     * // Create one InstrumenBosp
     * const InstrumenBosp = await prisma.instrumenBosp.create({
     *   data: {
     *     // ... data to create a InstrumenBosp
     *   }
     * })
     * 
     */
    create<T extends InstrumenBospCreateArgs>(args: SelectSubset<T, InstrumenBospCreateArgs<ExtArgs>>): Prisma__InstrumenBospClient<$Result.GetResult<Prisma.$InstrumenBospPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many InstrumenBosps.
     * @param {InstrumenBospCreateManyArgs} args - Arguments to create many InstrumenBosps.
     * @example
     * // Create many InstrumenBosps
     * const instrumenBosp = await prisma.instrumenBosp.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends InstrumenBospCreateManyArgs>(args?: SelectSubset<T, InstrumenBospCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many InstrumenBosps and returns the data saved in the database.
     * @param {InstrumenBospCreateManyAndReturnArgs} args - Arguments to create many InstrumenBosps.
     * @example
     * // Create many InstrumenBosps
     * const instrumenBosp = await prisma.instrumenBosp.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many InstrumenBosps and only return the `id`
     * const instrumenBospWithIdOnly = await prisma.instrumenBosp.createManyAndReturn({
     *   select: { id: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends InstrumenBospCreateManyAndReturnArgs>(args?: SelectSubset<T, InstrumenBospCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$InstrumenBospPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a InstrumenBosp.
     * @param {InstrumenBospDeleteArgs} args - Arguments to delete one InstrumenBosp.
     * @example
     * // Delete one InstrumenBosp
     * const InstrumenBosp = await prisma.instrumenBosp.delete({
     *   where: {
     *     // ... filter to delete one InstrumenBosp
     *   }
     * })
     * 
     */
    delete<T extends InstrumenBospDeleteArgs>(args: SelectSubset<T, InstrumenBospDeleteArgs<ExtArgs>>): Prisma__InstrumenBospClient<$Result.GetResult<Prisma.$InstrumenBospPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one InstrumenBosp.
     * @param {InstrumenBospUpdateArgs} args - Arguments to update one InstrumenBosp.
     * @example
     * // Update one InstrumenBosp
     * const instrumenBosp = await prisma.instrumenBosp.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends InstrumenBospUpdateArgs>(args: SelectSubset<T, InstrumenBospUpdateArgs<ExtArgs>>): Prisma__InstrumenBospClient<$Result.GetResult<Prisma.$InstrumenBospPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more InstrumenBosps.
     * @param {InstrumenBospDeleteManyArgs} args - Arguments to filter InstrumenBosps to delete.
     * @example
     * // Delete a few InstrumenBosps
     * const { count } = await prisma.instrumenBosp.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends InstrumenBospDeleteManyArgs>(args?: SelectSubset<T, InstrumenBospDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more InstrumenBosps.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {InstrumenBospUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many InstrumenBosps
     * const instrumenBosp = await prisma.instrumenBosp.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends InstrumenBospUpdateManyArgs>(args: SelectSubset<T, InstrumenBospUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more InstrumenBosps and returns the data updated in the database.
     * @param {InstrumenBospUpdateManyAndReturnArgs} args - Arguments to update many InstrumenBosps.
     * @example
     * // Update many InstrumenBosps
     * const instrumenBosp = await prisma.instrumenBosp.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more InstrumenBosps and only return the `id`
     * const instrumenBospWithIdOnly = await prisma.instrumenBosp.updateManyAndReturn({
     *   select: { id: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends InstrumenBospUpdateManyAndReturnArgs>(args: SelectSubset<T, InstrumenBospUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$InstrumenBospPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one InstrumenBosp.
     * @param {InstrumenBospUpsertArgs} args - Arguments to update or create a InstrumenBosp.
     * @example
     * // Update or create a InstrumenBosp
     * const instrumenBosp = await prisma.instrumenBosp.upsert({
     *   create: {
     *     // ... data to create a InstrumenBosp
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the InstrumenBosp we want to update
     *   }
     * })
     */
    upsert<T extends InstrumenBospUpsertArgs>(args: SelectSubset<T, InstrumenBospUpsertArgs<ExtArgs>>): Prisma__InstrumenBospClient<$Result.GetResult<Prisma.$InstrumenBospPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of InstrumenBosps.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {InstrumenBospCountArgs} args - Arguments to filter InstrumenBosps to count.
     * @example
     * // Count the number of InstrumenBosps
     * const count = await prisma.instrumenBosp.count({
     *   where: {
     *     // ... the filter for the InstrumenBosps we want to count
     *   }
     * })
    **/
    count<T extends InstrumenBospCountArgs>(
      args?: Subset<T, InstrumenBospCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], InstrumenBospCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a InstrumenBosp.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {InstrumenBospAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends InstrumenBospAggregateArgs>(args: Subset<T, InstrumenBospAggregateArgs>): Prisma.PrismaPromise<GetInstrumenBospAggregateType<T>>

    /**
     * Group by InstrumenBosp.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {InstrumenBospGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends InstrumenBospGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: InstrumenBospGroupByArgs['orderBy'] }
        : { orderBy?: InstrumenBospGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, InstrumenBospGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetInstrumenBospGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the InstrumenBosp model
   */
  readonly fields: InstrumenBospFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for InstrumenBosp.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__InstrumenBospClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    school<T extends SchoolDefaultArgs<ExtArgs> = {}>(args?: Subset<T, SchoolDefaultArgs<ExtArgs>>): Prisma__SchoolClient<$Result.GetResult<Prisma.$SchoolPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the InstrumenBosp model
   */
  interface InstrumenBospFieldRefs {
    readonly id: FieldRef<"InstrumenBosp", 'String'>
    readonly schoolId: FieldRef<"InstrumenBosp", 'String'>
    readonly year: FieldRef<"InstrumenBosp", 'Int'>
    readonly tahap: FieldRef<"InstrumenBosp", 'Int'>
    readonly jenisSatuan: FieldRef<"InstrumenBosp", 'String'>
    readonly statusSatuan: FieldRef<"InstrumenBosp", 'String'>
    readonly kelurahan: FieldRef<"InstrumenBosp", 'String'>
    readonly kecamatan: FieldRef<"InstrumenBosp", 'String'>
    readonly jenisDanaBosp: FieldRef<"InstrumenBosp", 'String'>
    readonly skNomor: FieldRef<"InstrumenBosp", 'String'>
    readonly skTanggal: FieldRef<"InstrumenBosp", 'String'>
    readonly kepalaName: FieldRef<"InstrumenBosp", 'String'>
    readonly bendaharaName: FieldRef<"InstrumenBosp", 'String'>
    readonly komiteName: FieldRef<"InstrumenBosp", 'String'>
    readonly adaBku: FieldRef<"InstrumenBosp", 'Boolean'>
    readonly adaBukuPembantuKas: FieldRef<"InstrumenBosp", 'Boolean'>
    readonly adaBukuPembantuPajak: FieldRef<"InstrumenBosp", 'Boolean'>
    readonly adaBukuPembantuBank: FieldRef<"InstrumenBosp", 'Boolean'>
    readonly adaLaporanRealisasi: FieldRef<"InstrumenBosp", 'Boolean'>
    readonly totalAlokasiTahunan: FieldRef<"InstrumenBosp", 'Int'>
    readonly saldoAwalOverride: FieldRef<"InstrumenBosp", 'Int'>
    readonly operasionalOverride: FieldRef<"InstrumenBosp", 'Int'>
    readonly honorSesuaiRkas: FieldRef<"InstrumenBosp", 'Boolean'>
    readonly honorBuktiLengkap: FieldRef<"InstrumenBosp", 'Boolean'>
    readonly honorPenerimaSesuai: FieldRef<"InstrumenBosp", 'Boolean'>
    readonly metodePengadaanBuku: FieldRef<"InstrumenBosp", 'String'>
    readonly metodePengadaanLain: FieldRef<"InstrumenBosp", 'String'>
    readonly belanjaModalJson: FieldRef<"InstrumenBosp", 'String'>
    readonly pemeliharaanJson: FieldRef<"InstrumenBosp", 'String'>
    readonly bukuOverrideJson: FieldRef<"InstrumenBosp", 'String'>
    readonly tanggalDokumen: FieldRef<"InstrumenBosp", 'String'>
    readonly createdAt: FieldRef<"InstrumenBosp", 'DateTime'>
    readonly updatedAt: FieldRef<"InstrumenBosp", 'DateTime'>
  }
    

  // Custom InputTypes
  /**
   * InstrumenBosp findUnique
   */
  export type InstrumenBospFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the InstrumenBosp
     */
    select?: InstrumenBospSelect<ExtArgs> | null
    /**
     * Omit specific fields from the InstrumenBosp
     */
    omit?: InstrumenBospOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: InstrumenBospInclude<ExtArgs> | null
    /**
     * Filter, which InstrumenBosp to fetch.
     */
    where: InstrumenBospWhereUniqueInput
  }

  /**
   * InstrumenBosp findUniqueOrThrow
   */
  export type InstrumenBospFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the InstrumenBosp
     */
    select?: InstrumenBospSelect<ExtArgs> | null
    /**
     * Omit specific fields from the InstrumenBosp
     */
    omit?: InstrumenBospOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: InstrumenBospInclude<ExtArgs> | null
    /**
     * Filter, which InstrumenBosp to fetch.
     */
    where: InstrumenBospWhereUniqueInput
  }

  /**
   * InstrumenBosp findFirst
   */
  export type InstrumenBospFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the InstrumenBosp
     */
    select?: InstrumenBospSelect<ExtArgs> | null
    /**
     * Omit specific fields from the InstrumenBosp
     */
    omit?: InstrumenBospOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: InstrumenBospInclude<ExtArgs> | null
    /**
     * Filter, which InstrumenBosp to fetch.
     */
    where?: InstrumenBospWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of InstrumenBosps to fetch.
     */
    orderBy?: InstrumenBospOrderByWithRelationInput | InstrumenBospOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for InstrumenBosps.
     */
    cursor?: InstrumenBospWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` InstrumenBosps from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` InstrumenBosps.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of InstrumenBosps.
     */
    distinct?: InstrumenBospScalarFieldEnum | InstrumenBospScalarFieldEnum[]
  }

  /**
   * InstrumenBosp findFirstOrThrow
   */
  export type InstrumenBospFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the InstrumenBosp
     */
    select?: InstrumenBospSelect<ExtArgs> | null
    /**
     * Omit specific fields from the InstrumenBosp
     */
    omit?: InstrumenBospOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: InstrumenBospInclude<ExtArgs> | null
    /**
     * Filter, which InstrumenBosp to fetch.
     */
    where?: InstrumenBospWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of InstrumenBosps to fetch.
     */
    orderBy?: InstrumenBospOrderByWithRelationInput | InstrumenBospOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for InstrumenBosps.
     */
    cursor?: InstrumenBospWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` InstrumenBosps from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` InstrumenBosps.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of InstrumenBosps.
     */
    distinct?: InstrumenBospScalarFieldEnum | InstrumenBospScalarFieldEnum[]
  }

  /**
   * InstrumenBosp findMany
   */
  export type InstrumenBospFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the InstrumenBosp
     */
    select?: InstrumenBospSelect<ExtArgs> | null
    /**
     * Omit specific fields from the InstrumenBosp
     */
    omit?: InstrumenBospOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: InstrumenBospInclude<ExtArgs> | null
    /**
     * Filter, which InstrumenBosps to fetch.
     */
    where?: InstrumenBospWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of InstrumenBosps to fetch.
     */
    orderBy?: InstrumenBospOrderByWithRelationInput | InstrumenBospOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing InstrumenBosps.
     */
    cursor?: InstrumenBospWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` InstrumenBosps from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` InstrumenBosps.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of InstrumenBosps.
     */
    distinct?: InstrumenBospScalarFieldEnum | InstrumenBospScalarFieldEnum[]
  }

  /**
   * InstrumenBosp create
   */
  export type InstrumenBospCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the InstrumenBosp
     */
    select?: InstrumenBospSelect<ExtArgs> | null
    /**
     * Omit specific fields from the InstrumenBosp
     */
    omit?: InstrumenBospOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: InstrumenBospInclude<ExtArgs> | null
    /**
     * The data needed to create a InstrumenBosp.
     */
    data: XOR<InstrumenBospCreateInput, InstrumenBospUncheckedCreateInput>
  }

  /**
   * InstrumenBosp createMany
   */
  export type InstrumenBospCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many InstrumenBosps.
     */
    data: InstrumenBospCreateManyInput | InstrumenBospCreateManyInput[]
  }

  /**
   * InstrumenBosp createManyAndReturn
   */
  export type InstrumenBospCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the InstrumenBosp
     */
    select?: InstrumenBospSelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the InstrumenBosp
     */
    omit?: InstrumenBospOmit<ExtArgs> | null
    /**
     * The data used to create many InstrumenBosps.
     */
    data: InstrumenBospCreateManyInput | InstrumenBospCreateManyInput[]
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: InstrumenBospIncludeCreateManyAndReturn<ExtArgs> | null
  }

  /**
   * InstrumenBosp update
   */
  export type InstrumenBospUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the InstrumenBosp
     */
    select?: InstrumenBospSelect<ExtArgs> | null
    /**
     * Omit specific fields from the InstrumenBosp
     */
    omit?: InstrumenBospOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: InstrumenBospInclude<ExtArgs> | null
    /**
     * The data needed to update a InstrumenBosp.
     */
    data: XOR<InstrumenBospUpdateInput, InstrumenBospUncheckedUpdateInput>
    /**
     * Choose, which InstrumenBosp to update.
     */
    where: InstrumenBospWhereUniqueInput
  }

  /**
   * InstrumenBosp updateMany
   */
  export type InstrumenBospUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update InstrumenBosps.
     */
    data: XOR<InstrumenBospUpdateManyMutationInput, InstrumenBospUncheckedUpdateManyInput>
    /**
     * Filter which InstrumenBosps to update
     */
    where?: InstrumenBospWhereInput
    /**
     * Limit how many InstrumenBosps to update.
     */
    limit?: number
  }

  /**
   * InstrumenBosp updateManyAndReturn
   */
  export type InstrumenBospUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the InstrumenBosp
     */
    select?: InstrumenBospSelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the InstrumenBosp
     */
    omit?: InstrumenBospOmit<ExtArgs> | null
    /**
     * The data used to update InstrumenBosps.
     */
    data: XOR<InstrumenBospUpdateManyMutationInput, InstrumenBospUncheckedUpdateManyInput>
    /**
     * Filter which InstrumenBosps to update
     */
    where?: InstrumenBospWhereInput
    /**
     * Limit how many InstrumenBosps to update.
     */
    limit?: number
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: InstrumenBospIncludeUpdateManyAndReturn<ExtArgs> | null
  }

  /**
   * InstrumenBosp upsert
   */
  export type InstrumenBospUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the InstrumenBosp
     */
    select?: InstrumenBospSelect<ExtArgs> | null
    /**
     * Omit specific fields from the InstrumenBosp
     */
    omit?: InstrumenBospOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: InstrumenBospInclude<ExtArgs> | null
    /**
     * The filter to search for the InstrumenBosp to update in case it exists.
     */
    where: InstrumenBospWhereUniqueInput
    /**
     * In case the InstrumenBosp found by the `where` argument doesn't exist, create a new InstrumenBosp with this data.
     */
    create: XOR<InstrumenBospCreateInput, InstrumenBospUncheckedCreateInput>
    /**
     * In case the InstrumenBosp was found with the provided `where` argument, update it with this data.
     */
    update: XOR<InstrumenBospUpdateInput, InstrumenBospUncheckedUpdateInput>
  }

  /**
   * InstrumenBosp delete
   */
  export type InstrumenBospDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the InstrumenBosp
     */
    select?: InstrumenBospSelect<ExtArgs> | null
    /**
     * Omit specific fields from the InstrumenBosp
     */
    omit?: InstrumenBospOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: InstrumenBospInclude<ExtArgs> | null
    /**
     * Filter which InstrumenBosp to delete.
     */
    where: InstrumenBospWhereUniqueInput
  }

  /**
   * InstrumenBosp deleteMany
   */
  export type InstrumenBospDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which InstrumenBosps to delete
     */
    where?: InstrumenBospWhereInput
    /**
     * Limit how many InstrumenBosps to delete.
     */
    limit?: number
  }

  /**
   * InstrumenBosp without action
   */
  export type InstrumenBospDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the InstrumenBosp
     */
    select?: InstrumenBospSelect<ExtArgs> | null
    /**
     * Omit specific fields from the InstrumenBosp
     */
    omit?: InstrumenBospOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: InstrumenBospInclude<ExtArgs> | null
  }


  /**
   * Enums
   */

  export const TransactionIsolationLevel: {
    Serializable: 'Serializable'
  };

  export type TransactionIsolationLevel = (typeof TransactionIsolationLevel)[keyof typeof TransactionIsolationLevel]


  export const SchoolScalarFieldEnum: {
    id: 'id',
    name: 'name',
    kopHeaderLine: 'kopHeaderLine',
    npsn: 'npsn',
    address: 'address',
    contact: 'contact',
    formatCode: 'formatCode',
    kepalaName: 'kepalaName',
    kepalaJabatan: 'kepalaJabatan',
    openingSentenceTemplate: 'openingSentenceTemplate',
    atasDasarLine1: 'atasDasarLine1',
    atasDasarLine2: 'atasDasarLine2',
    honorRecapTitle: 'honorRecapTitle',
    frazaListrikCustomerId: 'frazaListrikCustomerId',
    frazaInternetCustomerId: 'frazaInternetCustomerId',
    logoPath: 'logoPath',
    regionalLogoPath: 'regionalLogoPath',
    createdAt: 'createdAt',
    updatedAt: 'updatedAt'
  };

  export type SchoolScalarFieldEnum = (typeof SchoolScalarFieldEnum)[keyof typeof SchoolScalarFieldEnum]


  export const VendorRuleScalarFieldEnum: {
    id: 'id',
    schoolId: 'schoolId',
    keyword: 'keyword',
    recipient: 'recipient',
    paymentPrefix: 'paymentPrefix',
    matchKodeKegiatan: 'matchKodeKegiatan',
    formatType: 'formatType',
    isHonor: 'isHonor',
    isTransport: 'isTransport',
    priority: 'priority',
    isActive: 'isActive',
    createdAt: 'createdAt',
    updatedAt: 'updatedAt'
  };

  export type VendorRuleScalarFieldEnum = (typeof VendorRuleScalarFieldEnum)[keyof typeof VendorRuleScalarFieldEnum]


  export const BKUImportScalarFieldEnum: {
    id: 'id',
    schoolId: 'schoolId',
    month: 'month',
    year: 'year',
    sourceFileName: 'sourceFileName',
    status: 'status',
    importedAt: 'importedAt'
  };

  export type BKUImportScalarFieldEnum = (typeof BKUImportScalarFieldEnum)[keyof typeof BKUImportScalarFieldEnum]


  export const BKURowScalarFieldEnum: {
    id: 'id',
    bkuImportId: 'bkuImportId',
    tanggal: 'tanggal',
    kodeKegiatan: 'kodeKegiatan',
    kodeRekening: 'kodeRekening',
    bpuCode: 'bpuCode',
    bpuNumber: 'bpuNumber',
    uraian: 'uraian',
    penerimaan: 'penerimaan',
    pengeluaran: 'pengeluaran',
    saldo: 'saldo',
    pageIndex: 'pageIndex',
    createdAt: 'createdAt'
  };

  export type BKURowScalarFieldEnum = (typeof BKURowScalarFieldEnum)[keyof typeof BKURowScalarFieldEnum]


  export const BPUGroupScalarFieldEnum: {
    id: 'id',
    bkuImportId: 'bkuImportId',
    bpuCode: 'bpuCode',
    bpuNumber: 'bpuNumber',
    tanggal: 'tanggal',
    totalAmount: 'totalAmount',
    matchedVendorRuleId: 'matchedVendorRuleId',
    overrideRecipient: 'overrideRecipient',
    overridePaymentFor: 'overridePaymentFor',
    status: 'status',
    createdAt: 'createdAt',
    updatedAt: 'updatedAt'
  };

  export type BPUGroupScalarFieldEnum = (typeof BPUGroupScalarFieldEnum)[keyof typeof BPUGroupScalarFieldEnum]


  export const SPMDocumentScalarFieldEnum: {
    id: 'id',
    bpuGroupId: 'bpuGroupId',
    nomorSurat: 'nomorSurat',
    recipient: 'recipient',
    amount: 'amount',
    terbilang: 'terbilang',
    paymentFor: 'paymentFor',
    filePath: 'filePath',
    generatedAt: 'generatedAt'
  };

  export type SPMDocumentScalarFieldEnum = (typeof SPMDocumentScalarFieldEnum)[keyof typeof SPMDocumentScalarFieldEnum]


  export const RkasImportScalarFieldEnum: {
    id: 'id',
    schoolId: 'schoolId',
    month: 'month',
    year: 'year',
    sourceFileName: 'sourceFileName',
    sourceSchoolName: 'sourceSchoolName',
    npsn: 'npsn',
    namaPelaksana: 'namaPelaksana',
    programLabel: 'programLabel',
    namaKegiatan: 'namaKegiatan',
    sumberDana: 'sumberDana',
    pekerjaanLabel: 'pekerjaanLabel',
    kepalaName: 'kepalaName',
    bendaharaName: 'bendaharaName',
    importedAt: 'importedAt',
    updatedAt: 'updatedAt'
  };

  export type RkasImportScalarFieldEnum = (typeof RkasImportScalarFieldEnum)[keyof typeof RkasImportScalarFieldEnum]


  export const RkasProgramScalarFieldEnum: {
    id: 'id',
    rkasImportId: 'rkasImportId',
    urutan: 'urutan',
    kodeProgram: 'kodeProgram',
    nama: 'nama',
    standarName: 'standarName',
    kegiatanName: 'kegiatanName',
    included: 'included'
  };

  export type RkasProgramScalarFieldEnum = (typeof RkasProgramScalarFieldEnum)[keyof typeof RkasProgramScalarFieldEnum]


  export const RkasItemScalarFieldEnum: {
    id: 'id',
    rkasProgramId: 'rkasProgramId',
    urutan: 'urutan',
    noUrut: 'noUrut',
    kodeRekening: 'kodeRekening',
    uraian: 'uraian',
    volumeText: 'volumeText',
    tarifHarga: 'tarifHarga',
    jumlah: 'jumlah',
    excluded: 'excluded'
  };

  export type RkasItemScalarFieldEnum = (typeof RkasItemScalarFieldEnum)[keyof typeof RkasItemScalarFieldEnum]


  export const InstrumenBospScalarFieldEnum: {
    id: 'id',
    schoolId: 'schoolId',
    year: 'year',
    tahap: 'tahap',
    jenisSatuan: 'jenisSatuan',
    statusSatuan: 'statusSatuan',
    kelurahan: 'kelurahan',
    kecamatan: 'kecamatan',
    jenisDanaBosp: 'jenisDanaBosp',
    skNomor: 'skNomor',
    skTanggal: 'skTanggal',
    kepalaName: 'kepalaName',
    bendaharaName: 'bendaharaName',
    komiteName: 'komiteName',
    adaBku: 'adaBku',
    adaBukuPembantuKas: 'adaBukuPembantuKas',
    adaBukuPembantuPajak: 'adaBukuPembantuPajak',
    adaBukuPembantuBank: 'adaBukuPembantuBank',
    adaLaporanRealisasi: 'adaLaporanRealisasi',
    totalAlokasiTahunan: 'totalAlokasiTahunan',
    saldoAwalOverride: 'saldoAwalOverride',
    operasionalOverride: 'operasionalOverride',
    honorSesuaiRkas: 'honorSesuaiRkas',
    honorBuktiLengkap: 'honorBuktiLengkap',
    honorPenerimaSesuai: 'honorPenerimaSesuai',
    metodePengadaanBuku: 'metodePengadaanBuku',
    metodePengadaanLain: 'metodePengadaanLain',
    belanjaModalJson: 'belanjaModalJson',
    pemeliharaanJson: 'pemeliharaanJson',
    bukuOverrideJson: 'bukuOverrideJson',
    tanggalDokumen: 'tanggalDokumen',
    createdAt: 'createdAt',
    updatedAt: 'updatedAt'
  };

  export type InstrumenBospScalarFieldEnum = (typeof InstrumenBospScalarFieldEnum)[keyof typeof InstrumenBospScalarFieldEnum]


  export const SortOrder: {
    asc: 'asc',
    desc: 'desc'
  };

  export type SortOrder = (typeof SortOrder)[keyof typeof SortOrder]


  export const NullsOrder: {
    first: 'first',
    last: 'last'
  };

  export type NullsOrder = (typeof NullsOrder)[keyof typeof NullsOrder]


  /**
   * Field references
   */


  /**
   * Reference to a field of type 'String'
   */
  export type StringFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'String'>
    


  /**
   * Reference to a field of type 'DateTime'
   */
  export type DateTimeFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'DateTime'>
    


  /**
   * Reference to a field of type 'VendorRuleFormatType'
   */
  export type EnumVendorRuleFormatTypeFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'VendorRuleFormatType'>
    


  /**
   * Reference to a field of type 'Boolean'
   */
  export type BooleanFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Boolean'>
    


  /**
   * Reference to a field of type 'Int'
   */
  export type IntFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Int'>
    


  /**
   * Reference to a field of type 'BKUImportStatus'
   */
  export type EnumBKUImportStatusFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'BKUImportStatus'>
    


  /**
   * Reference to a field of type 'BPUGroupStatus'
   */
  export type EnumBPUGroupStatusFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'BPUGroupStatus'>
    


  /**
   * Reference to a field of type 'Float'
   */
  export type FloatFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Float'>
    
  /**
   * Deep Input Types
   */


  export type SchoolWhereInput = {
    AND?: SchoolWhereInput | SchoolWhereInput[]
    OR?: SchoolWhereInput[]
    NOT?: SchoolWhereInput | SchoolWhereInput[]
    id?: StringFilter<"School"> | string
    name?: StringFilter<"School"> | string
    kopHeaderLine?: StringNullableFilter<"School"> | string | null
    npsn?: StringNullableFilter<"School"> | string | null
    address?: StringFilter<"School"> | string
    contact?: StringNullableFilter<"School"> | string | null
    formatCode?: StringFilter<"School"> | string
    kepalaName?: StringFilter<"School"> | string
    kepalaJabatan?: StringFilter<"School"> | string
    openingSentenceTemplate?: StringFilter<"School"> | string
    atasDasarLine1?: StringFilter<"School"> | string
    atasDasarLine2?: StringFilter<"School"> | string
    honorRecapTitle?: StringNullableFilter<"School"> | string | null
    frazaListrikCustomerId?: StringNullableFilter<"School"> | string | null
    frazaInternetCustomerId?: StringNullableFilter<"School"> | string | null
    logoPath?: StringNullableFilter<"School"> | string | null
    regionalLogoPath?: StringNullableFilter<"School"> | string | null
    createdAt?: DateTimeFilter<"School"> | Date | string
    updatedAt?: DateTimeFilter<"School"> | Date | string
    vendorRules?: VendorRuleListRelationFilter
    bkuImports?: BKUImportListRelationFilter
    rkasImports?: RkasImportListRelationFilter
    instrumenBosp?: InstrumenBospListRelationFilter
  }

  export type SchoolOrderByWithRelationInput = {
    id?: SortOrder
    name?: SortOrder
    kopHeaderLine?: SortOrderInput | SortOrder
    npsn?: SortOrderInput | SortOrder
    address?: SortOrder
    contact?: SortOrderInput | SortOrder
    formatCode?: SortOrder
    kepalaName?: SortOrder
    kepalaJabatan?: SortOrder
    openingSentenceTemplate?: SortOrder
    atasDasarLine1?: SortOrder
    atasDasarLine2?: SortOrder
    honorRecapTitle?: SortOrderInput | SortOrder
    frazaListrikCustomerId?: SortOrderInput | SortOrder
    frazaInternetCustomerId?: SortOrderInput | SortOrder
    logoPath?: SortOrderInput | SortOrder
    regionalLogoPath?: SortOrderInput | SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    vendorRules?: VendorRuleOrderByRelationAggregateInput
    bkuImports?: BKUImportOrderByRelationAggregateInput
    rkasImports?: RkasImportOrderByRelationAggregateInput
    instrumenBosp?: InstrumenBospOrderByRelationAggregateInput
  }

  export type SchoolWhereUniqueInput = Prisma.AtLeast<{
    id?: string
    AND?: SchoolWhereInput | SchoolWhereInput[]
    OR?: SchoolWhereInput[]
    NOT?: SchoolWhereInput | SchoolWhereInput[]
    name?: StringFilter<"School"> | string
    kopHeaderLine?: StringNullableFilter<"School"> | string | null
    npsn?: StringNullableFilter<"School"> | string | null
    address?: StringFilter<"School"> | string
    contact?: StringNullableFilter<"School"> | string | null
    formatCode?: StringFilter<"School"> | string
    kepalaName?: StringFilter<"School"> | string
    kepalaJabatan?: StringFilter<"School"> | string
    openingSentenceTemplate?: StringFilter<"School"> | string
    atasDasarLine1?: StringFilter<"School"> | string
    atasDasarLine2?: StringFilter<"School"> | string
    honorRecapTitle?: StringNullableFilter<"School"> | string | null
    frazaListrikCustomerId?: StringNullableFilter<"School"> | string | null
    frazaInternetCustomerId?: StringNullableFilter<"School"> | string | null
    logoPath?: StringNullableFilter<"School"> | string | null
    regionalLogoPath?: StringNullableFilter<"School"> | string | null
    createdAt?: DateTimeFilter<"School"> | Date | string
    updatedAt?: DateTimeFilter<"School"> | Date | string
    vendorRules?: VendorRuleListRelationFilter
    bkuImports?: BKUImportListRelationFilter
    rkasImports?: RkasImportListRelationFilter
    instrumenBosp?: InstrumenBospListRelationFilter
  }, "id">

  export type SchoolOrderByWithAggregationInput = {
    id?: SortOrder
    name?: SortOrder
    kopHeaderLine?: SortOrderInput | SortOrder
    npsn?: SortOrderInput | SortOrder
    address?: SortOrder
    contact?: SortOrderInput | SortOrder
    formatCode?: SortOrder
    kepalaName?: SortOrder
    kepalaJabatan?: SortOrder
    openingSentenceTemplate?: SortOrder
    atasDasarLine1?: SortOrder
    atasDasarLine2?: SortOrder
    honorRecapTitle?: SortOrderInput | SortOrder
    frazaListrikCustomerId?: SortOrderInput | SortOrder
    frazaInternetCustomerId?: SortOrderInput | SortOrder
    logoPath?: SortOrderInput | SortOrder
    regionalLogoPath?: SortOrderInput | SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    _count?: SchoolCountOrderByAggregateInput
    _max?: SchoolMaxOrderByAggregateInput
    _min?: SchoolMinOrderByAggregateInput
  }

  export type SchoolScalarWhereWithAggregatesInput = {
    AND?: SchoolScalarWhereWithAggregatesInput | SchoolScalarWhereWithAggregatesInput[]
    OR?: SchoolScalarWhereWithAggregatesInput[]
    NOT?: SchoolScalarWhereWithAggregatesInput | SchoolScalarWhereWithAggregatesInput[]
    id?: StringWithAggregatesFilter<"School"> | string
    name?: StringWithAggregatesFilter<"School"> | string
    kopHeaderLine?: StringNullableWithAggregatesFilter<"School"> | string | null
    npsn?: StringNullableWithAggregatesFilter<"School"> | string | null
    address?: StringWithAggregatesFilter<"School"> | string
    contact?: StringNullableWithAggregatesFilter<"School"> | string | null
    formatCode?: StringWithAggregatesFilter<"School"> | string
    kepalaName?: StringWithAggregatesFilter<"School"> | string
    kepalaJabatan?: StringWithAggregatesFilter<"School"> | string
    openingSentenceTemplate?: StringWithAggregatesFilter<"School"> | string
    atasDasarLine1?: StringWithAggregatesFilter<"School"> | string
    atasDasarLine2?: StringWithAggregatesFilter<"School"> | string
    honorRecapTitle?: StringNullableWithAggregatesFilter<"School"> | string | null
    frazaListrikCustomerId?: StringNullableWithAggregatesFilter<"School"> | string | null
    frazaInternetCustomerId?: StringNullableWithAggregatesFilter<"School"> | string | null
    logoPath?: StringNullableWithAggregatesFilter<"School"> | string | null
    regionalLogoPath?: StringNullableWithAggregatesFilter<"School"> | string | null
    createdAt?: DateTimeWithAggregatesFilter<"School"> | Date | string
    updatedAt?: DateTimeWithAggregatesFilter<"School"> | Date | string
  }

  export type VendorRuleWhereInput = {
    AND?: VendorRuleWhereInput | VendorRuleWhereInput[]
    OR?: VendorRuleWhereInput[]
    NOT?: VendorRuleWhereInput | VendorRuleWhereInput[]
    id?: StringFilter<"VendorRule"> | string
    schoolId?: StringFilter<"VendorRule"> | string
    keyword?: StringFilter<"VendorRule"> | string
    recipient?: StringFilter<"VendorRule"> | string
    paymentPrefix?: StringFilter<"VendorRule"> | string
    matchKodeKegiatan?: StringNullableFilter<"VendorRule"> | string | null
    formatType?: EnumVendorRuleFormatTypeFilter<"VendorRule"> | $Enums.VendorRuleFormatType
    isHonor?: BoolFilter<"VendorRule"> | boolean
    isTransport?: BoolFilter<"VendorRule"> | boolean
    priority?: IntFilter<"VendorRule"> | number
    isActive?: BoolFilter<"VendorRule"> | boolean
    createdAt?: DateTimeFilter<"VendorRule"> | Date | string
    updatedAt?: DateTimeFilter<"VendorRule"> | Date | string
    school?: XOR<SchoolScalarRelationFilter, SchoolWhereInput>
    bpuGroups?: BPUGroupListRelationFilter
  }

  export type VendorRuleOrderByWithRelationInput = {
    id?: SortOrder
    schoolId?: SortOrder
    keyword?: SortOrder
    recipient?: SortOrder
    paymentPrefix?: SortOrder
    matchKodeKegiatan?: SortOrderInput | SortOrder
    formatType?: SortOrder
    isHonor?: SortOrder
    isTransport?: SortOrder
    priority?: SortOrder
    isActive?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    school?: SchoolOrderByWithRelationInput
    bpuGroups?: BPUGroupOrderByRelationAggregateInput
  }

  export type VendorRuleWhereUniqueInput = Prisma.AtLeast<{
    id?: string
    AND?: VendorRuleWhereInput | VendorRuleWhereInput[]
    OR?: VendorRuleWhereInput[]
    NOT?: VendorRuleWhereInput | VendorRuleWhereInput[]
    schoolId?: StringFilter<"VendorRule"> | string
    keyword?: StringFilter<"VendorRule"> | string
    recipient?: StringFilter<"VendorRule"> | string
    paymentPrefix?: StringFilter<"VendorRule"> | string
    matchKodeKegiatan?: StringNullableFilter<"VendorRule"> | string | null
    formatType?: EnumVendorRuleFormatTypeFilter<"VendorRule"> | $Enums.VendorRuleFormatType
    isHonor?: BoolFilter<"VendorRule"> | boolean
    isTransport?: BoolFilter<"VendorRule"> | boolean
    priority?: IntFilter<"VendorRule"> | number
    isActive?: BoolFilter<"VendorRule"> | boolean
    createdAt?: DateTimeFilter<"VendorRule"> | Date | string
    updatedAt?: DateTimeFilter<"VendorRule"> | Date | string
    school?: XOR<SchoolScalarRelationFilter, SchoolWhereInput>
    bpuGroups?: BPUGroupListRelationFilter
  }, "id">

  export type VendorRuleOrderByWithAggregationInput = {
    id?: SortOrder
    schoolId?: SortOrder
    keyword?: SortOrder
    recipient?: SortOrder
    paymentPrefix?: SortOrder
    matchKodeKegiatan?: SortOrderInput | SortOrder
    formatType?: SortOrder
    isHonor?: SortOrder
    isTransport?: SortOrder
    priority?: SortOrder
    isActive?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    _count?: VendorRuleCountOrderByAggregateInput
    _avg?: VendorRuleAvgOrderByAggregateInput
    _max?: VendorRuleMaxOrderByAggregateInput
    _min?: VendorRuleMinOrderByAggregateInput
    _sum?: VendorRuleSumOrderByAggregateInput
  }

  export type VendorRuleScalarWhereWithAggregatesInput = {
    AND?: VendorRuleScalarWhereWithAggregatesInput | VendorRuleScalarWhereWithAggregatesInput[]
    OR?: VendorRuleScalarWhereWithAggregatesInput[]
    NOT?: VendorRuleScalarWhereWithAggregatesInput | VendorRuleScalarWhereWithAggregatesInput[]
    id?: StringWithAggregatesFilter<"VendorRule"> | string
    schoolId?: StringWithAggregatesFilter<"VendorRule"> | string
    keyword?: StringWithAggregatesFilter<"VendorRule"> | string
    recipient?: StringWithAggregatesFilter<"VendorRule"> | string
    paymentPrefix?: StringWithAggregatesFilter<"VendorRule"> | string
    matchKodeKegiatan?: StringNullableWithAggregatesFilter<"VendorRule"> | string | null
    formatType?: EnumVendorRuleFormatTypeWithAggregatesFilter<"VendorRule"> | $Enums.VendorRuleFormatType
    isHonor?: BoolWithAggregatesFilter<"VendorRule"> | boolean
    isTransport?: BoolWithAggregatesFilter<"VendorRule"> | boolean
    priority?: IntWithAggregatesFilter<"VendorRule"> | number
    isActive?: BoolWithAggregatesFilter<"VendorRule"> | boolean
    createdAt?: DateTimeWithAggregatesFilter<"VendorRule"> | Date | string
    updatedAt?: DateTimeWithAggregatesFilter<"VendorRule"> | Date | string
  }

  export type BKUImportWhereInput = {
    AND?: BKUImportWhereInput | BKUImportWhereInput[]
    OR?: BKUImportWhereInput[]
    NOT?: BKUImportWhereInput | BKUImportWhereInput[]
    id?: StringFilter<"BKUImport"> | string
    schoolId?: StringFilter<"BKUImport"> | string
    month?: IntFilter<"BKUImport"> | number
    year?: IntFilter<"BKUImport"> | number
    sourceFileName?: StringFilter<"BKUImport"> | string
    status?: EnumBKUImportStatusFilter<"BKUImport"> | $Enums.BKUImportStatus
    importedAt?: DateTimeFilter<"BKUImport"> | Date | string
    school?: XOR<SchoolScalarRelationFilter, SchoolWhereInput>
    rows?: BKURowListRelationFilter
    bpuGroups?: BPUGroupListRelationFilter
  }

  export type BKUImportOrderByWithRelationInput = {
    id?: SortOrder
    schoolId?: SortOrder
    month?: SortOrder
    year?: SortOrder
    sourceFileName?: SortOrder
    status?: SortOrder
    importedAt?: SortOrder
    school?: SchoolOrderByWithRelationInput
    rows?: BKURowOrderByRelationAggregateInput
    bpuGroups?: BPUGroupOrderByRelationAggregateInput
  }

  export type BKUImportWhereUniqueInput = Prisma.AtLeast<{
    id?: string
    AND?: BKUImportWhereInput | BKUImportWhereInput[]
    OR?: BKUImportWhereInput[]
    NOT?: BKUImportWhereInput | BKUImportWhereInput[]
    schoolId?: StringFilter<"BKUImport"> | string
    month?: IntFilter<"BKUImport"> | number
    year?: IntFilter<"BKUImport"> | number
    sourceFileName?: StringFilter<"BKUImport"> | string
    status?: EnumBKUImportStatusFilter<"BKUImport"> | $Enums.BKUImportStatus
    importedAt?: DateTimeFilter<"BKUImport"> | Date | string
    school?: XOR<SchoolScalarRelationFilter, SchoolWhereInput>
    rows?: BKURowListRelationFilter
    bpuGroups?: BPUGroupListRelationFilter
  }, "id">

  export type BKUImportOrderByWithAggregationInput = {
    id?: SortOrder
    schoolId?: SortOrder
    month?: SortOrder
    year?: SortOrder
    sourceFileName?: SortOrder
    status?: SortOrder
    importedAt?: SortOrder
    _count?: BKUImportCountOrderByAggregateInput
    _avg?: BKUImportAvgOrderByAggregateInput
    _max?: BKUImportMaxOrderByAggregateInput
    _min?: BKUImportMinOrderByAggregateInput
    _sum?: BKUImportSumOrderByAggregateInput
  }

  export type BKUImportScalarWhereWithAggregatesInput = {
    AND?: BKUImportScalarWhereWithAggregatesInput | BKUImportScalarWhereWithAggregatesInput[]
    OR?: BKUImportScalarWhereWithAggregatesInput[]
    NOT?: BKUImportScalarWhereWithAggregatesInput | BKUImportScalarWhereWithAggregatesInput[]
    id?: StringWithAggregatesFilter<"BKUImport"> | string
    schoolId?: StringWithAggregatesFilter<"BKUImport"> | string
    month?: IntWithAggregatesFilter<"BKUImport"> | number
    year?: IntWithAggregatesFilter<"BKUImport"> | number
    sourceFileName?: StringWithAggregatesFilter<"BKUImport"> | string
    status?: EnumBKUImportStatusWithAggregatesFilter<"BKUImport"> | $Enums.BKUImportStatus
    importedAt?: DateTimeWithAggregatesFilter<"BKUImport"> | Date | string
  }

  export type BKURowWhereInput = {
    AND?: BKURowWhereInput | BKURowWhereInput[]
    OR?: BKURowWhereInput[]
    NOT?: BKURowWhereInput | BKURowWhereInput[]
    id?: StringFilter<"BKURow"> | string
    bkuImportId?: StringFilter<"BKURow"> | string
    tanggal?: DateTimeFilter<"BKURow"> | Date | string
    kodeKegiatan?: StringNullableFilter<"BKURow"> | string | null
    kodeRekening?: StringNullableFilter<"BKURow"> | string | null
    bpuCode?: StringNullableFilter<"BKURow"> | string | null
    bpuNumber?: IntNullableFilter<"BKURow"> | number | null
    uraian?: StringFilter<"BKURow"> | string
    penerimaan?: IntFilter<"BKURow"> | number
    pengeluaran?: IntFilter<"BKURow"> | number
    saldo?: IntFilter<"BKURow"> | number
    pageIndex?: IntNullableFilter<"BKURow"> | number | null
    createdAt?: DateTimeFilter<"BKURow"> | Date | string
    bkuImport?: XOR<BKUImportScalarRelationFilter, BKUImportWhereInput>
  }

  export type BKURowOrderByWithRelationInput = {
    id?: SortOrder
    bkuImportId?: SortOrder
    tanggal?: SortOrder
    kodeKegiatan?: SortOrderInput | SortOrder
    kodeRekening?: SortOrderInput | SortOrder
    bpuCode?: SortOrderInput | SortOrder
    bpuNumber?: SortOrderInput | SortOrder
    uraian?: SortOrder
    penerimaan?: SortOrder
    pengeluaran?: SortOrder
    saldo?: SortOrder
    pageIndex?: SortOrderInput | SortOrder
    createdAt?: SortOrder
    bkuImport?: BKUImportOrderByWithRelationInput
  }

  export type BKURowWhereUniqueInput = Prisma.AtLeast<{
    id?: string
    AND?: BKURowWhereInput | BKURowWhereInput[]
    OR?: BKURowWhereInput[]
    NOT?: BKURowWhereInput | BKURowWhereInput[]
    bkuImportId?: StringFilter<"BKURow"> | string
    tanggal?: DateTimeFilter<"BKURow"> | Date | string
    kodeKegiatan?: StringNullableFilter<"BKURow"> | string | null
    kodeRekening?: StringNullableFilter<"BKURow"> | string | null
    bpuCode?: StringNullableFilter<"BKURow"> | string | null
    bpuNumber?: IntNullableFilter<"BKURow"> | number | null
    uraian?: StringFilter<"BKURow"> | string
    penerimaan?: IntFilter<"BKURow"> | number
    pengeluaran?: IntFilter<"BKURow"> | number
    saldo?: IntFilter<"BKURow"> | number
    pageIndex?: IntNullableFilter<"BKURow"> | number | null
    createdAt?: DateTimeFilter<"BKURow"> | Date | string
    bkuImport?: XOR<BKUImportScalarRelationFilter, BKUImportWhereInput>
  }, "id">

  export type BKURowOrderByWithAggregationInput = {
    id?: SortOrder
    bkuImportId?: SortOrder
    tanggal?: SortOrder
    kodeKegiatan?: SortOrderInput | SortOrder
    kodeRekening?: SortOrderInput | SortOrder
    bpuCode?: SortOrderInput | SortOrder
    bpuNumber?: SortOrderInput | SortOrder
    uraian?: SortOrder
    penerimaan?: SortOrder
    pengeluaran?: SortOrder
    saldo?: SortOrder
    pageIndex?: SortOrderInput | SortOrder
    createdAt?: SortOrder
    _count?: BKURowCountOrderByAggregateInput
    _avg?: BKURowAvgOrderByAggregateInput
    _max?: BKURowMaxOrderByAggregateInput
    _min?: BKURowMinOrderByAggregateInput
    _sum?: BKURowSumOrderByAggregateInput
  }

  export type BKURowScalarWhereWithAggregatesInput = {
    AND?: BKURowScalarWhereWithAggregatesInput | BKURowScalarWhereWithAggregatesInput[]
    OR?: BKURowScalarWhereWithAggregatesInput[]
    NOT?: BKURowScalarWhereWithAggregatesInput | BKURowScalarWhereWithAggregatesInput[]
    id?: StringWithAggregatesFilter<"BKURow"> | string
    bkuImportId?: StringWithAggregatesFilter<"BKURow"> | string
    tanggal?: DateTimeWithAggregatesFilter<"BKURow"> | Date | string
    kodeKegiatan?: StringNullableWithAggregatesFilter<"BKURow"> | string | null
    kodeRekening?: StringNullableWithAggregatesFilter<"BKURow"> | string | null
    bpuCode?: StringNullableWithAggregatesFilter<"BKURow"> | string | null
    bpuNumber?: IntNullableWithAggregatesFilter<"BKURow"> | number | null
    uraian?: StringWithAggregatesFilter<"BKURow"> | string
    penerimaan?: IntWithAggregatesFilter<"BKURow"> | number
    pengeluaran?: IntWithAggregatesFilter<"BKURow"> | number
    saldo?: IntWithAggregatesFilter<"BKURow"> | number
    pageIndex?: IntNullableWithAggregatesFilter<"BKURow"> | number | null
    createdAt?: DateTimeWithAggregatesFilter<"BKURow"> | Date | string
  }

  export type BPUGroupWhereInput = {
    AND?: BPUGroupWhereInput | BPUGroupWhereInput[]
    OR?: BPUGroupWhereInput[]
    NOT?: BPUGroupWhereInput | BPUGroupWhereInput[]
    id?: StringFilter<"BPUGroup"> | string
    bkuImportId?: StringFilter<"BPUGroup"> | string
    bpuCode?: StringFilter<"BPUGroup"> | string
    bpuNumber?: IntFilter<"BPUGroup"> | number
    tanggal?: DateTimeFilter<"BPUGroup"> | Date | string
    totalAmount?: IntFilter<"BPUGroup"> | number
    matchedVendorRuleId?: StringNullableFilter<"BPUGroup"> | string | null
    overrideRecipient?: StringNullableFilter<"BPUGroup"> | string | null
    overridePaymentFor?: StringNullableFilter<"BPUGroup"> | string | null
    status?: EnumBPUGroupStatusFilter<"BPUGroup"> | $Enums.BPUGroupStatus
    createdAt?: DateTimeFilter<"BPUGroup"> | Date | string
    updatedAt?: DateTimeFilter<"BPUGroup"> | Date | string
    bkuImport?: XOR<BKUImportScalarRelationFilter, BKUImportWhereInput>
    matchedVendorRule?: XOR<VendorRuleNullableScalarRelationFilter, VendorRuleWhereInput> | null
    spmDocument?: XOR<SPMDocumentNullableScalarRelationFilter, SPMDocumentWhereInput> | null
  }

  export type BPUGroupOrderByWithRelationInput = {
    id?: SortOrder
    bkuImportId?: SortOrder
    bpuCode?: SortOrder
    bpuNumber?: SortOrder
    tanggal?: SortOrder
    totalAmount?: SortOrder
    matchedVendorRuleId?: SortOrderInput | SortOrder
    overrideRecipient?: SortOrderInput | SortOrder
    overridePaymentFor?: SortOrderInput | SortOrder
    status?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    bkuImport?: BKUImportOrderByWithRelationInput
    matchedVendorRule?: VendorRuleOrderByWithRelationInput
    spmDocument?: SPMDocumentOrderByWithRelationInput
  }

  export type BPUGroupWhereUniqueInput = Prisma.AtLeast<{
    id?: string
    bkuImportId_bpuCode?: BPUGroupBkuImportIdBpuCodeCompoundUniqueInput
    AND?: BPUGroupWhereInput | BPUGroupWhereInput[]
    OR?: BPUGroupWhereInput[]
    NOT?: BPUGroupWhereInput | BPUGroupWhereInput[]
    bkuImportId?: StringFilter<"BPUGroup"> | string
    bpuCode?: StringFilter<"BPUGroup"> | string
    bpuNumber?: IntFilter<"BPUGroup"> | number
    tanggal?: DateTimeFilter<"BPUGroup"> | Date | string
    totalAmount?: IntFilter<"BPUGroup"> | number
    matchedVendorRuleId?: StringNullableFilter<"BPUGroup"> | string | null
    overrideRecipient?: StringNullableFilter<"BPUGroup"> | string | null
    overridePaymentFor?: StringNullableFilter<"BPUGroup"> | string | null
    status?: EnumBPUGroupStatusFilter<"BPUGroup"> | $Enums.BPUGroupStatus
    createdAt?: DateTimeFilter<"BPUGroup"> | Date | string
    updatedAt?: DateTimeFilter<"BPUGroup"> | Date | string
    bkuImport?: XOR<BKUImportScalarRelationFilter, BKUImportWhereInput>
    matchedVendorRule?: XOR<VendorRuleNullableScalarRelationFilter, VendorRuleWhereInput> | null
    spmDocument?: XOR<SPMDocumentNullableScalarRelationFilter, SPMDocumentWhereInput> | null
  }, "id" | "bkuImportId_bpuCode">

  export type BPUGroupOrderByWithAggregationInput = {
    id?: SortOrder
    bkuImportId?: SortOrder
    bpuCode?: SortOrder
    bpuNumber?: SortOrder
    tanggal?: SortOrder
    totalAmount?: SortOrder
    matchedVendorRuleId?: SortOrderInput | SortOrder
    overrideRecipient?: SortOrderInput | SortOrder
    overridePaymentFor?: SortOrderInput | SortOrder
    status?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    _count?: BPUGroupCountOrderByAggregateInput
    _avg?: BPUGroupAvgOrderByAggregateInput
    _max?: BPUGroupMaxOrderByAggregateInput
    _min?: BPUGroupMinOrderByAggregateInput
    _sum?: BPUGroupSumOrderByAggregateInput
  }

  export type BPUGroupScalarWhereWithAggregatesInput = {
    AND?: BPUGroupScalarWhereWithAggregatesInput | BPUGroupScalarWhereWithAggregatesInput[]
    OR?: BPUGroupScalarWhereWithAggregatesInput[]
    NOT?: BPUGroupScalarWhereWithAggregatesInput | BPUGroupScalarWhereWithAggregatesInput[]
    id?: StringWithAggregatesFilter<"BPUGroup"> | string
    bkuImportId?: StringWithAggregatesFilter<"BPUGroup"> | string
    bpuCode?: StringWithAggregatesFilter<"BPUGroup"> | string
    bpuNumber?: IntWithAggregatesFilter<"BPUGroup"> | number
    tanggal?: DateTimeWithAggregatesFilter<"BPUGroup"> | Date | string
    totalAmount?: IntWithAggregatesFilter<"BPUGroup"> | number
    matchedVendorRuleId?: StringNullableWithAggregatesFilter<"BPUGroup"> | string | null
    overrideRecipient?: StringNullableWithAggregatesFilter<"BPUGroup"> | string | null
    overridePaymentFor?: StringNullableWithAggregatesFilter<"BPUGroup"> | string | null
    status?: EnumBPUGroupStatusWithAggregatesFilter<"BPUGroup"> | $Enums.BPUGroupStatus
    createdAt?: DateTimeWithAggregatesFilter<"BPUGroup"> | Date | string
    updatedAt?: DateTimeWithAggregatesFilter<"BPUGroup"> | Date | string
  }

  export type SPMDocumentWhereInput = {
    AND?: SPMDocumentWhereInput | SPMDocumentWhereInput[]
    OR?: SPMDocumentWhereInput[]
    NOT?: SPMDocumentWhereInput | SPMDocumentWhereInput[]
    id?: StringFilter<"SPMDocument"> | string
    bpuGroupId?: StringFilter<"SPMDocument"> | string
    nomorSurat?: StringFilter<"SPMDocument"> | string
    recipient?: StringFilter<"SPMDocument"> | string
    amount?: IntFilter<"SPMDocument"> | number
    terbilang?: StringFilter<"SPMDocument"> | string
    paymentFor?: StringFilter<"SPMDocument"> | string
    filePath?: StringFilter<"SPMDocument"> | string
    generatedAt?: DateTimeFilter<"SPMDocument"> | Date | string
    bpuGroup?: XOR<BPUGroupScalarRelationFilter, BPUGroupWhereInput>
  }

  export type SPMDocumentOrderByWithRelationInput = {
    id?: SortOrder
    bpuGroupId?: SortOrder
    nomorSurat?: SortOrder
    recipient?: SortOrder
    amount?: SortOrder
    terbilang?: SortOrder
    paymentFor?: SortOrder
    filePath?: SortOrder
    generatedAt?: SortOrder
    bpuGroup?: BPUGroupOrderByWithRelationInput
  }

  export type SPMDocumentWhereUniqueInput = Prisma.AtLeast<{
    id?: string
    bpuGroupId?: string
    AND?: SPMDocumentWhereInput | SPMDocumentWhereInput[]
    OR?: SPMDocumentWhereInput[]
    NOT?: SPMDocumentWhereInput | SPMDocumentWhereInput[]
    nomorSurat?: StringFilter<"SPMDocument"> | string
    recipient?: StringFilter<"SPMDocument"> | string
    amount?: IntFilter<"SPMDocument"> | number
    terbilang?: StringFilter<"SPMDocument"> | string
    paymentFor?: StringFilter<"SPMDocument"> | string
    filePath?: StringFilter<"SPMDocument"> | string
    generatedAt?: DateTimeFilter<"SPMDocument"> | Date | string
    bpuGroup?: XOR<BPUGroupScalarRelationFilter, BPUGroupWhereInput>
  }, "id" | "bpuGroupId">

  export type SPMDocumentOrderByWithAggregationInput = {
    id?: SortOrder
    bpuGroupId?: SortOrder
    nomorSurat?: SortOrder
    recipient?: SortOrder
    amount?: SortOrder
    terbilang?: SortOrder
    paymentFor?: SortOrder
    filePath?: SortOrder
    generatedAt?: SortOrder
    _count?: SPMDocumentCountOrderByAggregateInput
    _avg?: SPMDocumentAvgOrderByAggregateInput
    _max?: SPMDocumentMaxOrderByAggregateInput
    _min?: SPMDocumentMinOrderByAggregateInput
    _sum?: SPMDocumentSumOrderByAggregateInput
  }

  export type SPMDocumentScalarWhereWithAggregatesInput = {
    AND?: SPMDocumentScalarWhereWithAggregatesInput | SPMDocumentScalarWhereWithAggregatesInput[]
    OR?: SPMDocumentScalarWhereWithAggregatesInput[]
    NOT?: SPMDocumentScalarWhereWithAggregatesInput | SPMDocumentScalarWhereWithAggregatesInput[]
    id?: StringWithAggregatesFilter<"SPMDocument"> | string
    bpuGroupId?: StringWithAggregatesFilter<"SPMDocument"> | string
    nomorSurat?: StringWithAggregatesFilter<"SPMDocument"> | string
    recipient?: StringWithAggregatesFilter<"SPMDocument"> | string
    amount?: IntWithAggregatesFilter<"SPMDocument"> | number
    terbilang?: StringWithAggregatesFilter<"SPMDocument"> | string
    paymentFor?: StringWithAggregatesFilter<"SPMDocument"> | string
    filePath?: StringWithAggregatesFilter<"SPMDocument"> | string
    generatedAt?: DateTimeWithAggregatesFilter<"SPMDocument"> | Date | string
  }

  export type RkasImportWhereInput = {
    AND?: RkasImportWhereInput | RkasImportWhereInput[]
    OR?: RkasImportWhereInput[]
    NOT?: RkasImportWhereInput | RkasImportWhereInput[]
    id?: StringFilter<"RkasImport"> | string
    schoolId?: StringFilter<"RkasImport"> | string
    month?: IntFilter<"RkasImport"> | number
    year?: IntFilter<"RkasImport"> | number
    sourceFileName?: StringFilter<"RkasImport"> | string
    sourceSchoolName?: StringNullableFilter<"RkasImport"> | string | null
    npsn?: StringNullableFilter<"RkasImport"> | string | null
    namaPelaksana?: StringFilter<"RkasImport"> | string
    programLabel?: StringFilter<"RkasImport"> | string
    namaKegiatan?: StringFilter<"RkasImport"> | string
    sumberDana?: StringFilter<"RkasImport"> | string
    pekerjaanLabel?: StringFilter<"RkasImport"> | string
    kepalaName?: StringFilter<"RkasImport"> | string
    bendaharaName?: StringFilter<"RkasImport"> | string
    importedAt?: DateTimeFilter<"RkasImport"> | Date | string
    updatedAt?: DateTimeFilter<"RkasImport"> | Date | string
    school?: XOR<SchoolScalarRelationFilter, SchoolWhereInput>
    programs?: RkasProgramListRelationFilter
  }

  export type RkasImportOrderByWithRelationInput = {
    id?: SortOrder
    schoolId?: SortOrder
    month?: SortOrder
    year?: SortOrder
    sourceFileName?: SortOrder
    sourceSchoolName?: SortOrderInput | SortOrder
    npsn?: SortOrderInput | SortOrder
    namaPelaksana?: SortOrder
    programLabel?: SortOrder
    namaKegiatan?: SortOrder
    sumberDana?: SortOrder
    pekerjaanLabel?: SortOrder
    kepalaName?: SortOrder
    bendaharaName?: SortOrder
    importedAt?: SortOrder
    updatedAt?: SortOrder
    school?: SchoolOrderByWithRelationInput
    programs?: RkasProgramOrderByRelationAggregateInput
  }

  export type RkasImportWhereUniqueInput = Prisma.AtLeast<{
    id?: string
    AND?: RkasImportWhereInput | RkasImportWhereInput[]
    OR?: RkasImportWhereInput[]
    NOT?: RkasImportWhereInput | RkasImportWhereInput[]
    schoolId?: StringFilter<"RkasImport"> | string
    month?: IntFilter<"RkasImport"> | number
    year?: IntFilter<"RkasImport"> | number
    sourceFileName?: StringFilter<"RkasImport"> | string
    sourceSchoolName?: StringNullableFilter<"RkasImport"> | string | null
    npsn?: StringNullableFilter<"RkasImport"> | string | null
    namaPelaksana?: StringFilter<"RkasImport"> | string
    programLabel?: StringFilter<"RkasImport"> | string
    namaKegiatan?: StringFilter<"RkasImport"> | string
    sumberDana?: StringFilter<"RkasImport"> | string
    pekerjaanLabel?: StringFilter<"RkasImport"> | string
    kepalaName?: StringFilter<"RkasImport"> | string
    bendaharaName?: StringFilter<"RkasImport"> | string
    importedAt?: DateTimeFilter<"RkasImport"> | Date | string
    updatedAt?: DateTimeFilter<"RkasImport"> | Date | string
    school?: XOR<SchoolScalarRelationFilter, SchoolWhereInput>
    programs?: RkasProgramListRelationFilter
  }, "id">

  export type RkasImportOrderByWithAggregationInput = {
    id?: SortOrder
    schoolId?: SortOrder
    month?: SortOrder
    year?: SortOrder
    sourceFileName?: SortOrder
    sourceSchoolName?: SortOrderInput | SortOrder
    npsn?: SortOrderInput | SortOrder
    namaPelaksana?: SortOrder
    programLabel?: SortOrder
    namaKegiatan?: SortOrder
    sumberDana?: SortOrder
    pekerjaanLabel?: SortOrder
    kepalaName?: SortOrder
    bendaharaName?: SortOrder
    importedAt?: SortOrder
    updatedAt?: SortOrder
    _count?: RkasImportCountOrderByAggregateInput
    _avg?: RkasImportAvgOrderByAggregateInput
    _max?: RkasImportMaxOrderByAggregateInput
    _min?: RkasImportMinOrderByAggregateInput
    _sum?: RkasImportSumOrderByAggregateInput
  }

  export type RkasImportScalarWhereWithAggregatesInput = {
    AND?: RkasImportScalarWhereWithAggregatesInput | RkasImportScalarWhereWithAggregatesInput[]
    OR?: RkasImportScalarWhereWithAggregatesInput[]
    NOT?: RkasImportScalarWhereWithAggregatesInput | RkasImportScalarWhereWithAggregatesInput[]
    id?: StringWithAggregatesFilter<"RkasImport"> | string
    schoolId?: StringWithAggregatesFilter<"RkasImport"> | string
    month?: IntWithAggregatesFilter<"RkasImport"> | number
    year?: IntWithAggregatesFilter<"RkasImport"> | number
    sourceFileName?: StringWithAggregatesFilter<"RkasImport"> | string
    sourceSchoolName?: StringNullableWithAggregatesFilter<"RkasImport"> | string | null
    npsn?: StringNullableWithAggregatesFilter<"RkasImport"> | string | null
    namaPelaksana?: StringWithAggregatesFilter<"RkasImport"> | string
    programLabel?: StringWithAggregatesFilter<"RkasImport"> | string
    namaKegiatan?: StringWithAggregatesFilter<"RkasImport"> | string
    sumberDana?: StringWithAggregatesFilter<"RkasImport"> | string
    pekerjaanLabel?: StringWithAggregatesFilter<"RkasImport"> | string
    kepalaName?: StringWithAggregatesFilter<"RkasImport"> | string
    bendaharaName?: StringWithAggregatesFilter<"RkasImport"> | string
    importedAt?: DateTimeWithAggregatesFilter<"RkasImport"> | Date | string
    updatedAt?: DateTimeWithAggregatesFilter<"RkasImport"> | Date | string
  }

  export type RkasProgramWhereInput = {
    AND?: RkasProgramWhereInput | RkasProgramWhereInput[]
    OR?: RkasProgramWhereInput[]
    NOT?: RkasProgramWhereInput | RkasProgramWhereInput[]
    id?: StringFilter<"RkasProgram"> | string
    rkasImportId?: StringFilter<"RkasProgram"> | string
    urutan?: IntFilter<"RkasProgram"> | number
    kodeProgram?: StringFilter<"RkasProgram"> | string
    nama?: StringFilter<"RkasProgram"> | string
    standarName?: StringFilter<"RkasProgram"> | string
    kegiatanName?: StringFilter<"RkasProgram"> | string
    included?: BoolFilter<"RkasProgram"> | boolean
    rkasImport?: XOR<RkasImportScalarRelationFilter, RkasImportWhereInput>
    items?: RkasItemListRelationFilter
  }

  export type RkasProgramOrderByWithRelationInput = {
    id?: SortOrder
    rkasImportId?: SortOrder
    urutan?: SortOrder
    kodeProgram?: SortOrder
    nama?: SortOrder
    standarName?: SortOrder
    kegiatanName?: SortOrder
    included?: SortOrder
    rkasImport?: RkasImportOrderByWithRelationInput
    items?: RkasItemOrderByRelationAggregateInput
  }

  export type RkasProgramWhereUniqueInput = Prisma.AtLeast<{
    id?: string
    AND?: RkasProgramWhereInput | RkasProgramWhereInput[]
    OR?: RkasProgramWhereInput[]
    NOT?: RkasProgramWhereInput | RkasProgramWhereInput[]
    rkasImportId?: StringFilter<"RkasProgram"> | string
    urutan?: IntFilter<"RkasProgram"> | number
    kodeProgram?: StringFilter<"RkasProgram"> | string
    nama?: StringFilter<"RkasProgram"> | string
    standarName?: StringFilter<"RkasProgram"> | string
    kegiatanName?: StringFilter<"RkasProgram"> | string
    included?: BoolFilter<"RkasProgram"> | boolean
    rkasImport?: XOR<RkasImportScalarRelationFilter, RkasImportWhereInput>
    items?: RkasItemListRelationFilter
  }, "id">

  export type RkasProgramOrderByWithAggregationInput = {
    id?: SortOrder
    rkasImportId?: SortOrder
    urutan?: SortOrder
    kodeProgram?: SortOrder
    nama?: SortOrder
    standarName?: SortOrder
    kegiatanName?: SortOrder
    included?: SortOrder
    _count?: RkasProgramCountOrderByAggregateInput
    _avg?: RkasProgramAvgOrderByAggregateInput
    _max?: RkasProgramMaxOrderByAggregateInput
    _min?: RkasProgramMinOrderByAggregateInput
    _sum?: RkasProgramSumOrderByAggregateInput
  }

  export type RkasProgramScalarWhereWithAggregatesInput = {
    AND?: RkasProgramScalarWhereWithAggregatesInput | RkasProgramScalarWhereWithAggregatesInput[]
    OR?: RkasProgramScalarWhereWithAggregatesInput[]
    NOT?: RkasProgramScalarWhereWithAggregatesInput | RkasProgramScalarWhereWithAggregatesInput[]
    id?: StringWithAggregatesFilter<"RkasProgram"> | string
    rkasImportId?: StringWithAggregatesFilter<"RkasProgram"> | string
    urutan?: IntWithAggregatesFilter<"RkasProgram"> | number
    kodeProgram?: StringWithAggregatesFilter<"RkasProgram"> | string
    nama?: StringWithAggregatesFilter<"RkasProgram"> | string
    standarName?: StringWithAggregatesFilter<"RkasProgram"> | string
    kegiatanName?: StringWithAggregatesFilter<"RkasProgram"> | string
    included?: BoolWithAggregatesFilter<"RkasProgram"> | boolean
  }

  export type RkasItemWhereInput = {
    AND?: RkasItemWhereInput | RkasItemWhereInput[]
    OR?: RkasItemWhereInput[]
    NOT?: RkasItemWhereInput | RkasItemWhereInput[]
    id?: StringFilter<"RkasItem"> | string
    rkasProgramId?: StringFilter<"RkasItem"> | string
    urutan?: IntFilter<"RkasItem"> | number
    noUrut?: IntFilter<"RkasItem"> | number
    kodeRekening?: StringFilter<"RkasItem"> | string
    uraian?: StringFilter<"RkasItem"> | string
    volumeText?: StringFilter<"RkasItem"> | string
    tarifHarga?: IntFilter<"RkasItem"> | number
    jumlah?: IntFilter<"RkasItem"> | number
    excluded?: BoolFilter<"RkasItem"> | boolean
    rkasProgram?: XOR<RkasProgramScalarRelationFilter, RkasProgramWhereInput>
  }

  export type RkasItemOrderByWithRelationInput = {
    id?: SortOrder
    rkasProgramId?: SortOrder
    urutan?: SortOrder
    noUrut?: SortOrder
    kodeRekening?: SortOrder
    uraian?: SortOrder
    volumeText?: SortOrder
    tarifHarga?: SortOrder
    jumlah?: SortOrder
    excluded?: SortOrder
    rkasProgram?: RkasProgramOrderByWithRelationInput
  }

  export type RkasItemWhereUniqueInput = Prisma.AtLeast<{
    id?: string
    AND?: RkasItemWhereInput | RkasItemWhereInput[]
    OR?: RkasItemWhereInput[]
    NOT?: RkasItemWhereInput | RkasItemWhereInput[]
    rkasProgramId?: StringFilter<"RkasItem"> | string
    urutan?: IntFilter<"RkasItem"> | number
    noUrut?: IntFilter<"RkasItem"> | number
    kodeRekening?: StringFilter<"RkasItem"> | string
    uraian?: StringFilter<"RkasItem"> | string
    volumeText?: StringFilter<"RkasItem"> | string
    tarifHarga?: IntFilter<"RkasItem"> | number
    jumlah?: IntFilter<"RkasItem"> | number
    excluded?: BoolFilter<"RkasItem"> | boolean
    rkasProgram?: XOR<RkasProgramScalarRelationFilter, RkasProgramWhereInput>
  }, "id">

  export type RkasItemOrderByWithAggregationInput = {
    id?: SortOrder
    rkasProgramId?: SortOrder
    urutan?: SortOrder
    noUrut?: SortOrder
    kodeRekening?: SortOrder
    uraian?: SortOrder
    volumeText?: SortOrder
    tarifHarga?: SortOrder
    jumlah?: SortOrder
    excluded?: SortOrder
    _count?: RkasItemCountOrderByAggregateInput
    _avg?: RkasItemAvgOrderByAggregateInput
    _max?: RkasItemMaxOrderByAggregateInput
    _min?: RkasItemMinOrderByAggregateInput
    _sum?: RkasItemSumOrderByAggregateInput
  }

  export type RkasItemScalarWhereWithAggregatesInput = {
    AND?: RkasItemScalarWhereWithAggregatesInput | RkasItemScalarWhereWithAggregatesInput[]
    OR?: RkasItemScalarWhereWithAggregatesInput[]
    NOT?: RkasItemScalarWhereWithAggregatesInput | RkasItemScalarWhereWithAggregatesInput[]
    id?: StringWithAggregatesFilter<"RkasItem"> | string
    rkasProgramId?: StringWithAggregatesFilter<"RkasItem"> | string
    urutan?: IntWithAggregatesFilter<"RkasItem"> | number
    noUrut?: IntWithAggregatesFilter<"RkasItem"> | number
    kodeRekening?: StringWithAggregatesFilter<"RkasItem"> | string
    uraian?: StringWithAggregatesFilter<"RkasItem"> | string
    volumeText?: StringWithAggregatesFilter<"RkasItem"> | string
    tarifHarga?: IntWithAggregatesFilter<"RkasItem"> | number
    jumlah?: IntWithAggregatesFilter<"RkasItem"> | number
    excluded?: BoolWithAggregatesFilter<"RkasItem"> | boolean
  }

  export type InstrumenBospWhereInput = {
    AND?: InstrumenBospWhereInput | InstrumenBospWhereInput[]
    OR?: InstrumenBospWhereInput[]
    NOT?: InstrumenBospWhereInput | InstrumenBospWhereInput[]
    id?: StringFilter<"InstrumenBosp"> | string
    schoolId?: StringFilter<"InstrumenBosp"> | string
    year?: IntFilter<"InstrumenBosp"> | number
    tahap?: IntFilter<"InstrumenBosp"> | number
    jenisSatuan?: StringFilter<"InstrumenBosp"> | string
    statusSatuan?: StringFilter<"InstrumenBosp"> | string
    kelurahan?: StringFilter<"InstrumenBosp"> | string
    kecamatan?: StringFilter<"InstrumenBosp"> | string
    jenisDanaBosp?: StringFilter<"InstrumenBosp"> | string
    skNomor?: StringFilter<"InstrumenBosp"> | string
    skTanggal?: StringFilter<"InstrumenBosp"> | string
    kepalaName?: StringFilter<"InstrumenBosp"> | string
    bendaharaName?: StringFilter<"InstrumenBosp"> | string
    komiteName?: StringFilter<"InstrumenBosp"> | string
    adaBku?: BoolFilter<"InstrumenBosp"> | boolean
    adaBukuPembantuKas?: BoolFilter<"InstrumenBosp"> | boolean
    adaBukuPembantuPajak?: BoolFilter<"InstrumenBosp"> | boolean
    adaBukuPembantuBank?: BoolFilter<"InstrumenBosp"> | boolean
    adaLaporanRealisasi?: BoolFilter<"InstrumenBosp"> | boolean
    totalAlokasiTahunan?: IntFilter<"InstrumenBosp"> | number
    saldoAwalOverride?: IntNullableFilter<"InstrumenBosp"> | number | null
    operasionalOverride?: IntNullableFilter<"InstrumenBosp"> | number | null
    honorSesuaiRkas?: BoolFilter<"InstrumenBosp"> | boolean
    honorBuktiLengkap?: BoolFilter<"InstrumenBosp"> | boolean
    honorPenerimaSesuai?: BoolFilter<"InstrumenBosp"> | boolean
    metodePengadaanBuku?: StringFilter<"InstrumenBosp"> | string
    metodePengadaanLain?: StringFilter<"InstrumenBosp"> | string
    belanjaModalJson?: StringFilter<"InstrumenBosp"> | string
    pemeliharaanJson?: StringFilter<"InstrumenBosp"> | string
    bukuOverrideJson?: StringFilter<"InstrumenBosp"> | string
    tanggalDokumen?: StringFilter<"InstrumenBosp"> | string
    createdAt?: DateTimeFilter<"InstrumenBosp"> | Date | string
    updatedAt?: DateTimeFilter<"InstrumenBosp"> | Date | string
    school?: XOR<SchoolScalarRelationFilter, SchoolWhereInput>
  }

  export type InstrumenBospOrderByWithRelationInput = {
    id?: SortOrder
    schoolId?: SortOrder
    year?: SortOrder
    tahap?: SortOrder
    jenisSatuan?: SortOrder
    statusSatuan?: SortOrder
    kelurahan?: SortOrder
    kecamatan?: SortOrder
    jenisDanaBosp?: SortOrder
    skNomor?: SortOrder
    skTanggal?: SortOrder
    kepalaName?: SortOrder
    bendaharaName?: SortOrder
    komiteName?: SortOrder
    adaBku?: SortOrder
    adaBukuPembantuKas?: SortOrder
    adaBukuPembantuPajak?: SortOrder
    adaBukuPembantuBank?: SortOrder
    adaLaporanRealisasi?: SortOrder
    totalAlokasiTahunan?: SortOrder
    saldoAwalOverride?: SortOrderInput | SortOrder
    operasionalOverride?: SortOrderInput | SortOrder
    honorSesuaiRkas?: SortOrder
    honorBuktiLengkap?: SortOrder
    honorPenerimaSesuai?: SortOrder
    metodePengadaanBuku?: SortOrder
    metodePengadaanLain?: SortOrder
    belanjaModalJson?: SortOrder
    pemeliharaanJson?: SortOrder
    bukuOverrideJson?: SortOrder
    tanggalDokumen?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    school?: SchoolOrderByWithRelationInput
  }

  export type InstrumenBospWhereUniqueInput = Prisma.AtLeast<{
    id?: string
    schoolId_year_tahap?: InstrumenBospSchoolIdYearTahapCompoundUniqueInput
    AND?: InstrumenBospWhereInput | InstrumenBospWhereInput[]
    OR?: InstrumenBospWhereInput[]
    NOT?: InstrumenBospWhereInput | InstrumenBospWhereInput[]
    schoolId?: StringFilter<"InstrumenBosp"> | string
    year?: IntFilter<"InstrumenBosp"> | number
    tahap?: IntFilter<"InstrumenBosp"> | number
    jenisSatuan?: StringFilter<"InstrumenBosp"> | string
    statusSatuan?: StringFilter<"InstrumenBosp"> | string
    kelurahan?: StringFilter<"InstrumenBosp"> | string
    kecamatan?: StringFilter<"InstrumenBosp"> | string
    jenisDanaBosp?: StringFilter<"InstrumenBosp"> | string
    skNomor?: StringFilter<"InstrumenBosp"> | string
    skTanggal?: StringFilter<"InstrumenBosp"> | string
    kepalaName?: StringFilter<"InstrumenBosp"> | string
    bendaharaName?: StringFilter<"InstrumenBosp"> | string
    komiteName?: StringFilter<"InstrumenBosp"> | string
    adaBku?: BoolFilter<"InstrumenBosp"> | boolean
    adaBukuPembantuKas?: BoolFilter<"InstrumenBosp"> | boolean
    adaBukuPembantuPajak?: BoolFilter<"InstrumenBosp"> | boolean
    adaBukuPembantuBank?: BoolFilter<"InstrumenBosp"> | boolean
    adaLaporanRealisasi?: BoolFilter<"InstrumenBosp"> | boolean
    totalAlokasiTahunan?: IntFilter<"InstrumenBosp"> | number
    saldoAwalOverride?: IntNullableFilter<"InstrumenBosp"> | number | null
    operasionalOverride?: IntNullableFilter<"InstrumenBosp"> | number | null
    honorSesuaiRkas?: BoolFilter<"InstrumenBosp"> | boolean
    honorBuktiLengkap?: BoolFilter<"InstrumenBosp"> | boolean
    honorPenerimaSesuai?: BoolFilter<"InstrumenBosp"> | boolean
    metodePengadaanBuku?: StringFilter<"InstrumenBosp"> | string
    metodePengadaanLain?: StringFilter<"InstrumenBosp"> | string
    belanjaModalJson?: StringFilter<"InstrumenBosp"> | string
    pemeliharaanJson?: StringFilter<"InstrumenBosp"> | string
    bukuOverrideJson?: StringFilter<"InstrumenBosp"> | string
    tanggalDokumen?: StringFilter<"InstrumenBosp"> | string
    createdAt?: DateTimeFilter<"InstrumenBosp"> | Date | string
    updatedAt?: DateTimeFilter<"InstrumenBosp"> | Date | string
    school?: XOR<SchoolScalarRelationFilter, SchoolWhereInput>
  }, "id" | "schoolId_year_tahap">

  export type InstrumenBospOrderByWithAggregationInput = {
    id?: SortOrder
    schoolId?: SortOrder
    year?: SortOrder
    tahap?: SortOrder
    jenisSatuan?: SortOrder
    statusSatuan?: SortOrder
    kelurahan?: SortOrder
    kecamatan?: SortOrder
    jenisDanaBosp?: SortOrder
    skNomor?: SortOrder
    skTanggal?: SortOrder
    kepalaName?: SortOrder
    bendaharaName?: SortOrder
    komiteName?: SortOrder
    adaBku?: SortOrder
    adaBukuPembantuKas?: SortOrder
    adaBukuPembantuPajak?: SortOrder
    adaBukuPembantuBank?: SortOrder
    adaLaporanRealisasi?: SortOrder
    totalAlokasiTahunan?: SortOrder
    saldoAwalOverride?: SortOrderInput | SortOrder
    operasionalOverride?: SortOrderInput | SortOrder
    honorSesuaiRkas?: SortOrder
    honorBuktiLengkap?: SortOrder
    honorPenerimaSesuai?: SortOrder
    metodePengadaanBuku?: SortOrder
    metodePengadaanLain?: SortOrder
    belanjaModalJson?: SortOrder
    pemeliharaanJson?: SortOrder
    bukuOverrideJson?: SortOrder
    tanggalDokumen?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    _count?: InstrumenBospCountOrderByAggregateInput
    _avg?: InstrumenBospAvgOrderByAggregateInput
    _max?: InstrumenBospMaxOrderByAggregateInput
    _min?: InstrumenBospMinOrderByAggregateInput
    _sum?: InstrumenBospSumOrderByAggregateInput
  }

  export type InstrumenBospScalarWhereWithAggregatesInput = {
    AND?: InstrumenBospScalarWhereWithAggregatesInput | InstrumenBospScalarWhereWithAggregatesInput[]
    OR?: InstrumenBospScalarWhereWithAggregatesInput[]
    NOT?: InstrumenBospScalarWhereWithAggregatesInput | InstrumenBospScalarWhereWithAggregatesInput[]
    id?: StringWithAggregatesFilter<"InstrumenBosp"> | string
    schoolId?: StringWithAggregatesFilter<"InstrumenBosp"> | string
    year?: IntWithAggregatesFilter<"InstrumenBosp"> | number
    tahap?: IntWithAggregatesFilter<"InstrumenBosp"> | number
    jenisSatuan?: StringWithAggregatesFilter<"InstrumenBosp"> | string
    statusSatuan?: StringWithAggregatesFilter<"InstrumenBosp"> | string
    kelurahan?: StringWithAggregatesFilter<"InstrumenBosp"> | string
    kecamatan?: StringWithAggregatesFilter<"InstrumenBosp"> | string
    jenisDanaBosp?: StringWithAggregatesFilter<"InstrumenBosp"> | string
    skNomor?: StringWithAggregatesFilter<"InstrumenBosp"> | string
    skTanggal?: StringWithAggregatesFilter<"InstrumenBosp"> | string
    kepalaName?: StringWithAggregatesFilter<"InstrumenBosp"> | string
    bendaharaName?: StringWithAggregatesFilter<"InstrumenBosp"> | string
    komiteName?: StringWithAggregatesFilter<"InstrumenBosp"> | string
    adaBku?: BoolWithAggregatesFilter<"InstrumenBosp"> | boolean
    adaBukuPembantuKas?: BoolWithAggregatesFilter<"InstrumenBosp"> | boolean
    adaBukuPembantuPajak?: BoolWithAggregatesFilter<"InstrumenBosp"> | boolean
    adaBukuPembantuBank?: BoolWithAggregatesFilter<"InstrumenBosp"> | boolean
    adaLaporanRealisasi?: BoolWithAggregatesFilter<"InstrumenBosp"> | boolean
    totalAlokasiTahunan?: IntWithAggregatesFilter<"InstrumenBosp"> | number
    saldoAwalOverride?: IntNullableWithAggregatesFilter<"InstrumenBosp"> | number | null
    operasionalOverride?: IntNullableWithAggregatesFilter<"InstrumenBosp"> | number | null
    honorSesuaiRkas?: BoolWithAggregatesFilter<"InstrumenBosp"> | boolean
    honorBuktiLengkap?: BoolWithAggregatesFilter<"InstrumenBosp"> | boolean
    honorPenerimaSesuai?: BoolWithAggregatesFilter<"InstrumenBosp"> | boolean
    metodePengadaanBuku?: StringWithAggregatesFilter<"InstrumenBosp"> | string
    metodePengadaanLain?: StringWithAggregatesFilter<"InstrumenBosp"> | string
    belanjaModalJson?: StringWithAggregatesFilter<"InstrumenBosp"> | string
    pemeliharaanJson?: StringWithAggregatesFilter<"InstrumenBosp"> | string
    bukuOverrideJson?: StringWithAggregatesFilter<"InstrumenBosp"> | string
    tanggalDokumen?: StringWithAggregatesFilter<"InstrumenBosp"> | string
    createdAt?: DateTimeWithAggregatesFilter<"InstrumenBosp"> | Date | string
    updatedAt?: DateTimeWithAggregatesFilter<"InstrumenBosp"> | Date | string
  }

  export type SchoolCreateInput = {
    id?: string
    name: string
    kopHeaderLine?: string | null
    npsn?: string | null
    address: string
    contact?: string | null
    formatCode: string
    kepalaName: string
    kepalaJabatan: string
    openingSentenceTemplate?: string
    atasDasarLine1?: string
    atasDasarLine2?: string
    honorRecapTitle?: string | null
    frazaListrikCustomerId?: string | null
    frazaInternetCustomerId?: string | null
    logoPath?: string | null
    regionalLogoPath?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    vendorRules?: VendorRuleCreateNestedManyWithoutSchoolInput
    bkuImports?: BKUImportCreateNestedManyWithoutSchoolInput
    rkasImports?: RkasImportCreateNestedManyWithoutSchoolInput
    instrumenBosp?: InstrumenBospCreateNestedManyWithoutSchoolInput
  }

  export type SchoolUncheckedCreateInput = {
    id?: string
    name: string
    kopHeaderLine?: string | null
    npsn?: string | null
    address: string
    contact?: string | null
    formatCode: string
    kepalaName: string
    kepalaJabatan: string
    openingSentenceTemplate?: string
    atasDasarLine1?: string
    atasDasarLine2?: string
    honorRecapTitle?: string | null
    frazaListrikCustomerId?: string | null
    frazaInternetCustomerId?: string | null
    logoPath?: string | null
    regionalLogoPath?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    vendorRules?: VendorRuleUncheckedCreateNestedManyWithoutSchoolInput
    bkuImports?: BKUImportUncheckedCreateNestedManyWithoutSchoolInput
    rkasImports?: RkasImportUncheckedCreateNestedManyWithoutSchoolInput
    instrumenBosp?: InstrumenBospUncheckedCreateNestedManyWithoutSchoolInput
  }

  export type SchoolUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    kopHeaderLine?: NullableStringFieldUpdateOperationsInput | string | null
    npsn?: NullableStringFieldUpdateOperationsInput | string | null
    address?: StringFieldUpdateOperationsInput | string
    contact?: NullableStringFieldUpdateOperationsInput | string | null
    formatCode?: StringFieldUpdateOperationsInput | string
    kepalaName?: StringFieldUpdateOperationsInput | string
    kepalaJabatan?: StringFieldUpdateOperationsInput | string
    openingSentenceTemplate?: StringFieldUpdateOperationsInput | string
    atasDasarLine1?: StringFieldUpdateOperationsInput | string
    atasDasarLine2?: StringFieldUpdateOperationsInput | string
    honorRecapTitle?: NullableStringFieldUpdateOperationsInput | string | null
    frazaListrikCustomerId?: NullableStringFieldUpdateOperationsInput | string | null
    frazaInternetCustomerId?: NullableStringFieldUpdateOperationsInput | string | null
    logoPath?: NullableStringFieldUpdateOperationsInput | string | null
    regionalLogoPath?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    vendorRules?: VendorRuleUpdateManyWithoutSchoolNestedInput
    bkuImports?: BKUImportUpdateManyWithoutSchoolNestedInput
    rkasImports?: RkasImportUpdateManyWithoutSchoolNestedInput
    instrumenBosp?: InstrumenBospUpdateManyWithoutSchoolNestedInput
  }

  export type SchoolUncheckedUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    kopHeaderLine?: NullableStringFieldUpdateOperationsInput | string | null
    npsn?: NullableStringFieldUpdateOperationsInput | string | null
    address?: StringFieldUpdateOperationsInput | string
    contact?: NullableStringFieldUpdateOperationsInput | string | null
    formatCode?: StringFieldUpdateOperationsInput | string
    kepalaName?: StringFieldUpdateOperationsInput | string
    kepalaJabatan?: StringFieldUpdateOperationsInput | string
    openingSentenceTemplate?: StringFieldUpdateOperationsInput | string
    atasDasarLine1?: StringFieldUpdateOperationsInput | string
    atasDasarLine2?: StringFieldUpdateOperationsInput | string
    honorRecapTitle?: NullableStringFieldUpdateOperationsInput | string | null
    frazaListrikCustomerId?: NullableStringFieldUpdateOperationsInput | string | null
    frazaInternetCustomerId?: NullableStringFieldUpdateOperationsInput | string | null
    logoPath?: NullableStringFieldUpdateOperationsInput | string | null
    regionalLogoPath?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    vendorRules?: VendorRuleUncheckedUpdateManyWithoutSchoolNestedInput
    bkuImports?: BKUImportUncheckedUpdateManyWithoutSchoolNestedInput
    rkasImports?: RkasImportUncheckedUpdateManyWithoutSchoolNestedInput
    instrumenBosp?: InstrumenBospUncheckedUpdateManyWithoutSchoolNestedInput
  }

  export type SchoolCreateManyInput = {
    id?: string
    name: string
    kopHeaderLine?: string | null
    npsn?: string | null
    address: string
    contact?: string | null
    formatCode: string
    kepalaName: string
    kepalaJabatan: string
    openingSentenceTemplate?: string
    atasDasarLine1?: string
    atasDasarLine2?: string
    honorRecapTitle?: string | null
    frazaListrikCustomerId?: string | null
    frazaInternetCustomerId?: string | null
    logoPath?: string | null
    regionalLogoPath?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type SchoolUpdateManyMutationInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    kopHeaderLine?: NullableStringFieldUpdateOperationsInput | string | null
    npsn?: NullableStringFieldUpdateOperationsInput | string | null
    address?: StringFieldUpdateOperationsInput | string
    contact?: NullableStringFieldUpdateOperationsInput | string | null
    formatCode?: StringFieldUpdateOperationsInput | string
    kepalaName?: StringFieldUpdateOperationsInput | string
    kepalaJabatan?: StringFieldUpdateOperationsInput | string
    openingSentenceTemplate?: StringFieldUpdateOperationsInput | string
    atasDasarLine1?: StringFieldUpdateOperationsInput | string
    atasDasarLine2?: StringFieldUpdateOperationsInput | string
    honorRecapTitle?: NullableStringFieldUpdateOperationsInput | string | null
    frazaListrikCustomerId?: NullableStringFieldUpdateOperationsInput | string | null
    frazaInternetCustomerId?: NullableStringFieldUpdateOperationsInput | string | null
    logoPath?: NullableStringFieldUpdateOperationsInput | string | null
    regionalLogoPath?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type SchoolUncheckedUpdateManyInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    kopHeaderLine?: NullableStringFieldUpdateOperationsInput | string | null
    npsn?: NullableStringFieldUpdateOperationsInput | string | null
    address?: StringFieldUpdateOperationsInput | string
    contact?: NullableStringFieldUpdateOperationsInput | string | null
    formatCode?: StringFieldUpdateOperationsInput | string
    kepalaName?: StringFieldUpdateOperationsInput | string
    kepalaJabatan?: StringFieldUpdateOperationsInput | string
    openingSentenceTemplate?: StringFieldUpdateOperationsInput | string
    atasDasarLine1?: StringFieldUpdateOperationsInput | string
    atasDasarLine2?: StringFieldUpdateOperationsInput | string
    honorRecapTitle?: NullableStringFieldUpdateOperationsInput | string | null
    frazaListrikCustomerId?: NullableStringFieldUpdateOperationsInput | string | null
    frazaInternetCustomerId?: NullableStringFieldUpdateOperationsInput | string | null
    logoPath?: NullableStringFieldUpdateOperationsInput | string | null
    regionalLogoPath?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type VendorRuleCreateInput = {
    id?: string
    keyword: string
    recipient: string
    paymentPrefix: string
    matchKodeKegiatan?: string | null
    formatType?: $Enums.VendorRuleFormatType
    isHonor?: boolean
    isTransport?: boolean
    priority?: number
    isActive?: boolean
    createdAt?: Date | string
    updatedAt?: Date | string
    school: SchoolCreateNestedOneWithoutVendorRulesInput
    bpuGroups?: BPUGroupCreateNestedManyWithoutMatchedVendorRuleInput
  }

  export type VendorRuleUncheckedCreateInput = {
    id?: string
    schoolId: string
    keyword: string
    recipient: string
    paymentPrefix: string
    matchKodeKegiatan?: string | null
    formatType?: $Enums.VendorRuleFormatType
    isHonor?: boolean
    isTransport?: boolean
    priority?: number
    isActive?: boolean
    createdAt?: Date | string
    updatedAt?: Date | string
    bpuGroups?: BPUGroupUncheckedCreateNestedManyWithoutMatchedVendorRuleInput
  }

  export type VendorRuleUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    keyword?: StringFieldUpdateOperationsInput | string
    recipient?: StringFieldUpdateOperationsInput | string
    paymentPrefix?: StringFieldUpdateOperationsInput | string
    matchKodeKegiatan?: NullableStringFieldUpdateOperationsInput | string | null
    formatType?: EnumVendorRuleFormatTypeFieldUpdateOperationsInput | $Enums.VendorRuleFormatType
    isHonor?: BoolFieldUpdateOperationsInput | boolean
    isTransport?: BoolFieldUpdateOperationsInput | boolean
    priority?: IntFieldUpdateOperationsInput | number
    isActive?: BoolFieldUpdateOperationsInput | boolean
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    school?: SchoolUpdateOneRequiredWithoutVendorRulesNestedInput
    bpuGroups?: BPUGroupUpdateManyWithoutMatchedVendorRuleNestedInput
  }

  export type VendorRuleUncheckedUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    schoolId?: StringFieldUpdateOperationsInput | string
    keyword?: StringFieldUpdateOperationsInput | string
    recipient?: StringFieldUpdateOperationsInput | string
    paymentPrefix?: StringFieldUpdateOperationsInput | string
    matchKodeKegiatan?: NullableStringFieldUpdateOperationsInput | string | null
    formatType?: EnumVendorRuleFormatTypeFieldUpdateOperationsInput | $Enums.VendorRuleFormatType
    isHonor?: BoolFieldUpdateOperationsInput | boolean
    isTransport?: BoolFieldUpdateOperationsInput | boolean
    priority?: IntFieldUpdateOperationsInput | number
    isActive?: BoolFieldUpdateOperationsInput | boolean
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    bpuGroups?: BPUGroupUncheckedUpdateManyWithoutMatchedVendorRuleNestedInput
  }

  export type VendorRuleCreateManyInput = {
    id?: string
    schoolId: string
    keyword: string
    recipient: string
    paymentPrefix: string
    matchKodeKegiatan?: string | null
    formatType?: $Enums.VendorRuleFormatType
    isHonor?: boolean
    isTransport?: boolean
    priority?: number
    isActive?: boolean
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type VendorRuleUpdateManyMutationInput = {
    id?: StringFieldUpdateOperationsInput | string
    keyword?: StringFieldUpdateOperationsInput | string
    recipient?: StringFieldUpdateOperationsInput | string
    paymentPrefix?: StringFieldUpdateOperationsInput | string
    matchKodeKegiatan?: NullableStringFieldUpdateOperationsInput | string | null
    formatType?: EnumVendorRuleFormatTypeFieldUpdateOperationsInput | $Enums.VendorRuleFormatType
    isHonor?: BoolFieldUpdateOperationsInput | boolean
    isTransport?: BoolFieldUpdateOperationsInput | boolean
    priority?: IntFieldUpdateOperationsInput | number
    isActive?: BoolFieldUpdateOperationsInput | boolean
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type VendorRuleUncheckedUpdateManyInput = {
    id?: StringFieldUpdateOperationsInput | string
    schoolId?: StringFieldUpdateOperationsInput | string
    keyword?: StringFieldUpdateOperationsInput | string
    recipient?: StringFieldUpdateOperationsInput | string
    paymentPrefix?: StringFieldUpdateOperationsInput | string
    matchKodeKegiatan?: NullableStringFieldUpdateOperationsInput | string | null
    formatType?: EnumVendorRuleFormatTypeFieldUpdateOperationsInput | $Enums.VendorRuleFormatType
    isHonor?: BoolFieldUpdateOperationsInput | boolean
    isTransport?: BoolFieldUpdateOperationsInput | boolean
    priority?: IntFieldUpdateOperationsInput | number
    isActive?: BoolFieldUpdateOperationsInput | boolean
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type BKUImportCreateInput = {
    id?: string
    month: number
    year: number
    sourceFileName: string
    status?: $Enums.BKUImportStatus
    importedAt?: Date | string
    school: SchoolCreateNestedOneWithoutBkuImportsInput
    rows?: BKURowCreateNestedManyWithoutBkuImportInput
    bpuGroups?: BPUGroupCreateNestedManyWithoutBkuImportInput
  }

  export type BKUImportUncheckedCreateInput = {
    id?: string
    schoolId: string
    month: number
    year: number
    sourceFileName: string
    status?: $Enums.BKUImportStatus
    importedAt?: Date | string
    rows?: BKURowUncheckedCreateNestedManyWithoutBkuImportInput
    bpuGroups?: BPUGroupUncheckedCreateNestedManyWithoutBkuImportInput
  }

  export type BKUImportUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    month?: IntFieldUpdateOperationsInput | number
    year?: IntFieldUpdateOperationsInput | number
    sourceFileName?: StringFieldUpdateOperationsInput | string
    status?: EnumBKUImportStatusFieldUpdateOperationsInput | $Enums.BKUImportStatus
    importedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    school?: SchoolUpdateOneRequiredWithoutBkuImportsNestedInput
    rows?: BKURowUpdateManyWithoutBkuImportNestedInput
    bpuGroups?: BPUGroupUpdateManyWithoutBkuImportNestedInput
  }

  export type BKUImportUncheckedUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    schoolId?: StringFieldUpdateOperationsInput | string
    month?: IntFieldUpdateOperationsInput | number
    year?: IntFieldUpdateOperationsInput | number
    sourceFileName?: StringFieldUpdateOperationsInput | string
    status?: EnumBKUImportStatusFieldUpdateOperationsInput | $Enums.BKUImportStatus
    importedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    rows?: BKURowUncheckedUpdateManyWithoutBkuImportNestedInput
    bpuGroups?: BPUGroupUncheckedUpdateManyWithoutBkuImportNestedInput
  }

  export type BKUImportCreateManyInput = {
    id?: string
    schoolId: string
    month: number
    year: number
    sourceFileName: string
    status?: $Enums.BKUImportStatus
    importedAt?: Date | string
  }

  export type BKUImportUpdateManyMutationInput = {
    id?: StringFieldUpdateOperationsInput | string
    month?: IntFieldUpdateOperationsInput | number
    year?: IntFieldUpdateOperationsInput | number
    sourceFileName?: StringFieldUpdateOperationsInput | string
    status?: EnumBKUImportStatusFieldUpdateOperationsInput | $Enums.BKUImportStatus
    importedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type BKUImportUncheckedUpdateManyInput = {
    id?: StringFieldUpdateOperationsInput | string
    schoolId?: StringFieldUpdateOperationsInput | string
    month?: IntFieldUpdateOperationsInput | number
    year?: IntFieldUpdateOperationsInput | number
    sourceFileName?: StringFieldUpdateOperationsInput | string
    status?: EnumBKUImportStatusFieldUpdateOperationsInput | $Enums.BKUImportStatus
    importedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type BKURowCreateInput = {
    id?: string
    tanggal: Date | string
    kodeKegiatan?: string | null
    kodeRekening?: string | null
    bpuCode?: string | null
    bpuNumber?: number | null
    uraian: string
    penerimaan?: number
    pengeluaran?: number
    saldo?: number
    pageIndex?: number | null
    createdAt?: Date | string
    bkuImport: BKUImportCreateNestedOneWithoutRowsInput
  }

  export type BKURowUncheckedCreateInput = {
    id?: string
    bkuImportId: string
    tanggal: Date | string
    kodeKegiatan?: string | null
    kodeRekening?: string | null
    bpuCode?: string | null
    bpuNumber?: number | null
    uraian: string
    penerimaan?: number
    pengeluaran?: number
    saldo?: number
    pageIndex?: number | null
    createdAt?: Date | string
  }

  export type BKURowUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    tanggal?: DateTimeFieldUpdateOperationsInput | Date | string
    kodeKegiatan?: NullableStringFieldUpdateOperationsInput | string | null
    kodeRekening?: NullableStringFieldUpdateOperationsInput | string | null
    bpuCode?: NullableStringFieldUpdateOperationsInput | string | null
    bpuNumber?: NullableIntFieldUpdateOperationsInput | number | null
    uraian?: StringFieldUpdateOperationsInput | string
    penerimaan?: IntFieldUpdateOperationsInput | number
    pengeluaran?: IntFieldUpdateOperationsInput | number
    saldo?: IntFieldUpdateOperationsInput | number
    pageIndex?: NullableIntFieldUpdateOperationsInput | number | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    bkuImport?: BKUImportUpdateOneRequiredWithoutRowsNestedInput
  }

  export type BKURowUncheckedUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    bkuImportId?: StringFieldUpdateOperationsInput | string
    tanggal?: DateTimeFieldUpdateOperationsInput | Date | string
    kodeKegiatan?: NullableStringFieldUpdateOperationsInput | string | null
    kodeRekening?: NullableStringFieldUpdateOperationsInput | string | null
    bpuCode?: NullableStringFieldUpdateOperationsInput | string | null
    bpuNumber?: NullableIntFieldUpdateOperationsInput | number | null
    uraian?: StringFieldUpdateOperationsInput | string
    penerimaan?: IntFieldUpdateOperationsInput | number
    pengeluaran?: IntFieldUpdateOperationsInput | number
    saldo?: IntFieldUpdateOperationsInput | number
    pageIndex?: NullableIntFieldUpdateOperationsInput | number | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type BKURowCreateManyInput = {
    id?: string
    bkuImportId: string
    tanggal: Date | string
    kodeKegiatan?: string | null
    kodeRekening?: string | null
    bpuCode?: string | null
    bpuNumber?: number | null
    uraian: string
    penerimaan?: number
    pengeluaran?: number
    saldo?: number
    pageIndex?: number | null
    createdAt?: Date | string
  }

  export type BKURowUpdateManyMutationInput = {
    id?: StringFieldUpdateOperationsInput | string
    tanggal?: DateTimeFieldUpdateOperationsInput | Date | string
    kodeKegiatan?: NullableStringFieldUpdateOperationsInput | string | null
    kodeRekening?: NullableStringFieldUpdateOperationsInput | string | null
    bpuCode?: NullableStringFieldUpdateOperationsInput | string | null
    bpuNumber?: NullableIntFieldUpdateOperationsInput | number | null
    uraian?: StringFieldUpdateOperationsInput | string
    penerimaan?: IntFieldUpdateOperationsInput | number
    pengeluaran?: IntFieldUpdateOperationsInput | number
    saldo?: IntFieldUpdateOperationsInput | number
    pageIndex?: NullableIntFieldUpdateOperationsInput | number | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type BKURowUncheckedUpdateManyInput = {
    id?: StringFieldUpdateOperationsInput | string
    bkuImportId?: StringFieldUpdateOperationsInput | string
    tanggal?: DateTimeFieldUpdateOperationsInput | Date | string
    kodeKegiatan?: NullableStringFieldUpdateOperationsInput | string | null
    kodeRekening?: NullableStringFieldUpdateOperationsInput | string | null
    bpuCode?: NullableStringFieldUpdateOperationsInput | string | null
    bpuNumber?: NullableIntFieldUpdateOperationsInput | number | null
    uraian?: StringFieldUpdateOperationsInput | string
    penerimaan?: IntFieldUpdateOperationsInput | number
    pengeluaran?: IntFieldUpdateOperationsInput | number
    saldo?: IntFieldUpdateOperationsInput | number
    pageIndex?: NullableIntFieldUpdateOperationsInput | number | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type BPUGroupCreateInput = {
    id?: string
    bpuCode: string
    bpuNumber: number
    tanggal: Date | string
    totalAmount: number
    overrideRecipient?: string | null
    overridePaymentFor?: string | null
    status?: $Enums.BPUGroupStatus
    createdAt?: Date | string
    updatedAt?: Date | string
    bkuImport: BKUImportCreateNestedOneWithoutBpuGroupsInput
    matchedVendorRule?: VendorRuleCreateNestedOneWithoutBpuGroupsInput
    spmDocument?: SPMDocumentCreateNestedOneWithoutBpuGroupInput
  }

  export type BPUGroupUncheckedCreateInput = {
    id?: string
    bkuImportId: string
    bpuCode: string
    bpuNumber: number
    tanggal: Date | string
    totalAmount: number
    matchedVendorRuleId?: string | null
    overrideRecipient?: string | null
    overridePaymentFor?: string | null
    status?: $Enums.BPUGroupStatus
    createdAt?: Date | string
    updatedAt?: Date | string
    spmDocument?: SPMDocumentUncheckedCreateNestedOneWithoutBpuGroupInput
  }

  export type BPUGroupUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    bpuCode?: StringFieldUpdateOperationsInput | string
    bpuNumber?: IntFieldUpdateOperationsInput | number
    tanggal?: DateTimeFieldUpdateOperationsInput | Date | string
    totalAmount?: IntFieldUpdateOperationsInput | number
    overrideRecipient?: NullableStringFieldUpdateOperationsInput | string | null
    overridePaymentFor?: NullableStringFieldUpdateOperationsInput | string | null
    status?: EnumBPUGroupStatusFieldUpdateOperationsInput | $Enums.BPUGroupStatus
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    bkuImport?: BKUImportUpdateOneRequiredWithoutBpuGroupsNestedInput
    matchedVendorRule?: VendorRuleUpdateOneWithoutBpuGroupsNestedInput
    spmDocument?: SPMDocumentUpdateOneWithoutBpuGroupNestedInput
  }

  export type BPUGroupUncheckedUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    bkuImportId?: StringFieldUpdateOperationsInput | string
    bpuCode?: StringFieldUpdateOperationsInput | string
    bpuNumber?: IntFieldUpdateOperationsInput | number
    tanggal?: DateTimeFieldUpdateOperationsInput | Date | string
    totalAmount?: IntFieldUpdateOperationsInput | number
    matchedVendorRuleId?: NullableStringFieldUpdateOperationsInput | string | null
    overrideRecipient?: NullableStringFieldUpdateOperationsInput | string | null
    overridePaymentFor?: NullableStringFieldUpdateOperationsInput | string | null
    status?: EnumBPUGroupStatusFieldUpdateOperationsInput | $Enums.BPUGroupStatus
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    spmDocument?: SPMDocumentUncheckedUpdateOneWithoutBpuGroupNestedInput
  }

  export type BPUGroupCreateManyInput = {
    id?: string
    bkuImportId: string
    bpuCode: string
    bpuNumber: number
    tanggal: Date | string
    totalAmount: number
    matchedVendorRuleId?: string | null
    overrideRecipient?: string | null
    overridePaymentFor?: string | null
    status?: $Enums.BPUGroupStatus
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type BPUGroupUpdateManyMutationInput = {
    id?: StringFieldUpdateOperationsInput | string
    bpuCode?: StringFieldUpdateOperationsInput | string
    bpuNumber?: IntFieldUpdateOperationsInput | number
    tanggal?: DateTimeFieldUpdateOperationsInput | Date | string
    totalAmount?: IntFieldUpdateOperationsInput | number
    overrideRecipient?: NullableStringFieldUpdateOperationsInput | string | null
    overridePaymentFor?: NullableStringFieldUpdateOperationsInput | string | null
    status?: EnumBPUGroupStatusFieldUpdateOperationsInput | $Enums.BPUGroupStatus
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type BPUGroupUncheckedUpdateManyInput = {
    id?: StringFieldUpdateOperationsInput | string
    bkuImportId?: StringFieldUpdateOperationsInput | string
    bpuCode?: StringFieldUpdateOperationsInput | string
    bpuNumber?: IntFieldUpdateOperationsInput | number
    tanggal?: DateTimeFieldUpdateOperationsInput | Date | string
    totalAmount?: IntFieldUpdateOperationsInput | number
    matchedVendorRuleId?: NullableStringFieldUpdateOperationsInput | string | null
    overrideRecipient?: NullableStringFieldUpdateOperationsInput | string | null
    overridePaymentFor?: NullableStringFieldUpdateOperationsInput | string | null
    status?: EnumBPUGroupStatusFieldUpdateOperationsInput | $Enums.BPUGroupStatus
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type SPMDocumentCreateInput = {
    id?: string
    nomorSurat: string
    recipient: string
    amount: number
    terbilang: string
    paymentFor: string
    filePath: string
    generatedAt?: Date | string
    bpuGroup: BPUGroupCreateNestedOneWithoutSpmDocumentInput
  }

  export type SPMDocumentUncheckedCreateInput = {
    id?: string
    bpuGroupId: string
    nomorSurat: string
    recipient: string
    amount: number
    terbilang: string
    paymentFor: string
    filePath: string
    generatedAt?: Date | string
  }

  export type SPMDocumentUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    nomorSurat?: StringFieldUpdateOperationsInput | string
    recipient?: StringFieldUpdateOperationsInput | string
    amount?: IntFieldUpdateOperationsInput | number
    terbilang?: StringFieldUpdateOperationsInput | string
    paymentFor?: StringFieldUpdateOperationsInput | string
    filePath?: StringFieldUpdateOperationsInput | string
    generatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    bpuGroup?: BPUGroupUpdateOneRequiredWithoutSpmDocumentNestedInput
  }

  export type SPMDocumentUncheckedUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    bpuGroupId?: StringFieldUpdateOperationsInput | string
    nomorSurat?: StringFieldUpdateOperationsInput | string
    recipient?: StringFieldUpdateOperationsInput | string
    amount?: IntFieldUpdateOperationsInput | number
    terbilang?: StringFieldUpdateOperationsInput | string
    paymentFor?: StringFieldUpdateOperationsInput | string
    filePath?: StringFieldUpdateOperationsInput | string
    generatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type SPMDocumentCreateManyInput = {
    id?: string
    bpuGroupId: string
    nomorSurat: string
    recipient: string
    amount: number
    terbilang: string
    paymentFor: string
    filePath: string
    generatedAt?: Date | string
  }

  export type SPMDocumentUpdateManyMutationInput = {
    id?: StringFieldUpdateOperationsInput | string
    nomorSurat?: StringFieldUpdateOperationsInput | string
    recipient?: StringFieldUpdateOperationsInput | string
    amount?: IntFieldUpdateOperationsInput | number
    terbilang?: StringFieldUpdateOperationsInput | string
    paymentFor?: StringFieldUpdateOperationsInput | string
    filePath?: StringFieldUpdateOperationsInput | string
    generatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type SPMDocumentUncheckedUpdateManyInput = {
    id?: StringFieldUpdateOperationsInput | string
    bpuGroupId?: StringFieldUpdateOperationsInput | string
    nomorSurat?: StringFieldUpdateOperationsInput | string
    recipient?: StringFieldUpdateOperationsInput | string
    amount?: IntFieldUpdateOperationsInput | number
    terbilang?: StringFieldUpdateOperationsInput | string
    paymentFor?: StringFieldUpdateOperationsInput | string
    filePath?: StringFieldUpdateOperationsInput | string
    generatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type RkasImportCreateInput = {
    id?: string
    month: number
    year: number
    sourceFileName: string
    sourceSchoolName?: string | null
    npsn?: string | null
    namaPelaksana?: string
    programLabel?: string
    namaKegiatan?: string
    sumberDana?: string
    pekerjaanLabel?: string
    kepalaName?: string
    bendaharaName?: string
    importedAt?: Date | string
    updatedAt?: Date | string
    school: SchoolCreateNestedOneWithoutRkasImportsInput
    programs?: RkasProgramCreateNestedManyWithoutRkasImportInput
  }

  export type RkasImportUncheckedCreateInput = {
    id?: string
    schoolId: string
    month: number
    year: number
    sourceFileName: string
    sourceSchoolName?: string | null
    npsn?: string | null
    namaPelaksana?: string
    programLabel?: string
    namaKegiatan?: string
    sumberDana?: string
    pekerjaanLabel?: string
    kepalaName?: string
    bendaharaName?: string
    importedAt?: Date | string
    updatedAt?: Date | string
    programs?: RkasProgramUncheckedCreateNestedManyWithoutRkasImportInput
  }

  export type RkasImportUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    month?: IntFieldUpdateOperationsInput | number
    year?: IntFieldUpdateOperationsInput | number
    sourceFileName?: StringFieldUpdateOperationsInput | string
    sourceSchoolName?: NullableStringFieldUpdateOperationsInput | string | null
    npsn?: NullableStringFieldUpdateOperationsInput | string | null
    namaPelaksana?: StringFieldUpdateOperationsInput | string
    programLabel?: StringFieldUpdateOperationsInput | string
    namaKegiatan?: StringFieldUpdateOperationsInput | string
    sumberDana?: StringFieldUpdateOperationsInput | string
    pekerjaanLabel?: StringFieldUpdateOperationsInput | string
    kepalaName?: StringFieldUpdateOperationsInput | string
    bendaharaName?: StringFieldUpdateOperationsInput | string
    importedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    school?: SchoolUpdateOneRequiredWithoutRkasImportsNestedInput
    programs?: RkasProgramUpdateManyWithoutRkasImportNestedInput
  }

  export type RkasImportUncheckedUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    schoolId?: StringFieldUpdateOperationsInput | string
    month?: IntFieldUpdateOperationsInput | number
    year?: IntFieldUpdateOperationsInput | number
    sourceFileName?: StringFieldUpdateOperationsInput | string
    sourceSchoolName?: NullableStringFieldUpdateOperationsInput | string | null
    npsn?: NullableStringFieldUpdateOperationsInput | string | null
    namaPelaksana?: StringFieldUpdateOperationsInput | string
    programLabel?: StringFieldUpdateOperationsInput | string
    namaKegiatan?: StringFieldUpdateOperationsInput | string
    sumberDana?: StringFieldUpdateOperationsInput | string
    pekerjaanLabel?: StringFieldUpdateOperationsInput | string
    kepalaName?: StringFieldUpdateOperationsInput | string
    bendaharaName?: StringFieldUpdateOperationsInput | string
    importedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    programs?: RkasProgramUncheckedUpdateManyWithoutRkasImportNestedInput
  }

  export type RkasImportCreateManyInput = {
    id?: string
    schoolId: string
    month: number
    year: number
    sourceFileName: string
    sourceSchoolName?: string | null
    npsn?: string | null
    namaPelaksana?: string
    programLabel?: string
    namaKegiatan?: string
    sumberDana?: string
    pekerjaanLabel?: string
    kepalaName?: string
    bendaharaName?: string
    importedAt?: Date | string
    updatedAt?: Date | string
  }

  export type RkasImportUpdateManyMutationInput = {
    id?: StringFieldUpdateOperationsInput | string
    month?: IntFieldUpdateOperationsInput | number
    year?: IntFieldUpdateOperationsInput | number
    sourceFileName?: StringFieldUpdateOperationsInput | string
    sourceSchoolName?: NullableStringFieldUpdateOperationsInput | string | null
    npsn?: NullableStringFieldUpdateOperationsInput | string | null
    namaPelaksana?: StringFieldUpdateOperationsInput | string
    programLabel?: StringFieldUpdateOperationsInput | string
    namaKegiatan?: StringFieldUpdateOperationsInput | string
    sumberDana?: StringFieldUpdateOperationsInput | string
    pekerjaanLabel?: StringFieldUpdateOperationsInput | string
    kepalaName?: StringFieldUpdateOperationsInput | string
    bendaharaName?: StringFieldUpdateOperationsInput | string
    importedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type RkasImportUncheckedUpdateManyInput = {
    id?: StringFieldUpdateOperationsInput | string
    schoolId?: StringFieldUpdateOperationsInput | string
    month?: IntFieldUpdateOperationsInput | number
    year?: IntFieldUpdateOperationsInput | number
    sourceFileName?: StringFieldUpdateOperationsInput | string
    sourceSchoolName?: NullableStringFieldUpdateOperationsInput | string | null
    npsn?: NullableStringFieldUpdateOperationsInput | string | null
    namaPelaksana?: StringFieldUpdateOperationsInput | string
    programLabel?: StringFieldUpdateOperationsInput | string
    namaKegiatan?: StringFieldUpdateOperationsInput | string
    sumberDana?: StringFieldUpdateOperationsInput | string
    pekerjaanLabel?: StringFieldUpdateOperationsInput | string
    kepalaName?: StringFieldUpdateOperationsInput | string
    bendaharaName?: StringFieldUpdateOperationsInput | string
    importedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type RkasProgramCreateInput = {
    id?: string
    urutan: number
    kodeProgram: string
    nama: string
    standarName?: string
    kegiatanName?: string
    included?: boolean
    rkasImport: RkasImportCreateNestedOneWithoutProgramsInput
    items?: RkasItemCreateNestedManyWithoutRkasProgramInput
  }

  export type RkasProgramUncheckedCreateInput = {
    id?: string
    rkasImportId: string
    urutan: number
    kodeProgram: string
    nama: string
    standarName?: string
    kegiatanName?: string
    included?: boolean
    items?: RkasItemUncheckedCreateNestedManyWithoutRkasProgramInput
  }

  export type RkasProgramUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    urutan?: IntFieldUpdateOperationsInput | number
    kodeProgram?: StringFieldUpdateOperationsInput | string
    nama?: StringFieldUpdateOperationsInput | string
    standarName?: StringFieldUpdateOperationsInput | string
    kegiatanName?: StringFieldUpdateOperationsInput | string
    included?: BoolFieldUpdateOperationsInput | boolean
    rkasImport?: RkasImportUpdateOneRequiredWithoutProgramsNestedInput
    items?: RkasItemUpdateManyWithoutRkasProgramNestedInput
  }

  export type RkasProgramUncheckedUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    rkasImportId?: StringFieldUpdateOperationsInput | string
    urutan?: IntFieldUpdateOperationsInput | number
    kodeProgram?: StringFieldUpdateOperationsInput | string
    nama?: StringFieldUpdateOperationsInput | string
    standarName?: StringFieldUpdateOperationsInput | string
    kegiatanName?: StringFieldUpdateOperationsInput | string
    included?: BoolFieldUpdateOperationsInput | boolean
    items?: RkasItemUncheckedUpdateManyWithoutRkasProgramNestedInput
  }

  export type RkasProgramCreateManyInput = {
    id?: string
    rkasImportId: string
    urutan: number
    kodeProgram: string
    nama: string
    standarName?: string
    kegiatanName?: string
    included?: boolean
  }

  export type RkasProgramUpdateManyMutationInput = {
    id?: StringFieldUpdateOperationsInput | string
    urutan?: IntFieldUpdateOperationsInput | number
    kodeProgram?: StringFieldUpdateOperationsInput | string
    nama?: StringFieldUpdateOperationsInput | string
    standarName?: StringFieldUpdateOperationsInput | string
    kegiatanName?: StringFieldUpdateOperationsInput | string
    included?: BoolFieldUpdateOperationsInput | boolean
  }

  export type RkasProgramUncheckedUpdateManyInput = {
    id?: StringFieldUpdateOperationsInput | string
    rkasImportId?: StringFieldUpdateOperationsInput | string
    urutan?: IntFieldUpdateOperationsInput | number
    kodeProgram?: StringFieldUpdateOperationsInput | string
    nama?: StringFieldUpdateOperationsInput | string
    standarName?: StringFieldUpdateOperationsInput | string
    kegiatanName?: StringFieldUpdateOperationsInput | string
    included?: BoolFieldUpdateOperationsInput | boolean
  }

  export type RkasItemCreateInput = {
    id?: string
    urutan: number
    noUrut: number
    kodeRekening: string
    uraian: string
    volumeText: string
    tarifHarga: number
    jumlah: number
    excluded?: boolean
    rkasProgram: RkasProgramCreateNestedOneWithoutItemsInput
  }

  export type RkasItemUncheckedCreateInput = {
    id?: string
    rkasProgramId: string
    urutan: number
    noUrut: number
    kodeRekening: string
    uraian: string
    volumeText: string
    tarifHarga: number
    jumlah: number
    excluded?: boolean
  }

  export type RkasItemUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    urutan?: IntFieldUpdateOperationsInput | number
    noUrut?: IntFieldUpdateOperationsInput | number
    kodeRekening?: StringFieldUpdateOperationsInput | string
    uraian?: StringFieldUpdateOperationsInput | string
    volumeText?: StringFieldUpdateOperationsInput | string
    tarifHarga?: IntFieldUpdateOperationsInput | number
    jumlah?: IntFieldUpdateOperationsInput | number
    excluded?: BoolFieldUpdateOperationsInput | boolean
    rkasProgram?: RkasProgramUpdateOneRequiredWithoutItemsNestedInput
  }

  export type RkasItemUncheckedUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    rkasProgramId?: StringFieldUpdateOperationsInput | string
    urutan?: IntFieldUpdateOperationsInput | number
    noUrut?: IntFieldUpdateOperationsInput | number
    kodeRekening?: StringFieldUpdateOperationsInput | string
    uraian?: StringFieldUpdateOperationsInput | string
    volumeText?: StringFieldUpdateOperationsInput | string
    tarifHarga?: IntFieldUpdateOperationsInput | number
    jumlah?: IntFieldUpdateOperationsInput | number
    excluded?: BoolFieldUpdateOperationsInput | boolean
  }

  export type RkasItemCreateManyInput = {
    id?: string
    rkasProgramId: string
    urutan: number
    noUrut: number
    kodeRekening: string
    uraian: string
    volumeText: string
    tarifHarga: number
    jumlah: number
    excluded?: boolean
  }

  export type RkasItemUpdateManyMutationInput = {
    id?: StringFieldUpdateOperationsInput | string
    urutan?: IntFieldUpdateOperationsInput | number
    noUrut?: IntFieldUpdateOperationsInput | number
    kodeRekening?: StringFieldUpdateOperationsInput | string
    uraian?: StringFieldUpdateOperationsInput | string
    volumeText?: StringFieldUpdateOperationsInput | string
    tarifHarga?: IntFieldUpdateOperationsInput | number
    jumlah?: IntFieldUpdateOperationsInput | number
    excluded?: BoolFieldUpdateOperationsInput | boolean
  }

  export type RkasItemUncheckedUpdateManyInput = {
    id?: StringFieldUpdateOperationsInput | string
    rkasProgramId?: StringFieldUpdateOperationsInput | string
    urutan?: IntFieldUpdateOperationsInput | number
    noUrut?: IntFieldUpdateOperationsInput | number
    kodeRekening?: StringFieldUpdateOperationsInput | string
    uraian?: StringFieldUpdateOperationsInput | string
    volumeText?: StringFieldUpdateOperationsInput | string
    tarifHarga?: IntFieldUpdateOperationsInput | number
    jumlah?: IntFieldUpdateOperationsInput | number
    excluded?: BoolFieldUpdateOperationsInput | boolean
  }

  export type InstrumenBospCreateInput = {
    id?: string
    year: number
    tahap: number
    jenisSatuan?: string
    statusSatuan?: string
    kelurahan?: string
    kecamatan?: string
    jenisDanaBosp?: string
    skNomor?: string
    skTanggal?: string
    kepalaName?: string
    bendaharaName?: string
    komiteName?: string
    adaBku?: boolean
    adaBukuPembantuKas?: boolean
    adaBukuPembantuPajak?: boolean
    adaBukuPembantuBank?: boolean
    adaLaporanRealisasi?: boolean
    totalAlokasiTahunan?: number
    saldoAwalOverride?: number | null
    operasionalOverride?: number | null
    honorSesuaiRkas?: boolean
    honorBuktiLengkap?: boolean
    honorPenerimaSesuai?: boolean
    metodePengadaanBuku?: string
    metodePengadaanLain?: string
    belanjaModalJson?: string
    pemeliharaanJson?: string
    bukuOverrideJson?: string
    tanggalDokumen?: string
    createdAt?: Date | string
    updatedAt?: Date | string
    school: SchoolCreateNestedOneWithoutInstrumenBospInput
  }

  export type InstrumenBospUncheckedCreateInput = {
    id?: string
    schoolId: string
    year: number
    tahap: number
    jenisSatuan?: string
    statusSatuan?: string
    kelurahan?: string
    kecamatan?: string
    jenisDanaBosp?: string
    skNomor?: string
    skTanggal?: string
    kepalaName?: string
    bendaharaName?: string
    komiteName?: string
    adaBku?: boolean
    adaBukuPembantuKas?: boolean
    adaBukuPembantuPajak?: boolean
    adaBukuPembantuBank?: boolean
    adaLaporanRealisasi?: boolean
    totalAlokasiTahunan?: number
    saldoAwalOverride?: number | null
    operasionalOverride?: number | null
    honorSesuaiRkas?: boolean
    honorBuktiLengkap?: boolean
    honorPenerimaSesuai?: boolean
    metodePengadaanBuku?: string
    metodePengadaanLain?: string
    belanjaModalJson?: string
    pemeliharaanJson?: string
    bukuOverrideJson?: string
    tanggalDokumen?: string
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type InstrumenBospUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    year?: IntFieldUpdateOperationsInput | number
    tahap?: IntFieldUpdateOperationsInput | number
    jenisSatuan?: StringFieldUpdateOperationsInput | string
    statusSatuan?: StringFieldUpdateOperationsInput | string
    kelurahan?: StringFieldUpdateOperationsInput | string
    kecamatan?: StringFieldUpdateOperationsInput | string
    jenisDanaBosp?: StringFieldUpdateOperationsInput | string
    skNomor?: StringFieldUpdateOperationsInput | string
    skTanggal?: StringFieldUpdateOperationsInput | string
    kepalaName?: StringFieldUpdateOperationsInput | string
    bendaharaName?: StringFieldUpdateOperationsInput | string
    komiteName?: StringFieldUpdateOperationsInput | string
    adaBku?: BoolFieldUpdateOperationsInput | boolean
    adaBukuPembantuKas?: BoolFieldUpdateOperationsInput | boolean
    adaBukuPembantuPajak?: BoolFieldUpdateOperationsInput | boolean
    adaBukuPembantuBank?: BoolFieldUpdateOperationsInput | boolean
    adaLaporanRealisasi?: BoolFieldUpdateOperationsInput | boolean
    totalAlokasiTahunan?: IntFieldUpdateOperationsInput | number
    saldoAwalOverride?: NullableIntFieldUpdateOperationsInput | number | null
    operasionalOverride?: NullableIntFieldUpdateOperationsInput | number | null
    honorSesuaiRkas?: BoolFieldUpdateOperationsInput | boolean
    honorBuktiLengkap?: BoolFieldUpdateOperationsInput | boolean
    honorPenerimaSesuai?: BoolFieldUpdateOperationsInput | boolean
    metodePengadaanBuku?: StringFieldUpdateOperationsInput | string
    metodePengadaanLain?: StringFieldUpdateOperationsInput | string
    belanjaModalJson?: StringFieldUpdateOperationsInput | string
    pemeliharaanJson?: StringFieldUpdateOperationsInput | string
    bukuOverrideJson?: StringFieldUpdateOperationsInput | string
    tanggalDokumen?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    school?: SchoolUpdateOneRequiredWithoutInstrumenBospNestedInput
  }

  export type InstrumenBospUncheckedUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    schoolId?: StringFieldUpdateOperationsInput | string
    year?: IntFieldUpdateOperationsInput | number
    tahap?: IntFieldUpdateOperationsInput | number
    jenisSatuan?: StringFieldUpdateOperationsInput | string
    statusSatuan?: StringFieldUpdateOperationsInput | string
    kelurahan?: StringFieldUpdateOperationsInput | string
    kecamatan?: StringFieldUpdateOperationsInput | string
    jenisDanaBosp?: StringFieldUpdateOperationsInput | string
    skNomor?: StringFieldUpdateOperationsInput | string
    skTanggal?: StringFieldUpdateOperationsInput | string
    kepalaName?: StringFieldUpdateOperationsInput | string
    bendaharaName?: StringFieldUpdateOperationsInput | string
    komiteName?: StringFieldUpdateOperationsInput | string
    adaBku?: BoolFieldUpdateOperationsInput | boolean
    adaBukuPembantuKas?: BoolFieldUpdateOperationsInput | boolean
    adaBukuPembantuPajak?: BoolFieldUpdateOperationsInput | boolean
    adaBukuPembantuBank?: BoolFieldUpdateOperationsInput | boolean
    adaLaporanRealisasi?: BoolFieldUpdateOperationsInput | boolean
    totalAlokasiTahunan?: IntFieldUpdateOperationsInput | number
    saldoAwalOverride?: NullableIntFieldUpdateOperationsInput | number | null
    operasionalOverride?: NullableIntFieldUpdateOperationsInput | number | null
    honorSesuaiRkas?: BoolFieldUpdateOperationsInput | boolean
    honorBuktiLengkap?: BoolFieldUpdateOperationsInput | boolean
    honorPenerimaSesuai?: BoolFieldUpdateOperationsInput | boolean
    metodePengadaanBuku?: StringFieldUpdateOperationsInput | string
    metodePengadaanLain?: StringFieldUpdateOperationsInput | string
    belanjaModalJson?: StringFieldUpdateOperationsInput | string
    pemeliharaanJson?: StringFieldUpdateOperationsInput | string
    bukuOverrideJson?: StringFieldUpdateOperationsInput | string
    tanggalDokumen?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type InstrumenBospCreateManyInput = {
    id?: string
    schoolId: string
    year: number
    tahap: number
    jenisSatuan?: string
    statusSatuan?: string
    kelurahan?: string
    kecamatan?: string
    jenisDanaBosp?: string
    skNomor?: string
    skTanggal?: string
    kepalaName?: string
    bendaharaName?: string
    komiteName?: string
    adaBku?: boolean
    adaBukuPembantuKas?: boolean
    adaBukuPembantuPajak?: boolean
    adaBukuPembantuBank?: boolean
    adaLaporanRealisasi?: boolean
    totalAlokasiTahunan?: number
    saldoAwalOverride?: number | null
    operasionalOverride?: number | null
    honorSesuaiRkas?: boolean
    honorBuktiLengkap?: boolean
    honorPenerimaSesuai?: boolean
    metodePengadaanBuku?: string
    metodePengadaanLain?: string
    belanjaModalJson?: string
    pemeliharaanJson?: string
    bukuOverrideJson?: string
    tanggalDokumen?: string
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type InstrumenBospUpdateManyMutationInput = {
    id?: StringFieldUpdateOperationsInput | string
    year?: IntFieldUpdateOperationsInput | number
    tahap?: IntFieldUpdateOperationsInput | number
    jenisSatuan?: StringFieldUpdateOperationsInput | string
    statusSatuan?: StringFieldUpdateOperationsInput | string
    kelurahan?: StringFieldUpdateOperationsInput | string
    kecamatan?: StringFieldUpdateOperationsInput | string
    jenisDanaBosp?: StringFieldUpdateOperationsInput | string
    skNomor?: StringFieldUpdateOperationsInput | string
    skTanggal?: StringFieldUpdateOperationsInput | string
    kepalaName?: StringFieldUpdateOperationsInput | string
    bendaharaName?: StringFieldUpdateOperationsInput | string
    komiteName?: StringFieldUpdateOperationsInput | string
    adaBku?: BoolFieldUpdateOperationsInput | boolean
    adaBukuPembantuKas?: BoolFieldUpdateOperationsInput | boolean
    adaBukuPembantuPajak?: BoolFieldUpdateOperationsInput | boolean
    adaBukuPembantuBank?: BoolFieldUpdateOperationsInput | boolean
    adaLaporanRealisasi?: BoolFieldUpdateOperationsInput | boolean
    totalAlokasiTahunan?: IntFieldUpdateOperationsInput | number
    saldoAwalOverride?: NullableIntFieldUpdateOperationsInput | number | null
    operasionalOverride?: NullableIntFieldUpdateOperationsInput | number | null
    honorSesuaiRkas?: BoolFieldUpdateOperationsInput | boolean
    honorBuktiLengkap?: BoolFieldUpdateOperationsInput | boolean
    honorPenerimaSesuai?: BoolFieldUpdateOperationsInput | boolean
    metodePengadaanBuku?: StringFieldUpdateOperationsInput | string
    metodePengadaanLain?: StringFieldUpdateOperationsInput | string
    belanjaModalJson?: StringFieldUpdateOperationsInput | string
    pemeliharaanJson?: StringFieldUpdateOperationsInput | string
    bukuOverrideJson?: StringFieldUpdateOperationsInput | string
    tanggalDokumen?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type InstrumenBospUncheckedUpdateManyInput = {
    id?: StringFieldUpdateOperationsInput | string
    schoolId?: StringFieldUpdateOperationsInput | string
    year?: IntFieldUpdateOperationsInput | number
    tahap?: IntFieldUpdateOperationsInput | number
    jenisSatuan?: StringFieldUpdateOperationsInput | string
    statusSatuan?: StringFieldUpdateOperationsInput | string
    kelurahan?: StringFieldUpdateOperationsInput | string
    kecamatan?: StringFieldUpdateOperationsInput | string
    jenisDanaBosp?: StringFieldUpdateOperationsInput | string
    skNomor?: StringFieldUpdateOperationsInput | string
    skTanggal?: StringFieldUpdateOperationsInput | string
    kepalaName?: StringFieldUpdateOperationsInput | string
    bendaharaName?: StringFieldUpdateOperationsInput | string
    komiteName?: StringFieldUpdateOperationsInput | string
    adaBku?: BoolFieldUpdateOperationsInput | boolean
    adaBukuPembantuKas?: BoolFieldUpdateOperationsInput | boolean
    adaBukuPembantuPajak?: BoolFieldUpdateOperationsInput | boolean
    adaBukuPembantuBank?: BoolFieldUpdateOperationsInput | boolean
    adaLaporanRealisasi?: BoolFieldUpdateOperationsInput | boolean
    totalAlokasiTahunan?: IntFieldUpdateOperationsInput | number
    saldoAwalOverride?: NullableIntFieldUpdateOperationsInput | number | null
    operasionalOverride?: NullableIntFieldUpdateOperationsInput | number | null
    honorSesuaiRkas?: BoolFieldUpdateOperationsInput | boolean
    honorBuktiLengkap?: BoolFieldUpdateOperationsInput | boolean
    honorPenerimaSesuai?: BoolFieldUpdateOperationsInput | boolean
    metodePengadaanBuku?: StringFieldUpdateOperationsInput | string
    metodePengadaanLain?: StringFieldUpdateOperationsInput | string
    belanjaModalJson?: StringFieldUpdateOperationsInput | string
    pemeliharaanJson?: StringFieldUpdateOperationsInput | string
    bukuOverrideJson?: StringFieldUpdateOperationsInput | string
    tanggalDokumen?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type StringFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel>
    in?: string[]
    notIn?: string[]
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    not?: NestedStringFilter<$PrismaModel> | string
  }

  export type StringNullableFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel> | null
    in?: string[] | null
    notIn?: string[] | null
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    not?: NestedStringNullableFilter<$PrismaModel> | string | null
  }

  export type DateTimeFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    in?: Date[] | string[]
    notIn?: Date[] | string[]
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeFilter<$PrismaModel> | Date | string
  }

  export type VendorRuleListRelationFilter = {
    every?: VendorRuleWhereInput
    some?: VendorRuleWhereInput
    none?: VendorRuleWhereInput
  }

  export type BKUImportListRelationFilter = {
    every?: BKUImportWhereInput
    some?: BKUImportWhereInput
    none?: BKUImportWhereInput
  }

  export type RkasImportListRelationFilter = {
    every?: RkasImportWhereInput
    some?: RkasImportWhereInput
    none?: RkasImportWhereInput
  }

  export type InstrumenBospListRelationFilter = {
    every?: InstrumenBospWhereInput
    some?: InstrumenBospWhereInput
    none?: InstrumenBospWhereInput
  }

  export type SortOrderInput = {
    sort: SortOrder
    nulls?: NullsOrder
  }

  export type VendorRuleOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type BKUImportOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type RkasImportOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type InstrumenBospOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type SchoolCountOrderByAggregateInput = {
    id?: SortOrder
    name?: SortOrder
    kopHeaderLine?: SortOrder
    npsn?: SortOrder
    address?: SortOrder
    contact?: SortOrder
    formatCode?: SortOrder
    kepalaName?: SortOrder
    kepalaJabatan?: SortOrder
    openingSentenceTemplate?: SortOrder
    atasDasarLine1?: SortOrder
    atasDasarLine2?: SortOrder
    honorRecapTitle?: SortOrder
    frazaListrikCustomerId?: SortOrder
    frazaInternetCustomerId?: SortOrder
    logoPath?: SortOrder
    regionalLogoPath?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type SchoolMaxOrderByAggregateInput = {
    id?: SortOrder
    name?: SortOrder
    kopHeaderLine?: SortOrder
    npsn?: SortOrder
    address?: SortOrder
    contact?: SortOrder
    formatCode?: SortOrder
    kepalaName?: SortOrder
    kepalaJabatan?: SortOrder
    openingSentenceTemplate?: SortOrder
    atasDasarLine1?: SortOrder
    atasDasarLine2?: SortOrder
    honorRecapTitle?: SortOrder
    frazaListrikCustomerId?: SortOrder
    frazaInternetCustomerId?: SortOrder
    logoPath?: SortOrder
    regionalLogoPath?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type SchoolMinOrderByAggregateInput = {
    id?: SortOrder
    name?: SortOrder
    kopHeaderLine?: SortOrder
    npsn?: SortOrder
    address?: SortOrder
    contact?: SortOrder
    formatCode?: SortOrder
    kepalaName?: SortOrder
    kepalaJabatan?: SortOrder
    openingSentenceTemplate?: SortOrder
    atasDasarLine1?: SortOrder
    atasDasarLine2?: SortOrder
    honorRecapTitle?: SortOrder
    frazaListrikCustomerId?: SortOrder
    frazaInternetCustomerId?: SortOrder
    logoPath?: SortOrder
    regionalLogoPath?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type StringWithAggregatesFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel>
    in?: string[]
    notIn?: string[]
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    not?: NestedStringWithAggregatesFilter<$PrismaModel> | string
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedStringFilter<$PrismaModel>
    _max?: NestedStringFilter<$PrismaModel>
  }

  export type StringNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel> | null
    in?: string[] | null
    notIn?: string[] | null
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    not?: NestedStringNullableWithAggregatesFilter<$PrismaModel> | string | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedStringNullableFilter<$PrismaModel>
    _max?: NestedStringNullableFilter<$PrismaModel>
  }

  export type DateTimeWithAggregatesFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    in?: Date[] | string[]
    notIn?: Date[] | string[]
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeWithAggregatesFilter<$PrismaModel> | Date | string
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedDateTimeFilter<$PrismaModel>
    _max?: NestedDateTimeFilter<$PrismaModel>
  }

  export type EnumVendorRuleFormatTypeFilter<$PrismaModel = never> = {
    equals?: $Enums.VendorRuleFormatType | EnumVendorRuleFormatTypeFieldRefInput<$PrismaModel>
    in?: $Enums.VendorRuleFormatType[]
    notIn?: $Enums.VendorRuleFormatType[]
    not?: NestedEnumVendorRuleFormatTypeFilter<$PrismaModel> | $Enums.VendorRuleFormatType
  }

  export type BoolFilter<$PrismaModel = never> = {
    equals?: boolean | BooleanFieldRefInput<$PrismaModel>
    not?: NestedBoolFilter<$PrismaModel> | boolean
  }

  export type IntFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel>
    in?: number[]
    notIn?: number[]
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntFilter<$PrismaModel> | number
  }

  export type SchoolScalarRelationFilter = {
    is?: SchoolWhereInput
    isNot?: SchoolWhereInput
  }

  export type BPUGroupListRelationFilter = {
    every?: BPUGroupWhereInput
    some?: BPUGroupWhereInput
    none?: BPUGroupWhereInput
  }

  export type BPUGroupOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type VendorRuleCountOrderByAggregateInput = {
    id?: SortOrder
    schoolId?: SortOrder
    keyword?: SortOrder
    recipient?: SortOrder
    paymentPrefix?: SortOrder
    matchKodeKegiatan?: SortOrder
    formatType?: SortOrder
    isHonor?: SortOrder
    isTransport?: SortOrder
    priority?: SortOrder
    isActive?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type VendorRuleAvgOrderByAggregateInput = {
    priority?: SortOrder
  }

  export type VendorRuleMaxOrderByAggregateInput = {
    id?: SortOrder
    schoolId?: SortOrder
    keyword?: SortOrder
    recipient?: SortOrder
    paymentPrefix?: SortOrder
    matchKodeKegiatan?: SortOrder
    formatType?: SortOrder
    isHonor?: SortOrder
    isTransport?: SortOrder
    priority?: SortOrder
    isActive?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type VendorRuleMinOrderByAggregateInput = {
    id?: SortOrder
    schoolId?: SortOrder
    keyword?: SortOrder
    recipient?: SortOrder
    paymentPrefix?: SortOrder
    matchKodeKegiatan?: SortOrder
    formatType?: SortOrder
    isHonor?: SortOrder
    isTransport?: SortOrder
    priority?: SortOrder
    isActive?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type VendorRuleSumOrderByAggregateInput = {
    priority?: SortOrder
  }

  export type EnumVendorRuleFormatTypeWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.VendorRuleFormatType | EnumVendorRuleFormatTypeFieldRefInput<$PrismaModel>
    in?: $Enums.VendorRuleFormatType[]
    notIn?: $Enums.VendorRuleFormatType[]
    not?: NestedEnumVendorRuleFormatTypeWithAggregatesFilter<$PrismaModel> | $Enums.VendorRuleFormatType
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedEnumVendorRuleFormatTypeFilter<$PrismaModel>
    _max?: NestedEnumVendorRuleFormatTypeFilter<$PrismaModel>
  }

  export type BoolWithAggregatesFilter<$PrismaModel = never> = {
    equals?: boolean | BooleanFieldRefInput<$PrismaModel>
    not?: NestedBoolWithAggregatesFilter<$PrismaModel> | boolean
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedBoolFilter<$PrismaModel>
    _max?: NestedBoolFilter<$PrismaModel>
  }

  export type IntWithAggregatesFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel>
    in?: number[]
    notIn?: number[]
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntWithAggregatesFilter<$PrismaModel> | number
    _count?: NestedIntFilter<$PrismaModel>
    _avg?: NestedFloatFilter<$PrismaModel>
    _sum?: NestedIntFilter<$PrismaModel>
    _min?: NestedIntFilter<$PrismaModel>
    _max?: NestedIntFilter<$PrismaModel>
  }

  export type EnumBKUImportStatusFilter<$PrismaModel = never> = {
    equals?: $Enums.BKUImportStatus | EnumBKUImportStatusFieldRefInput<$PrismaModel>
    in?: $Enums.BKUImportStatus[]
    notIn?: $Enums.BKUImportStatus[]
    not?: NestedEnumBKUImportStatusFilter<$PrismaModel> | $Enums.BKUImportStatus
  }

  export type BKURowListRelationFilter = {
    every?: BKURowWhereInput
    some?: BKURowWhereInput
    none?: BKURowWhereInput
  }

  export type BKURowOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type BKUImportCountOrderByAggregateInput = {
    id?: SortOrder
    schoolId?: SortOrder
    month?: SortOrder
    year?: SortOrder
    sourceFileName?: SortOrder
    status?: SortOrder
    importedAt?: SortOrder
  }

  export type BKUImportAvgOrderByAggregateInput = {
    month?: SortOrder
    year?: SortOrder
  }

  export type BKUImportMaxOrderByAggregateInput = {
    id?: SortOrder
    schoolId?: SortOrder
    month?: SortOrder
    year?: SortOrder
    sourceFileName?: SortOrder
    status?: SortOrder
    importedAt?: SortOrder
  }

  export type BKUImportMinOrderByAggregateInput = {
    id?: SortOrder
    schoolId?: SortOrder
    month?: SortOrder
    year?: SortOrder
    sourceFileName?: SortOrder
    status?: SortOrder
    importedAt?: SortOrder
  }

  export type BKUImportSumOrderByAggregateInput = {
    month?: SortOrder
    year?: SortOrder
  }

  export type EnumBKUImportStatusWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.BKUImportStatus | EnumBKUImportStatusFieldRefInput<$PrismaModel>
    in?: $Enums.BKUImportStatus[]
    notIn?: $Enums.BKUImportStatus[]
    not?: NestedEnumBKUImportStatusWithAggregatesFilter<$PrismaModel> | $Enums.BKUImportStatus
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedEnumBKUImportStatusFilter<$PrismaModel>
    _max?: NestedEnumBKUImportStatusFilter<$PrismaModel>
  }

  export type IntNullableFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel> | null
    in?: number[] | null
    notIn?: number[] | null
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntNullableFilter<$PrismaModel> | number | null
  }

  export type BKUImportScalarRelationFilter = {
    is?: BKUImportWhereInput
    isNot?: BKUImportWhereInput
  }

  export type BKURowCountOrderByAggregateInput = {
    id?: SortOrder
    bkuImportId?: SortOrder
    tanggal?: SortOrder
    kodeKegiatan?: SortOrder
    kodeRekening?: SortOrder
    bpuCode?: SortOrder
    bpuNumber?: SortOrder
    uraian?: SortOrder
    penerimaan?: SortOrder
    pengeluaran?: SortOrder
    saldo?: SortOrder
    pageIndex?: SortOrder
    createdAt?: SortOrder
  }

  export type BKURowAvgOrderByAggregateInput = {
    bpuNumber?: SortOrder
    penerimaan?: SortOrder
    pengeluaran?: SortOrder
    saldo?: SortOrder
    pageIndex?: SortOrder
  }

  export type BKURowMaxOrderByAggregateInput = {
    id?: SortOrder
    bkuImportId?: SortOrder
    tanggal?: SortOrder
    kodeKegiatan?: SortOrder
    kodeRekening?: SortOrder
    bpuCode?: SortOrder
    bpuNumber?: SortOrder
    uraian?: SortOrder
    penerimaan?: SortOrder
    pengeluaran?: SortOrder
    saldo?: SortOrder
    pageIndex?: SortOrder
    createdAt?: SortOrder
  }

  export type BKURowMinOrderByAggregateInput = {
    id?: SortOrder
    bkuImportId?: SortOrder
    tanggal?: SortOrder
    kodeKegiatan?: SortOrder
    kodeRekening?: SortOrder
    bpuCode?: SortOrder
    bpuNumber?: SortOrder
    uraian?: SortOrder
    penerimaan?: SortOrder
    pengeluaran?: SortOrder
    saldo?: SortOrder
    pageIndex?: SortOrder
    createdAt?: SortOrder
  }

  export type BKURowSumOrderByAggregateInput = {
    bpuNumber?: SortOrder
    penerimaan?: SortOrder
    pengeluaran?: SortOrder
    saldo?: SortOrder
    pageIndex?: SortOrder
  }

  export type IntNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel> | null
    in?: number[] | null
    notIn?: number[] | null
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntNullableWithAggregatesFilter<$PrismaModel> | number | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _avg?: NestedFloatNullableFilter<$PrismaModel>
    _sum?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedIntNullableFilter<$PrismaModel>
    _max?: NestedIntNullableFilter<$PrismaModel>
  }

  export type EnumBPUGroupStatusFilter<$PrismaModel = never> = {
    equals?: $Enums.BPUGroupStatus | EnumBPUGroupStatusFieldRefInput<$PrismaModel>
    in?: $Enums.BPUGroupStatus[]
    notIn?: $Enums.BPUGroupStatus[]
    not?: NestedEnumBPUGroupStatusFilter<$PrismaModel> | $Enums.BPUGroupStatus
  }

  export type VendorRuleNullableScalarRelationFilter = {
    is?: VendorRuleWhereInput | null
    isNot?: VendorRuleWhereInput | null
  }

  export type SPMDocumentNullableScalarRelationFilter = {
    is?: SPMDocumentWhereInput | null
    isNot?: SPMDocumentWhereInput | null
  }

  export type BPUGroupBkuImportIdBpuCodeCompoundUniqueInput = {
    bkuImportId: string
    bpuCode: string
  }

  export type BPUGroupCountOrderByAggregateInput = {
    id?: SortOrder
    bkuImportId?: SortOrder
    bpuCode?: SortOrder
    bpuNumber?: SortOrder
    tanggal?: SortOrder
    totalAmount?: SortOrder
    matchedVendorRuleId?: SortOrder
    overrideRecipient?: SortOrder
    overridePaymentFor?: SortOrder
    status?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type BPUGroupAvgOrderByAggregateInput = {
    bpuNumber?: SortOrder
    totalAmount?: SortOrder
  }

  export type BPUGroupMaxOrderByAggregateInput = {
    id?: SortOrder
    bkuImportId?: SortOrder
    bpuCode?: SortOrder
    bpuNumber?: SortOrder
    tanggal?: SortOrder
    totalAmount?: SortOrder
    matchedVendorRuleId?: SortOrder
    overrideRecipient?: SortOrder
    overridePaymentFor?: SortOrder
    status?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type BPUGroupMinOrderByAggregateInput = {
    id?: SortOrder
    bkuImportId?: SortOrder
    bpuCode?: SortOrder
    bpuNumber?: SortOrder
    tanggal?: SortOrder
    totalAmount?: SortOrder
    matchedVendorRuleId?: SortOrder
    overrideRecipient?: SortOrder
    overridePaymentFor?: SortOrder
    status?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type BPUGroupSumOrderByAggregateInput = {
    bpuNumber?: SortOrder
    totalAmount?: SortOrder
  }

  export type EnumBPUGroupStatusWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.BPUGroupStatus | EnumBPUGroupStatusFieldRefInput<$PrismaModel>
    in?: $Enums.BPUGroupStatus[]
    notIn?: $Enums.BPUGroupStatus[]
    not?: NestedEnumBPUGroupStatusWithAggregatesFilter<$PrismaModel> | $Enums.BPUGroupStatus
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedEnumBPUGroupStatusFilter<$PrismaModel>
    _max?: NestedEnumBPUGroupStatusFilter<$PrismaModel>
  }

  export type BPUGroupScalarRelationFilter = {
    is?: BPUGroupWhereInput
    isNot?: BPUGroupWhereInput
  }

  export type SPMDocumentCountOrderByAggregateInput = {
    id?: SortOrder
    bpuGroupId?: SortOrder
    nomorSurat?: SortOrder
    recipient?: SortOrder
    amount?: SortOrder
    terbilang?: SortOrder
    paymentFor?: SortOrder
    filePath?: SortOrder
    generatedAt?: SortOrder
  }

  export type SPMDocumentAvgOrderByAggregateInput = {
    amount?: SortOrder
  }

  export type SPMDocumentMaxOrderByAggregateInput = {
    id?: SortOrder
    bpuGroupId?: SortOrder
    nomorSurat?: SortOrder
    recipient?: SortOrder
    amount?: SortOrder
    terbilang?: SortOrder
    paymentFor?: SortOrder
    filePath?: SortOrder
    generatedAt?: SortOrder
  }

  export type SPMDocumentMinOrderByAggregateInput = {
    id?: SortOrder
    bpuGroupId?: SortOrder
    nomorSurat?: SortOrder
    recipient?: SortOrder
    amount?: SortOrder
    terbilang?: SortOrder
    paymentFor?: SortOrder
    filePath?: SortOrder
    generatedAt?: SortOrder
  }

  export type SPMDocumentSumOrderByAggregateInput = {
    amount?: SortOrder
  }

  export type RkasProgramListRelationFilter = {
    every?: RkasProgramWhereInput
    some?: RkasProgramWhereInput
    none?: RkasProgramWhereInput
  }

  export type RkasProgramOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type RkasImportCountOrderByAggregateInput = {
    id?: SortOrder
    schoolId?: SortOrder
    month?: SortOrder
    year?: SortOrder
    sourceFileName?: SortOrder
    sourceSchoolName?: SortOrder
    npsn?: SortOrder
    namaPelaksana?: SortOrder
    programLabel?: SortOrder
    namaKegiatan?: SortOrder
    sumberDana?: SortOrder
    pekerjaanLabel?: SortOrder
    kepalaName?: SortOrder
    bendaharaName?: SortOrder
    importedAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type RkasImportAvgOrderByAggregateInput = {
    month?: SortOrder
    year?: SortOrder
  }

  export type RkasImportMaxOrderByAggregateInput = {
    id?: SortOrder
    schoolId?: SortOrder
    month?: SortOrder
    year?: SortOrder
    sourceFileName?: SortOrder
    sourceSchoolName?: SortOrder
    npsn?: SortOrder
    namaPelaksana?: SortOrder
    programLabel?: SortOrder
    namaKegiatan?: SortOrder
    sumberDana?: SortOrder
    pekerjaanLabel?: SortOrder
    kepalaName?: SortOrder
    bendaharaName?: SortOrder
    importedAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type RkasImportMinOrderByAggregateInput = {
    id?: SortOrder
    schoolId?: SortOrder
    month?: SortOrder
    year?: SortOrder
    sourceFileName?: SortOrder
    sourceSchoolName?: SortOrder
    npsn?: SortOrder
    namaPelaksana?: SortOrder
    programLabel?: SortOrder
    namaKegiatan?: SortOrder
    sumberDana?: SortOrder
    pekerjaanLabel?: SortOrder
    kepalaName?: SortOrder
    bendaharaName?: SortOrder
    importedAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type RkasImportSumOrderByAggregateInput = {
    month?: SortOrder
    year?: SortOrder
  }

  export type RkasImportScalarRelationFilter = {
    is?: RkasImportWhereInput
    isNot?: RkasImportWhereInput
  }

  export type RkasItemListRelationFilter = {
    every?: RkasItemWhereInput
    some?: RkasItemWhereInput
    none?: RkasItemWhereInput
  }

  export type RkasItemOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type RkasProgramCountOrderByAggregateInput = {
    id?: SortOrder
    rkasImportId?: SortOrder
    urutan?: SortOrder
    kodeProgram?: SortOrder
    nama?: SortOrder
    standarName?: SortOrder
    kegiatanName?: SortOrder
    included?: SortOrder
  }

  export type RkasProgramAvgOrderByAggregateInput = {
    urutan?: SortOrder
  }

  export type RkasProgramMaxOrderByAggregateInput = {
    id?: SortOrder
    rkasImportId?: SortOrder
    urutan?: SortOrder
    kodeProgram?: SortOrder
    nama?: SortOrder
    standarName?: SortOrder
    kegiatanName?: SortOrder
    included?: SortOrder
  }

  export type RkasProgramMinOrderByAggregateInput = {
    id?: SortOrder
    rkasImportId?: SortOrder
    urutan?: SortOrder
    kodeProgram?: SortOrder
    nama?: SortOrder
    standarName?: SortOrder
    kegiatanName?: SortOrder
    included?: SortOrder
  }

  export type RkasProgramSumOrderByAggregateInput = {
    urutan?: SortOrder
  }

  export type RkasProgramScalarRelationFilter = {
    is?: RkasProgramWhereInput
    isNot?: RkasProgramWhereInput
  }

  export type RkasItemCountOrderByAggregateInput = {
    id?: SortOrder
    rkasProgramId?: SortOrder
    urutan?: SortOrder
    noUrut?: SortOrder
    kodeRekening?: SortOrder
    uraian?: SortOrder
    volumeText?: SortOrder
    tarifHarga?: SortOrder
    jumlah?: SortOrder
    excluded?: SortOrder
  }

  export type RkasItemAvgOrderByAggregateInput = {
    urutan?: SortOrder
    noUrut?: SortOrder
    tarifHarga?: SortOrder
    jumlah?: SortOrder
  }

  export type RkasItemMaxOrderByAggregateInput = {
    id?: SortOrder
    rkasProgramId?: SortOrder
    urutan?: SortOrder
    noUrut?: SortOrder
    kodeRekening?: SortOrder
    uraian?: SortOrder
    volumeText?: SortOrder
    tarifHarga?: SortOrder
    jumlah?: SortOrder
    excluded?: SortOrder
  }

  export type RkasItemMinOrderByAggregateInput = {
    id?: SortOrder
    rkasProgramId?: SortOrder
    urutan?: SortOrder
    noUrut?: SortOrder
    kodeRekening?: SortOrder
    uraian?: SortOrder
    volumeText?: SortOrder
    tarifHarga?: SortOrder
    jumlah?: SortOrder
    excluded?: SortOrder
  }

  export type RkasItemSumOrderByAggregateInput = {
    urutan?: SortOrder
    noUrut?: SortOrder
    tarifHarga?: SortOrder
    jumlah?: SortOrder
  }

  export type InstrumenBospSchoolIdYearTahapCompoundUniqueInput = {
    schoolId: string
    year: number
    tahap: number
  }

  export type InstrumenBospCountOrderByAggregateInput = {
    id?: SortOrder
    schoolId?: SortOrder
    year?: SortOrder
    tahap?: SortOrder
    jenisSatuan?: SortOrder
    statusSatuan?: SortOrder
    kelurahan?: SortOrder
    kecamatan?: SortOrder
    jenisDanaBosp?: SortOrder
    skNomor?: SortOrder
    skTanggal?: SortOrder
    kepalaName?: SortOrder
    bendaharaName?: SortOrder
    komiteName?: SortOrder
    adaBku?: SortOrder
    adaBukuPembantuKas?: SortOrder
    adaBukuPembantuPajak?: SortOrder
    adaBukuPembantuBank?: SortOrder
    adaLaporanRealisasi?: SortOrder
    totalAlokasiTahunan?: SortOrder
    saldoAwalOverride?: SortOrder
    operasionalOverride?: SortOrder
    honorSesuaiRkas?: SortOrder
    honorBuktiLengkap?: SortOrder
    honorPenerimaSesuai?: SortOrder
    metodePengadaanBuku?: SortOrder
    metodePengadaanLain?: SortOrder
    belanjaModalJson?: SortOrder
    pemeliharaanJson?: SortOrder
    bukuOverrideJson?: SortOrder
    tanggalDokumen?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type InstrumenBospAvgOrderByAggregateInput = {
    year?: SortOrder
    tahap?: SortOrder
    totalAlokasiTahunan?: SortOrder
    saldoAwalOverride?: SortOrder
    operasionalOverride?: SortOrder
  }

  export type InstrumenBospMaxOrderByAggregateInput = {
    id?: SortOrder
    schoolId?: SortOrder
    year?: SortOrder
    tahap?: SortOrder
    jenisSatuan?: SortOrder
    statusSatuan?: SortOrder
    kelurahan?: SortOrder
    kecamatan?: SortOrder
    jenisDanaBosp?: SortOrder
    skNomor?: SortOrder
    skTanggal?: SortOrder
    kepalaName?: SortOrder
    bendaharaName?: SortOrder
    komiteName?: SortOrder
    adaBku?: SortOrder
    adaBukuPembantuKas?: SortOrder
    adaBukuPembantuPajak?: SortOrder
    adaBukuPembantuBank?: SortOrder
    adaLaporanRealisasi?: SortOrder
    totalAlokasiTahunan?: SortOrder
    saldoAwalOverride?: SortOrder
    operasionalOverride?: SortOrder
    honorSesuaiRkas?: SortOrder
    honorBuktiLengkap?: SortOrder
    honorPenerimaSesuai?: SortOrder
    metodePengadaanBuku?: SortOrder
    metodePengadaanLain?: SortOrder
    belanjaModalJson?: SortOrder
    pemeliharaanJson?: SortOrder
    bukuOverrideJson?: SortOrder
    tanggalDokumen?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type InstrumenBospMinOrderByAggregateInput = {
    id?: SortOrder
    schoolId?: SortOrder
    year?: SortOrder
    tahap?: SortOrder
    jenisSatuan?: SortOrder
    statusSatuan?: SortOrder
    kelurahan?: SortOrder
    kecamatan?: SortOrder
    jenisDanaBosp?: SortOrder
    skNomor?: SortOrder
    skTanggal?: SortOrder
    kepalaName?: SortOrder
    bendaharaName?: SortOrder
    komiteName?: SortOrder
    adaBku?: SortOrder
    adaBukuPembantuKas?: SortOrder
    adaBukuPembantuPajak?: SortOrder
    adaBukuPembantuBank?: SortOrder
    adaLaporanRealisasi?: SortOrder
    totalAlokasiTahunan?: SortOrder
    saldoAwalOverride?: SortOrder
    operasionalOverride?: SortOrder
    honorSesuaiRkas?: SortOrder
    honorBuktiLengkap?: SortOrder
    honorPenerimaSesuai?: SortOrder
    metodePengadaanBuku?: SortOrder
    metodePengadaanLain?: SortOrder
    belanjaModalJson?: SortOrder
    pemeliharaanJson?: SortOrder
    bukuOverrideJson?: SortOrder
    tanggalDokumen?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type InstrumenBospSumOrderByAggregateInput = {
    year?: SortOrder
    tahap?: SortOrder
    totalAlokasiTahunan?: SortOrder
    saldoAwalOverride?: SortOrder
    operasionalOverride?: SortOrder
  }

  export type VendorRuleCreateNestedManyWithoutSchoolInput = {
    create?: XOR<VendorRuleCreateWithoutSchoolInput, VendorRuleUncheckedCreateWithoutSchoolInput> | VendorRuleCreateWithoutSchoolInput[] | VendorRuleUncheckedCreateWithoutSchoolInput[]
    connectOrCreate?: VendorRuleCreateOrConnectWithoutSchoolInput | VendorRuleCreateOrConnectWithoutSchoolInput[]
    createMany?: VendorRuleCreateManySchoolInputEnvelope
    connect?: VendorRuleWhereUniqueInput | VendorRuleWhereUniqueInput[]
  }

  export type BKUImportCreateNestedManyWithoutSchoolInput = {
    create?: XOR<BKUImportCreateWithoutSchoolInput, BKUImportUncheckedCreateWithoutSchoolInput> | BKUImportCreateWithoutSchoolInput[] | BKUImportUncheckedCreateWithoutSchoolInput[]
    connectOrCreate?: BKUImportCreateOrConnectWithoutSchoolInput | BKUImportCreateOrConnectWithoutSchoolInput[]
    createMany?: BKUImportCreateManySchoolInputEnvelope
    connect?: BKUImportWhereUniqueInput | BKUImportWhereUniqueInput[]
  }

  export type RkasImportCreateNestedManyWithoutSchoolInput = {
    create?: XOR<RkasImportCreateWithoutSchoolInput, RkasImportUncheckedCreateWithoutSchoolInput> | RkasImportCreateWithoutSchoolInput[] | RkasImportUncheckedCreateWithoutSchoolInput[]
    connectOrCreate?: RkasImportCreateOrConnectWithoutSchoolInput | RkasImportCreateOrConnectWithoutSchoolInput[]
    createMany?: RkasImportCreateManySchoolInputEnvelope
    connect?: RkasImportWhereUniqueInput | RkasImportWhereUniqueInput[]
  }

  export type InstrumenBospCreateNestedManyWithoutSchoolInput = {
    create?: XOR<InstrumenBospCreateWithoutSchoolInput, InstrumenBospUncheckedCreateWithoutSchoolInput> | InstrumenBospCreateWithoutSchoolInput[] | InstrumenBospUncheckedCreateWithoutSchoolInput[]
    connectOrCreate?: InstrumenBospCreateOrConnectWithoutSchoolInput | InstrumenBospCreateOrConnectWithoutSchoolInput[]
    createMany?: InstrumenBospCreateManySchoolInputEnvelope
    connect?: InstrumenBospWhereUniqueInput | InstrumenBospWhereUniqueInput[]
  }

  export type VendorRuleUncheckedCreateNestedManyWithoutSchoolInput = {
    create?: XOR<VendorRuleCreateWithoutSchoolInput, VendorRuleUncheckedCreateWithoutSchoolInput> | VendorRuleCreateWithoutSchoolInput[] | VendorRuleUncheckedCreateWithoutSchoolInput[]
    connectOrCreate?: VendorRuleCreateOrConnectWithoutSchoolInput | VendorRuleCreateOrConnectWithoutSchoolInput[]
    createMany?: VendorRuleCreateManySchoolInputEnvelope
    connect?: VendorRuleWhereUniqueInput | VendorRuleWhereUniqueInput[]
  }

  export type BKUImportUncheckedCreateNestedManyWithoutSchoolInput = {
    create?: XOR<BKUImportCreateWithoutSchoolInput, BKUImportUncheckedCreateWithoutSchoolInput> | BKUImportCreateWithoutSchoolInput[] | BKUImportUncheckedCreateWithoutSchoolInput[]
    connectOrCreate?: BKUImportCreateOrConnectWithoutSchoolInput | BKUImportCreateOrConnectWithoutSchoolInput[]
    createMany?: BKUImportCreateManySchoolInputEnvelope
    connect?: BKUImportWhereUniqueInput | BKUImportWhereUniqueInput[]
  }

  export type RkasImportUncheckedCreateNestedManyWithoutSchoolInput = {
    create?: XOR<RkasImportCreateWithoutSchoolInput, RkasImportUncheckedCreateWithoutSchoolInput> | RkasImportCreateWithoutSchoolInput[] | RkasImportUncheckedCreateWithoutSchoolInput[]
    connectOrCreate?: RkasImportCreateOrConnectWithoutSchoolInput | RkasImportCreateOrConnectWithoutSchoolInput[]
    createMany?: RkasImportCreateManySchoolInputEnvelope
    connect?: RkasImportWhereUniqueInput | RkasImportWhereUniqueInput[]
  }

  export type InstrumenBospUncheckedCreateNestedManyWithoutSchoolInput = {
    create?: XOR<InstrumenBospCreateWithoutSchoolInput, InstrumenBospUncheckedCreateWithoutSchoolInput> | InstrumenBospCreateWithoutSchoolInput[] | InstrumenBospUncheckedCreateWithoutSchoolInput[]
    connectOrCreate?: InstrumenBospCreateOrConnectWithoutSchoolInput | InstrumenBospCreateOrConnectWithoutSchoolInput[]
    createMany?: InstrumenBospCreateManySchoolInputEnvelope
    connect?: InstrumenBospWhereUniqueInput | InstrumenBospWhereUniqueInput[]
  }

  export type StringFieldUpdateOperationsInput = {
    set?: string
  }

  export type NullableStringFieldUpdateOperationsInput = {
    set?: string | null
  }

  export type DateTimeFieldUpdateOperationsInput = {
    set?: Date | string
  }

  export type VendorRuleUpdateManyWithoutSchoolNestedInput = {
    create?: XOR<VendorRuleCreateWithoutSchoolInput, VendorRuleUncheckedCreateWithoutSchoolInput> | VendorRuleCreateWithoutSchoolInput[] | VendorRuleUncheckedCreateWithoutSchoolInput[]
    connectOrCreate?: VendorRuleCreateOrConnectWithoutSchoolInput | VendorRuleCreateOrConnectWithoutSchoolInput[]
    upsert?: VendorRuleUpsertWithWhereUniqueWithoutSchoolInput | VendorRuleUpsertWithWhereUniqueWithoutSchoolInput[]
    createMany?: VendorRuleCreateManySchoolInputEnvelope
    set?: VendorRuleWhereUniqueInput | VendorRuleWhereUniqueInput[]
    disconnect?: VendorRuleWhereUniqueInput | VendorRuleWhereUniqueInput[]
    delete?: VendorRuleWhereUniqueInput | VendorRuleWhereUniqueInput[]
    connect?: VendorRuleWhereUniqueInput | VendorRuleWhereUniqueInput[]
    update?: VendorRuleUpdateWithWhereUniqueWithoutSchoolInput | VendorRuleUpdateWithWhereUniqueWithoutSchoolInput[]
    updateMany?: VendorRuleUpdateManyWithWhereWithoutSchoolInput | VendorRuleUpdateManyWithWhereWithoutSchoolInput[]
    deleteMany?: VendorRuleScalarWhereInput | VendorRuleScalarWhereInput[]
  }

  export type BKUImportUpdateManyWithoutSchoolNestedInput = {
    create?: XOR<BKUImportCreateWithoutSchoolInput, BKUImportUncheckedCreateWithoutSchoolInput> | BKUImportCreateWithoutSchoolInput[] | BKUImportUncheckedCreateWithoutSchoolInput[]
    connectOrCreate?: BKUImportCreateOrConnectWithoutSchoolInput | BKUImportCreateOrConnectWithoutSchoolInput[]
    upsert?: BKUImportUpsertWithWhereUniqueWithoutSchoolInput | BKUImportUpsertWithWhereUniqueWithoutSchoolInput[]
    createMany?: BKUImportCreateManySchoolInputEnvelope
    set?: BKUImportWhereUniqueInput | BKUImportWhereUniqueInput[]
    disconnect?: BKUImportWhereUniqueInput | BKUImportWhereUniqueInput[]
    delete?: BKUImportWhereUniqueInput | BKUImportWhereUniqueInput[]
    connect?: BKUImportWhereUniqueInput | BKUImportWhereUniqueInput[]
    update?: BKUImportUpdateWithWhereUniqueWithoutSchoolInput | BKUImportUpdateWithWhereUniqueWithoutSchoolInput[]
    updateMany?: BKUImportUpdateManyWithWhereWithoutSchoolInput | BKUImportUpdateManyWithWhereWithoutSchoolInput[]
    deleteMany?: BKUImportScalarWhereInput | BKUImportScalarWhereInput[]
  }

  export type RkasImportUpdateManyWithoutSchoolNestedInput = {
    create?: XOR<RkasImportCreateWithoutSchoolInput, RkasImportUncheckedCreateWithoutSchoolInput> | RkasImportCreateWithoutSchoolInput[] | RkasImportUncheckedCreateWithoutSchoolInput[]
    connectOrCreate?: RkasImportCreateOrConnectWithoutSchoolInput | RkasImportCreateOrConnectWithoutSchoolInput[]
    upsert?: RkasImportUpsertWithWhereUniqueWithoutSchoolInput | RkasImportUpsertWithWhereUniqueWithoutSchoolInput[]
    createMany?: RkasImportCreateManySchoolInputEnvelope
    set?: RkasImportWhereUniqueInput | RkasImportWhereUniqueInput[]
    disconnect?: RkasImportWhereUniqueInput | RkasImportWhereUniqueInput[]
    delete?: RkasImportWhereUniqueInput | RkasImportWhereUniqueInput[]
    connect?: RkasImportWhereUniqueInput | RkasImportWhereUniqueInput[]
    update?: RkasImportUpdateWithWhereUniqueWithoutSchoolInput | RkasImportUpdateWithWhereUniqueWithoutSchoolInput[]
    updateMany?: RkasImportUpdateManyWithWhereWithoutSchoolInput | RkasImportUpdateManyWithWhereWithoutSchoolInput[]
    deleteMany?: RkasImportScalarWhereInput | RkasImportScalarWhereInput[]
  }

  export type InstrumenBospUpdateManyWithoutSchoolNestedInput = {
    create?: XOR<InstrumenBospCreateWithoutSchoolInput, InstrumenBospUncheckedCreateWithoutSchoolInput> | InstrumenBospCreateWithoutSchoolInput[] | InstrumenBospUncheckedCreateWithoutSchoolInput[]
    connectOrCreate?: InstrumenBospCreateOrConnectWithoutSchoolInput | InstrumenBospCreateOrConnectWithoutSchoolInput[]
    upsert?: InstrumenBospUpsertWithWhereUniqueWithoutSchoolInput | InstrumenBospUpsertWithWhereUniqueWithoutSchoolInput[]
    createMany?: InstrumenBospCreateManySchoolInputEnvelope
    set?: InstrumenBospWhereUniqueInput | InstrumenBospWhereUniqueInput[]
    disconnect?: InstrumenBospWhereUniqueInput | InstrumenBospWhereUniqueInput[]
    delete?: InstrumenBospWhereUniqueInput | InstrumenBospWhereUniqueInput[]
    connect?: InstrumenBospWhereUniqueInput | InstrumenBospWhereUniqueInput[]
    update?: InstrumenBospUpdateWithWhereUniqueWithoutSchoolInput | InstrumenBospUpdateWithWhereUniqueWithoutSchoolInput[]
    updateMany?: InstrumenBospUpdateManyWithWhereWithoutSchoolInput | InstrumenBospUpdateManyWithWhereWithoutSchoolInput[]
    deleteMany?: InstrumenBospScalarWhereInput | InstrumenBospScalarWhereInput[]
  }

  export type VendorRuleUncheckedUpdateManyWithoutSchoolNestedInput = {
    create?: XOR<VendorRuleCreateWithoutSchoolInput, VendorRuleUncheckedCreateWithoutSchoolInput> | VendorRuleCreateWithoutSchoolInput[] | VendorRuleUncheckedCreateWithoutSchoolInput[]
    connectOrCreate?: VendorRuleCreateOrConnectWithoutSchoolInput | VendorRuleCreateOrConnectWithoutSchoolInput[]
    upsert?: VendorRuleUpsertWithWhereUniqueWithoutSchoolInput | VendorRuleUpsertWithWhereUniqueWithoutSchoolInput[]
    createMany?: VendorRuleCreateManySchoolInputEnvelope
    set?: VendorRuleWhereUniqueInput | VendorRuleWhereUniqueInput[]
    disconnect?: VendorRuleWhereUniqueInput | VendorRuleWhereUniqueInput[]
    delete?: VendorRuleWhereUniqueInput | VendorRuleWhereUniqueInput[]
    connect?: VendorRuleWhereUniqueInput | VendorRuleWhereUniqueInput[]
    update?: VendorRuleUpdateWithWhereUniqueWithoutSchoolInput | VendorRuleUpdateWithWhereUniqueWithoutSchoolInput[]
    updateMany?: VendorRuleUpdateManyWithWhereWithoutSchoolInput | VendorRuleUpdateManyWithWhereWithoutSchoolInput[]
    deleteMany?: VendorRuleScalarWhereInput | VendorRuleScalarWhereInput[]
  }

  export type BKUImportUncheckedUpdateManyWithoutSchoolNestedInput = {
    create?: XOR<BKUImportCreateWithoutSchoolInput, BKUImportUncheckedCreateWithoutSchoolInput> | BKUImportCreateWithoutSchoolInput[] | BKUImportUncheckedCreateWithoutSchoolInput[]
    connectOrCreate?: BKUImportCreateOrConnectWithoutSchoolInput | BKUImportCreateOrConnectWithoutSchoolInput[]
    upsert?: BKUImportUpsertWithWhereUniqueWithoutSchoolInput | BKUImportUpsertWithWhereUniqueWithoutSchoolInput[]
    createMany?: BKUImportCreateManySchoolInputEnvelope
    set?: BKUImportWhereUniqueInput | BKUImportWhereUniqueInput[]
    disconnect?: BKUImportWhereUniqueInput | BKUImportWhereUniqueInput[]
    delete?: BKUImportWhereUniqueInput | BKUImportWhereUniqueInput[]
    connect?: BKUImportWhereUniqueInput | BKUImportWhereUniqueInput[]
    update?: BKUImportUpdateWithWhereUniqueWithoutSchoolInput | BKUImportUpdateWithWhereUniqueWithoutSchoolInput[]
    updateMany?: BKUImportUpdateManyWithWhereWithoutSchoolInput | BKUImportUpdateManyWithWhereWithoutSchoolInput[]
    deleteMany?: BKUImportScalarWhereInput | BKUImportScalarWhereInput[]
  }

  export type RkasImportUncheckedUpdateManyWithoutSchoolNestedInput = {
    create?: XOR<RkasImportCreateWithoutSchoolInput, RkasImportUncheckedCreateWithoutSchoolInput> | RkasImportCreateWithoutSchoolInput[] | RkasImportUncheckedCreateWithoutSchoolInput[]
    connectOrCreate?: RkasImportCreateOrConnectWithoutSchoolInput | RkasImportCreateOrConnectWithoutSchoolInput[]
    upsert?: RkasImportUpsertWithWhereUniqueWithoutSchoolInput | RkasImportUpsertWithWhereUniqueWithoutSchoolInput[]
    createMany?: RkasImportCreateManySchoolInputEnvelope
    set?: RkasImportWhereUniqueInput | RkasImportWhereUniqueInput[]
    disconnect?: RkasImportWhereUniqueInput | RkasImportWhereUniqueInput[]
    delete?: RkasImportWhereUniqueInput | RkasImportWhereUniqueInput[]
    connect?: RkasImportWhereUniqueInput | RkasImportWhereUniqueInput[]
    update?: RkasImportUpdateWithWhereUniqueWithoutSchoolInput | RkasImportUpdateWithWhereUniqueWithoutSchoolInput[]
    updateMany?: RkasImportUpdateManyWithWhereWithoutSchoolInput | RkasImportUpdateManyWithWhereWithoutSchoolInput[]
    deleteMany?: RkasImportScalarWhereInput | RkasImportScalarWhereInput[]
  }

  export type InstrumenBospUncheckedUpdateManyWithoutSchoolNestedInput = {
    create?: XOR<InstrumenBospCreateWithoutSchoolInput, InstrumenBospUncheckedCreateWithoutSchoolInput> | InstrumenBospCreateWithoutSchoolInput[] | InstrumenBospUncheckedCreateWithoutSchoolInput[]
    connectOrCreate?: InstrumenBospCreateOrConnectWithoutSchoolInput | InstrumenBospCreateOrConnectWithoutSchoolInput[]
    upsert?: InstrumenBospUpsertWithWhereUniqueWithoutSchoolInput | InstrumenBospUpsertWithWhereUniqueWithoutSchoolInput[]
    createMany?: InstrumenBospCreateManySchoolInputEnvelope
    set?: InstrumenBospWhereUniqueInput | InstrumenBospWhereUniqueInput[]
    disconnect?: InstrumenBospWhereUniqueInput | InstrumenBospWhereUniqueInput[]
    delete?: InstrumenBospWhereUniqueInput | InstrumenBospWhereUniqueInput[]
    connect?: InstrumenBospWhereUniqueInput | InstrumenBospWhereUniqueInput[]
    update?: InstrumenBospUpdateWithWhereUniqueWithoutSchoolInput | InstrumenBospUpdateWithWhereUniqueWithoutSchoolInput[]
    updateMany?: InstrumenBospUpdateManyWithWhereWithoutSchoolInput | InstrumenBospUpdateManyWithWhereWithoutSchoolInput[]
    deleteMany?: InstrumenBospScalarWhereInput | InstrumenBospScalarWhereInput[]
  }

  export type SchoolCreateNestedOneWithoutVendorRulesInput = {
    create?: XOR<SchoolCreateWithoutVendorRulesInput, SchoolUncheckedCreateWithoutVendorRulesInput>
    connectOrCreate?: SchoolCreateOrConnectWithoutVendorRulesInput
    connect?: SchoolWhereUniqueInput
  }

  export type BPUGroupCreateNestedManyWithoutMatchedVendorRuleInput = {
    create?: XOR<BPUGroupCreateWithoutMatchedVendorRuleInput, BPUGroupUncheckedCreateWithoutMatchedVendorRuleInput> | BPUGroupCreateWithoutMatchedVendorRuleInput[] | BPUGroupUncheckedCreateWithoutMatchedVendorRuleInput[]
    connectOrCreate?: BPUGroupCreateOrConnectWithoutMatchedVendorRuleInput | BPUGroupCreateOrConnectWithoutMatchedVendorRuleInput[]
    createMany?: BPUGroupCreateManyMatchedVendorRuleInputEnvelope
    connect?: BPUGroupWhereUniqueInput | BPUGroupWhereUniqueInput[]
  }

  export type BPUGroupUncheckedCreateNestedManyWithoutMatchedVendorRuleInput = {
    create?: XOR<BPUGroupCreateWithoutMatchedVendorRuleInput, BPUGroupUncheckedCreateWithoutMatchedVendorRuleInput> | BPUGroupCreateWithoutMatchedVendorRuleInput[] | BPUGroupUncheckedCreateWithoutMatchedVendorRuleInput[]
    connectOrCreate?: BPUGroupCreateOrConnectWithoutMatchedVendorRuleInput | BPUGroupCreateOrConnectWithoutMatchedVendorRuleInput[]
    createMany?: BPUGroupCreateManyMatchedVendorRuleInputEnvelope
    connect?: BPUGroupWhereUniqueInput | BPUGroupWhereUniqueInput[]
  }

  export type EnumVendorRuleFormatTypeFieldUpdateOperationsInput = {
    set?: $Enums.VendorRuleFormatType
  }

  export type BoolFieldUpdateOperationsInput = {
    set?: boolean
  }

  export type IntFieldUpdateOperationsInput = {
    set?: number
    increment?: number
    decrement?: number
    multiply?: number
    divide?: number
  }

  export type SchoolUpdateOneRequiredWithoutVendorRulesNestedInput = {
    create?: XOR<SchoolCreateWithoutVendorRulesInput, SchoolUncheckedCreateWithoutVendorRulesInput>
    connectOrCreate?: SchoolCreateOrConnectWithoutVendorRulesInput
    upsert?: SchoolUpsertWithoutVendorRulesInput
    connect?: SchoolWhereUniqueInput
    update?: XOR<XOR<SchoolUpdateToOneWithWhereWithoutVendorRulesInput, SchoolUpdateWithoutVendorRulesInput>, SchoolUncheckedUpdateWithoutVendorRulesInput>
  }

  export type BPUGroupUpdateManyWithoutMatchedVendorRuleNestedInput = {
    create?: XOR<BPUGroupCreateWithoutMatchedVendorRuleInput, BPUGroupUncheckedCreateWithoutMatchedVendorRuleInput> | BPUGroupCreateWithoutMatchedVendorRuleInput[] | BPUGroupUncheckedCreateWithoutMatchedVendorRuleInput[]
    connectOrCreate?: BPUGroupCreateOrConnectWithoutMatchedVendorRuleInput | BPUGroupCreateOrConnectWithoutMatchedVendorRuleInput[]
    upsert?: BPUGroupUpsertWithWhereUniqueWithoutMatchedVendorRuleInput | BPUGroupUpsertWithWhereUniqueWithoutMatchedVendorRuleInput[]
    createMany?: BPUGroupCreateManyMatchedVendorRuleInputEnvelope
    set?: BPUGroupWhereUniqueInput | BPUGroupWhereUniqueInput[]
    disconnect?: BPUGroupWhereUniqueInput | BPUGroupWhereUniqueInput[]
    delete?: BPUGroupWhereUniqueInput | BPUGroupWhereUniqueInput[]
    connect?: BPUGroupWhereUniqueInput | BPUGroupWhereUniqueInput[]
    update?: BPUGroupUpdateWithWhereUniqueWithoutMatchedVendorRuleInput | BPUGroupUpdateWithWhereUniqueWithoutMatchedVendorRuleInput[]
    updateMany?: BPUGroupUpdateManyWithWhereWithoutMatchedVendorRuleInput | BPUGroupUpdateManyWithWhereWithoutMatchedVendorRuleInput[]
    deleteMany?: BPUGroupScalarWhereInput | BPUGroupScalarWhereInput[]
  }

  export type BPUGroupUncheckedUpdateManyWithoutMatchedVendorRuleNestedInput = {
    create?: XOR<BPUGroupCreateWithoutMatchedVendorRuleInput, BPUGroupUncheckedCreateWithoutMatchedVendorRuleInput> | BPUGroupCreateWithoutMatchedVendorRuleInput[] | BPUGroupUncheckedCreateWithoutMatchedVendorRuleInput[]
    connectOrCreate?: BPUGroupCreateOrConnectWithoutMatchedVendorRuleInput | BPUGroupCreateOrConnectWithoutMatchedVendorRuleInput[]
    upsert?: BPUGroupUpsertWithWhereUniqueWithoutMatchedVendorRuleInput | BPUGroupUpsertWithWhereUniqueWithoutMatchedVendorRuleInput[]
    createMany?: BPUGroupCreateManyMatchedVendorRuleInputEnvelope
    set?: BPUGroupWhereUniqueInput | BPUGroupWhereUniqueInput[]
    disconnect?: BPUGroupWhereUniqueInput | BPUGroupWhereUniqueInput[]
    delete?: BPUGroupWhereUniqueInput | BPUGroupWhereUniqueInput[]
    connect?: BPUGroupWhereUniqueInput | BPUGroupWhereUniqueInput[]
    update?: BPUGroupUpdateWithWhereUniqueWithoutMatchedVendorRuleInput | BPUGroupUpdateWithWhereUniqueWithoutMatchedVendorRuleInput[]
    updateMany?: BPUGroupUpdateManyWithWhereWithoutMatchedVendorRuleInput | BPUGroupUpdateManyWithWhereWithoutMatchedVendorRuleInput[]
    deleteMany?: BPUGroupScalarWhereInput | BPUGroupScalarWhereInput[]
  }

  export type SchoolCreateNestedOneWithoutBkuImportsInput = {
    create?: XOR<SchoolCreateWithoutBkuImportsInput, SchoolUncheckedCreateWithoutBkuImportsInput>
    connectOrCreate?: SchoolCreateOrConnectWithoutBkuImportsInput
    connect?: SchoolWhereUniqueInput
  }

  export type BKURowCreateNestedManyWithoutBkuImportInput = {
    create?: XOR<BKURowCreateWithoutBkuImportInput, BKURowUncheckedCreateWithoutBkuImportInput> | BKURowCreateWithoutBkuImportInput[] | BKURowUncheckedCreateWithoutBkuImportInput[]
    connectOrCreate?: BKURowCreateOrConnectWithoutBkuImportInput | BKURowCreateOrConnectWithoutBkuImportInput[]
    createMany?: BKURowCreateManyBkuImportInputEnvelope
    connect?: BKURowWhereUniqueInput | BKURowWhereUniqueInput[]
  }

  export type BPUGroupCreateNestedManyWithoutBkuImportInput = {
    create?: XOR<BPUGroupCreateWithoutBkuImportInput, BPUGroupUncheckedCreateWithoutBkuImportInput> | BPUGroupCreateWithoutBkuImportInput[] | BPUGroupUncheckedCreateWithoutBkuImportInput[]
    connectOrCreate?: BPUGroupCreateOrConnectWithoutBkuImportInput | BPUGroupCreateOrConnectWithoutBkuImportInput[]
    createMany?: BPUGroupCreateManyBkuImportInputEnvelope
    connect?: BPUGroupWhereUniqueInput | BPUGroupWhereUniqueInput[]
  }

  export type BKURowUncheckedCreateNestedManyWithoutBkuImportInput = {
    create?: XOR<BKURowCreateWithoutBkuImportInput, BKURowUncheckedCreateWithoutBkuImportInput> | BKURowCreateWithoutBkuImportInput[] | BKURowUncheckedCreateWithoutBkuImportInput[]
    connectOrCreate?: BKURowCreateOrConnectWithoutBkuImportInput | BKURowCreateOrConnectWithoutBkuImportInput[]
    createMany?: BKURowCreateManyBkuImportInputEnvelope
    connect?: BKURowWhereUniqueInput | BKURowWhereUniqueInput[]
  }

  export type BPUGroupUncheckedCreateNestedManyWithoutBkuImportInput = {
    create?: XOR<BPUGroupCreateWithoutBkuImportInput, BPUGroupUncheckedCreateWithoutBkuImportInput> | BPUGroupCreateWithoutBkuImportInput[] | BPUGroupUncheckedCreateWithoutBkuImportInput[]
    connectOrCreate?: BPUGroupCreateOrConnectWithoutBkuImportInput | BPUGroupCreateOrConnectWithoutBkuImportInput[]
    createMany?: BPUGroupCreateManyBkuImportInputEnvelope
    connect?: BPUGroupWhereUniqueInput | BPUGroupWhereUniqueInput[]
  }

  export type EnumBKUImportStatusFieldUpdateOperationsInput = {
    set?: $Enums.BKUImportStatus
  }

  export type SchoolUpdateOneRequiredWithoutBkuImportsNestedInput = {
    create?: XOR<SchoolCreateWithoutBkuImportsInput, SchoolUncheckedCreateWithoutBkuImportsInput>
    connectOrCreate?: SchoolCreateOrConnectWithoutBkuImportsInput
    upsert?: SchoolUpsertWithoutBkuImportsInput
    connect?: SchoolWhereUniqueInput
    update?: XOR<XOR<SchoolUpdateToOneWithWhereWithoutBkuImportsInput, SchoolUpdateWithoutBkuImportsInput>, SchoolUncheckedUpdateWithoutBkuImportsInput>
  }

  export type BKURowUpdateManyWithoutBkuImportNestedInput = {
    create?: XOR<BKURowCreateWithoutBkuImportInput, BKURowUncheckedCreateWithoutBkuImportInput> | BKURowCreateWithoutBkuImportInput[] | BKURowUncheckedCreateWithoutBkuImportInput[]
    connectOrCreate?: BKURowCreateOrConnectWithoutBkuImportInput | BKURowCreateOrConnectWithoutBkuImportInput[]
    upsert?: BKURowUpsertWithWhereUniqueWithoutBkuImportInput | BKURowUpsertWithWhereUniqueWithoutBkuImportInput[]
    createMany?: BKURowCreateManyBkuImportInputEnvelope
    set?: BKURowWhereUniqueInput | BKURowWhereUniqueInput[]
    disconnect?: BKURowWhereUniqueInput | BKURowWhereUniqueInput[]
    delete?: BKURowWhereUniqueInput | BKURowWhereUniqueInput[]
    connect?: BKURowWhereUniqueInput | BKURowWhereUniqueInput[]
    update?: BKURowUpdateWithWhereUniqueWithoutBkuImportInput | BKURowUpdateWithWhereUniqueWithoutBkuImportInput[]
    updateMany?: BKURowUpdateManyWithWhereWithoutBkuImportInput | BKURowUpdateManyWithWhereWithoutBkuImportInput[]
    deleteMany?: BKURowScalarWhereInput | BKURowScalarWhereInput[]
  }

  export type BPUGroupUpdateManyWithoutBkuImportNestedInput = {
    create?: XOR<BPUGroupCreateWithoutBkuImportInput, BPUGroupUncheckedCreateWithoutBkuImportInput> | BPUGroupCreateWithoutBkuImportInput[] | BPUGroupUncheckedCreateWithoutBkuImportInput[]
    connectOrCreate?: BPUGroupCreateOrConnectWithoutBkuImportInput | BPUGroupCreateOrConnectWithoutBkuImportInput[]
    upsert?: BPUGroupUpsertWithWhereUniqueWithoutBkuImportInput | BPUGroupUpsertWithWhereUniqueWithoutBkuImportInput[]
    createMany?: BPUGroupCreateManyBkuImportInputEnvelope
    set?: BPUGroupWhereUniqueInput | BPUGroupWhereUniqueInput[]
    disconnect?: BPUGroupWhereUniqueInput | BPUGroupWhereUniqueInput[]
    delete?: BPUGroupWhereUniqueInput | BPUGroupWhereUniqueInput[]
    connect?: BPUGroupWhereUniqueInput | BPUGroupWhereUniqueInput[]
    update?: BPUGroupUpdateWithWhereUniqueWithoutBkuImportInput | BPUGroupUpdateWithWhereUniqueWithoutBkuImportInput[]
    updateMany?: BPUGroupUpdateManyWithWhereWithoutBkuImportInput | BPUGroupUpdateManyWithWhereWithoutBkuImportInput[]
    deleteMany?: BPUGroupScalarWhereInput | BPUGroupScalarWhereInput[]
  }

  export type BKURowUncheckedUpdateManyWithoutBkuImportNestedInput = {
    create?: XOR<BKURowCreateWithoutBkuImportInput, BKURowUncheckedCreateWithoutBkuImportInput> | BKURowCreateWithoutBkuImportInput[] | BKURowUncheckedCreateWithoutBkuImportInput[]
    connectOrCreate?: BKURowCreateOrConnectWithoutBkuImportInput | BKURowCreateOrConnectWithoutBkuImportInput[]
    upsert?: BKURowUpsertWithWhereUniqueWithoutBkuImportInput | BKURowUpsertWithWhereUniqueWithoutBkuImportInput[]
    createMany?: BKURowCreateManyBkuImportInputEnvelope
    set?: BKURowWhereUniqueInput | BKURowWhereUniqueInput[]
    disconnect?: BKURowWhereUniqueInput | BKURowWhereUniqueInput[]
    delete?: BKURowWhereUniqueInput | BKURowWhereUniqueInput[]
    connect?: BKURowWhereUniqueInput | BKURowWhereUniqueInput[]
    update?: BKURowUpdateWithWhereUniqueWithoutBkuImportInput | BKURowUpdateWithWhereUniqueWithoutBkuImportInput[]
    updateMany?: BKURowUpdateManyWithWhereWithoutBkuImportInput | BKURowUpdateManyWithWhereWithoutBkuImportInput[]
    deleteMany?: BKURowScalarWhereInput | BKURowScalarWhereInput[]
  }

  export type BPUGroupUncheckedUpdateManyWithoutBkuImportNestedInput = {
    create?: XOR<BPUGroupCreateWithoutBkuImportInput, BPUGroupUncheckedCreateWithoutBkuImportInput> | BPUGroupCreateWithoutBkuImportInput[] | BPUGroupUncheckedCreateWithoutBkuImportInput[]
    connectOrCreate?: BPUGroupCreateOrConnectWithoutBkuImportInput | BPUGroupCreateOrConnectWithoutBkuImportInput[]
    upsert?: BPUGroupUpsertWithWhereUniqueWithoutBkuImportInput | BPUGroupUpsertWithWhereUniqueWithoutBkuImportInput[]
    createMany?: BPUGroupCreateManyBkuImportInputEnvelope
    set?: BPUGroupWhereUniqueInput | BPUGroupWhereUniqueInput[]
    disconnect?: BPUGroupWhereUniqueInput | BPUGroupWhereUniqueInput[]
    delete?: BPUGroupWhereUniqueInput | BPUGroupWhereUniqueInput[]
    connect?: BPUGroupWhereUniqueInput | BPUGroupWhereUniqueInput[]
    update?: BPUGroupUpdateWithWhereUniqueWithoutBkuImportInput | BPUGroupUpdateWithWhereUniqueWithoutBkuImportInput[]
    updateMany?: BPUGroupUpdateManyWithWhereWithoutBkuImportInput | BPUGroupUpdateManyWithWhereWithoutBkuImportInput[]
    deleteMany?: BPUGroupScalarWhereInput | BPUGroupScalarWhereInput[]
  }

  export type BKUImportCreateNestedOneWithoutRowsInput = {
    create?: XOR<BKUImportCreateWithoutRowsInput, BKUImportUncheckedCreateWithoutRowsInput>
    connectOrCreate?: BKUImportCreateOrConnectWithoutRowsInput
    connect?: BKUImportWhereUniqueInput
  }

  export type NullableIntFieldUpdateOperationsInput = {
    set?: number | null
    increment?: number
    decrement?: number
    multiply?: number
    divide?: number
  }

  export type BKUImportUpdateOneRequiredWithoutRowsNestedInput = {
    create?: XOR<BKUImportCreateWithoutRowsInput, BKUImportUncheckedCreateWithoutRowsInput>
    connectOrCreate?: BKUImportCreateOrConnectWithoutRowsInput
    upsert?: BKUImportUpsertWithoutRowsInput
    connect?: BKUImportWhereUniqueInput
    update?: XOR<XOR<BKUImportUpdateToOneWithWhereWithoutRowsInput, BKUImportUpdateWithoutRowsInput>, BKUImportUncheckedUpdateWithoutRowsInput>
  }

  export type BKUImportCreateNestedOneWithoutBpuGroupsInput = {
    create?: XOR<BKUImportCreateWithoutBpuGroupsInput, BKUImportUncheckedCreateWithoutBpuGroupsInput>
    connectOrCreate?: BKUImportCreateOrConnectWithoutBpuGroupsInput
    connect?: BKUImportWhereUniqueInput
  }

  export type VendorRuleCreateNestedOneWithoutBpuGroupsInput = {
    create?: XOR<VendorRuleCreateWithoutBpuGroupsInput, VendorRuleUncheckedCreateWithoutBpuGroupsInput>
    connectOrCreate?: VendorRuleCreateOrConnectWithoutBpuGroupsInput
    connect?: VendorRuleWhereUniqueInput
  }

  export type SPMDocumentCreateNestedOneWithoutBpuGroupInput = {
    create?: XOR<SPMDocumentCreateWithoutBpuGroupInput, SPMDocumentUncheckedCreateWithoutBpuGroupInput>
    connectOrCreate?: SPMDocumentCreateOrConnectWithoutBpuGroupInput
    connect?: SPMDocumentWhereUniqueInput
  }

  export type SPMDocumentUncheckedCreateNestedOneWithoutBpuGroupInput = {
    create?: XOR<SPMDocumentCreateWithoutBpuGroupInput, SPMDocumentUncheckedCreateWithoutBpuGroupInput>
    connectOrCreate?: SPMDocumentCreateOrConnectWithoutBpuGroupInput
    connect?: SPMDocumentWhereUniqueInput
  }

  export type EnumBPUGroupStatusFieldUpdateOperationsInput = {
    set?: $Enums.BPUGroupStatus
  }

  export type BKUImportUpdateOneRequiredWithoutBpuGroupsNestedInput = {
    create?: XOR<BKUImportCreateWithoutBpuGroupsInput, BKUImportUncheckedCreateWithoutBpuGroupsInput>
    connectOrCreate?: BKUImportCreateOrConnectWithoutBpuGroupsInput
    upsert?: BKUImportUpsertWithoutBpuGroupsInput
    connect?: BKUImportWhereUniqueInput
    update?: XOR<XOR<BKUImportUpdateToOneWithWhereWithoutBpuGroupsInput, BKUImportUpdateWithoutBpuGroupsInput>, BKUImportUncheckedUpdateWithoutBpuGroupsInput>
  }

  export type VendorRuleUpdateOneWithoutBpuGroupsNestedInput = {
    create?: XOR<VendorRuleCreateWithoutBpuGroupsInput, VendorRuleUncheckedCreateWithoutBpuGroupsInput>
    connectOrCreate?: VendorRuleCreateOrConnectWithoutBpuGroupsInput
    upsert?: VendorRuleUpsertWithoutBpuGroupsInput
    disconnect?: VendorRuleWhereInput | boolean
    delete?: VendorRuleWhereInput | boolean
    connect?: VendorRuleWhereUniqueInput
    update?: XOR<XOR<VendorRuleUpdateToOneWithWhereWithoutBpuGroupsInput, VendorRuleUpdateWithoutBpuGroupsInput>, VendorRuleUncheckedUpdateWithoutBpuGroupsInput>
  }

  export type SPMDocumentUpdateOneWithoutBpuGroupNestedInput = {
    create?: XOR<SPMDocumentCreateWithoutBpuGroupInput, SPMDocumentUncheckedCreateWithoutBpuGroupInput>
    connectOrCreate?: SPMDocumentCreateOrConnectWithoutBpuGroupInput
    upsert?: SPMDocumentUpsertWithoutBpuGroupInput
    disconnect?: SPMDocumentWhereInput | boolean
    delete?: SPMDocumentWhereInput | boolean
    connect?: SPMDocumentWhereUniqueInput
    update?: XOR<XOR<SPMDocumentUpdateToOneWithWhereWithoutBpuGroupInput, SPMDocumentUpdateWithoutBpuGroupInput>, SPMDocumentUncheckedUpdateWithoutBpuGroupInput>
  }

  export type SPMDocumentUncheckedUpdateOneWithoutBpuGroupNestedInput = {
    create?: XOR<SPMDocumentCreateWithoutBpuGroupInput, SPMDocumentUncheckedCreateWithoutBpuGroupInput>
    connectOrCreate?: SPMDocumentCreateOrConnectWithoutBpuGroupInput
    upsert?: SPMDocumentUpsertWithoutBpuGroupInput
    disconnect?: SPMDocumentWhereInput | boolean
    delete?: SPMDocumentWhereInput | boolean
    connect?: SPMDocumentWhereUniqueInput
    update?: XOR<XOR<SPMDocumentUpdateToOneWithWhereWithoutBpuGroupInput, SPMDocumentUpdateWithoutBpuGroupInput>, SPMDocumentUncheckedUpdateWithoutBpuGroupInput>
  }

  export type BPUGroupCreateNestedOneWithoutSpmDocumentInput = {
    create?: XOR<BPUGroupCreateWithoutSpmDocumentInput, BPUGroupUncheckedCreateWithoutSpmDocumentInput>
    connectOrCreate?: BPUGroupCreateOrConnectWithoutSpmDocumentInput
    connect?: BPUGroupWhereUniqueInput
  }

  export type BPUGroupUpdateOneRequiredWithoutSpmDocumentNestedInput = {
    create?: XOR<BPUGroupCreateWithoutSpmDocumentInput, BPUGroupUncheckedCreateWithoutSpmDocumentInput>
    connectOrCreate?: BPUGroupCreateOrConnectWithoutSpmDocumentInput
    upsert?: BPUGroupUpsertWithoutSpmDocumentInput
    connect?: BPUGroupWhereUniqueInput
    update?: XOR<XOR<BPUGroupUpdateToOneWithWhereWithoutSpmDocumentInput, BPUGroupUpdateWithoutSpmDocumentInput>, BPUGroupUncheckedUpdateWithoutSpmDocumentInput>
  }

  export type SchoolCreateNestedOneWithoutRkasImportsInput = {
    create?: XOR<SchoolCreateWithoutRkasImportsInput, SchoolUncheckedCreateWithoutRkasImportsInput>
    connectOrCreate?: SchoolCreateOrConnectWithoutRkasImportsInput
    connect?: SchoolWhereUniqueInput
  }

  export type RkasProgramCreateNestedManyWithoutRkasImportInput = {
    create?: XOR<RkasProgramCreateWithoutRkasImportInput, RkasProgramUncheckedCreateWithoutRkasImportInput> | RkasProgramCreateWithoutRkasImportInput[] | RkasProgramUncheckedCreateWithoutRkasImportInput[]
    connectOrCreate?: RkasProgramCreateOrConnectWithoutRkasImportInput | RkasProgramCreateOrConnectWithoutRkasImportInput[]
    createMany?: RkasProgramCreateManyRkasImportInputEnvelope
    connect?: RkasProgramWhereUniqueInput | RkasProgramWhereUniqueInput[]
  }

  export type RkasProgramUncheckedCreateNestedManyWithoutRkasImportInput = {
    create?: XOR<RkasProgramCreateWithoutRkasImportInput, RkasProgramUncheckedCreateWithoutRkasImportInput> | RkasProgramCreateWithoutRkasImportInput[] | RkasProgramUncheckedCreateWithoutRkasImportInput[]
    connectOrCreate?: RkasProgramCreateOrConnectWithoutRkasImportInput | RkasProgramCreateOrConnectWithoutRkasImportInput[]
    createMany?: RkasProgramCreateManyRkasImportInputEnvelope
    connect?: RkasProgramWhereUniqueInput | RkasProgramWhereUniqueInput[]
  }

  export type SchoolUpdateOneRequiredWithoutRkasImportsNestedInput = {
    create?: XOR<SchoolCreateWithoutRkasImportsInput, SchoolUncheckedCreateWithoutRkasImportsInput>
    connectOrCreate?: SchoolCreateOrConnectWithoutRkasImportsInput
    upsert?: SchoolUpsertWithoutRkasImportsInput
    connect?: SchoolWhereUniqueInput
    update?: XOR<XOR<SchoolUpdateToOneWithWhereWithoutRkasImportsInput, SchoolUpdateWithoutRkasImportsInput>, SchoolUncheckedUpdateWithoutRkasImportsInput>
  }

  export type RkasProgramUpdateManyWithoutRkasImportNestedInput = {
    create?: XOR<RkasProgramCreateWithoutRkasImportInput, RkasProgramUncheckedCreateWithoutRkasImportInput> | RkasProgramCreateWithoutRkasImportInput[] | RkasProgramUncheckedCreateWithoutRkasImportInput[]
    connectOrCreate?: RkasProgramCreateOrConnectWithoutRkasImportInput | RkasProgramCreateOrConnectWithoutRkasImportInput[]
    upsert?: RkasProgramUpsertWithWhereUniqueWithoutRkasImportInput | RkasProgramUpsertWithWhereUniqueWithoutRkasImportInput[]
    createMany?: RkasProgramCreateManyRkasImportInputEnvelope
    set?: RkasProgramWhereUniqueInput | RkasProgramWhereUniqueInput[]
    disconnect?: RkasProgramWhereUniqueInput | RkasProgramWhereUniqueInput[]
    delete?: RkasProgramWhereUniqueInput | RkasProgramWhereUniqueInput[]
    connect?: RkasProgramWhereUniqueInput | RkasProgramWhereUniqueInput[]
    update?: RkasProgramUpdateWithWhereUniqueWithoutRkasImportInput | RkasProgramUpdateWithWhereUniqueWithoutRkasImportInput[]
    updateMany?: RkasProgramUpdateManyWithWhereWithoutRkasImportInput | RkasProgramUpdateManyWithWhereWithoutRkasImportInput[]
    deleteMany?: RkasProgramScalarWhereInput | RkasProgramScalarWhereInput[]
  }

  export type RkasProgramUncheckedUpdateManyWithoutRkasImportNestedInput = {
    create?: XOR<RkasProgramCreateWithoutRkasImportInput, RkasProgramUncheckedCreateWithoutRkasImportInput> | RkasProgramCreateWithoutRkasImportInput[] | RkasProgramUncheckedCreateWithoutRkasImportInput[]
    connectOrCreate?: RkasProgramCreateOrConnectWithoutRkasImportInput | RkasProgramCreateOrConnectWithoutRkasImportInput[]
    upsert?: RkasProgramUpsertWithWhereUniqueWithoutRkasImportInput | RkasProgramUpsertWithWhereUniqueWithoutRkasImportInput[]
    createMany?: RkasProgramCreateManyRkasImportInputEnvelope
    set?: RkasProgramWhereUniqueInput | RkasProgramWhereUniqueInput[]
    disconnect?: RkasProgramWhereUniqueInput | RkasProgramWhereUniqueInput[]
    delete?: RkasProgramWhereUniqueInput | RkasProgramWhereUniqueInput[]
    connect?: RkasProgramWhereUniqueInput | RkasProgramWhereUniqueInput[]
    update?: RkasProgramUpdateWithWhereUniqueWithoutRkasImportInput | RkasProgramUpdateWithWhereUniqueWithoutRkasImportInput[]
    updateMany?: RkasProgramUpdateManyWithWhereWithoutRkasImportInput | RkasProgramUpdateManyWithWhereWithoutRkasImportInput[]
    deleteMany?: RkasProgramScalarWhereInput | RkasProgramScalarWhereInput[]
  }

  export type RkasImportCreateNestedOneWithoutProgramsInput = {
    create?: XOR<RkasImportCreateWithoutProgramsInput, RkasImportUncheckedCreateWithoutProgramsInput>
    connectOrCreate?: RkasImportCreateOrConnectWithoutProgramsInput
    connect?: RkasImportWhereUniqueInput
  }

  export type RkasItemCreateNestedManyWithoutRkasProgramInput = {
    create?: XOR<RkasItemCreateWithoutRkasProgramInput, RkasItemUncheckedCreateWithoutRkasProgramInput> | RkasItemCreateWithoutRkasProgramInput[] | RkasItemUncheckedCreateWithoutRkasProgramInput[]
    connectOrCreate?: RkasItemCreateOrConnectWithoutRkasProgramInput | RkasItemCreateOrConnectWithoutRkasProgramInput[]
    createMany?: RkasItemCreateManyRkasProgramInputEnvelope
    connect?: RkasItemWhereUniqueInput | RkasItemWhereUniqueInput[]
  }

  export type RkasItemUncheckedCreateNestedManyWithoutRkasProgramInput = {
    create?: XOR<RkasItemCreateWithoutRkasProgramInput, RkasItemUncheckedCreateWithoutRkasProgramInput> | RkasItemCreateWithoutRkasProgramInput[] | RkasItemUncheckedCreateWithoutRkasProgramInput[]
    connectOrCreate?: RkasItemCreateOrConnectWithoutRkasProgramInput | RkasItemCreateOrConnectWithoutRkasProgramInput[]
    createMany?: RkasItemCreateManyRkasProgramInputEnvelope
    connect?: RkasItemWhereUniqueInput | RkasItemWhereUniqueInput[]
  }

  export type RkasImportUpdateOneRequiredWithoutProgramsNestedInput = {
    create?: XOR<RkasImportCreateWithoutProgramsInput, RkasImportUncheckedCreateWithoutProgramsInput>
    connectOrCreate?: RkasImportCreateOrConnectWithoutProgramsInput
    upsert?: RkasImportUpsertWithoutProgramsInput
    connect?: RkasImportWhereUniqueInput
    update?: XOR<XOR<RkasImportUpdateToOneWithWhereWithoutProgramsInput, RkasImportUpdateWithoutProgramsInput>, RkasImportUncheckedUpdateWithoutProgramsInput>
  }

  export type RkasItemUpdateManyWithoutRkasProgramNestedInput = {
    create?: XOR<RkasItemCreateWithoutRkasProgramInput, RkasItemUncheckedCreateWithoutRkasProgramInput> | RkasItemCreateWithoutRkasProgramInput[] | RkasItemUncheckedCreateWithoutRkasProgramInput[]
    connectOrCreate?: RkasItemCreateOrConnectWithoutRkasProgramInput | RkasItemCreateOrConnectWithoutRkasProgramInput[]
    upsert?: RkasItemUpsertWithWhereUniqueWithoutRkasProgramInput | RkasItemUpsertWithWhereUniqueWithoutRkasProgramInput[]
    createMany?: RkasItemCreateManyRkasProgramInputEnvelope
    set?: RkasItemWhereUniqueInput | RkasItemWhereUniqueInput[]
    disconnect?: RkasItemWhereUniqueInput | RkasItemWhereUniqueInput[]
    delete?: RkasItemWhereUniqueInput | RkasItemWhereUniqueInput[]
    connect?: RkasItemWhereUniqueInput | RkasItemWhereUniqueInput[]
    update?: RkasItemUpdateWithWhereUniqueWithoutRkasProgramInput | RkasItemUpdateWithWhereUniqueWithoutRkasProgramInput[]
    updateMany?: RkasItemUpdateManyWithWhereWithoutRkasProgramInput | RkasItemUpdateManyWithWhereWithoutRkasProgramInput[]
    deleteMany?: RkasItemScalarWhereInput | RkasItemScalarWhereInput[]
  }

  export type RkasItemUncheckedUpdateManyWithoutRkasProgramNestedInput = {
    create?: XOR<RkasItemCreateWithoutRkasProgramInput, RkasItemUncheckedCreateWithoutRkasProgramInput> | RkasItemCreateWithoutRkasProgramInput[] | RkasItemUncheckedCreateWithoutRkasProgramInput[]
    connectOrCreate?: RkasItemCreateOrConnectWithoutRkasProgramInput | RkasItemCreateOrConnectWithoutRkasProgramInput[]
    upsert?: RkasItemUpsertWithWhereUniqueWithoutRkasProgramInput | RkasItemUpsertWithWhereUniqueWithoutRkasProgramInput[]
    createMany?: RkasItemCreateManyRkasProgramInputEnvelope
    set?: RkasItemWhereUniqueInput | RkasItemWhereUniqueInput[]
    disconnect?: RkasItemWhereUniqueInput | RkasItemWhereUniqueInput[]
    delete?: RkasItemWhereUniqueInput | RkasItemWhereUniqueInput[]
    connect?: RkasItemWhereUniqueInput | RkasItemWhereUniqueInput[]
    update?: RkasItemUpdateWithWhereUniqueWithoutRkasProgramInput | RkasItemUpdateWithWhereUniqueWithoutRkasProgramInput[]
    updateMany?: RkasItemUpdateManyWithWhereWithoutRkasProgramInput | RkasItemUpdateManyWithWhereWithoutRkasProgramInput[]
    deleteMany?: RkasItemScalarWhereInput | RkasItemScalarWhereInput[]
  }

  export type RkasProgramCreateNestedOneWithoutItemsInput = {
    create?: XOR<RkasProgramCreateWithoutItemsInput, RkasProgramUncheckedCreateWithoutItemsInput>
    connectOrCreate?: RkasProgramCreateOrConnectWithoutItemsInput
    connect?: RkasProgramWhereUniqueInput
  }

  export type RkasProgramUpdateOneRequiredWithoutItemsNestedInput = {
    create?: XOR<RkasProgramCreateWithoutItemsInput, RkasProgramUncheckedCreateWithoutItemsInput>
    connectOrCreate?: RkasProgramCreateOrConnectWithoutItemsInput
    upsert?: RkasProgramUpsertWithoutItemsInput
    connect?: RkasProgramWhereUniqueInput
    update?: XOR<XOR<RkasProgramUpdateToOneWithWhereWithoutItemsInput, RkasProgramUpdateWithoutItemsInput>, RkasProgramUncheckedUpdateWithoutItemsInput>
  }

  export type SchoolCreateNestedOneWithoutInstrumenBospInput = {
    create?: XOR<SchoolCreateWithoutInstrumenBospInput, SchoolUncheckedCreateWithoutInstrumenBospInput>
    connectOrCreate?: SchoolCreateOrConnectWithoutInstrumenBospInput
    connect?: SchoolWhereUniqueInput
  }

  export type SchoolUpdateOneRequiredWithoutInstrumenBospNestedInput = {
    create?: XOR<SchoolCreateWithoutInstrumenBospInput, SchoolUncheckedCreateWithoutInstrumenBospInput>
    connectOrCreate?: SchoolCreateOrConnectWithoutInstrumenBospInput
    upsert?: SchoolUpsertWithoutInstrumenBospInput
    connect?: SchoolWhereUniqueInput
    update?: XOR<XOR<SchoolUpdateToOneWithWhereWithoutInstrumenBospInput, SchoolUpdateWithoutInstrumenBospInput>, SchoolUncheckedUpdateWithoutInstrumenBospInput>
  }

  export type NestedStringFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel>
    in?: string[]
    notIn?: string[]
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    not?: NestedStringFilter<$PrismaModel> | string
  }

  export type NestedStringNullableFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel> | null
    in?: string[] | null
    notIn?: string[] | null
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    not?: NestedStringNullableFilter<$PrismaModel> | string | null
  }

  export type NestedDateTimeFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    in?: Date[] | string[]
    notIn?: Date[] | string[]
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeFilter<$PrismaModel> | Date | string
  }

  export type NestedStringWithAggregatesFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel>
    in?: string[]
    notIn?: string[]
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    not?: NestedStringWithAggregatesFilter<$PrismaModel> | string
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedStringFilter<$PrismaModel>
    _max?: NestedStringFilter<$PrismaModel>
  }

  export type NestedIntFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel>
    in?: number[]
    notIn?: number[]
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntFilter<$PrismaModel> | number
  }

  export type NestedStringNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel> | null
    in?: string[] | null
    notIn?: string[] | null
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    not?: NestedStringNullableWithAggregatesFilter<$PrismaModel> | string | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedStringNullableFilter<$PrismaModel>
    _max?: NestedStringNullableFilter<$PrismaModel>
  }

  export type NestedIntNullableFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel> | null
    in?: number[] | null
    notIn?: number[] | null
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntNullableFilter<$PrismaModel> | number | null
  }

  export type NestedDateTimeWithAggregatesFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    in?: Date[] | string[]
    notIn?: Date[] | string[]
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeWithAggregatesFilter<$PrismaModel> | Date | string
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedDateTimeFilter<$PrismaModel>
    _max?: NestedDateTimeFilter<$PrismaModel>
  }

  export type NestedEnumVendorRuleFormatTypeFilter<$PrismaModel = never> = {
    equals?: $Enums.VendorRuleFormatType | EnumVendorRuleFormatTypeFieldRefInput<$PrismaModel>
    in?: $Enums.VendorRuleFormatType[]
    notIn?: $Enums.VendorRuleFormatType[]
    not?: NestedEnumVendorRuleFormatTypeFilter<$PrismaModel> | $Enums.VendorRuleFormatType
  }

  export type NestedBoolFilter<$PrismaModel = never> = {
    equals?: boolean | BooleanFieldRefInput<$PrismaModel>
    not?: NestedBoolFilter<$PrismaModel> | boolean
  }

  export type NestedEnumVendorRuleFormatTypeWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.VendorRuleFormatType | EnumVendorRuleFormatTypeFieldRefInput<$PrismaModel>
    in?: $Enums.VendorRuleFormatType[]
    notIn?: $Enums.VendorRuleFormatType[]
    not?: NestedEnumVendorRuleFormatTypeWithAggregatesFilter<$PrismaModel> | $Enums.VendorRuleFormatType
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedEnumVendorRuleFormatTypeFilter<$PrismaModel>
    _max?: NestedEnumVendorRuleFormatTypeFilter<$PrismaModel>
  }

  export type NestedBoolWithAggregatesFilter<$PrismaModel = never> = {
    equals?: boolean | BooleanFieldRefInput<$PrismaModel>
    not?: NestedBoolWithAggregatesFilter<$PrismaModel> | boolean
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedBoolFilter<$PrismaModel>
    _max?: NestedBoolFilter<$PrismaModel>
  }

  export type NestedIntWithAggregatesFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel>
    in?: number[]
    notIn?: number[]
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntWithAggregatesFilter<$PrismaModel> | number
    _count?: NestedIntFilter<$PrismaModel>
    _avg?: NestedFloatFilter<$PrismaModel>
    _sum?: NestedIntFilter<$PrismaModel>
    _min?: NestedIntFilter<$PrismaModel>
    _max?: NestedIntFilter<$PrismaModel>
  }

  export type NestedFloatFilter<$PrismaModel = never> = {
    equals?: number | FloatFieldRefInput<$PrismaModel>
    in?: number[]
    notIn?: number[]
    lt?: number | FloatFieldRefInput<$PrismaModel>
    lte?: number | FloatFieldRefInput<$PrismaModel>
    gt?: number | FloatFieldRefInput<$PrismaModel>
    gte?: number | FloatFieldRefInput<$PrismaModel>
    not?: NestedFloatFilter<$PrismaModel> | number
  }

  export type NestedEnumBKUImportStatusFilter<$PrismaModel = never> = {
    equals?: $Enums.BKUImportStatus | EnumBKUImportStatusFieldRefInput<$PrismaModel>
    in?: $Enums.BKUImportStatus[]
    notIn?: $Enums.BKUImportStatus[]
    not?: NestedEnumBKUImportStatusFilter<$PrismaModel> | $Enums.BKUImportStatus
  }

  export type NestedEnumBKUImportStatusWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.BKUImportStatus | EnumBKUImportStatusFieldRefInput<$PrismaModel>
    in?: $Enums.BKUImportStatus[]
    notIn?: $Enums.BKUImportStatus[]
    not?: NestedEnumBKUImportStatusWithAggregatesFilter<$PrismaModel> | $Enums.BKUImportStatus
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedEnumBKUImportStatusFilter<$PrismaModel>
    _max?: NestedEnumBKUImportStatusFilter<$PrismaModel>
  }

  export type NestedIntNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel> | null
    in?: number[] | null
    notIn?: number[] | null
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntNullableWithAggregatesFilter<$PrismaModel> | number | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _avg?: NestedFloatNullableFilter<$PrismaModel>
    _sum?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedIntNullableFilter<$PrismaModel>
    _max?: NestedIntNullableFilter<$PrismaModel>
  }

  export type NestedFloatNullableFilter<$PrismaModel = never> = {
    equals?: number | FloatFieldRefInput<$PrismaModel> | null
    in?: number[] | null
    notIn?: number[] | null
    lt?: number | FloatFieldRefInput<$PrismaModel>
    lte?: number | FloatFieldRefInput<$PrismaModel>
    gt?: number | FloatFieldRefInput<$PrismaModel>
    gte?: number | FloatFieldRefInput<$PrismaModel>
    not?: NestedFloatNullableFilter<$PrismaModel> | number | null
  }

  export type NestedEnumBPUGroupStatusFilter<$PrismaModel = never> = {
    equals?: $Enums.BPUGroupStatus | EnumBPUGroupStatusFieldRefInput<$PrismaModel>
    in?: $Enums.BPUGroupStatus[]
    notIn?: $Enums.BPUGroupStatus[]
    not?: NestedEnumBPUGroupStatusFilter<$PrismaModel> | $Enums.BPUGroupStatus
  }

  export type NestedEnumBPUGroupStatusWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.BPUGroupStatus | EnumBPUGroupStatusFieldRefInput<$PrismaModel>
    in?: $Enums.BPUGroupStatus[]
    notIn?: $Enums.BPUGroupStatus[]
    not?: NestedEnumBPUGroupStatusWithAggregatesFilter<$PrismaModel> | $Enums.BPUGroupStatus
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedEnumBPUGroupStatusFilter<$PrismaModel>
    _max?: NestedEnumBPUGroupStatusFilter<$PrismaModel>
  }

  export type VendorRuleCreateWithoutSchoolInput = {
    id?: string
    keyword: string
    recipient: string
    paymentPrefix: string
    matchKodeKegiatan?: string | null
    formatType?: $Enums.VendorRuleFormatType
    isHonor?: boolean
    isTransport?: boolean
    priority?: number
    isActive?: boolean
    createdAt?: Date | string
    updatedAt?: Date | string
    bpuGroups?: BPUGroupCreateNestedManyWithoutMatchedVendorRuleInput
  }

  export type VendorRuleUncheckedCreateWithoutSchoolInput = {
    id?: string
    keyword: string
    recipient: string
    paymentPrefix: string
    matchKodeKegiatan?: string | null
    formatType?: $Enums.VendorRuleFormatType
    isHonor?: boolean
    isTransport?: boolean
    priority?: number
    isActive?: boolean
    createdAt?: Date | string
    updatedAt?: Date | string
    bpuGroups?: BPUGroupUncheckedCreateNestedManyWithoutMatchedVendorRuleInput
  }

  export type VendorRuleCreateOrConnectWithoutSchoolInput = {
    where: VendorRuleWhereUniqueInput
    create: XOR<VendorRuleCreateWithoutSchoolInput, VendorRuleUncheckedCreateWithoutSchoolInput>
  }

  export type VendorRuleCreateManySchoolInputEnvelope = {
    data: VendorRuleCreateManySchoolInput | VendorRuleCreateManySchoolInput[]
  }

  export type BKUImportCreateWithoutSchoolInput = {
    id?: string
    month: number
    year: number
    sourceFileName: string
    status?: $Enums.BKUImportStatus
    importedAt?: Date | string
    rows?: BKURowCreateNestedManyWithoutBkuImportInput
    bpuGroups?: BPUGroupCreateNestedManyWithoutBkuImportInput
  }

  export type BKUImportUncheckedCreateWithoutSchoolInput = {
    id?: string
    month: number
    year: number
    sourceFileName: string
    status?: $Enums.BKUImportStatus
    importedAt?: Date | string
    rows?: BKURowUncheckedCreateNestedManyWithoutBkuImportInput
    bpuGroups?: BPUGroupUncheckedCreateNestedManyWithoutBkuImportInput
  }

  export type BKUImportCreateOrConnectWithoutSchoolInput = {
    where: BKUImportWhereUniqueInput
    create: XOR<BKUImportCreateWithoutSchoolInput, BKUImportUncheckedCreateWithoutSchoolInput>
  }

  export type BKUImportCreateManySchoolInputEnvelope = {
    data: BKUImportCreateManySchoolInput | BKUImportCreateManySchoolInput[]
  }

  export type RkasImportCreateWithoutSchoolInput = {
    id?: string
    month: number
    year: number
    sourceFileName: string
    sourceSchoolName?: string | null
    npsn?: string | null
    namaPelaksana?: string
    programLabel?: string
    namaKegiatan?: string
    sumberDana?: string
    pekerjaanLabel?: string
    kepalaName?: string
    bendaharaName?: string
    importedAt?: Date | string
    updatedAt?: Date | string
    programs?: RkasProgramCreateNestedManyWithoutRkasImportInput
  }

  export type RkasImportUncheckedCreateWithoutSchoolInput = {
    id?: string
    month: number
    year: number
    sourceFileName: string
    sourceSchoolName?: string | null
    npsn?: string | null
    namaPelaksana?: string
    programLabel?: string
    namaKegiatan?: string
    sumberDana?: string
    pekerjaanLabel?: string
    kepalaName?: string
    bendaharaName?: string
    importedAt?: Date | string
    updatedAt?: Date | string
    programs?: RkasProgramUncheckedCreateNestedManyWithoutRkasImportInput
  }

  export type RkasImportCreateOrConnectWithoutSchoolInput = {
    where: RkasImportWhereUniqueInput
    create: XOR<RkasImportCreateWithoutSchoolInput, RkasImportUncheckedCreateWithoutSchoolInput>
  }

  export type RkasImportCreateManySchoolInputEnvelope = {
    data: RkasImportCreateManySchoolInput | RkasImportCreateManySchoolInput[]
  }

  export type InstrumenBospCreateWithoutSchoolInput = {
    id?: string
    year: number
    tahap: number
    jenisSatuan?: string
    statusSatuan?: string
    kelurahan?: string
    kecamatan?: string
    jenisDanaBosp?: string
    skNomor?: string
    skTanggal?: string
    kepalaName?: string
    bendaharaName?: string
    komiteName?: string
    adaBku?: boolean
    adaBukuPembantuKas?: boolean
    adaBukuPembantuPajak?: boolean
    adaBukuPembantuBank?: boolean
    adaLaporanRealisasi?: boolean
    totalAlokasiTahunan?: number
    saldoAwalOverride?: number | null
    operasionalOverride?: number | null
    honorSesuaiRkas?: boolean
    honorBuktiLengkap?: boolean
    honorPenerimaSesuai?: boolean
    metodePengadaanBuku?: string
    metodePengadaanLain?: string
    belanjaModalJson?: string
    pemeliharaanJson?: string
    bukuOverrideJson?: string
    tanggalDokumen?: string
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type InstrumenBospUncheckedCreateWithoutSchoolInput = {
    id?: string
    year: number
    tahap: number
    jenisSatuan?: string
    statusSatuan?: string
    kelurahan?: string
    kecamatan?: string
    jenisDanaBosp?: string
    skNomor?: string
    skTanggal?: string
    kepalaName?: string
    bendaharaName?: string
    komiteName?: string
    adaBku?: boolean
    adaBukuPembantuKas?: boolean
    adaBukuPembantuPajak?: boolean
    adaBukuPembantuBank?: boolean
    adaLaporanRealisasi?: boolean
    totalAlokasiTahunan?: number
    saldoAwalOverride?: number | null
    operasionalOverride?: number | null
    honorSesuaiRkas?: boolean
    honorBuktiLengkap?: boolean
    honorPenerimaSesuai?: boolean
    metodePengadaanBuku?: string
    metodePengadaanLain?: string
    belanjaModalJson?: string
    pemeliharaanJson?: string
    bukuOverrideJson?: string
    tanggalDokumen?: string
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type InstrumenBospCreateOrConnectWithoutSchoolInput = {
    where: InstrumenBospWhereUniqueInput
    create: XOR<InstrumenBospCreateWithoutSchoolInput, InstrumenBospUncheckedCreateWithoutSchoolInput>
  }

  export type InstrumenBospCreateManySchoolInputEnvelope = {
    data: InstrumenBospCreateManySchoolInput | InstrumenBospCreateManySchoolInput[]
  }

  export type VendorRuleUpsertWithWhereUniqueWithoutSchoolInput = {
    where: VendorRuleWhereUniqueInput
    update: XOR<VendorRuleUpdateWithoutSchoolInput, VendorRuleUncheckedUpdateWithoutSchoolInput>
    create: XOR<VendorRuleCreateWithoutSchoolInput, VendorRuleUncheckedCreateWithoutSchoolInput>
  }

  export type VendorRuleUpdateWithWhereUniqueWithoutSchoolInput = {
    where: VendorRuleWhereUniqueInput
    data: XOR<VendorRuleUpdateWithoutSchoolInput, VendorRuleUncheckedUpdateWithoutSchoolInput>
  }

  export type VendorRuleUpdateManyWithWhereWithoutSchoolInput = {
    where: VendorRuleScalarWhereInput
    data: XOR<VendorRuleUpdateManyMutationInput, VendorRuleUncheckedUpdateManyWithoutSchoolInput>
  }

  export type VendorRuleScalarWhereInput = {
    AND?: VendorRuleScalarWhereInput | VendorRuleScalarWhereInput[]
    OR?: VendorRuleScalarWhereInput[]
    NOT?: VendorRuleScalarWhereInput | VendorRuleScalarWhereInput[]
    id?: StringFilter<"VendorRule"> | string
    schoolId?: StringFilter<"VendorRule"> | string
    keyword?: StringFilter<"VendorRule"> | string
    recipient?: StringFilter<"VendorRule"> | string
    paymentPrefix?: StringFilter<"VendorRule"> | string
    matchKodeKegiatan?: StringNullableFilter<"VendorRule"> | string | null
    formatType?: EnumVendorRuleFormatTypeFilter<"VendorRule"> | $Enums.VendorRuleFormatType
    isHonor?: BoolFilter<"VendorRule"> | boolean
    isTransport?: BoolFilter<"VendorRule"> | boolean
    priority?: IntFilter<"VendorRule"> | number
    isActive?: BoolFilter<"VendorRule"> | boolean
    createdAt?: DateTimeFilter<"VendorRule"> | Date | string
    updatedAt?: DateTimeFilter<"VendorRule"> | Date | string
  }

  export type BKUImportUpsertWithWhereUniqueWithoutSchoolInput = {
    where: BKUImportWhereUniqueInput
    update: XOR<BKUImportUpdateWithoutSchoolInput, BKUImportUncheckedUpdateWithoutSchoolInput>
    create: XOR<BKUImportCreateWithoutSchoolInput, BKUImportUncheckedCreateWithoutSchoolInput>
  }

  export type BKUImportUpdateWithWhereUniqueWithoutSchoolInput = {
    where: BKUImportWhereUniqueInput
    data: XOR<BKUImportUpdateWithoutSchoolInput, BKUImportUncheckedUpdateWithoutSchoolInput>
  }

  export type BKUImportUpdateManyWithWhereWithoutSchoolInput = {
    where: BKUImportScalarWhereInput
    data: XOR<BKUImportUpdateManyMutationInput, BKUImportUncheckedUpdateManyWithoutSchoolInput>
  }

  export type BKUImportScalarWhereInput = {
    AND?: BKUImportScalarWhereInput | BKUImportScalarWhereInput[]
    OR?: BKUImportScalarWhereInput[]
    NOT?: BKUImportScalarWhereInput | BKUImportScalarWhereInput[]
    id?: StringFilter<"BKUImport"> | string
    schoolId?: StringFilter<"BKUImport"> | string
    month?: IntFilter<"BKUImport"> | number
    year?: IntFilter<"BKUImport"> | number
    sourceFileName?: StringFilter<"BKUImport"> | string
    status?: EnumBKUImportStatusFilter<"BKUImport"> | $Enums.BKUImportStatus
    importedAt?: DateTimeFilter<"BKUImport"> | Date | string
  }

  export type RkasImportUpsertWithWhereUniqueWithoutSchoolInput = {
    where: RkasImportWhereUniqueInput
    update: XOR<RkasImportUpdateWithoutSchoolInput, RkasImportUncheckedUpdateWithoutSchoolInput>
    create: XOR<RkasImportCreateWithoutSchoolInput, RkasImportUncheckedCreateWithoutSchoolInput>
  }

  export type RkasImportUpdateWithWhereUniqueWithoutSchoolInput = {
    where: RkasImportWhereUniqueInput
    data: XOR<RkasImportUpdateWithoutSchoolInput, RkasImportUncheckedUpdateWithoutSchoolInput>
  }

  export type RkasImportUpdateManyWithWhereWithoutSchoolInput = {
    where: RkasImportScalarWhereInput
    data: XOR<RkasImportUpdateManyMutationInput, RkasImportUncheckedUpdateManyWithoutSchoolInput>
  }

  export type RkasImportScalarWhereInput = {
    AND?: RkasImportScalarWhereInput | RkasImportScalarWhereInput[]
    OR?: RkasImportScalarWhereInput[]
    NOT?: RkasImportScalarWhereInput | RkasImportScalarWhereInput[]
    id?: StringFilter<"RkasImport"> | string
    schoolId?: StringFilter<"RkasImport"> | string
    month?: IntFilter<"RkasImport"> | number
    year?: IntFilter<"RkasImport"> | number
    sourceFileName?: StringFilter<"RkasImport"> | string
    sourceSchoolName?: StringNullableFilter<"RkasImport"> | string | null
    npsn?: StringNullableFilter<"RkasImport"> | string | null
    namaPelaksana?: StringFilter<"RkasImport"> | string
    programLabel?: StringFilter<"RkasImport"> | string
    namaKegiatan?: StringFilter<"RkasImport"> | string
    sumberDana?: StringFilter<"RkasImport"> | string
    pekerjaanLabel?: StringFilter<"RkasImport"> | string
    kepalaName?: StringFilter<"RkasImport"> | string
    bendaharaName?: StringFilter<"RkasImport"> | string
    importedAt?: DateTimeFilter<"RkasImport"> | Date | string
    updatedAt?: DateTimeFilter<"RkasImport"> | Date | string
  }

  export type InstrumenBospUpsertWithWhereUniqueWithoutSchoolInput = {
    where: InstrumenBospWhereUniqueInput
    update: XOR<InstrumenBospUpdateWithoutSchoolInput, InstrumenBospUncheckedUpdateWithoutSchoolInput>
    create: XOR<InstrumenBospCreateWithoutSchoolInput, InstrumenBospUncheckedCreateWithoutSchoolInput>
  }

  export type InstrumenBospUpdateWithWhereUniqueWithoutSchoolInput = {
    where: InstrumenBospWhereUniqueInput
    data: XOR<InstrumenBospUpdateWithoutSchoolInput, InstrumenBospUncheckedUpdateWithoutSchoolInput>
  }

  export type InstrumenBospUpdateManyWithWhereWithoutSchoolInput = {
    where: InstrumenBospScalarWhereInput
    data: XOR<InstrumenBospUpdateManyMutationInput, InstrumenBospUncheckedUpdateManyWithoutSchoolInput>
  }

  export type InstrumenBospScalarWhereInput = {
    AND?: InstrumenBospScalarWhereInput | InstrumenBospScalarWhereInput[]
    OR?: InstrumenBospScalarWhereInput[]
    NOT?: InstrumenBospScalarWhereInput | InstrumenBospScalarWhereInput[]
    id?: StringFilter<"InstrumenBosp"> | string
    schoolId?: StringFilter<"InstrumenBosp"> | string
    year?: IntFilter<"InstrumenBosp"> | number
    tahap?: IntFilter<"InstrumenBosp"> | number
    jenisSatuan?: StringFilter<"InstrumenBosp"> | string
    statusSatuan?: StringFilter<"InstrumenBosp"> | string
    kelurahan?: StringFilter<"InstrumenBosp"> | string
    kecamatan?: StringFilter<"InstrumenBosp"> | string
    jenisDanaBosp?: StringFilter<"InstrumenBosp"> | string
    skNomor?: StringFilter<"InstrumenBosp"> | string
    skTanggal?: StringFilter<"InstrumenBosp"> | string
    kepalaName?: StringFilter<"InstrumenBosp"> | string
    bendaharaName?: StringFilter<"InstrumenBosp"> | string
    komiteName?: StringFilter<"InstrumenBosp"> | string
    adaBku?: BoolFilter<"InstrumenBosp"> | boolean
    adaBukuPembantuKas?: BoolFilter<"InstrumenBosp"> | boolean
    adaBukuPembantuPajak?: BoolFilter<"InstrumenBosp"> | boolean
    adaBukuPembantuBank?: BoolFilter<"InstrumenBosp"> | boolean
    adaLaporanRealisasi?: BoolFilter<"InstrumenBosp"> | boolean
    totalAlokasiTahunan?: IntFilter<"InstrumenBosp"> | number
    saldoAwalOverride?: IntNullableFilter<"InstrumenBosp"> | number | null
    operasionalOverride?: IntNullableFilter<"InstrumenBosp"> | number | null
    honorSesuaiRkas?: BoolFilter<"InstrumenBosp"> | boolean
    honorBuktiLengkap?: BoolFilter<"InstrumenBosp"> | boolean
    honorPenerimaSesuai?: BoolFilter<"InstrumenBosp"> | boolean
    metodePengadaanBuku?: StringFilter<"InstrumenBosp"> | string
    metodePengadaanLain?: StringFilter<"InstrumenBosp"> | string
    belanjaModalJson?: StringFilter<"InstrumenBosp"> | string
    pemeliharaanJson?: StringFilter<"InstrumenBosp"> | string
    bukuOverrideJson?: StringFilter<"InstrumenBosp"> | string
    tanggalDokumen?: StringFilter<"InstrumenBosp"> | string
    createdAt?: DateTimeFilter<"InstrumenBosp"> | Date | string
    updatedAt?: DateTimeFilter<"InstrumenBosp"> | Date | string
  }

  export type SchoolCreateWithoutVendorRulesInput = {
    id?: string
    name: string
    kopHeaderLine?: string | null
    npsn?: string | null
    address: string
    contact?: string | null
    formatCode: string
    kepalaName: string
    kepalaJabatan: string
    openingSentenceTemplate?: string
    atasDasarLine1?: string
    atasDasarLine2?: string
    honorRecapTitle?: string | null
    frazaListrikCustomerId?: string | null
    frazaInternetCustomerId?: string | null
    logoPath?: string | null
    regionalLogoPath?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    bkuImports?: BKUImportCreateNestedManyWithoutSchoolInput
    rkasImports?: RkasImportCreateNestedManyWithoutSchoolInput
    instrumenBosp?: InstrumenBospCreateNestedManyWithoutSchoolInput
  }

  export type SchoolUncheckedCreateWithoutVendorRulesInput = {
    id?: string
    name: string
    kopHeaderLine?: string | null
    npsn?: string | null
    address: string
    contact?: string | null
    formatCode: string
    kepalaName: string
    kepalaJabatan: string
    openingSentenceTemplate?: string
    atasDasarLine1?: string
    atasDasarLine2?: string
    honorRecapTitle?: string | null
    frazaListrikCustomerId?: string | null
    frazaInternetCustomerId?: string | null
    logoPath?: string | null
    regionalLogoPath?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    bkuImports?: BKUImportUncheckedCreateNestedManyWithoutSchoolInput
    rkasImports?: RkasImportUncheckedCreateNestedManyWithoutSchoolInput
    instrumenBosp?: InstrumenBospUncheckedCreateNestedManyWithoutSchoolInput
  }

  export type SchoolCreateOrConnectWithoutVendorRulesInput = {
    where: SchoolWhereUniqueInput
    create: XOR<SchoolCreateWithoutVendorRulesInput, SchoolUncheckedCreateWithoutVendorRulesInput>
  }

  export type BPUGroupCreateWithoutMatchedVendorRuleInput = {
    id?: string
    bpuCode: string
    bpuNumber: number
    tanggal: Date | string
    totalAmount: number
    overrideRecipient?: string | null
    overridePaymentFor?: string | null
    status?: $Enums.BPUGroupStatus
    createdAt?: Date | string
    updatedAt?: Date | string
    bkuImport: BKUImportCreateNestedOneWithoutBpuGroupsInput
    spmDocument?: SPMDocumentCreateNestedOneWithoutBpuGroupInput
  }

  export type BPUGroupUncheckedCreateWithoutMatchedVendorRuleInput = {
    id?: string
    bkuImportId: string
    bpuCode: string
    bpuNumber: number
    tanggal: Date | string
    totalAmount: number
    overrideRecipient?: string | null
    overridePaymentFor?: string | null
    status?: $Enums.BPUGroupStatus
    createdAt?: Date | string
    updatedAt?: Date | string
    spmDocument?: SPMDocumentUncheckedCreateNestedOneWithoutBpuGroupInput
  }

  export type BPUGroupCreateOrConnectWithoutMatchedVendorRuleInput = {
    where: BPUGroupWhereUniqueInput
    create: XOR<BPUGroupCreateWithoutMatchedVendorRuleInput, BPUGroupUncheckedCreateWithoutMatchedVendorRuleInput>
  }

  export type BPUGroupCreateManyMatchedVendorRuleInputEnvelope = {
    data: BPUGroupCreateManyMatchedVendorRuleInput | BPUGroupCreateManyMatchedVendorRuleInput[]
  }

  export type SchoolUpsertWithoutVendorRulesInput = {
    update: XOR<SchoolUpdateWithoutVendorRulesInput, SchoolUncheckedUpdateWithoutVendorRulesInput>
    create: XOR<SchoolCreateWithoutVendorRulesInput, SchoolUncheckedCreateWithoutVendorRulesInput>
    where?: SchoolWhereInput
  }

  export type SchoolUpdateToOneWithWhereWithoutVendorRulesInput = {
    where?: SchoolWhereInput
    data: XOR<SchoolUpdateWithoutVendorRulesInput, SchoolUncheckedUpdateWithoutVendorRulesInput>
  }

  export type SchoolUpdateWithoutVendorRulesInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    kopHeaderLine?: NullableStringFieldUpdateOperationsInput | string | null
    npsn?: NullableStringFieldUpdateOperationsInput | string | null
    address?: StringFieldUpdateOperationsInput | string
    contact?: NullableStringFieldUpdateOperationsInput | string | null
    formatCode?: StringFieldUpdateOperationsInput | string
    kepalaName?: StringFieldUpdateOperationsInput | string
    kepalaJabatan?: StringFieldUpdateOperationsInput | string
    openingSentenceTemplate?: StringFieldUpdateOperationsInput | string
    atasDasarLine1?: StringFieldUpdateOperationsInput | string
    atasDasarLine2?: StringFieldUpdateOperationsInput | string
    honorRecapTitle?: NullableStringFieldUpdateOperationsInput | string | null
    frazaListrikCustomerId?: NullableStringFieldUpdateOperationsInput | string | null
    frazaInternetCustomerId?: NullableStringFieldUpdateOperationsInput | string | null
    logoPath?: NullableStringFieldUpdateOperationsInput | string | null
    regionalLogoPath?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    bkuImports?: BKUImportUpdateManyWithoutSchoolNestedInput
    rkasImports?: RkasImportUpdateManyWithoutSchoolNestedInput
    instrumenBosp?: InstrumenBospUpdateManyWithoutSchoolNestedInput
  }

  export type SchoolUncheckedUpdateWithoutVendorRulesInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    kopHeaderLine?: NullableStringFieldUpdateOperationsInput | string | null
    npsn?: NullableStringFieldUpdateOperationsInput | string | null
    address?: StringFieldUpdateOperationsInput | string
    contact?: NullableStringFieldUpdateOperationsInput | string | null
    formatCode?: StringFieldUpdateOperationsInput | string
    kepalaName?: StringFieldUpdateOperationsInput | string
    kepalaJabatan?: StringFieldUpdateOperationsInput | string
    openingSentenceTemplate?: StringFieldUpdateOperationsInput | string
    atasDasarLine1?: StringFieldUpdateOperationsInput | string
    atasDasarLine2?: StringFieldUpdateOperationsInput | string
    honorRecapTitle?: NullableStringFieldUpdateOperationsInput | string | null
    frazaListrikCustomerId?: NullableStringFieldUpdateOperationsInput | string | null
    frazaInternetCustomerId?: NullableStringFieldUpdateOperationsInput | string | null
    logoPath?: NullableStringFieldUpdateOperationsInput | string | null
    regionalLogoPath?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    bkuImports?: BKUImportUncheckedUpdateManyWithoutSchoolNestedInput
    rkasImports?: RkasImportUncheckedUpdateManyWithoutSchoolNestedInput
    instrumenBosp?: InstrumenBospUncheckedUpdateManyWithoutSchoolNestedInput
  }

  export type BPUGroupUpsertWithWhereUniqueWithoutMatchedVendorRuleInput = {
    where: BPUGroupWhereUniqueInput
    update: XOR<BPUGroupUpdateWithoutMatchedVendorRuleInput, BPUGroupUncheckedUpdateWithoutMatchedVendorRuleInput>
    create: XOR<BPUGroupCreateWithoutMatchedVendorRuleInput, BPUGroupUncheckedCreateWithoutMatchedVendorRuleInput>
  }

  export type BPUGroupUpdateWithWhereUniqueWithoutMatchedVendorRuleInput = {
    where: BPUGroupWhereUniqueInput
    data: XOR<BPUGroupUpdateWithoutMatchedVendorRuleInput, BPUGroupUncheckedUpdateWithoutMatchedVendorRuleInput>
  }

  export type BPUGroupUpdateManyWithWhereWithoutMatchedVendorRuleInput = {
    where: BPUGroupScalarWhereInput
    data: XOR<BPUGroupUpdateManyMutationInput, BPUGroupUncheckedUpdateManyWithoutMatchedVendorRuleInput>
  }

  export type BPUGroupScalarWhereInput = {
    AND?: BPUGroupScalarWhereInput | BPUGroupScalarWhereInput[]
    OR?: BPUGroupScalarWhereInput[]
    NOT?: BPUGroupScalarWhereInput | BPUGroupScalarWhereInput[]
    id?: StringFilter<"BPUGroup"> | string
    bkuImportId?: StringFilter<"BPUGroup"> | string
    bpuCode?: StringFilter<"BPUGroup"> | string
    bpuNumber?: IntFilter<"BPUGroup"> | number
    tanggal?: DateTimeFilter<"BPUGroup"> | Date | string
    totalAmount?: IntFilter<"BPUGroup"> | number
    matchedVendorRuleId?: StringNullableFilter<"BPUGroup"> | string | null
    overrideRecipient?: StringNullableFilter<"BPUGroup"> | string | null
    overridePaymentFor?: StringNullableFilter<"BPUGroup"> | string | null
    status?: EnumBPUGroupStatusFilter<"BPUGroup"> | $Enums.BPUGroupStatus
    createdAt?: DateTimeFilter<"BPUGroup"> | Date | string
    updatedAt?: DateTimeFilter<"BPUGroup"> | Date | string
  }

  export type SchoolCreateWithoutBkuImportsInput = {
    id?: string
    name: string
    kopHeaderLine?: string | null
    npsn?: string | null
    address: string
    contact?: string | null
    formatCode: string
    kepalaName: string
    kepalaJabatan: string
    openingSentenceTemplate?: string
    atasDasarLine1?: string
    atasDasarLine2?: string
    honorRecapTitle?: string | null
    frazaListrikCustomerId?: string | null
    frazaInternetCustomerId?: string | null
    logoPath?: string | null
    regionalLogoPath?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    vendorRules?: VendorRuleCreateNestedManyWithoutSchoolInput
    rkasImports?: RkasImportCreateNestedManyWithoutSchoolInput
    instrumenBosp?: InstrumenBospCreateNestedManyWithoutSchoolInput
  }

  export type SchoolUncheckedCreateWithoutBkuImportsInput = {
    id?: string
    name: string
    kopHeaderLine?: string | null
    npsn?: string | null
    address: string
    contact?: string | null
    formatCode: string
    kepalaName: string
    kepalaJabatan: string
    openingSentenceTemplate?: string
    atasDasarLine1?: string
    atasDasarLine2?: string
    honorRecapTitle?: string | null
    frazaListrikCustomerId?: string | null
    frazaInternetCustomerId?: string | null
    logoPath?: string | null
    regionalLogoPath?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    vendorRules?: VendorRuleUncheckedCreateNestedManyWithoutSchoolInput
    rkasImports?: RkasImportUncheckedCreateNestedManyWithoutSchoolInput
    instrumenBosp?: InstrumenBospUncheckedCreateNestedManyWithoutSchoolInput
  }

  export type SchoolCreateOrConnectWithoutBkuImportsInput = {
    where: SchoolWhereUniqueInput
    create: XOR<SchoolCreateWithoutBkuImportsInput, SchoolUncheckedCreateWithoutBkuImportsInput>
  }

  export type BKURowCreateWithoutBkuImportInput = {
    id?: string
    tanggal: Date | string
    kodeKegiatan?: string | null
    kodeRekening?: string | null
    bpuCode?: string | null
    bpuNumber?: number | null
    uraian: string
    penerimaan?: number
    pengeluaran?: number
    saldo?: number
    pageIndex?: number | null
    createdAt?: Date | string
  }

  export type BKURowUncheckedCreateWithoutBkuImportInput = {
    id?: string
    tanggal: Date | string
    kodeKegiatan?: string | null
    kodeRekening?: string | null
    bpuCode?: string | null
    bpuNumber?: number | null
    uraian: string
    penerimaan?: number
    pengeluaran?: number
    saldo?: number
    pageIndex?: number | null
    createdAt?: Date | string
  }

  export type BKURowCreateOrConnectWithoutBkuImportInput = {
    where: BKURowWhereUniqueInput
    create: XOR<BKURowCreateWithoutBkuImportInput, BKURowUncheckedCreateWithoutBkuImportInput>
  }

  export type BKURowCreateManyBkuImportInputEnvelope = {
    data: BKURowCreateManyBkuImportInput | BKURowCreateManyBkuImportInput[]
  }

  export type BPUGroupCreateWithoutBkuImportInput = {
    id?: string
    bpuCode: string
    bpuNumber: number
    tanggal: Date | string
    totalAmount: number
    overrideRecipient?: string | null
    overridePaymentFor?: string | null
    status?: $Enums.BPUGroupStatus
    createdAt?: Date | string
    updatedAt?: Date | string
    matchedVendorRule?: VendorRuleCreateNestedOneWithoutBpuGroupsInput
    spmDocument?: SPMDocumentCreateNestedOneWithoutBpuGroupInput
  }

  export type BPUGroupUncheckedCreateWithoutBkuImportInput = {
    id?: string
    bpuCode: string
    bpuNumber: number
    tanggal: Date | string
    totalAmount: number
    matchedVendorRuleId?: string | null
    overrideRecipient?: string | null
    overridePaymentFor?: string | null
    status?: $Enums.BPUGroupStatus
    createdAt?: Date | string
    updatedAt?: Date | string
    spmDocument?: SPMDocumentUncheckedCreateNestedOneWithoutBpuGroupInput
  }

  export type BPUGroupCreateOrConnectWithoutBkuImportInput = {
    where: BPUGroupWhereUniqueInput
    create: XOR<BPUGroupCreateWithoutBkuImportInput, BPUGroupUncheckedCreateWithoutBkuImportInput>
  }

  export type BPUGroupCreateManyBkuImportInputEnvelope = {
    data: BPUGroupCreateManyBkuImportInput | BPUGroupCreateManyBkuImportInput[]
  }

  export type SchoolUpsertWithoutBkuImportsInput = {
    update: XOR<SchoolUpdateWithoutBkuImportsInput, SchoolUncheckedUpdateWithoutBkuImportsInput>
    create: XOR<SchoolCreateWithoutBkuImportsInput, SchoolUncheckedCreateWithoutBkuImportsInput>
    where?: SchoolWhereInput
  }

  export type SchoolUpdateToOneWithWhereWithoutBkuImportsInput = {
    where?: SchoolWhereInput
    data: XOR<SchoolUpdateWithoutBkuImportsInput, SchoolUncheckedUpdateWithoutBkuImportsInput>
  }

  export type SchoolUpdateWithoutBkuImportsInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    kopHeaderLine?: NullableStringFieldUpdateOperationsInput | string | null
    npsn?: NullableStringFieldUpdateOperationsInput | string | null
    address?: StringFieldUpdateOperationsInput | string
    contact?: NullableStringFieldUpdateOperationsInput | string | null
    formatCode?: StringFieldUpdateOperationsInput | string
    kepalaName?: StringFieldUpdateOperationsInput | string
    kepalaJabatan?: StringFieldUpdateOperationsInput | string
    openingSentenceTemplate?: StringFieldUpdateOperationsInput | string
    atasDasarLine1?: StringFieldUpdateOperationsInput | string
    atasDasarLine2?: StringFieldUpdateOperationsInput | string
    honorRecapTitle?: NullableStringFieldUpdateOperationsInput | string | null
    frazaListrikCustomerId?: NullableStringFieldUpdateOperationsInput | string | null
    frazaInternetCustomerId?: NullableStringFieldUpdateOperationsInput | string | null
    logoPath?: NullableStringFieldUpdateOperationsInput | string | null
    regionalLogoPath?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    vendorRules?: VendorRuleUpdateManyWithoutSchoolNestedInput
    rkasImports?: RkasImportUpdateManyWithoutSchoolNestedInput
    instrumenBosp?: InstrumenBospUpdateManyWithoutSchoolNestedInput
  }

  export type SchoolUncheckedUpdateWithoutBkuImportsInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    kopHeaderLine?: NullableStringFieldUpdateOperationsInput | string | null
    npsn?: NullableStringFieldUpdateOperationsInput | string | null
    address?: StringFieldUpdateOperationsInput | string
    contact?: NullableStringFieldUpdateOperationsInput | string | null
    formatCode?: StringFieldUpdateOperationsInput | string
    kepalaName?: StringFieldUpdateOperationsInput | string
    kepalaJabatan?: StringFieldUpdateOperationsInput | string
    openingSentenceTemplate?: StringFieldUpdateOperationsInput | string
    atasDasarLine1?: StringFieldUpdateOperationsInput | string
    atasDasarLine2?: StringFieldUpdateOperationsInput | string
    honorRecapTitle?: NullableStringFieldUpdateOperationsInput | string | null
    frazaListrikCustomerId?: NullableStringFieldUpdateOperationsInput | string | null
    frazaInternetCustomerId?: NullableStringFieldUpdateOperationsInput | string | null
    logoPath?: NullableStringFieldUpdateOperationsInput | string | null
    regionalLogoPath?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    vendorRules?: VendorRuleUncheckedUpdateManyWithoutSchoolNestedInput
    rkasImports?: RkasImportUncheckedUpdateManyWithoutSchoolNestedInput
    instrumenBosp?: InstrumenBospUncheckedUpdateManyWithoutSchoolNestedInput
  }

  export type BKURowUpsertWithWhereUniqueWithoutBkuImportInput = {
    where: BKURowWhereUniqueInput
    update: XOR<BKURowUpdateWithoutBkuImportInput, BKURowUncheckedUpdateWithoutBkuImportInput>
    create: XOR<BKURowCreateWithoutBkuImportInput, BKURowUncheckedCreateWithoutBkuImportInput>
  }

  export type BKURowUpdateWithWhereUniqueWithoutBkuImportInput = {
    where: BKURowWhereUniqueInput
    data: XOR<BKURowUpdateWithoutBkuImportInput, BKURowUncheckedUpdateWithoutBkuImportInput>
  }

  export type BKURowUpdateManyWithWhereWithoutBkuImportInput = {
    where: BKURowScalarWhereInput
    data: XOR<BKURowUpdateManyMutationInput, BKURowUncheckedUpdateManyWithoutBkuImportInput>
  }

  export type BKURowScalarWhereInput = {
    AND?: BKURowScalarWhereInput | BKURowScalarWhereInput[]
    OR?: BKURowScalarWhereInput[]
    NOT?: BKURowScalarWhereInput | BKURowScalarWhereInput[]
    id?: StringFilter<"BKURow"> | string
    bkuImportId?: StringFilter<"BKURow"> | string
    tanggal?: DateTimeFilter<"BKURow"> | Date | string
    kodeKegiatan?: StringNullableFilter<"BKURow"> | string | null
    kodeRekening?: StringNullableFilter<"BKURow"> | string | null
    bpuCode?: StringNullableFilter<"BKURow"> | string | null
    bpuNumber?: IntNullableFilter<"BKURow"> | number | null
    uraian?: StringFilter<"BKURow"> | string
    penerimaan?: IntFilter<"BKURow"> | number
    pengeluaran?: IntFilter<"BKURow"> | number
    saldo?: IntFilter<"BKURow"> | number
    pageIndex?: IntNullableFilter<"BKURow"> | number | null
    createdAt?: DateTimeFilter<"BKURow"> | Date | string
  }

  export type BPUGroupUpsertWithWhereUniqueWithoutBkuImportInput = {
    where: BPUGroupWhereUniqueInput
    update: XOR<BPUGroupUpdateWithoutBkuImportInput, BPUGroupUncheckedUpdateWithoutBkuImportInput>
    create: XOR<BPUGroupCreateWithoutBkuImportInput, BPUGroupUncheckedCreateWithoutBkuImportInput>
  }

  export type BPUGroupUpdateWithWhereUniqueWithoutBkuImportInput = {
    where: BPUGroupWhereUniqueInput
    data: XOR<BPUGroupUpdateWithoutBkuImportInput, BPUGroupUncheckedUpdateWithoutBkuImportInput>
  }

  export type BPUGroupUpdateManyWithWhereWithoutBkuImportInput = {
    where: BPUGroupScalarWhereInput
    data: XOR<BPUGroupUpdateManyMutationInput, BPUGroupUncheckedUpdateManyWithoutBkuImportInput>
  }

  export type BKUImportCreateWithoutRowsInput = {
    id?: string
    month: number
    year: number
    sourceFileName: string
    status?: $Enums.BKUImportStatus
    importedAt?: Date | string
    school: SchoolCreateNestedOneWithoutBkuImportsInput
    bpuGroups?: BPUGroupCreateNestedManyWithoutBkuImportInput
  }

  export type BKUImportUncheckedCreateWithoutRowsInput = {
    id?: string
    schoolId: string
    month: number
    year: number
    sourceFileName: string
    status?: $Enums.BKUImportStatus
    importedAt?: Date | string
    bpuGroups?: BPUGroupUncheckedCreateNestedManyWithoutBkuImportInput
  }

  export type BKUImportCreateOrConnectWithoutRowsInput = {
    where: BKUImportWhereUniqueInput
    create: XOR<BKUImportCreateWithoutRowsInput, BKUImportUncheckedCreateWithoutRowsInput>
  }

  export type BKUImportUpsertWithoutRowsInput = {
    update: XOR<BKUImportUpdateWithoutRowsInput, BKUImportUncheckedUpdateWithoutRowsInput>
    create: XOR<BKUImportCreateWithoutRowsInput, BKUImportUncheckedCreateWithoutRowsInput>
    where?: BKUImportWhereInput
  }

  export type BKUImportUpdateToOneWithWhereWithoutRowsInput = {
    where?: BKUImportWhereInput
    data: XOR<BKUImportUpdateWithoutRowsInput, BKUImportUncheckedUpdateWithoutRowsInput>
  }

  export type BKUImportUpdateWithoutRowsInput = {
    id?: StringFieldUpdateOperationsInput | string
    month?: IntFieldUpdateOperationsInput | number
    year?: IntFieldUpdateOperationsInput | number
    sourceFileName?: StringFieldUpdateOperationsInput | string
    status?: EnumBKUImportStatusFieldUpdateOperationsInput | $Enums.BKUImportStatus
    importedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    school?: SchoolUpdateOneRequiredWithoutBkuImportsNestedInput
    bpuGroups?: BPUGroupUpdateManyWithoutBkuImportNestedInput
  }

  export type BKUImportUncheckedUpdateWithoutRowsInput = {
    id?: StringFieldUpdateOperationsInput | string
    schoolId?: StringFieldUpdateOperationsInput | string
    month?: IntFieldUpdateOperationsInput | number
    year?: IntFieldUpdateOperationsInput | number
    sourceFileName?: StringFieldUpdateOperationsInput | string
    status?: EnumBKUImportStatusFieldUpdateOperationsInput | $Enums.BKUImportStatus
    importedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    bpuGroups?: BPUGroupUncheckedUpdateManyWithoutBkuImportNestedInput
  }

  export type BKUImportCreateWithoutBpuGroupsInput = {
    id?: string
    month: number
    year: number
    sourceFileName: string
    status?: $Enums.BKUImportStatus
    importedAt?: Date | string
    school: SchoolCreateNestedOneWithoutBkuImportsInput
    rows?: BKURowCreateNestedManyWithoutBkuImportInput
  }

  export type BKUImportUncheckedCreateWithoutBpuGroupsInput = {
    id?: string
    schoolId: string
    month: number
    year: number
    sourceFileName: string
    status?: $Enums.BKUImportStatus
    importedAt?: Date | string
    rows?: BKURowUncheckedCreateNestedManyWithoutBkuImportInput
  }

  export type BKUImportCreateOrConnectWithoutBpuGroupsInput = {
    where: BKUImportWhereUniqueInput
    create: XOR<BKUImportCreateWithoutBpuGroupsInput, BKUImportUncheckedCreateWithoutBpuGroupsInput>
  }

  export type VendorRuleCreateWithoutBpuGroupsInput = {
    id?: string
    keyword: string
    recipient: string
    paymentPrefix: string
    matchKodeKegiatan?: string | null
    formatType?: $Enums.VendorRuleFormatType
    isHonor?: boolean
    isTransport?: boolean
    priority?: number
    isActive?: boolean
    createdAt?: Date | string
    updatedAt?: Date | string
    school: SchoolCreateNestedOneWithoutVendorRulesInput
  }

  export type VendorRuleUncheckedCreateWithoutBpuGroupsInput = {
    id?: string
    schoolId: string
    keyword: string
    recipient: string
    paymentPrefix: string
    matchKodeKegiatan?: string | null
    formatType?: $Enums.VendorRuleFormatType
    isHonor?: boolean
    isTransport?: boolean
    priority?: number
    isActive?: boolean
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type VendorRuleCreateOrConnectWithoutBpuGroupsInput = {
    where: VendorRuleWhereUniqueInput
    create: XOR<VendorRuleCreateWithoutBpuGroupsInput, VendorRuleUncheckedCreateWithoutBpuGroupsInput>
  }

  export type SPMDocumentCreateWithoutBpuGroupInput = {
    id?: string
    nomorSurat: string
    recipient: string
    amount: number
    terbilang: string
    paymentFor: string
    filePath: string
    generatedAt?: Date | string
  }

  export type SPMDocumentUncheckedCreateWithoutBpuGroupInput = {
    id?: string
    nomorSurat: string
    recipient: string
    amount: number
    terbilang: string
    paymentFor: string
    filePath: string
    generatedAt?: Date | string
  }

  export type SPMDocumentCreateOrConnectWithoutBpuGroupInput = {
    where: SPMDocumentWhereUniqueInput
    create: XOR<SPMDocumentCreateWithoutBpuGroupInput, SPMDocumentUncheckedCreateWithoutBpuGroupInput>
  }

  export type BKUImportUpsertWithoutBpuGroupsInput = {
    update: XOR<BKUImportUpdateWithoutBpuGroupsInput, BKUImportUncheckedUpdateWithoutBpuGroupsInput>
    create: XOR<BKUImportCreateWithoutBpuGroupsInput, BKUImportUncheckedCreateWithoutBpuGroupsInput>
    where?: BKUImportWhereInput
  }

  export type BKUImportUpdateToOneWithWhereWithoutBpuGroupsInput = {
    where?: BKUImportWhereInput
    data: XOR<BKUImportUpdateWithoutBpuGroupsInput, BKUImportUncheckedUpdateWithoutBpuGroupsInput>
  }

  export type BKUImportUpdateWithoutBpuGroupsInput = {
    id?: StringFieldUpdateOperationsInput | string
    month?: IntFieldUpdateOperationsInput | number
    year?: IntFieldUpdateOperationsInput | number
    sourceFileName?: StringFieldUpdateOperationsInput | string
    status?: EnumBKUImportStatusFieldUpdateOperationsInput | $Enums.BKUImportStatus
    importedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    school?: SchoolUpdateOneRequiredWithoutBkuImportsNestedInput
    rows?: BKURowUpdateManyWithoutBkuImportNestedInput
  }

  export type BKUImportUncheckedUpdateWithoutBpuGroupsInput = {
    id?: StringFieldUpdateOperationsInput | string
    schoolId?: StringFieldUpdateOperationsInput | string
    month?: IntFieldUpdateOperationsInput | number
    year?: IntFieldUpdateOperationsInput | number
    sourceFileName?: StringFieldUpdateOperationsInput | string
    status?: EnumBKUImportStatusFieldUpdateOperationsInput | $Enums.BKUImportStatus
    importedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    rows?: BKURowUncheckedUpdateManyWithoutBkuImportNestedInput
  }

  export type VendorRuleUpsertWithoutBpuGroupsInput = {
    update: XOR<VendorRuleUpdateWithoutBpuGroupsInput, VendorRuleUncheckedUpdateWithoutBpuGroupsInput>
    create: XOR<VendorRuleCreateWithoutBpuGroupsInput, VendorRuleUncheckedCreateWithoutBpuGroupsInput>
    where?: VendorRuleWhereInput
  }

  export type VendorRuleUpdateToOneWithWhereWithoutBpuGroupsInput = {
    where?: VendorRuleWhereInput
    data: XOR<VendorRuleUpdateWithoutBpuGroupsInput, VendorRuleUncheckedUpdateWithoutBpuGroupsInput>
  }

  export type VendorRuleUpdateWithoutBpuGroupsInput = {
    id?: StringFieldUpdateOperationsInput | string
    keyword?: StringFieldUpdateOperationsInput | string
    recipient?: StringFieldUpdateOperationsInput | string
    paymentPrefix?: StringFieldUpdateOperationsInput | string
    matchKodeKegiatan?: NullableStringFieldUpdateOperationsInput | string | null
    formatType?: EnumVendorRuleFormatTypeFieldUpdateOperationsInput | $Enums.VendorRuleFormatType
    isHonor?: BoolFieldUpdateOperationsInput | boolean
    isTransport?: BoolFieldUpdateOperationsInput | boolean
    priority?: IntFieldUpdateOperationsInput | number
    isActive?: BoolFieldUpdateOperationsInput | boolean
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    school?: SchoolUpdateOneRequiredWithoutVendorRulesNestedInput
  }

  export type VendorRuleUncheckedUpdateWithoutBpuGroupsInput = {
    id?: StringFieldUpdateOperationsInput | string
    schoolId?: StringFieldUpdateOperationsInput | string
    keyword?: StringFieldUpdateOperationsInput | string
    recipient?: StringFieldUpdateOperationsInput | string
    paymentPrefix?: StringFieldUpdateOperationsInput | string
    matchKodeKegiatan?: NullableStringFieldUpdateOperationsInput | string | null
    formatType?: EnumVendorRuleFormatTypeFieldUpdateOperationsInput | $Enums.VendorRuleFormatType
    isHonor?: BoolFieldUpdateOperationsInput | boolean
    isTransport?: BoolFieldUpdateOperationsInput | boolean
    priority?: IntFieldUpdateOperationsInput | number
    isActive?: BoolFieldUpdateOperationsInput | boolean
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type SPMDocumentUpsertWithoutBpuGroupInput = {
    update: XOR<SPMDocumentUpdateWithoutBpuGroupInput, SPMDocumentUncheckedUpdateWithoutBpuGroupInput>
    create: XOR<SPMDocumentCreateWithoutBpuGroupInput, SPMDocumentUncheckedCreateWithoutBpuGroupInput>
    where?: SPMDocumentWhereInput
  }

  export type SPMDocumentUpdateToOneWithWhereWithoutBpuGroupInput = {
    where?: SPMDocumentWhereInput
    data: XOR<SPMDocumentUpdateWithoutBpuGroupInput, SPMDocumentUncheckedUpdateWithoutBpuGroupInput>
  }

  export type SPMDocumentUpdateWithoutBpuGroupInput = {
    id?: StringFieldUpdateOperationsInput | string
    nomorSurat?: StringFieldUpdateOperationsInput | string
    recipient?: StringFieldUpdateOperationsInput | string
    amount?: IntFieldUpdateOperationsInput | number
    terbilang?: StringFieldUpdateOperationsInput | string
    paymentFor?: StringFieldUpdateOperationsInput | string
    filePath?: StringFieldUpdateOperationsInput | string
    generatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type SPMDocumentUncheckedUpdateWithoutBpuGroupInput = {
    id?: StringFieldUpdateOperationsInput | string
    nomorSurat?: StringFieldUpdateOperationsInput | string
    recipient?: StringFieldUpdateOperationsInput | string
    amount?: IntFieldUpdateOperationsInput | number
    terbilang?: StringFieldUpdateOperationsInput | string
    paymentFor?: StringFieldUpdateOperationsInput | string
    filePath?: StringFieldUpdateOperationsInput | string
    generatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type BPUGroupCreateWithoutSpmDocumentInput = {
    id?: string
    bpuCode: string
    bpuNumber: number
    tanggal: Date | string
    totalAmount: number
    overrideRecipient?: string | null
    overridePaymentFor?: string | null
    status?: $Enums.BPUGroupStatus
    createdAt?: Date | string
    updatedAt?: Date | string
    bkuImport: BKUImportCreateNestedOneWithoutBpuGroupsInput
    matchedVendorRule?: VendorRuleCreateNestedOneWithoutBpuGroupsInput
  }

  export type BPUGroupUncheckedCreateWithoutSpmDocumentInput = {
    id?: string
    bkuImportId: string
    bpuCode: string
    bpuNumber: number
    tanggal: Date | string
    totalAmount: number
    matchedVendorRuleId?: string | null
    overrideRecipient?: string | null
    overridePaymentFor?: string | null
    status?: $Enums.BPUGroupStatus
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type BPUGroupCreateOrConnectWithoutSpmDocumentInput = {
    where: BPUGroupWhereUniqueInput
    create: XOR<BPUGroupCreateWithoutSpmDocumentInput, BPUGroupUncheckedCreateWithoutSpmDocumentInput>
  }

  export type BPUGroupUpsertWithoutSpmDocumentInput = {
    update: XOR<BPUGroupUpdateWithoutSpmDocumentInput, BPUGroupUncheckedUpdateWithoutSpmDocumentInput>
    create: XOR<BPUGroupCreateWithoutSpmDocumentInput, BPUGroupUncheckedCreateWithoutSpmDocumentInput>
    where?: BPUGroupWhereInput
  }

  export type BPUGroupUpdateToOneWithWhereWithoutSpmDocumentInput = {
    where?: BPUGroupWhereInput
    data: XOR<BPUGroupUpdateWithoutSpmDocumentInput, BPUGroupUncheckedUpdateWithoutSpmDocumentInput>
  }

  export type BPUGroupUpdateWithoutSpmDocumentInput = {
    id?: StringFieldUpdateOperationsInput | string
    bpuCode?: StringFieldUpdateOperationsInput | string
    bpuNumber?: IntFieldUpdateOperationsInput | number
    tanggal?: DateTimeFieldUpdateOperationsInput | Date | string
    totalAmount?: IntFieldUpdateOperationsInput | number
    overrideRecipient?: NullableStringFieldUpdateOperationsInput | string | null
    overridePaymentFor?: NullableStringFieldUpdateOperationsInput | string | null
    status?: EnumBPUGroupStatusFieldUpdateOperationsInput | $Enums.BPUGroupStatus
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    bkuImport?: BKUImportUpdateOneRequiredWithoutBpuGroupsNestedInput
    matchedVendorRule?: VendorRuleUpdateOneWithoutBpuGroupsNestedInput
  }

  export type BPUGroupUncheckedUpdateWithoutSpmDocumentInput = {
    id?: StringFieldUpdateOperationsInput | string
    bkuImportId?: StringFieldUpdateOperationsInput | string
    bpuCode?: StringFieldUpdateOperationsInput | string
    bpuNumber?: IntFieldUpdateOperationsInput | number
    tanggal?: DateTimeFieldUpdateOperationsInput | Date | string
    totalAmount?: IntFieldUpdateOperationsInput | number
    matchedVendorRuleId?: NullableStringFieldUpdateOperationsInput | string | null
    overrideRecipient?: NullableStringFieldUpdateOperationsInput | string | null
    overridePaymentFor?: NullableStringFieldUpdateOperationsInput | string | null
    status?: EnumBPUGroupStatusFieldUpdateOperationsInput | $Enums.BPUGroupStatus
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type SchoolCreateWithoutRkasImportsInput = {
    id?: string
    name: string
    kopHeaderLine?: string | null
    npsn?: string | null
    address: string
    contact?: string | null
    formatCode: string
    kepalaName: string
    kepalaJabatan: string
    openingSentenceTemplate?: string
    atasDasarLine1?: string
    atasDasarLine2?: string
    honorRecapTitle?: string | null
    frazaListrikCustomerId?: string | null
    frazaInternetCustomerId?: string | null
    logoPath?: string | null
    regionalLogoPath?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    vendorRules?: VendorRuleCreateNestedManyWithoutSchoolInput
    bkuImports?: BKUImportCreateNestedManyWithoutSchoolInput
    instrumenBosp?: InstrumenBospCreateNestedManyWithoutSchoolInput
  }

  export type SchoolUncheckedCreateWithoutRkasImportsInput = {
    id?: string
    name: string
    kopHeaderLine?: string | null
    npsn?: string | null
    address: string
    contact?: string | null
    formatCode: string
    kepalaName: string
    kepalaJabatan: string
    openingSentenceTemplate?: string
    atasDasarLine1?: string
    atasDasarLine2?: string
    honorRecapTitle?: string | null
    frazaListrikCustomerId?: string | null
    frazaInternetCustomerId?: string | null
    logoPath?: string | null
    regionalLogoPath?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    vendorRules?: VendorRuleUncheckedCreateNestedManyWithoutSchoolInput
    bkuImports?: BKUImportUncheckedCreateNestedManyWithoutSchoolInput
    instrumenBosp?: InstrumenBospUncheckedCreateNestedManyWithoutSchoolInput
  }

  export type SchoolCreateOrConnectWithoutRkasImportsInput = {
    where: SchoolWhereUniqueInput
    create: XOR<SchoolCreateWithoutRkasImportsInput, SchoolUncheckedCreateWithoutRkasImportsInput>
  }

  export type RkasProgramCreateWithoutRkasImportInput = {
    id?: string
    urutan: number
    kodeProgram: string
    nama: string
    standarName?: string
    kegiatanName?: string
    included?: boolean
    items?: RkasItemCreateNestedManyWithoutRkasProgramInput
  }

  export type RkasProgramUncheckedCreateWithoutRkasImportInput = {
    id?: string
    urutan: number
    kodeProgram: string
    nama: string
    standarName?: string
    kegiatanName?: string
    included?: boolean
    items?: RkasItemUncheckedCreateNestedManyWithoutRkasProgramInput
  }

  export type RkasProgramCreateOrConnectWithoutRkasImportInput = {
    where: RkasProgramWhereUniqueInput
    create: XOR<RkasProgramCreateWithoutRkasImportInput, RkasProgramUncheckedCreateWithoutRkasImportInput>
  }

  export type RkasProgramCreateManyRkasImportInputEnvelope = {
    data: RkasProgramCreateManyRkasImportInput | RkasProgramCreateManyRkasImportInput[]
  }

  export type SchoolUpsertWithoutRkasImportsInput = {
    update: XOR<SchoolUpdateWithoutRkasImportsInput, SchoolUncheckedUpdateWithoutRkasImportsInput>
    create: XOR<SchoolCreateWithoutRkasImportsInput, SchoolUncheckedCreateWithoutRkasImportsInput>
    where?: SchoolWhereInput
  }

  export type SchoolUpdateToOneWithWhereWithoutRkasImportsInput = {
    where?: SchoolWhereInput
    data: XOR<SchoolUpdateWithoutRkasImportsInput, SchoolUncheckedUpdateWithoutRkasImportsInput>
  }

  export type SchoolUpdateWithoutRkasImportsInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    kopHeaderLine?: NullableStringFieldUpdateOperationsInput | string | null
    npsn?: NullableStringFieldUpdateOperationsInput | string | null
    address?: StringFieldUpdateOperationsInput | string
    contact?: NullableStringFieldUpdateOperationsInput | string | null
    formatCode?: StringFieldUpdateOperationsInput | string
    kepalaName?: StringFieldUpdateOperationsInput | string
    kepalaJabatan?: StringFieldUpdateOperationsInput | string
    openingSentenceTemplate?: StringFieldUpdateOperationsInput | string
    atasDasarLine1?: StringFieldUpdateOperationsInput | string
    atasDasarLine2?: StringFieldUpdateOperationsInput | string
    honorRecapTitle?: NullableStringFieldUpdateOperationsInput | string | null
    frazaListrikCustomerId?: NullableStringFieldUpdateOperationsInput | string | null
    frazaInternetCustomerId?: NullableStringFieldUpdateOperationsInput | string | null
    logoPath?: NullableStringFieldUpdateOperationsInput | string | null
    regionalLogoPath?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    vendorRules?: VendorRuleUpdateManyWithoutSchoolNestedInput
    bkuImports?: BKUImportUpdateManyWithoutSchoolNestedInput
    instrumenBosp?: InstrumenBospUpdateManyWithoutSchoolNestedInput
  }

  export type SchoolUncheckedUpdateWithoutRkasImportsInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    kopHeaderLine?: NullableStringFieldUpdateOperationsInput | string | null
    npsn?: NullableStringFieldUpdateOperationsInput | string | null
    address?: StringFieldUpdateOperationsInput | string
    contact?: NullableStringFieldUpdateOperationsInput | string | null
    formatCode?: StringFieldUpdateOperationsInput | string
    kepalaName?: StringFieldUpdateOperationsInput | string
    kepalaJabatan?: StringFieldUpdateOperationsInput | string
    openingSentenceTemplate?: StringFieldUpdateOperationsInput | string
    atasDasarLine1?: StringFieldUpdateOperationsInput | string
    atasDasarLine2?: StringFieldUpdateOperationsInput | string
    honorRecapTitle?: NullableStringFieldUpdateOperationsInput | string | null
    frazaListrikCustomerId?: NullableStringFieldUpdateOperationsInput | string | null
    frazaInternetCustomerId?: NullableStringFieldUpdateOperationsInput | string | null
    logoPath?: NullableStringFieldUpdateOperationsInput | string | null
    regionalLogoPath?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    vendorRules?: VendorRuleUncheckedUpdateManyWithoutSchoolNestedInput
    bkuImports?: BKUImportUncheckedUpdateManyWithoutSchoolNestedInput
    instrumenBosp?: InstrumenBospUncheckedUpdateManyWithoutSchoolNestedInput
  }

  export type RkasProgramUpsertWithWhereUniqueWithoutRkasImportInput = {
    where: RkasProgramWhereUniqueInput
    update: XOR<RkasProgramUpdateWithoutRkasImportInput, RkasProgramUncheckedUpdateWithoutRkasImportInput>
    create: XOR<RkasProgramCreateWithoutRkasImportInput, RkasProgramUncheckedCreateWithoutRkasImportInput>
  }

  export type RkasProgramUpdateWithWhereUniqueWithoutRkasImportInput = {
    where: RkasProgramWhereUniqueInput
    data: XOR<RkasProgramUpdateWithoutRkasImportInput, RkasProgramUncheckedUpdateWithoutRkasImportInput>
  }

  export type RkasProgramUpdateManyWithWhereWithoutRkasImportInput = {
    where: RkasProgramScalarWhereInput
    data: XOR<RkasProgramUpdateManyMutationInput, RkasProgramUncheckedUpdateManyWithoutRkasImportInput>
  }

  export type RkasProgramScalarWhereInput = {
    AND?: RkasProgramScalarWhereInput | RkasProgramScalarWhereInput[]
    OR?: RkasProgramScalarWhereInput[]
    NOT?: RkasProgramScalarWhereInput | RkasProgramScalarWhereInput[]
    id?: StringFilter<"RkasProgram"> | string
    rkasImportId?: StringFilter<"RkasProgram"> | string
    urutan?: IntFilter<"RkasProgram"> | number
    kodeProgram?: StringFilter<"RkasProgram"> | string
    nama?: StringFilter<"RkasProgram"> | string
    standarName?: StringFilter<"RkasProgram"> | string
    kegiatanName?: StringFilter<"RkasProgram"> | string
    included?: BoolFilter<"RkasProgram"> | boolean
  }

  export type RkasImportCreateWithoutProgramsInput = {
    id?: string
    month: number
    year: number
    sourceFileName: string
    sourceSchoolName?: string | null
    npsn?: string | null
    namaPelaksana?: string
    programLabel?: string
    namaKegiatan?: string
    sumberDana?: string
    pekerjaanLabel?: string
    kepalaName?: string
    bendaharaName?: string
    importedAt?: Date | string
    updatedAt?: Date | string
    school: SchoolCreateNestedOneWithoutRkasImportsInput
  }

  export type RkasImportUncheckedCreateWithoutProgramsInput = {
    id?: string
    schoolId: string
    month: number
    year: number
    sourceFileName: string
    sourceSchoolName?: string | null
    npsn?: string | null
    namaPelaksana?: string
    programLabel?: string
    namaKegiatan?: string
    sumberDana?: string
    pekerjaanLabel?: string
    kepalaName?: string
    bendaharaName?: string
    importedAt?: Date | string
    updatedAt?: Date | string
  }

  export type RkasImportCreateOrConnectWithoutProgramsInput = {
    where: RkasImportWhereUniqueInput
    create: XOR<RkasImportCreateWithoutProgramsInput, RkasImportUncheckedCreateWithoutProgramsInput>
  }

  export type RkasItemCreateWithoutRkasProgramInput = {
    id?: string
    urutan: number
    noUrut: number
    kodeRekening: string
    uraian: string
    volumeText: string
    tarifHarga: number
    jumlah: number
    excluded?: boolean
  }

  export type RkasItemUncheckedCreateWithoutRkasProgramInput = {
    id?: string
    urutan: number
    noUrut: number
    kodeRekening: string
    uraian: string
    volumeText: string
    tarifHarga: number
    jumlah: number
    excluded?: boolean
  }

  export type RkasItemCreateOrConnectWithoutRkasProgramInput = {
    where: RkasItemWhereUniqueInput
    create: XOR<RkasItemCreateWithoutRkasProgramInput, RkasItemUncheckedCreateWithoutRkasProgramInput>
  }

  export type RkasItemCreateManyRkasProgramInputEnvelope = {
    data: RkasItemCreateManyRkasProgramInput | RkasItemCreateManyRkasProgramInput[]
  }

  export type RkasImportUpsertWithoutProgramsInput = {
    update: XOR<RkasImportUpdateWithoutProgramsInput, RkasImportUncheckedUpdateWithoutProgramsInput>
    create: XOR<RkasImportCreateWithoutProgramsInput, RkasImportUncheckedCreateWithoutProgramsInput>
    where?: RkasImportWhereInput
  }

  export type RkasImportUpdateToOneWithWhereWithoutProgramsInput = {
    where?: RkasImportWhereInput
    data: XOR<RkasImportUpdateWithoutProgramsInput, RkasImportUncheckedUpdateWithoutProgramsInput>
  }

  export type RkasImportUpdateWithoutProgramsInput = {
    id?: StringFieldUpdateOperationsInput | string
    month?: IntFieldUpdateOperationsInput | number
    year?: IntFieldUpdateOperationsInput | number
    sourceFileName?: StringFieldUpdateOperationsInput | string
    sourceSchoolName?: NullableStringFieldUpdateOperationsInput | string | null
    npsn?: NullableStringFieldUpdateOperationsInput | string | null
    namaPelaksana?: StringFieldUpdateOperationsInput | string
    programLabel?: StringFieldUpdateOperationsInput | string
    namaKegiatan?: StringFieldUpdateOperationsInput | string
    sumberDana?: StringFieldUpdateOperationsInput | string
    pekerjaanLabel?: StringFieldUpdateOperationsInput | string
    kepalaName?: StringFieldUpdateOperationsInput | string
    bendaharaName?: StringFieldUpdateOperationsInput | string
    importedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    school?: SchoolUpdateOneRequiredWithoutRkasImportsNestedInput
  }

  export type RkasImportUncheckedUpdateWithoutProgramsInput = {
    id?: StringFieldUpdateOperationsInput | string
    schoolId?: StringFieldUpdateOperationsInput | string
    month?: IntFieldUpdateOperationsInput | number
    year?: IntFieldUpdateOperationsInput | number
    sourceFileName?: StringFieldUpdateOperationsInput | string
    sourceSchoolName?: NullableStringFieldUpdateOperationsInput | string | null
    npsn?: NullableStringFieldUpdateOperationsInput | string | null
    namaPelaksana?: StringFieldUpdateOperationsInput | string
    programLabel?: StringFieldUpdateOperationsInput | string
    namaKegiatan?: StringFieldUpdateOperationsInput | string
    sumberDana?: StringFieldUpdateOperationsInput | string
    pekerjaanLabel?: StringFieldUpdateOperationsInput | string
    kepalaName?: StringFieldUpdateOperationsInput | string
    bendaharaName?: StringFieldUpdateOperationsInput | string
    importedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type RkasItemUpsertWithWhereUniqueWithoutRkasProgramInput = {
    where: RkasItemWhereUniqueInput
    update: XOR<RkasItemUpdateWithoutRkasProgramInput, RkasItemUncheckedUpdateWithoutRkasProgramInput>
    create: XOR<RkasItemCreateWithoutRkasProgramInput, RkasItemUncheckedCreateWithoutRkasProgramInput>
  }

  export type RkasItemUpdateWithWhereUniqueWithoutRkasProgramInput = {
    where: RkasItemWhereUniqueInput
    data: XOR<RkasItemUpdateWithoutRkasProgramInput, RkasItemUncheckedUpdateWithoutRkasProgramInput>
  }

  export type RkasItemUpdateManyWithWhereWithoutRkasProgramInput = {
    where: RkasItemScalarWhereInput
    data: XOR<RkasItemUpdateManyMutationInput, RkasItemUncheckedUpdateManyWithoutRkasProgramInput>
  }

  export type RkasItemScalarWhereInput = {
    AND?: RkasItemScalarWhereInput | RkasItemScalarWhereInput[]
    OR?: RkasItemScalarWhereInput[]
    NOT?: RkasItemScalarWhereInput | RkasItemScalarWhereInput[]
    id?: StringFilter<"RkasItem"> | string
    rkasProgramId?: StringFilter<"RkasItem"> | string
    urutan?: IntFilter<"RkasItem"> | number
    noUrut?: IntFilter<"RkasItem"> | number
    kodeRekening?: StringFilter<"RkasItem"> | string
    uraian?: StringFilter<"RkasItem"> | string
    volumeText?: StringFilter<"RkasItem"> | string
    tarifHarga?: IntFilter<"RkasItem"> | number
    jumlah?: IntFilter<"RkasItem"> | number
    excluded?: BoolFilter<"RkasItem"> | boolean
  }

  export type RkasProgramCreateWithoutItemsInput = {
    id?: string
    urutan: number
    kodeProgram: string
    nama: string
    standarName?: string
    kegiatanName?: string
    included?: boolean
    rkasImport: RkasImportCreateNestedOneWithoutProgramsInput
  }

  export type RkasProgramUncheckedCreateWithoutItemsInput = {
    id?: string
    rkasImportId: string
    urutan: number
    kodeProgram: string
    nama: string
    standarName?: string
    kegiatanName?: string
    included?: boolean
  }

  export type RkasProgramCreateOrConnectWithoutItemsInput = {
    where: RkasProgramWhereUniqueInput
    create: XOR<RkasProgramCreateWithoutItemsInput, RkasProgramUncheckedCreateWithoutItemsInput>
  }

  export type RkasProgramUpsertWithoutItemsInput = {
    update: XOR<RkasProgramUpdateWithoutItemsInput, RkasProgramUncheckedUpdateWithoutItemsInput>
    create: XOR<RkasProgramCreateWithoutItemsInput, RkasProgramUncheckedCreateWithoutItemsInput>
    where?: RkasProgramWhereInput
  }

  export type RkasProgramUpdateToOneWithWhereWithoutItemsInput = {
    where?: RkasProgramWhereInput
    data: XOR<RkasProgramUpdateWithoutItemsInput, RkasProgramUncheckedUpdateWithoutItemsInput>
  }

  export type RkasProgramUpdateWithoutItemsInput = {
    id?: StringFieldUpdateOperationsInput | string
    urutan?: IntFieldUpdateOperationsInput | number
    kodeProgram?: StringFieldUpdateOperationsInput | string
    nama?: StringFieldUpdateOperationsInput | string
    standarName?: StringFieldUpdateOperationsInput | string
    kegiatanName?: StringFieldUpdateOperationsInput | string
    included?: BoolFieldUpdateOperationsInput | boolean
    rkasImport?: RkasImportUpdateOneRequiredWithoutProgramsNestedInput
  }

  export type RkasProgramUncheckedUpdateWithoutItemsInput = {
    id?: StringFieldUpdateOperationsInput | string
    rkasImportId?: StringFieldUpdateOperationsInput | string
    urutan?: IntFieldUpdateOperationsInput | number
    kodeProgram?: StringFieldUpdateOperationsInput | string
    nama?: StringFieldUpdateOperationsInput | string
    standarName?: StringFieldUpdateOperationsInput | string
    kegiatanName?: StringFieldUpdateOperationsInput | string
    included?: BoolFieldUpdateOperationsInput | boolean
  }

  export type SchoolCreateWithoutInstrumenBospInput = {
    id?: string
    name: string
    kopHeaderLine?: string | null
    npsn?: string | null
    address: string
    contact?: string | null
    formatCode: string
    kepalaName: string
    kepalaJabatan: string
    openingSentenceTemplate?: string
    atasDasarLine1?: string
    atasDasarLine2?: string
    honorRecapTitle?: string | null
    frazaListrikCustomerId?: string | null
    frazaInternetCustomerId?: string | null
    logoPath?: string | null
    regionalLogoPath?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    vendorRules?: VendorRuleCreateNestedManyWithoutSchoolInput
    bkuImports?: BKUImportCreateNestedManyWithoutSchoolInput
    rkasImports?: RkasImportCreateNestedManyWithoutSchoolInput
  }

  export type SchoolUncheckedCreateWithoutInstrumenBospInput = {
    id?: string
    name: string
    kopHeaderLine?: string | null
    npsn?: string | null
    address: string
    contact?: string | null
    formatCode: string
    kepalaName: string
    kepalaJabatan: string
    openingSentenceTemplate?: string
    atasDasarLine1?: string
    atasDasarLine2?: string
    honorRecapTitle?: string | null
    frazaListrikCustomerId?: string | null
    frazaInternetCustomerId?: string | null
    logoPath?: string | null
    regionalLogoPath?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    vendorRules?: VendorRuleUncheckedCreateNestedManyWithoutSchoolInput
    bkuImports?: BKUImportUncheckedCreateNestedManyWithoutSchoolInput
    rkasImports?: RkasImportUncheckedCreateNestedManyWithoutSchoolInput
  }

  export type SchoolCreateOrConnectWithoutInstrumenBospInput = {
    where: SchoolWhereUniqueInput
    create: XOR<SchoolCreateWithoutInstrumenBospInput, SchoolUncheckedCreateWithoutInstrumenBospInput>
  }

  export type SchoolUpsertWithoutInstrumenBospInput = {
    update: XOR<SchoolUpdateWithoutInstrumenBospInput, SchoolUncheckedUpdateWithoutInstrumenBospInput>
    create: XOR<SchoolCreateWithoutInstrumenBospInput, SchoolUncheckedCreateWithoutInstrumenBospInput>
    where?: SchoolWhereInput
  }

  export type SchoolUpdateToOneWithWhereWithoutInstrumenBospInput = {
    where?: SchoolWhereInput
    data: XOR<SchoolUpdateWithoutInstrumenBospInput, SchoolUncheckedUpdateWithoutInstrumenBospInput>
  }

  export type SchoolUpdateWithoutInstrumenBospInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    kopHeaderLine?: NullableStringFieldUpdateOperationsInput | string | null
    npsn?: NullableStringFieldUpdateOperationsInput | string | null
    address?: StringFieldUpdateOperationsInput | string
    contact?: NullableStringFieldUpdateOperationsInput | string | null
    formatCode?: StringFieldUpdateOperationsInput | string
    kepalaName?: StringFieldUpdateOperationsInput | string
    kepalaJabatan?: StringFieldUpdateOperationsInput | string
    openingSentenceTemplate?: StringFieldUpdateOperationsInput | string
    atasDasarLine1?: StringFieldUpdateOperationsInput | string
    atasDasarLine2?: StringFieldUpdateOperationsInput | string
    honorRecapTitle?: NullableStringFieldUpdateOperationsInput | string | null
    frazaListrikCustomerId?: NullableStringFieldUpdateOperationsInput | string | null
    frazaInternetCustomerId?: NullableStringFieldUpdateOperationsInput | string | null
    logoPath?: NullableStringFieldUpdateOperationsInput | string | null
    regionalLogoPath?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    vendorRules?: VendorRuleUpdateManyWithoutSchoolNestedInput
    bkuImports?: BKUImportUpdateManyWithoutSchoolNestedInput
    rkasImports?: RkasImportUpdateManyWithoutSchoolNestedInput
  }

  export type SchoolUncheckedUpdateWithoutInstrumenBospInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    kopHeaderLine?: NullableStringFieldUpdateOperationsInput | string | null
    npsn?: NullableStringFieldUpdateOperationsInput | string | null
    address?: StringFieldUpdateOperationsInput | string
    contact?: NullableStringFieldUpdateOperationsInput | string | null
    formatCode?: StringFieldUpdateOperationsInput | string
    kepalaName?: StringFieldUpdateOperationsInput | string
    kepalaJabatan?: StringFieldUpdateOperationsInput | string
    openingSentenceTemplate?: StringFieldUpdateOperationsInput | string
    atasDasarLine1?: StringFieldUpdateOperationsInput | string
    atasDasarLine2?: StringFieldUpdateOperationsInput | string
    honorRecapTitle?: NullableStringFieldUpdateOperationsInput | string | null
    frazaListrikCustomerId?: NullableStringFieldUpdateOperationsInput | string | null
    frazaInternetCustomerId?: NullableStringFieldUpdateOperationsInput | string | null
    logoPath?: NullableStringFieldUpdateOperationsInput | string | null
    regionalLogoPath?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    vendorRules?: VendorRuleUncheckedUpdateManyWithoutSchoolNestedInput
    bkuImports?: BKUImportUncheckedUpdateManyWithoutSchoolNestedInput
    rkasImports?: RkasImportUncheckedUpdateManyWithoutSchoolNestedInput
  }

  export type VendorRuleCreateManySchoolInput = {
    id?: string
    keyword: string
    recipient: string
    paymentPrefix: string
    matchKodeKegiatan?: string | null
    formatType?: $Enums.VendorRuleFormatType
    isHonor?: boolean
    isTransport?: boolean
    priority?: number
    isActive?: boolean
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type BKUImportCreateManySchoolInput = {
    id?: string
    month: number
    year: number
    sourceFileName: string
    status?: $Enums.BKUImportStatus
    importedAt?: Date | string
  }

  export type RkasImportCreateManySchoolInput = {
    id?: string
    month: number
    year: number
    sourceFileName: string
    sourceSchoolName?: string | null
    npsn?: string | null
    namaPelaksana?: string
    programLabel?: string
    namaKegiatan?: string
    sumberDana?: string
    pekerjaanLabel?: string
    kepalaName?: string
    bendaharaName?: string
    importedAt?: Date | string
    updatedAt?: Date | string
  }

  export type InstrumenBospCreateManySchoolInput = {
    id?: string
    year: number
    tahap: number
    jenisSatuan?: string
    statusSatuan?: string
    kelurahan?: string
    kecamatan?: string
    jenisDanaBosp?: string
    skNomor?: string
    skTanggal?: string
    kepalaName?: string
    bendaharaName?: string
    komiteName?: string
    adaBku?: boolean
    adaBukuPembantuKas?: boolean
    adaBukuPembantuPajak?: boolean
    adaBukuPembantuBank?: boolean
    adaLaporanRealisasi?: boolean
    totalAlokasiTahunan?: number
    saldoAwalOverride?: number | null
    operasionalOverride?: number | null
    honorSesuaiRkas?: boolean
    honorBuktiLengkap?: boolean
    honorPenerimaSesuai?: boolean
    metodePengadaanBuku?: string
    metodePengadaanLain?: string
    belanjaModalJson?: string
    pemeliharaanJson?: string
    bukuOverrideJson?: string
    tanggalDokumen?: string
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type VendorRuleUpdateWithoutSchoolInput = {
    id?: StringFieldUpdateOperationsInput | string
    keyword?: StringFieldUpdateOperationsInput | string
    recipient?: StringFieldUpdateOperationsInput | string
    paymentPrefix?: StringFieldUpdateOperationsInput | string
    matchKodeKegiatan?: NullableStringFieldUpdateOperationsInput | string | null
    formatType?: EnumVendorRuleFormatTypeFieldUpdateOperationsInput | $Enums.VendorRuleFormatType
    isHonor?: BoolFieldUpdateOperationsInput | boolean
    isTransport?: BoolFieldUpdateOperationsInput | boolean
    priority?: IntFieldUpdateOperationsInput | number
    isActive?: BoolFieldUpdateOperationsInput | boolean
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    bpuGroups?: BPUGroupUpdateManyWithoutMatchedVendorRuleNestedInput
  }

  export type VendorRuleUncheckedUpdateWithoutSchoolInput = {
    id?: StringFieldUpdateOperationsInput | string
    keyword?: StringFieldUpdateOperationsInput | string
    recipient?: StringFieldUpdateOperationsInput | string
    paymentPrefix?: StringFieldUpdateOperationsInput | string
    matchKodeKegiatan?: NullableStringFieldUpdateOperationsInput | string | null
    formatType?: EnumVendorRuleFormatTypeFieldUpdateOperationsInput | $Enums.VendorRuleFormatType
    isHonor?: BoolFieldUpdateOperationsInput | boolean
    isTransport?: BoolFieldUpdateOperationsInput | boolean
    priority?: IntFieldUpdateOperationsInput | number
    isActive?: BoolFieldUpdateOperationsInput | boolean
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    bpuGroups?: BPUGroupUncheckedUpdateManyWithoutMatchedVendorRuleNestedInput
  }

  export type VendorRuleUncheckedUpdateManyWithoutSchoolInput = {
    id?: StringFieldUpdateOperationsInput | string
    keyword?: StringFieldUpdateOperationsInput | string
    recipient?: StringFieldUpdateOperationsInput | string
    paymentPrefix?: StringFieldUpdateOperationsInput | string
    matchKodeKegiatan?: NullableStringFieldUpdateOperationsInput | string | null
    formatType?: EnumVendorRuleFormatTypeFieldUpdateOperationsInput | $Enums.VendorRuleFormatType
    isHonor?: BoolFieldUpdateOperationsInput | boolean
    isTransport?: BoolFieldUpdateOperationsInput | boolean
    priority?: IntFieldUpdateOperationsInput | number
    isActive?: BoolFieldUpdateOperationsInput | boolean
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type BKUImportUpdateWithoutSchoolInput = {
    id?: StringFieldUpdateOperationsInput | string
    month?: IntFieldUpdateOperationsInput | number
    year?: IntFieldUpdateOperationsInput | number
    sourceFileName?: StringFieldUpdateOperationsInput | string
    status?: EnumBKUImportStatusFieldUpdateOperationsInput | $Enums.BKUImportStatus
    importedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    rows?: BKURowUpdateManyWithoutBkuImportNestedInput
    bpuGroups?: BPUGroupUpdateManyWithoutBkuImportNestedInput
  }

  export type BKUImportUncheckedUpdateWithoutSchoolInput = {
    id?: StringFieldUpdateOperationsInput | string
    month?: IntFieldUpdateOperationsInput | number
    year?: IntFieldUpdateOperationsInput | number
    sourceFileName?: StringFieldUpdateOperationsInput | string
    status?: EnumBKUImportStatusFieldUpdateOperationsInput | $Enums.BKUImportStatus
    importedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    rows?: BKURowUncheckedUpdateManyWithoutBkuImportNestedInput
    bpuGroups?: BPUGroupUncheckedUpdateManyWithoutBkuImportNestedInput
  }

  export type BKUImportUncheckedUpdateManyWithoutSchoolInput = {
    id?: StringFieldUpdateOperationsInput | string
    month?: IntFieldUpdateOperationsInput | number
    year?: IntFieldUpdateOperationsInput | number
    sourceFileName?: StringFieldUpdateOperationsInput | string
    status?: EnumBKUImportStatusFieldUpdateOperationsInput | $Enums.BKUImportStatus
    importedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type RkasImportUpdateWithoutSchoolInput = {
    id?: StringFieldUpdateOperationsInput | string
    month?: IntFieldUpdateOperationsInput | number
    year?: IntFieldUpdateOperationsInput | number
    sourceFileName?: StringFieldUpdateOperationsInput | string
    sourceSchoolName?: NullableStringFieldUpdateOperationsInput | string | null
    npsn?: NullableStringFieldUpdateOperationsInput | string | null
    namaPelaksana?: StringFieldUpdateOperationsInput | string
    programLabel?: StringFieldUpdateOperationsInput | string
    namaKegiatan?: StringFieldUpdateOperationsInput | string
    sumberDana?: StringFieldUpdateOperationsInput | string
    pekerjaanLabel?: StringFieldUpdateOperationsInput | string
    kepalaName?: StringFieldUpdateOperationsInput | string
    bendaharaName?: StringFieldUpdateOperationsInput | string
    importedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    programs?: RkasProgramUpdateManyWithoutRkasImportNestedInput
  }

  export type RkasImportUncheckedUpdateWithoutSchoolInput = {
    id?: StringFieldUpdateOperationsInput | string
    month?: IntFieldUpdateOperationsInput | number
    year?: IntFieldUpdateOperationsInput | number
    sourceFileName?: StringFieldUpdateOperationsInput | string
    sourceSchoolName?: NullableStringFieldUpdateOperationsInput | string | null
    npsn?: NullableStringFieldUpdateOperationsInput | string | null
    namaPelaksana?: StringFieldUpdateOperationsInput | string
    programLabel?: StringFieldUpdateOperationsInput | string
    namaKegiatan?: StringFieldUpdateOperationsInput | string
    sumberDana?: StringFieldUpdateOperationsInput | string
    pekerjaanLabel?: StringFieldUpdateOperationsInput | string
    kepalaName?: StringFieldUpdateOperationsInput | string
    bendaharaName?: StringFieldUpdateOperationsInput | string
    importedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    programs?: RkasProgramUncheckedUpdateManyWithoutRkasImportNestedInput
  }

  export type RkasImportUncheckedUpdateManyWithoutSchoolInput = {
    id?: StringFieldUpdateOperationsInput | string
    month?: IntFieldUpdateOperationsInput | number
    year?: IntFieldUpdateOperationsInput | number
    sourceFileName?: StringFieldUpdateOperationsInput | string
    sourceSchoolName?: NullableStringFieldUpdateOperationsInput | string | null
    npsn?: NullableStringFieldUpdateOperationsInput | string | null
    namaPelaksana?: StringFieldUpdateOperationsInput | string
    programLabel?: StringFieldUpdateOperationsInput | string
    namaKegiatan?: StringFieldUpdateOperationsInput | string
    sumberDana?: StringFieldUpdateOperationsInput | string
    pekerjaanLabel?: StringFieldUpdateOperationsInput | string
    kepalaName?: StringFieldUpdateOperationsInput | string
    bendaharaName?: StringFieldUpdateOperationsInput | string
    importedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type InstrumenBospUpdateWithoutSchoolInput = {
    id?: StringFieldUpdateOperationsInput | string
    year?: IntFieldUpdateOperationsInput | number
    tahap?: IntFieldUpdateOperationsInput | number
    jenisSatuan?: StringFieldUpdateOperationsInput | string
    statusSatuan?: StringFieldUpdateOperationsInput | string
    kelurahan?: StringFieldUpdateOperationsInput | string
    kecamatan?: StringFieldUpdateOperationsInput | string
    jenisDanaBosp?: StringFieldUpdateOperationsInput | string
    skNomor?: StringFieldUpdateOperationsInput | string
    skTanggal?: StringFieldUpdateOperationsInput | string
    kepalaName?: StringFieldUpdateOperationsInput | string
    bendaharaName?: StringFieldUpdateOperationsInput | string
    komiteName?: StringFieldUpdateOperationsInput | string
    adaBku?: BoolFieldUpdateOperationsInput | boolean
    adaBukuPembantuKas?: BoolFieldUpdateOperationsInput | boolean
    adaBukuPembantuPajak?: BoolFieldUpdateOperationsInput | boolean
    adaBukuPembantuBank?: BoolFieldUpdateOperationsInput | boolean
    adaLaporanRealisasi?: BoolFieldUpdateOperationsInput | boolean
    totalAlokasiTahunan?: IntFieldUpdateOperationsInput | number
    saldoAwalOverride?: NullableIntFieldUpdateOperationsInput | number | null
    operasionalOverride?: NullableIntFieldUpdateOperationsInput | number | null
    honorSesuaiRkas?: BoolFieldUpdateOperationsInput | boolean
    honorBuktiLengkap?: BoolFieldUpdateOperationsInput | boolean
    honorPenerimaSesuai?: BoolFieldUpdateOperationsInput | boolean
    metodePengadaanBuku?: StringFieldUpdateOperationsInput | string
    metodePengadaanLain?: StringFieldUpdateOperationsInput | string
    belanjaModalJson?: StringFieldUpdateOperationsInput | string
    pemeliharaanJson?: StringFieldUpdateOperationsInput | string
    bukuOverrideJson?: StringFieldUpdateOperationsInput | string
    tanggalDokumen?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type InstrumenBospUncheckedUpdateWithoutSchoolInput = {
    id?: StringFieldUpdateOperationsInput | string
    year?: IntFieldUpdateOperationsInput | number
    tahap?: IntFieldUpdateOperationsInput | number
    jenisSatuan?: StringFieldUpdateOperationsInput | string
    statusSatuan?: StringFieldUpdateOperationsInput | string
    kelurahan?: StringFieldUpdateOperationsInput | string
    kecamatan?: StringFieldUpdateOperationsInput | string
    jenisDanaBosp?: StringFieldUpdateOperationsInput | string
    skNomor?: StringFieldUpdateOperationsInput | string
    skTanggal?: StringFieldUpdateOperationsInput | string
    kepalaName?: StringFieldUpdateOperationsInput | string
    bendaharaName?: StringFieldUpdateOperationsInput | string
    komiteName?: StringFieldUpdateOperationsInput | string
    adaBku?: BoolFieldUpdateOperationsInput | boolean
    adaBukuPembantuKas?: BoolFieldUpdateOperationsInput | boolean
    adaBukuPembantuPajak?: BoolFieldUpdateOperationsInput | boolean
    adaBukuPembantuBank?: BoolFieldUpdateOperationsInput | boolean
    adaLaporanRealisasi?: BoolFieldUpdateOperationsInput | boolean
    totalAlokasiTahunan?: IntFieldUpdateOperationsInput | number
    saldoAwalOverride?: NullableIntFieldUpdateOperationsInput | number | null
    operasionalOverride?: NullableIntFieldUpdateOperationsInput | number | null
    honorSesuaiRkas?: BoolFieldUpdateOperationsInput | boolean
    honorBuktiLengkap?: BoolFieldUpdateOperationsInput | boolean
    honorPenerimaSesuai?: BoolFieldUpdateOperationsInput | boolean
    metodePengadaanBuku?: StringFieldUpdateOperationsInput | string
    metodePengadaanLain?: StringFieldUpdateOperationsInput | string
    belanjaModalJson?: StringFieldUpdateOperationsInput | string
    pemeliharaanJson?: StringFieldUpdateOperationsInput | string
    bukuOverrideJson?: StringFieldUpdateOperationsInput | string
    tanggalDokumen?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type InstrumenBospUncheckedUpdateManyWithoutSchoolInput = {
    id?: StringFieldUpdateOperationsInput | string
    year?: IntFieldUpdateOperationsInput | number
    tahap?: IntFieldUpdateOperationsInput | number
    jenisSatuan?: StringFieldUpdateOperationsInput | string
    statusSatuan?: StringFieldUpdateOperationsInput | string
    kelurahan?: StringFieldUpdateOperationsInput | string
    kecamatan?: StringFieldUpdateOperationsInput | string
    jenisDanaBosp?: StringFieldUpdateOperationsInput | string
    skNomor?: StringFieldUpdateOperationsInput | string
    skTanggal?: StringFieldUpdateOperationsInput | string
    kepalaName?: StringFieldUpdateOperationsInput | string
    bendaharaName?: StringFieldUpdateOperationsInput | string
    komiteName?: StringFieldUpdateOperationsInput | string
    adaBku?: BoolFieldUpdateOperationsInput | boolean
    adaBukuPembantuKas?: BoolFieldUpdateOperationsInput | boolean
    adaBukuPembantuPajak?: BoolFieldUpdateOperationsInput | boolean
    adaBukuPembantuBank?: BoolFieldUpdateOperationsInput | boolean
    adaLaporanRealisasi?: BoolFieldUpdateOperationsInput | boolean
    totalAlokasiTahunan?: IntFieldUpdateOperationsInput | number
    saldoAwalOverride?: NullableIntFieldUpdateOperationsInput | number | null
    operasionalOverride?: NullableIntFieldUpdateOperationsInput | number | null
    honorSesuaiRkas?: BoolFieldUpdateOperationsInput | boolean
    honorBuktiLengkap?: BoolFieldUpdateOperationsInput | boolean
    honorPenerimaSesuai?: BoolFieldUpdateOperationsInput | boolean
    metodePengadaanBuku?: StringFieldUpdateOperationsInput | string
    metodePengadaanLain?: StringFieldUpdateOperationsInput | string
    belanjaModalJson?: StringFieldUpdateOperationsInput | string
    pemeliharaanJson?: StringFieldUpdateOperationsInput | string
    bukuOverrideJson?: StringFieldUpdateOperationsInput | string
    tanggalDokumen?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type BPUGroupCreateManyMatchedVendorRuleInput = {
    id?: string
    bkuImportId: string
    bpuCode: string
    bpuNumber: number
    tanggal: Date | string
    totalAmount: number
    overrideRecipient?: string | null
    overridePaymentFor?: string | null
    status?: $Enums.BPUGroupStatus
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type BPUGroupUpdateWithoutMatchedVendorRuleInput = {
    id?: StringFieldUpdateOperationsInput | string
    bpuCode?: StringFieldUpdateOperationsInput | string
    bpuNumber?: IntFieldUpdateOperationsInput | number
    tanggal?: DateTimeFieldUpdateOperationsInput | Date | string
    totalAmount?: IntFieldUpdateOperationsInput | number
    overrideRecipient?: NullableStringFieldUpdateOperationsInput | string | null
    overridePaymentFor?: NullableStringFieldUpdateOperationsInput | string | null
    status?: EnumBPUGroupStatusFieldUpdateOperationsInput | $Enums.BPUGroupStatus
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    bkuImport?: BKUImportUpdateOneRequiredWithoutBpuGroupsNestedInput
    spmDocument?: SPMDocumentUpdateOneWithoutBpuGroupNestedInput
  }

  export type BPUGroupUncheckedUpdateWithoutMatchedVendorRuleInput = {
    id?: StringFieldUpdateOperationsInput | string
    bkuImportId?: StringFieldUpdateOperationsInput | string
    bpuCode?: StringFieldUpdateOperationsInput | string
    bpuNumber?: IntFieldUpdateOperationsInput | number
    tanggal?: DateTimeFieldUpdateOperationsInput | Date | string
    totalAmount?: IntFieldUpdateOperationsInput | number
    overrideRecipient?: NullableStringFieldUpdateOperationsInput | string | null
    overridePaymentFor?: NullableStringFieldUpdateOperationsInput | string | null
    status?: EnumBPUGroupStatusFieldUpdateOperationsInput | $Enums.BPUGroupStatus
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    spmDocument?: SPMDocumentUncheckedUpdateOneWithoutBpuGroupNestedInput
  }

  export type BPUGroupUncheckedUpdateManyWithoutMatchedVendorRuleInput = {
    id?: StringFieldUpdateOperationsInput | string
    bkuImportId?: StringFieldUpdateOperationsInput | string
    bpuCode?: StringFieldUpdateOperationsInput | string
    bpuNumber?: IntFieldUpdateOperationsInput | number
    tanggal?: DateTimeFieldUpdateOperationsInput | Date | string
    totalAmount?: IntFieldUpdateOperationsInput | number
    overrideRecipient?: NullableStringFieldUpdateOperationsInput | string | null
    overridePaymentFor?: NullableStringFieldUpdateOperationsInput | string | null
    status?: EnumBPUGroupStatusFieldUpdateOperationsInput | $Enums.BPUGroupStatus
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type BKURowCreateManyBkuImportInput = {
    id?: string
    tanggal: Date | string
    kodeKegiatan?: string | null
    kodeRekening?: string | null
    bpuCode?: string | null
    bpuNumber?: number | null
    uraian: string
    penerimaan?: number
    pengeluaran?: number
    saldo?: number
    pageIndex?: number | null
    createdAt?: Date | string
  }

  export type BPUGroupCreateManyBkuImportInput = {
    id?: string
    bpuCode: string
    bpuNumber: number
    tanggal: Date | string
    totalAmount: number
    matchedVendorRuleId?: string | null
    overrideRecipient?: string | null
    overridePaymentFor?: string | null
    status?: $Enums.BPUGroupStatus
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type BKURowUpdateWithoutBkuImportInput = {
    id?: StringFieldUpdateOperationsInput | string
    tanggal?: DateTimeFieldUpdateOperationsInput | Date | string
    kodeKegiatan?: NullableStringFieldUpdateOperationsInput | string | null
    kodeRekening?: NullableStringFieldUpdateOperationsInput | string | null
    bpuCode?: NullableStringFieldUpdateOperationsInput | string | null
    bpuNumber?: NullableIntFieldUpdateOperationsInput | number | null
    uraian?: StringFieldUpdateOperationsInput | string
    penerimaan?: IntFieldUpdateOperationsInput | number
    pengeluaran?: IntFieldUpdateOperationsInput | number
    saldo?: IntFieldUpdateOperationsInput | number
    pageIndex?: NullableIntFieldUpdateOperationsInput | number | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type BKURowUncheckedUpdateWithoutBkuImportInput = {
    id?: StringFieldUpdateOperationsInput | string
    tanggal?: DateTimeFieldUpdateOperationsInput | Date | string
    kodeKegiatan?: NullableStringFieldUpdateOperationsInput | string | null
    kodeRekening?: NullableStringFieldUpdateOperationsInput | string | null
    bpuCode?: NullableStringFieldUpdateOperationsInput | string | null
    bpuNumber?: NullableIntFieldUpdateOperationsInput | number | null
    uraian?: StringFieldUpdateOperationsInput | string
    penerimaan?: IntFieldUpdateOperationsInput | number
    pengeluaran?: IntFieldUpdateOperationsInput | number
    saldo?: IntFieldUpdateOperationsInput | number
    pageIndex?: NullableIntFieldUpdateOperationsInput | number | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type BKURowUncheckedUpdateManyWithoutBkuImportInput = {
    id?: StringFieldUpdateOperationsInput | string
    tanggal?: DateTimeFieldUpdateOperationsInput | Date | string
    kodeKegiatan?: NullableStringFieldUpdateOperationsInput | string | null
    kodeRekening?: NullableStringFieldUpdateOperationsInput | string | null
    bpuCode?: NullableStringFieldUpdateOperationsInput | string | null
    bpuNumber?: NullableIntFieldUpdateOperationsInput | number | null
    uraian?: StringFieldUpdateOperationsInput | string
    penerimaan?: IntFieldUpdateOperationsInput | number
    pengeluaran?: IntFieldUpdateOperationsInput | number
    saldo?: IntFieldUpdateOperationsInput | number
    pageIndex?: NullableIntFieldUpdateOperationsInput | number | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type BPUGroupUpdateWithoutBkuImportInput = {
    id?: StringFieldUpdateOperationsInput | string
    bpuCode?: StringFieldUpdateOperationsInput | string
    bpuNumber?: IntFieldUpdateOperationsInput | number
    tanggal?: DateTimeFieldUpdateOperationsInput | Date | string
    totalAmount?: IntFieldUpdateOperationsInput | number
    overrideRecipient?: NullableStringFieldUpdateOperationsInput | string | null
    overridePaymentFor?: NullableStringFieldUpdateOperationsInput | string | null
    status?: EnumBPUGroupStatusFieldUpdateOperationsInput | $Enums.BPUGroupStatus
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    matchedVendorRule?: VendorRuleUpdateOneWithoutBpuGroupsNestedInput
    spmDocument?: SPMDocumentUpdateOneWithoutBpuGroupNestedInput
  }

  export type BPUGroupUncheckedUpdateWithoutBkuImportInput = {
    id?: StringFieldUpdateOperationsInput | string
    bpuCode?: StringFieldUpdateOperationsInput | string
    bpuNumber?: IntFieldUpdateOperationsInput | number
    tanggal?: DateTimeFieldUpdateOperationsInput | Date | string
    totalAmount?: IntFieldUpdateOperationsInput | number
    matchedVendorRuleId?: NullableStringFieldUpdateOperationsInput | string | null
    overrideRecipient?: NullableStringFieldUpdateOperationsInput | string | null
    overridePaymentFor?: NullableStringFieldUpdateOperationsInput | string | null
    status?: EnumBPUGroupStatusFieldUpdateOperationsInput | $Enums.BPUGroupStatus
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    spmDocument?: SPMDocumentUncheckedUpdateOneWithoutBpuGroupNestedInput
  }

  export type BPUGroupUncheckedUpdateManyWithoutBkuImportInput = {
    id?: StringFieldUpdateOperationsInput | string
    bpuCode?: StringFieldUpdateOperationsInput | string
    bpuNumber?: IntFieldUpdateOperationsInput | number
    tanggal?: DateTimeFieldUpdateOperationsInput | Date | string
    totalAmount?: IntFieldUpdateOperationsInput | number
    matchedVendorRuleId?: NullableStringFieldUpdateOperationsInput | string | null
    overrideRecipient?: NullableStringFieldUpdateOperationsInput | string | null
    overridePaymentFor?: NullableStringFieldUpdateOperationsInput | string | null
    status?: EnumBPUGroupStatusFieldUpdateOperationsInput | $Enums.BPUGroupStatus
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type RkasProgramCreateManyRkasImportInput = {
    id?: string
    urutan: number
    kodeProgram: string
    nama: string
    standarName?: string
    kegiatanName?: string
    included?: boolean
  }

  export type RkasProgramUpdateWithoutRkasImportInput = {
    id?: StringFieldUpdateOperationsInput | string
    urutan?: IntFieldUpdateOperationsInput | number
    kodeProgram?: StringFieldUpdateOperationsInput | string
    nama?: StringFieldUpdateOperationsInput | string
    standarName?: StringFieldUpdateOperationsInput | string
    kegiatanName?: StringFieldUpdateOperationsInput | string
    included?: BoolFieldUpdateOperationsInput | boolean
    items?: RkasItemUpdateManyWithoutRkasProgramNestedInput
  }

  export type RkasProgramUncheckedUpdateWithoutRkasImportInput = {
    id?: StringFieldUpdateOperationsInput | string
    urutan?: IntFieldUpdateOperationsInput | number
    kodeProgram?: StringFieldUpdateOperationsInput | string
    nama?: StringFieldUpdateOperationsInput | string
    standarName?: StringFieldUpdateOperationsInput | string
    kegiatanName?: StringFieldUpdateOperationsInput | string
    included?: BoolFieldUpdateOperationsInput | boolean
    items?: RkasItemUncheckedUpdateManyWithoutRkasProgramNestedInput
  }

  export type RkasProgramUncheckedUpdateManyWithoutRkasImportInput = {
    id?: StringFieldUpdateOperationsInput | string
    urutan?: IntFieldUpdateOperationsInput | number
    kodeProgram?: StringFieldUpdateOperationsInput | string
    nama?: StringFieldUpdateOperationsInput | string
    standarName?: StringFieldUpdateOperationsInput | string
    kegiatanName?: StringFieldUpdateOperationsInput | string
    included?: BoolFieldUpdateOperationsInput | boolean
  }

  export type RkasItemCreateManyRkasProgramInput = {
    id?: string
    urutan: number
    noUrut: number
    kodeRekening: string
    uraian: string
    volumeText: string
    tarifHarga: number
    jumlah: number
    excluded?: boolean
  }

  export type RkasItemUpdateWithoutRkasProgramInput = {
    id?: StringFieldUpdateOperationsInput | string
    urutan?: IntFieldUpdateOperationsInput | number
    noUrut?: IntFieldUpdateOperationsInput | number
    kodeRekening?: StringFieldUpdateOperationsInput | string
    uraian?: StringFieldUpdateOperationsInput | string
    volumeText?: StringFieldUpdateOperationsInput | string
    tarifHarga?: IntFieldUpdateOperationsInput | number
    jumlah?: IntFieldUpdateOperationsInput | number
    excluded?: BoolFieldUpdateOperationsInput | boolean
  }

  export type RkasItemUncheckedUpdateWithoutRkasProgramInput = {
    id?: StringFieldUpdateOperationsInput | string
    urutan?: IntFieldUpdateOperationsInput | number
    noUrut?: IntFieldUpdateOperationsInput | number
    kodeRekening?: StringFieldUpdateOperationsInput | string
    uraian?: StringFieldUpdateOperationsInput | string
    volumeText?: StringFieldUpdateOperationsInput | string
    tarifHarga?: IntFieldUpdateOperationsInput | number
    jumlah?: IntFieldUpdateOperationsInput | number
    excluded?: BoolFieldUpdateOperationsInput | boolean
  }

  export type RkasItemUncheckedUpdateManyWithoutRkasProgramInput = {
    id?: StringFieldUpdateOperationsInput | string
    urutan?: IntFieldUpdateOperationsInput | number
    noUrut?: IntFieldUpdateOperationsInput | number
    kodeRekening?: StringFieldUpdateOperationsInput | string
    uraian?: StringFieldUpdateOperationsInput | string
    volumeText?: StringFieldUpdateOperationsInput | string
    tarifHarga?: IntFieldUpdateOperationsInput | number
    jumlah?: IntFieldUpdateOperationsInput | number
    excluded?: BoolFieldUpdateOperationsInput | boolean
  }



  /**
   * Batch Payload for updateMany & deleteMany & createMany
   */

  export type BatchPayload = {
    count: number
  }

  /**
   * DMMF
   */
  export const dmmf: runtime.BaseDMMF
}