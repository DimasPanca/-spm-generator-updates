import { prisma } from "@/lib/db";
import { renderCombinedSpm } from "@/lib/pdf-render/renderCombinedSpm";
import { monthName } from "@/lib/indonesian/months";

export async function GET(
  _req: Request,
  { params }: { params: Promise<{ importId: string }> }
) {
  const { importId } = await params;

  const bkuImport = await prisma.bKUImport.findUnique({ where: { id: importId } });
  if (!bkuImport) return new Response("Import tidak ditemukan.", { status: 404 });

  const result = await renderCombinedSpm(bkuImport.schoolId, importId);
  if (!result) {
    return new Response(
      "Belum ada BPU yang dikonfirmasi untuk bulan ini -- konfirmasi dulu di halaman review.",
      { status: 404 }
    );
  }

  const fileName = `SPM_Keseluruhan_${monthName(bkuImport.month)}_${bkuImport.year}.pdf`;
  return new Response(new Uint8Array(result.buffer), {
    headers: {
      "Content-Type": "application/pdf",
      "Content-Disposition": `attachment; filename="${fileName}"`,
    },
  });
}
