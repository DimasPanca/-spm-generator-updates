import { prisma } from "@/lib/db";
import { renderHonorRecapPdf } from "@/lib/pdf-render/renderHonorRecapPdf";
import { monthName } from "@/lib/indonesian/months";

export async function GET(
  _req: Request,
  { params }: { params: Promise<{ importId: string }> }
) {
  const { importId } = await params;

  const bkuImport = await prisma.bKUImport.findUnique({ where: { id: importId } });
  if (!bkuImport) return new Response("Import tidak ditemukan.", { status: 404 });

  const result = await renderHonorRecapPdf(bkuImport.schoolId, importId);
  if (!result) {
    return new Response(
      "Belum ada BPU honor yang dikonfirmasi untuk bulan ini. Konfirmasi dulu di halaman review, dan pastikan aturan vendornya dicentang sebagai Honor.",
      { status: 404 }
    );
  }

  const fileName = `Rekap_Honor_${monthName(bkuImport.month)}_${bkuImport.year}.pdf`;
  return new Response(new Uint8Array(result.buffer), {
    headers: {
      "Content-Type": "application/pdf",
      "Content-Disposition": `attachment; filename="${fileName}"`,
    },
  });
}
