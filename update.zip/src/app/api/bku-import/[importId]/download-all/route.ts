import { ZipArchive } from "archiver";
import { PassThrough } from "node:stream";
import path from "node:path";
import { prisma } from "@/lib/db";
import { monthName } from "@/lib/indonesian/months";

export async function GET(
  _req: Request,
  { params }: { params: Promise<{ importId: string }> }
) {
  const { importId } = await params;

  const bkuImport = await prisma.bKUImport.findUnique({ where: { id: importId } });
  if (!bkuImport) return new Response("Import tidak ditemukan.", { status: 404 });

  const docs = await prisma.sPMDocument.findMany({
    where: { bpuGroup: { bkuImportId: importId } },
  });

  if (docs.length === 0) {
    return new Response("Belum ada SPM yang digenerate untuk BKU ini.", { status: 404 });
  }

  const archive = new ZipArchive({ zlib: { level: 9 } });
  const stream = new PassThrough();
  archive.pipe(stream);

  for (const doc of docs) {
    archive.file(doc.filePath, { name: path.basename(doc.filePath) });
  }
  archive.finalize();

  const chunks: Buffer[] = [];
  await new Promise<void>((resolve, reject) => {
    stream.on("data", (chunk) => chunks.push(chunk));
    stream.on("end", () => resolve());
    stream.on("error", reject);
    archive.on("error", reject);
  });

  return new Response(new Uint8Array(Buffer.concat(chunks)), {
    headers: {
      "Content-Type": "application/zip",
      "Content-Disposition": `attachment; filename="SPM_${monthName(bkuImport.month)}_${bkuImport.year}.zip"`,
    },
  });
}
