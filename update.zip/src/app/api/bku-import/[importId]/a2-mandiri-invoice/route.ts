import { prisma } from "@/lib/db";
import { renderA2MandiriInvoice } from "@/lib/pdf-render/renderA2MandiriInvoice";
import { monthName } from "@/lib/indonesian/months";

export async function GET(
  _req: Request,
  { params }: { params: Promise<{ importId: string }> }
) {
  const { importId } = await params;

  const bkuImport = await prisma.bKUImport.findUnique({ where: { id: importId } });
  if (!bkuImport) return new Response("Import tidak ditemukan.", { status: 404 });

  const result = await renderA2MandiriInvoice(importId);
  if (!result) {
    return new Response(
      "Belum ada pembelian buku pelajaran (A2 Mandiri) yang dikonfirmasi untuk bulan ini.",
      { status: 404 }
    );
  }

  const fileName = `Invoice_A2_Mandiri_${monthName(bkuImport.month)}_${bkuImport.year}.pdf`;
  return new Response(new Uint8Array(result.buffer), {
    headers: {
      "Content-Type": "application/pdf",
      "Content-Disposition": `attachment; filename="${fileName}"`,
    },
  });
}
