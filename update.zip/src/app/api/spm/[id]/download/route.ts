import { readFile } from "node:fs/promises";
import path from "node:path";
import { prisma } from "@/lib/db";

export async function GET(
  _req: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;
  const doc = await prisma.sPMDocument.findUnique({ where: { id } });
  if (!doc) return new Response("Not found", { status: 404 });

  const buffer = await readFile(doc.filePath);
  return new Response(new Uint8Array(buffer), {
    headers: {
      "Content-Type": "application/pdf",
      "Content-Disposition": `attachment; filename="${path.basename(doc.filePath)}"`,
    },
  });
}
