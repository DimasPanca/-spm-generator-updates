import { renderLampiranPdf } from "@/lib/pdf-render/renderLampiranPdf";
import { monthName } from "@/lib/indonesian/months";

export async function GET(
  _req: Request,
  { params }: { params: Promise<{ rkasId: string }> }
) {
  const { rkasId } = await params;

  const result = await renderLampiranPdf(rkasId);
  if (!result) {
    return new Response(
      "Belum ada kode program yang dikonfirmasi. Centang dulu kode program " +
        "yang mau dimasukkan ke lampiran, lalu simpan.",
      { status: 404 }
    );
  }

  const fileName = `Lampiran_Belanja_Tunai_${monthName(result.month)}_${result.year}.pdf`;
  return new Response(new Uint8Array(result.buffer), {
    headers: {
      "Content-Type": "application/pdf",
      "Content-Disposition": `attachment; filename="${fileName}"`,
    },
  });
}
