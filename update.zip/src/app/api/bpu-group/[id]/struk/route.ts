import { renderFrazaReceipt } from "@/lib/pdf-render/renderFrazaReceipt";

export async function GET(
  _req: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;
  const result = await renderFrazaReceipt(id);

  if (!result) {
    return new Response(
      "Struk hanya tersedia untuk BPU Fraza Cell (listrik/internet) yang sudah dikonfirmasi.",
      { status: 404 }
    );
  }

  return new Response(new Uint8Array(result.buffer), {
    headers: {
      "Content-Type": "application/pdf",
      "Content-Disposition": `attachment; filename="Struk_Fraza_Cell_${result.bpuCode}.pdf"`,
    },
  });
}
