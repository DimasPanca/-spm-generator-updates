import { prisma } from "@/lib/db";
import { renderHonorRecapPdf } from "@/lib/pdf-render/renderHonorRecapPdf";

/** One PDF containing separate recaps for each imported BKU month. */
export async function GET(
  _req: Request,
  { params }: { params: Promise<{ schoolId: string }> }
) {
  const { schoolId } = await params;

  const school = await prisma.school.findUnique({ where: { id: schoolId } });
  if (!school) return new Response("Sekolah tidak ditemukan.", { status: 404 });

  const result = await renderHonorRecapPdf(schoolId);
  if (!result) {
    return new Response(
      "Belum ada BPU honor yang dikonfirmasi di sekolah ini. Konfirmasi dulu di halaman review, dan pastikan aturan vendornya dicentang sebagai Honor.",
      { status: 404 }
    );
  }

  const safeName = school.name.replace(/[^A-Za-z0-9]+/g, "_").replace(/^_|_$/g, "");
  return new Response(new Uint8Array(result.buffer), {
    headers: {
      "Content-Type": "application/pdf",
      "Content-Disposition": `attachment; filename="Rekap_Honor_Per_Bulan_${safeName}.pdf"`,
    },
  });
}
