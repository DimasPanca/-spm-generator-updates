import { renderSkDocx } from "@/lib/sk/renderSkDocx";
import { convertDocxToPdf, WordNotAvailableError } from "@/lib/docx/docxToPdf";

const DOCX_MIME =
  "application/vnd.openxmlformats-officedocument.wordprocessingml.document";

export async function GET(
  request: Request,
  { params }: { params: Promise<{ schoolId: string }> }
) {
  const { schoolId } = await params;
  const url = new URL(request.url);
  const year = Number(url.searchParams.get("year"));
  const format = url.searchParams.get("format") === "pdf" ? "pdf" : "docx";

  if (!Number.isInteger(year) || year < 2000 || year > 2100) {
    return new Response("Parameter tahun tidak valid.", { status: 400 });
  }

  const result = await renderSkDocx(schoolId, year);
  if (!result) return new Response("Sekolah tidak ditemukan.", { status: 404 });

  if (format === "docx") {
    return new Response(new Uint8Array(result.buffer), {
      headers: {
        "Content-Type": DOCX_MIME,
        "Content-Disposition": `attachment; filename="${result.fileName}"`,
      },
    });
  }

  try {
    const pdf = await convertDocxToPdf(result.buffer);
    return new Response(new Uint8Array(pdf), {
      headers: {
        "Content-Type": "application/pdf",
        "Content-Disposition": `attachment; filename="${result.fileName.replace(/\.docx$/, ".pdf")}"`,
      },
    });
  } catch (err) {
    if (err instanceof WordNotAvailableError) {
      return new Response(err.message, { status: 503 });
    }
    return new Response(err instanceof Error ? err.message : "Gagal mengonversi ke PDF.", { status: 500 });
  }
}
