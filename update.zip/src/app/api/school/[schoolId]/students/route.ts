import { prisma } from "@/lib/db";
import {
  parseStudentListOutputFormat,
  type StudentListDocumentInput,
} from "@/lib/student-lists/report";
import { renderStudentListDownload } from "@/lib/student-lists/renderStudentListDownload";

const MAX_STUDENTS = 5_000;

export async function POST(
  request: Request,
  { params }: { params: Promise<{ schoolId: string }> }
) {
  const { schoolId } = await params;
  const formData = await request.formData();
  const importId = String(formData.get("importId") ?? "");
  const year = Number(formData.get("year"));
  const outputFormat = parseStudentListOutputFormat(formData.get("outputFormat"));
  const keterangan = String(formData.get("keterangan") ?? "Siswa Aktif")
    .trim()
    .slice(0, 100);

  if (!Number.isInteger(year) || year < 2000 || year > 2100) {
    return new Response("Tahun dokumen tidak valid.", { status: 400 });
  }
  if (!outputFormat) {
    return new Response("Pilih format Excel atau PDF.", { status: 400 });
  }
  if (!keterangan) {
    return new Response("Keterangan tidak boleh kosong.", { status: 400 });
  }

  const imported = await prisma.studentDataImport.findFirst({
    where: { id: importId, schoolId },
    select: { id: true },
  });
  if (!imported) return new Response("Data impor tidak ditemukan.", { status: 404 });

  const [school, students] = await Promise.all([
    prisma.school.findUnique({ where: { id: schoolId } }),
    prisma.studentRecord.findMany({
      where: { studentDataImportId: importId },
      orderBy: [{ sourceNumber: "asc" }, { name: "asc" }],
      take: MAX_STUDENTS + 1,
    }),
  ]);
  if (!school) return new Response("Sekolah tidak ditemukan.", { status: 404 });
  if (students.length === 0) {
    return new Response("Data impor ini tidak memiliki siswa.", { status: 400 });
  }
  if (students.length > MAX_STUDENTS) {
    return new Response("Jumlah siswa melebihi batas aman 5.000 data.", {
      status: 400,
    });
  }

  const documentInput: StudentListDocumentInput = {
    kind: "all",
    schoolName: school.name,
    kepalaName: school.kepalaName,
    kepalaJabatan: school.kepalaJabatan,
    year,
    keterangan,
    students,
  };
  const download = await renderStudentListDownload(documentInput, outputFormat);

  return new Response(new Uint8Array(download.buffer), {
    headers: {
      "Content-Type": download.contentType,
      "Content-Disposition": `attachment; filename="${download.fileName}"`,
      "Cache-Control": "no-store",
      "X-Content-Type-Options": "nosniff",
    },
  });
}

