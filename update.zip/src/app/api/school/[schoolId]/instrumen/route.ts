import { renderInstrumenDocx } from "@/lib/instrumen/renderInstrumenDocx";
import { convertDocxToPdf, WordNotAvailableError } from "@/lib/docx/docxToPdf";

const DOCX_MIME =
  "application/vnd.openxmlformats-officedocument.wordprocessingml.document";

export async function GET(
  request: Request,
  { params }: { params: Promise<{ schoolId: string }> }
) {
  const { schoolId } = await params;
  const url = new URL(request.url);

  const year = Number(url.searchParams.get("year"));
  const tahapRaw = url.searchParams.get("tahap");
  const tahap = tahapRaw === "2" ? 2 : tahapRaw === "1" ? 1 : null;
  const format = url.searchParams.get("format") === "pdf" ? "pdf" : "docx";

  if (!tahap || !Number.isInteger(year) || year < 2000 || year > 2100) {
    return new Response("Parameter tahun atau tahap tidak valid.", { status: 400 });
  }

  const result = await renderInstrumenDocx(schoolId, year, tahap);
  if (!result) {
    return new Response(
      `Belum ada BKU yang diimpor untuk Tahap ${tahap} tahun ${year}. ` +
        "Impor BKU bulanannya dulu di menu Impor BKU.",
      { status: 404 }
    );
  }

  if (format === "docx") {
    return new Response(new Uint8Array(result.buffer), {
      headers: {
        "Content-Type": DOCX_MIME,
        "Content-Disposition": `attachment; filename="${result.fileName}"`,
      },
    });
  }

  try {
    const pdf = await convertDocxToPdf(result.buffer);
    return new Response(new Uint8Array(pdf), {
      headers: {
        "Content-Type": "application/pdf",
        "Content-Disposition": `attachment; filename="${result.fileName.replace(/\.docx$/, ".pdf")}"`,
      },
    });
  } catch (err) {
    if (err instanceof WordNotAvailableError) {
      return new Response(err.message, { status: 503 });
    }
    return new Response(
      err instanceof Error ? err.message : "Gagal mengonversi ke PDF.",
      { status: 500 }
    );
  }
}
