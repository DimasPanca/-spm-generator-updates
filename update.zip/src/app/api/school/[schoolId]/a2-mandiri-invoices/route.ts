import { prisma } from "@/lib/db";
import { renderA2MandiriInvoicesForSchool } from "@/lib/pdf-render/renderA2MandiriInvoice";

export async function GET(
  _req: Request,
  { params }: { params: Promise<{ schoolId: string }> }
) {
  const { schoolId } = await params;

  const school = await prisma.school.findUnique({ where: { id: schoolId } });
  if (!school) return new Response("Sekolah tidak ditemukan.", { status: 404 });

  const result = await renderA2MandiriInvoicesForSchool(schoolId);
  if (!result) {
    return new Response(
      "Belum ada pembelian buku pelajaran (A2 Mandiri) yang dikonfirmasi di bulan manapun.",
      { status: 404 }
    );
  }

  const safeName = school.name.replace(/[^a-z0-9]+/gi, "_");
  return new Response(new Uint8Array(result.buffer), {
    headers: {
      "Content-Type": "application/pdf",
      "Content-Disposition": `attachment; filename="Invoice_A2_Mandiri_${safeName}.pdf"`,
    },
  });
}
