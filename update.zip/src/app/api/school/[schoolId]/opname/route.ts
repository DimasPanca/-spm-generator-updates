import { renderStockOpnameXlsx } from "@/lib/opname/renderStockOpnameXlsx";
import { renderCashOpnameDocx } from "@/lib/opname/renderCashOpnameDocx";
import { convertDocxToPdf, WordNotAvailableError } from "@/lib/docx/docxToPdf";

const XLSX_MIME = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
const DOCX_MIME = "application/vnd.openxmlformats-officedocument.wordprocessingml.document";

/**
 * ?kind=stock -> Stock Opname xlsx  |  ?kind=cash -> Cash Opname docx/pdf
 * Cash also accepts ?format=pdf which pipes the docx through MS Word.
 */
export async function GET(
  request: Request,
  { params }: { params: Promise<{ schoolId: string }> }
) {
  const { schoolId } = await params;
  const url = new URL(request.url);
  const kind = url.searchParams.get("kind") === "cash" ? "cash" : "stock";
  const format = url.searchParams.get("format") === "pdf" ? "pdf" : kind === "stock" ? "xlsx" : "docx";
  const year = Number(url.searchParams.get("year"));
  const tahapRaw = url.searchParams.get("tahap");
  const tahap = tahapRaw === "2" ? 2 : tahapRaw === "1" ? 1 : null;

  if (!tahap || !Number.isInteger(year) || year < 2000 || year > 2100) {
    return new Response("Parameter tahun atau tahap tidak valid.", { status: 400 });
  }

  if (kind === "stock") {
    const r = await renderStockOpnameXlsx(schoolId, year, tahap);
    if (!r) return new Response("Sekolah tidak ditemukan.", { status: 404 });
    return new Response(new Uint8Array(r.buffer), {
      headers: {
        "Content-Type": XLSX_MIME,
        "Content-Disposition": `attachment; filename="${r.fileName}"`,
      },
    });
  }

  const r = await renderCashOpnameDocx(schoolId, year, tahap);
  if (!r) return new Response("Sekolah tidak ditemukan.", { status: 404 });
  if (format === "docx") {
    return new Response(new Uint8Array(r.buffer), {
      headers: {
        "Content-Type": DOCX_MIME,
        "Content-Disposition": `attachment; filename="${r.fileName}"`,
      },
    });
  }
  try {
    const pdf = await convertDocxToPdf(r.buffer);
    return new Response(new Uint8Array(pdf), {
      headers: {
        "Content-Type": "application/pdf",
        "Content-Disposition": `attachment; filename="${r.fileName.replace(/\.docx$/, ".pdf")}"`,
      },
    });
  } catch (err) {
    if (err instanceof WordNotAvailableError) return new Response(err.message, { status: 503 });
    return new Response(err instanceof Error ? err.message : "Gagal konversi PDF.", { status: 500 });
  }
}
