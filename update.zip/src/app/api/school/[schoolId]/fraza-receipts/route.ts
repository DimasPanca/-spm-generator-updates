import { renderFrazaReceiptSemester } from "@/lib/pdf-render/renderFrazaReceipt";

function parseSemester(value: string | null): 1 | 2 | null {
  return value === "1" ? 1 : value === "2" ? 2 : null;
}

export async function GET(
  request: Request,
  { params }: { params: Promise<{ schoolId: string }> }
) {
  const { schoolId } = await params;
  const url = new URL(request.url);
  const semester = parseSemester(url.searchParams.get("semester"));
  const year = Number(url.searchParams.get("year"));
  if (!semester || !Number.isInteger(year) || year < 2000 || year > 2100) {
    return new Response("Parameter tahun atau semester tidak valid.", { status: 400 });
  }

  const result = await renderFrazaReceiptSemester(schoolId, year, semester);
  if (!result) {
    return new Response(
      "Belum ada BPU Fraza Cell untuk listrik/internet yang sudah dikonfirmasi pada semester ini.",
      { status: 404 }
    );
  }

  return new Response(new Uint8Array(result.buffer), {
    headers: {
      "Content-Type": "application/pdf",
      "Content-Disposition": `attachment; filename="Struk_Fraza_Cell_Semester_${semester}_${year}.pdf"`,
    },
  });
}
