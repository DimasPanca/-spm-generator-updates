import { prisma } from "@/lib/db";
import {
  parseStudentListOutputFormat,
  type StudentListDocumentInput,
} from "@/lib/student-lists/report";
import { renderStudentListDownload } from "@/lib/student-lists/renderStudentListDownload";

const MAX_SELECTED_STUDENTS = 5_000;

export async function POST(
  request: Request,
  { params }: { params: Promise<{ schoolId: string }> }
) {
  const { schoolId } = await params;
  const formData = await request.formData();
  const importId = String(formData.get("importId") ?? "");
  const year = Number(formData.get("year"));
  const expectedCount = Number(formData.get("expectedCount"));
  const outputFormat = parseStudentListOutputFormat(formData.get("outputFormat"));
  const keterangan = String(formData.get("keterangan") ?? "Siswa Miskin")
    .trim()
    .slice(0, 100);
  const requestedIds = formData
    .getAll("studentId")
    .map(String)
    .filter(Boolean);
  const studentIds = [...new Set(requestedIds)];

  if (!Number.isInteger(year) || year < 2000 || year > 2100) {
    return new Response("Tahun dokumen tidak valid.", { status: 400 });
  }
  if (!outputFormat) {
    return new Response("Pilih format Excel atau PDF.", { status: 400 });
  }
  if (
    !Number.isInteger(expectedCount) ||
    expectedCount < 1 ||
    expectedCount > MAX_SELECTED_STUDENTS ||
    studentIds.length !== expectedCount ||
    requestedIds.length !== studentIds.length
  ) {
    return new Response("Jumlah siswa yang dipilih tidak sesuai.", { status: 400 });
  }
  if (keterangan === "") {
    return new Response("Keterangan tidak boleh kosong.", { status: 400 });
  }

  const imported = await prisma.studentDataImport.findFirst({
    where: { id: importId, schoolId },
    select: { id: true },
  });
  if (!imported) return new Response("Data impor tidak ditemukan.", { status: 404 });

  const [school, records] = await Promise.all([
    prisma.school.findUnique({ where: { id: schoolId } }),
    prisma.studentRecord.findMany({
      where: { studentDataImportId: importId, id: { in: studentIds } },
      orderBy: [{ sourceNumber: "asc" }, { name: "asc" }],
    }),
  ]);
  if (!school) return new Response("Sekolah tidak ditemukan.", { status: 404 });
  if (records.length !== studentIds.length) {
    return new Response("Ada siswa yang tidak berasal dari data impor ini.", { status: 400 });
  }

  const documentInput: StudentListDocumentInput = {
    kind: "poor",
    schoolName: school.name,
    kepalaName: school.kepalaName,
    kepalaJabatan: school.kepalaJabatan,
    year,
    keterangan,
    students: records,
  };
  const download = await renderStudentListDownload(documentInput, outputFormat);

  return new Response(new Uint8Array(download.buffer), {
    headers: {
      "Content-Type": download.contentType,
      "Content-Disposition": `attachment; filename="${download.fileName}"`,
      "Cache-Control": "no-store",
      "X-Content-Type-Options": "nosniff",
    },
  });
}
