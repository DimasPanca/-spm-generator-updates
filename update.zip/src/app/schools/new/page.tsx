import Link from "next/link";
import { createSchool } from "@/lib/actions/school";

export default function NewSchoolPage() {
  return (
    <div className="mx-auto flex max-w-2xl flex-col gap-6">
      <div>
        <Link href="/schools" className="text-sm text-teal hover:underline">
          &larr; Kembali
        </Link>
        <h1 className="mt-2 text-2xl font-bold tracking-tight">
          Tambah Sekolah
        </h1>
        <p className="mt-1 text-sm text-muted">
          Isi profil dasar dan unggah logo. Teks surat & aturan vendor bisa
          dilengkapi setelah ini.
        </p>
      </div>

      <form
        action={createSchool}
        className="card flex flex-col gap-5 p-6"
      >
        <div className="grid gap-4 sm:grid-cols-2">
          <div className="flex flex-col gap-1.5">
            <span className="field-label">Logo Sekolah (kiri)</span>
            <input
              type="file"
              name="logo"
              accept="image/*"
              className="text-sm text-muted file:mr-3 file:rounded-md file:border-0 file:bg-primary file:px-3 file:py-1.5 file:text-sm file:font-medium file:text-white hover:file:bg-primary-dark"
            />
            <span className="text-xs text-muted">
              Disarankan gambar persegi (PNG transparan).
            </span>
          </div>
          <div className="flex flex-col gap-1.5">
            <span className="field-label">Logo Kota/Kabupaten (kanan, opsional)</span>
            <input
              type="file"
              name="regionalLogo"
              accept="image/*"
              className="text-sm text-muted file:mr-3 file:rounded-md file:border-0 file:bg-primary file:px-3 file:py-1.5 file:text-sm file:font-medium file:text-white hover:file:bg-primary-dark"
            />
            <span className="text-xs text-muted">
              Logo pemerintah daerah, tampil di pojok kanan kop.
            </span>
          </div>
        </div>

        <div className="h-px bg-line" />

        <Field
          label="Baris Kecil di Atas KOP (opsional)"
          name="kopHeaderLine"
          placeholder="PUSAT KEGIATAN BELAJAR MASYARAKAT"
          hint='Ditampilkan kecil di atas nama sekolah di KOP, mis. "PUSAT KEGIATAN BELAJAR MASYARAKAT" di atas "PKBM ABDI PERTIWI".'
        />
        <Field label="Nama Sekolah/Lembaga" name="name" required placeholder="PKBM ABDI PERTIWI" />
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="NPSN" name="npsn" placeholder="P2962617" />
          <Field label="Kontak (opsional)" name="contact" placeholder="087771920322" />
        </div>
        <Field
          label="Alamat Lengkap"
          name="address"
          required
          placeholder="Komp. TPI Blok F3 No. 33-34, Kec. Walantaka, Kota Serang, Prov. Banten"
          textarea
        />
        <Field
          label="Kode Format Nomor Surat"
          name="formatCode"
          required
          placeholder="SPM.PKBM-AP"
          hint='Contoh hasil: "32/SPM.PKBM-AP/I/2026"'
        />
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="Nama Kepala" name="kepalaName" required placeholder="DRS. M. YUSUF" />
          <Field
            label="Jabatan Kepala"
            name="kepalaJabatan"
            required
            placeholder="Kepala PKBM ABDI PERTIWI"
          />
        </div>
        <Field
          label="Judul Rekap Honor (opsional)"
          name="honorRecapTitle"
          placeholder="HONOR TUTOR PKBM ABDI PERTIWI"
        />

        <button type="submit" className="btn btn-primary mt-1 self-start">
          Simpan &amp; Lanjutkan
        </button>
      </form>
    </div>
  );
}

function Field({
  label,
  name,
  placeholder,
  required,
  textarea,
  hint,
}: {
  label: string;
  name: string;
  placeholder?: string;
  required?: boolean;
  textarea?: boolean;
  hint?: string;
}) {
  return (
    <label className="flex flex-col gap-1.5">
      <span className="field-label">
        {label}
        {required && <span className="text-teal"> *</span>}
      </span>
      {textarea ? (
        <textarea
          name={name}
          required={required}
          placeholder={placeholder}
          rows={2}
          className="input-field"
        />
      ) : (
        <input
          type="text"
          name={name}
          required={required}
          placeholder={placeholder}
          className="input-field"
        />
      )}
      {hint && <span className="text-xs text-muted">{hint}</span>}
    </label>
  );
}
