import Link from "next/link";
import Image from "next/image";
import { prisma } from "@/lib/db";

export default async function SchoolsPage() {
  const schools = await prisma.school.findMany({
    orderBy: { name: "asc" },
    include: {
      _count: { select: { vendorRules: true, bkuImports: true, rkasImports: true } },
    },
  });

  return (
    <div className="flex flex-col gap-6">
      <div className="flex items-end justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Sekolah</h1>
          <p className="mt-1 text-sm text-muted">
            Pilih sekolah untuk mengelola aturan vendor dan membuat SPM dari BKU.
          </p>
        </div>
        <Link href="/schools/new" className="btn btn-primary">
          + Tambah Sekolah
        </Link>
      </div>

      {schools.length === 0 ? (
        <div className="card flex flex-col items-center gap-3 p-12 text-center">
          <div className="flex h-12 w-12 items-center justify-center rounded-full bg-mint-soft text-xl">
            🏫
          </div>
          <p className="font-medium">Belum ada sekolah</p>
          <p className="max-w-sm text-sm text-muted">
            Tambahkan profil sekolah dulu (KOP, logo, kepala, format nomor
            surat) sebelum mengunggah BKU.
          </p>
          <Link href="/schools/new" className="btn btn-primary mt-1">
            + Tambah Sekolah
          </Link>
        </div>
      ) : (
        <div className="grid gap-4 sm:grid-cols-2">
          {schools.map((school) => (
            <div key={school.id} className="card flex flex-col gap-4 p-5">
              <div className="flex items-center gap-3">
                {school.logoPath ? (
                  <Image
                    src={school.logoPath}
                    alt=""
                    width={44}
                    height={44}
                    className="h-11 w-11 rounded-lg object-contain"
                  />
                ) : (
                  <span className="flex h-11 w-11 items-center justify-center rounded-lg bg-cream text-lg font-bold text-primary">
                    {school.name.charAt(0)}
                  </span>
                )}
                <div className="min-w-0">
                  <p className="truncate font-semibold">{school.name}</p>
                  <p className="truncate font-mono text-xs text-muted">
                    {school.formatCode}
                  </p>
                </div>
              </div>

              <div className="flex gap-2 text-xs">
                <span className="badge badge-muted">
                  {school._count.vendorRules} aturan vendor
                </span>
                <span className="badge badge-muted">
                  {school._count.bkuImports} BKU
                </span>
                <span className="badge badge-muted">
                  {school._count.rkasImports} RKAS
                </span>
              </div>

              <div className="mt-auto flex flex-wrap gap-2 border-t border-line pt-3 text-sm">
                <Link
                  href={`/schools/${school.id}/import`}
                  className="btn btn-teal flex-1"
                >
                  Impor BKU
                </Link>
                <Link
                  href={`/schools/${school.id}/rkas`}
                  className="btn btn-primary flex-1"
                >
                  Surat Lampiran
                </Link>
                <Link
                  href={`/schools/${school.id}/instrumen`}
                  className="btn btn-teal flex-1"
                >
                  Instrumen BOSP
                </Link>
                <Link
                  href={`/schools/${school.id}/vendor-rules`}
                  className="btn btn-ghost"
                >
                  Vendor
                </Link>
                <Link
                  href={`/schools/${school.id}/setup`}
                  className="btn btn-ghost"
                >
                  Setelan
                </Link>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
