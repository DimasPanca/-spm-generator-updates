import Link from "next/link";
import { notFound } from "next/navigation";
import { prisma } from "@/lib/db";
import { deleteBKUImport } from "@/lib/actions/bku-import";
import { monthName } from "@/lib/indonesian/months";
import ImportForm from "./ImportForm";

export default async function ImportPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id: schoolId } = await params;
  const school = await prisma.school.findUnique({ where: { id: schoolId } });
  if (!school) notFound();

  const imports = await prisma.bKUImport.findMany({
    where: { schoolId },
    orderBy: [{ year: "desc" }, { month: "desc" }],
    include: { _count: { select: { rows: true, bpuGroups: true } } },
  });

  return (
    <div className="flex flex-col gap-6">
      <div>
        <Link href="/schools" className="text-sm text-teal hover:underline">
          &larr; Kembali
        </Link>
        <h1 className="mt-2 text-2xl font-bold tracking-tight">
          Impor BKU &mdash; {school.name}
        </h1>
        <p className="mt-1 text-sm text-muted">
          Unggah satu atau beberapa BKU bulanan, lalu review sebelum membuat SPM.
        </p>
      </div>

      <ImportForm schoolId={schoolId} />

      {imports.length > 0 && (
        <div className="card flex flex-wrap items-center justify-between gap-3 p-4">
          <div>
            <p className="text-sm font-semibold">Rekap Honor per Bulan</p>
            <p className="mt-0.5 text-xs text-muted">
              Satu PDF berisi rekap honor terpisah untuk setiap BKU bulanan
              yang diimpor ({imports.length} bulan). Honor hanya dicatat pada
              bulan dana tersebut tercantum di BKU.
            </p>
          </div>
          <a
            href={`/api/school/${schoolId}/honor-all`}
            className="btn btn-teal shrink-0"
          >
            ⬇ Unduh Rekap Honor per Bulan
          </a>
        </div>
      )}

      {imports.length > 0 && (
        <div className="card flex flex-wrap items-center justify-between gap-3 p-4">
          <div>
            <p className="text-sm font-semibold">Invoice A2 Mandiri Keseluruhan</p>
            <p className="mt-0.5 text-xs text-muted">
              Satu PDF, satu invoice per bulan yang punya pembelian buku
              pelajaran yang sudah dikonfirmasi — bulan tanpa pembelian buku
              dilewati otomatis.
            </p>
          </div>
          <a
            href={`/api/school/${schoolId}/a2-mandiri-invoices`}
            className="btn btn-primary shrink-0"
          >
            ⬇ Generate Semua Invoice A2 Mandiri
          </a>
        </div>
      )}

      <div>
        <h2 className="mb-3 text-sm font-semibold">Riwayat Impor</h2>
        {imports.length === 0 ? (
          <div className="card p-8 text-center text-sm text-muted">
            Belum ada BKU yang diimpor untuk sekolah ini.
          </div>
        ) : (
          <ul className="grid gap-3 sm:grid-cols-2">
            {imports.map((imp) => {
              const deleteAction = deleteBKUImport.bind(null, schoolId, imp.id);
              return (
                <li key={imp.id} className="card flex flex-col gap-3 p-4">
                  <div className="flex items-start justify-between">
                    <div>
                      <p className="font-semibold">
                        {monthName(imp.month)} {imp.year}
                      </p>
                      <p className="text-xs text-muted">{imp.sourceFileName}</p>
                    </div>
                    <span className="badge badge-info">{imp.status}</span>
                  </div>
                  <div className="flex gap-2 text-xs">
                    <span className="badge badge-muted">{imp._count.rows} baris</span>
                    <span className="badge badge-muted">
                      {imp._count.bpuGroups} kode BPU
                    </span>
                  </div>
                  <div className="mt-auto flex items-center gap-2 border-t border-line pt-3">
                    <Link
                      href={`/schools/${schoolId}/import/${imp.id}/review`}
                      className="btn btn-teal flex-1"
                    >
                      Review &amp; Buat SPM
                    </Link>
                    <form action={deleteAction}>
                      <button type="submit" className="btn btn-danger px-3 py-2 text-xs">
                        Hapus
                      </button>
                    </form>
                  </div>
                </li>
              );
            })}
          </ul>
        )}
      </div>
    </div>
  );
}
