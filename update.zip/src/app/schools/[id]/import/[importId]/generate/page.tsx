import Link from "next/link";
import { notFound } from "next/navigation";
import { prisma } from "@/lib/db";
import { generateSPMDocuments } from "@/lib/actions/spm";
import { buildHonorRecapData } from "@/lib/honor-recap/recapBuilder";
import { buildA2MandiriInvoiceData } from "@/lib/invoice/buildA2MandiriInvoiceData";
import { monthName } from "@/lib/indonesian/months";

export default async function GeneratePage({
  params,
}: {
  params: Promise<{ id: string; importId: string }>;
}) {
  const { id: schoolId, importId: bkuImportId } = await params;

  const school = await prisma.school.findUnique({ where: { id: schoolId } });
  const bkuImport = await prisma.bKUImport.findUnique({ where: { id: bkuImportId } });
  if (!school || !bkuImport || bkuImport.schoolId !== schoolId) notFound();

  const groups = await prisma.bPUGroup.findMany({
    where: { bkuImportId },
    include: { spmDocument: true, matchedVendorRule: true },
    orderBy: { bpuNumber: "asc" },
  });

  const confirmed = groups.filter((g) => g.status === "CONFIRMED");
  const notConfirmed = groups.filter((g) => g.status !== "CONFIRMED");
  const generatedCount = groups.filter((g) => g.spmDocument).length;

  const generateAction = generateSPMDocuments.bind(null, schoolId, bkuImportId);

  const honor = await buildHonorRecapData(schoolId, bkuImportId);
  const honorRowCount = honor.sheets.reduce((n, s) => n + s.rows.length, 0);

  const a2MandiriInvoice = await buildA2MandiriInvoiceData(schoolId, bkuImportId);

  return (
    <div className="flex flex-col gap-6">
      <div>
        <Link
          href={`/schools/${schoolId}/import/${bkuImportId}/review`}
          className="text-sm text-teal hover:underline"
        >
          &larr; Kembali ke Review
        </Link>
        <h1 className="mt-2 text-2xl font-bold tracking-tight">
          Generate SPM &mdash; {school.name} · {monthName(bkuImport.month)}{" "}
          {bkuImport.year}
        </h1>
      </div>

      <div className="card flex flex-col gap-3 p-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex flex-wrap items-center gap-x-5 gap-y-1 text-sm">
            <span>
              <strong>{confirmed.length}</strong> BPU siap ·{" "}
              <strong>{generatedCount}</strong> sudah digenerate
            </span>
            <span className="font-semibold text-primary">
              Total Rp{" "}
              {confirmed
                .reduce((sum, g) => sum + g.totalAmount, 0)
                .toLocaleString("id-ID")}
            </span>
            {notConfirmed.length > 0 && (
              <span className="badge badge-warn">
                {notConfirmed.length} belum dikonfirmasi — tidak ikut
              </span>
            )}
          </div>
          <form action={generateAction}>
            <button type="submit" disabled={confirmed.length === 0} className="btn btn-primary">
              Generate {confirmed.length} SPM
            </button>
          </form>
        </div>

        {confirmed.length > 0 && (
          <div className="flex flex-wrap items-center gap-2 border-t border-line pt-3">
            <span className="text-xs font-medium text-muted">Unduhan:</span>
            <a
              href={`/api/bku-import/${bkuImportId}/combined`}
              className="btn btn-teal px-3 py-1.5 text-xs"
              title="Satu file PDF berisi seluruh SPM bulan ini, satu surat per halaman — praktis untuk cetak sekaligus."
            >
              📄 SPM Keseluruhan (1 PDF, {confirmed.length} surat)
            </a>
            {generatedCount > 0 && (
              <a
                href={`/api/bku-import/${bkuImportId}/download-all`}
                className="btn btn-ghost px-3 py-1.5 text-xs"
              >
                🗂 File Terpisah (.zip)
              </a>
            )}
            {([1, 2] as const).map((semester) => (
              <a
                key={semester}
                href={`/api/school/${schoolId}/fraza-receipts?year=${bkuImport.year}&semester=${semester}`}
                className="btn btn-ghost px-3 py-1.5 text-xs"
                title={`Satu PDF struk Fraza Cell ${semester === 1 ? "Januari-Juni" : "Juli-Desember"}. Semua BPU listrik/internet pada bulan yang sama dijumlahkan, lalu biaya admin Rp2.000 dipotong sekali.`}
              >
                🧾 Struk Fraza Cell Semester {semester}
              </a>
            ))}
          </div>
        )}
      </div>

      <div className="card overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-line bg-cream text-left text-xs uppercase tracking-wide text-muted">
              <th className="p-3">BPU</th>
              <th className="p-3">Nomor Surat</th>
              <th className="p-3">Kepada</th>
              <th className="p-3 text-right">Jumlah</th>
              <th className="p-3">Status</th>
              <th className="p-3"></th>
            </tr>
          </thead>
          <tbody>
            {groups.map((group) => (
              <tr key={group.id} className="border-b border-line/60 last:border-0">
                <td className="p-3 font-mono text-xs text-muted">{group.bpuCode}</td>
                <td className="p-3 font-medium text-primary">
                  {group.spmDocument?.nomorSurat ?? "—"}
                </td>
                <td className="p-3">
                  {group.spmDocument?.recipient ?? group.overrideRecipient ?? (
                    <span className="text-muted">—</span>
                  )}
                </td>
                <td className="p-3 text-right tabular-nums">
                  Rp {group.totalAmount.toLocaleString("id-ID")}
                </td>
                <td className="p-3">
                  {group.status !== "CONFIRMED" ? (
                    <span className="badge badge-warn">Belum dikonfirmasi</span>
                  ) : group.spmDocument ? (
                    <span className="badge badge-success">Sudah digenerate</span>
                  ) : (
                    <span className="badge badge-info">Siap digenerate</span>
                  )}
                </td>
                <td className="p-3">
                  {group.spmDocument && (
                    <a
                      href={`/api/spm/${group.spmDocument.id}/download`}
                      className="font-medium text-teal hover:underline"
                    >
                      Unduh PDF
                    </a>
                  )}
                  {group.status === "CONFIRMED" &&
                    /fraza\s*cell/i.test(
                      group.overrideRecipient ?? group.matchedVendorRule?.recipient ?? ""
                    ) && (
                      <a
                        href={`/api/bpu-group/${group.id}/struk`}
                        className="ml-3 font-medium text-teal hover:underline"
                        title="PDF berisi satu struk Fraza Cell. Nominal tagihan sudah dikurangi biaya admin Rp2.000."
                      >
                        Struk Fraza Cell
                      </a>
                    )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div>
        <h2 className="mb-3 text-sm font-semibold">Rekap Honor</h2>
        <div className="card flex flex-col gap-3 p-4">
          {honor.sheets.length === 0 ? (
            <p className="text-sm text-muted">
              Belum ada BPU honor yang dikonfirmasi bulan ini. Pastikan aturan
              vendornya sudah dicentang <strong>Honor</strong> di halaman Aturan
              Vendor.
            </p>
          ) : (
            <>
              <div className="flex flex-wrap items-center justify-between gap-3">
                <p className="text-sm">
                  <strong>{honor.sheets.length}</strong> daftar honor ·{" "}
                  <strong>{honorRowCount}</strong> baris penerima untuk{" "}
                  {monthName(bkuImport.month)} {bkuImport.year}.
                </p>
                <a
                  href={`/api/bku-import/${bkuImportId}/honor`}
                  className="btn btn-primary"
                  title="Satu PDF, satu halaman per jenis honor."
                >
                  ⬇ Unduh Rekap Honor
                </a>
              </div>
              <ul className="flex flex-wrap gap-1.5 border-t border-line pt-3">
                {honor.sheets.map((sheet) => (
                  <li key={sheet.category} className="badge badge-muted">
                    {sheet.category} ({sheet.rows.length})
                  </li>
                ))}
              </ul>
            </>
          )}
        </div>
      </div>

      <div>
        <h2 className="mb-3 text-sm font-semibold">Invoice A2 Mandiri (Buku Pelajaran)</h2>
        <div className="card flex flex-col gap-3 p-4">
          {!a2MandiriInvoice ? (
            <p className="text-sm text-muted">
              Belum ada pembelian buku pelajaran (A2 Mandiri) yang dikonfirmasi
              bulan ini.
            </p>
          ) : (
            <div className="flex flex-wrap items-center justify-between gap-3">
              <p className="text-sm">
                <strong>{a2MandiriInvoice.lines.length}</strong> judul buku ·
                total{" "}
                <strong className="text-primary">
                  Rp {a2MandiriInvoice.total.toLocaleString("id-ID")}
                </strong>{" "}
                · No. Invoice {a2MandiriInvoice.noInvoice}
              </p>
              <a
                href={`/api/bku-import/${bkuImportId}/a2-mandiri-invoice`}
                className="btn btn-primary"
                title="PDF invoice A2 Mandiri untuk seluruh pembelian buku pelajaran bulan ini."
              >
                ⬇ Unduh Invoice
              </a>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
