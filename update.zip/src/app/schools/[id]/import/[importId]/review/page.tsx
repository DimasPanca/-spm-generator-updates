import Link from "next/link";
import { notFound } from "next/navigation";
import { prisma } from "@/lib/db";
import {
  applyVendorRule,
  confirmAllComplete,
  confirmBPUGroup,
  unconfirmBPUGroup,
} from "@/lib/actions/bpu-group";
import { rerunMatching } from "@/lib/actions/bku-import";
import { computeGroupFields } from "@/lib/spm/paymentFormatter";
import { buildNomorSurat, formatFullIndonesianDate } from "@/lib/spm/nomorSurat";
import { amountToTerbilang } from "@/lib/terbilang/terbilang";
import { monthName } from "@/lib/indonesian/months";

type FilterKey = "semua" | "belum" | "tanpa-saran" | "perlu-nama" | "sudah";

export default async function ReviewPage({
  params,
  searchParams,
}: {
  params: Promise<{ id: string; importId: string }>;
  searchParams: Promise<{ filter?: string }>;
}) {
  const { id: schoolId, importId: bkuImportId } = await params;
  const { filter: rawFilter } = await searchParams;
  const filter: FilterKey = (
    ["semua", "belum", "tanpa-saran", "perlu-nama", "sudah"] as const
  ).includes(rawFilter as FilterKey)
    ? (rawFilter as FilterKey)
    : "semua";

  const school = await prisma.school.findUnique({ where: { id: schoolId } });
  const bkuImport = await prisma.bKUImport.findUnique({ where: { id: bkuImportId } });
  if (!school || !bkuImport || bkuImport.schoolId !== schoolId) notFound();

  const [groups, vendorRules] = await Promise.all([
    prisma.bPUGroup.findMany({
      where: { bkuImportId },
      include: { matchedVendorRule: true },
      orderBy: { bpuNumber: "asc" },
    }),
    prisma.vendorRule.findMany({
      where: { schoolId, isActive: true },
      orderBy: { priority: "asc" },
    }),
  ]);

  const rowsByGroup = new Map(
    await Promise.all(
      groups.map(
        async (g) =>
          [
            g.bpuCode,
            await prisma.bKURow.findMany({ where: { bkuImportId, bpuCode: g.bpuCode } }),
          ] as const
      )
    )
  );

  // Per-group classification drives the filter chips and the bulk action's
  // eligibility count. "perlu-nama" = a rule matched, but its recipient is a
  // person the admin still has to fill in; "siap" = suggestion is complete
  // and only awaits a click.
  type Kind = "sudah" | "tanpa-saran" | "perlu-nama" | "siap";
  function classify(group: (typeof groups)[number]): Kind {
    if (group.status === "CONFIRMED") return "sudah";
    if (!group.matchedVendorRuleId) return "tanpa-saran";
    const rows = rowsByGroup.get(group.bpuCode) ?? [];
    const computed = computeGroupFields(rows, group.matchedVendorRule);
    const recipient = group.overrideRecipient ?? computed.recipient;
    return recipient.trim() === "" ? "perlu-nama" : "siap";
  }

  const kinds = new Map(groups.map((g) => [g.id, classify(g)] as const));
  const confirmedCount = groups.filter((g) => kinds.get(g.id) === "sudah").length;
  const noMatchCount = groups.filter((g) => kinds.get(g.id) === "tanpa-saran").length;
  const needsNameCount = groups.filter((g) => kinds.get(g.id) === "perlu-nama").length;
  const readyCount = groups.filter((g) => kinds.get(g.id) === "siap").length;

  const visibleGroups = groups.filter((g) => {
    const kind = kinds.get(g.id)!;
    if (filter === "semua") return true;
    if (filter === "belum") return kind !== "sudah";
    return kind === filter;
  });

  const rerunMatchingWithId = rerunMatching.bind(null, schoolId, bkuImportId);
  const confirmAllWithId = confirmAllComplete.bind(null, schoolId, bkuImportId);
  const progress = groups.length ? Math.round((confirmedCount / groups.length) * 100) : 0;

  const chips: { key: FilterKey; label: string; count: number }[] = [
    { key: "semua", label: "Semua", count: groups.length },
    { key: "belum", label: "Belum dikonfirmasi", count: groups.length - confirmedCount },
    { key: "tanpa-saran", label: "Tanpa saran", count: noMatchCount },
    { key: "perlu-nama", label: "Perlu isi nama", count: needsNameCount },
    { key: "sudah", label: "Dikonfirmasi", count: confirmedCount },
  ];

  return (
    <div className="flex flex-col gap-6">
      <div>
        <Link
          href={`/schools/${schoolId}/import`}
          className="text-sm text-teal hover:underline"
        >
          &larr; Kembali
        </Link>
        <h1 className="mt-2 text-2xl font-bold tracking-tight">
          Review &mdash; {school.name} · {monthName(bkuImport.month)} {bkuImport.year}
        </h1>
        <p className="mt-1 max-w-2xl text-sm text-muted">
          &quot;Kepada&quot; &amp; &quot;Untuk Pembayaran&quot; adalah saran
          otomatis. Edit bila perlu lalu <strong>Konfirmasi</strong> — SPM hanya
          dibuat untuk BPU yang sudah dikonfirmasi.
        </p>
      </div>

      <div className="card sticky top-3 z-10 flex flex-col gap-3 p-4 shadow-md">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-4">
            <div className="flex flex-col">
              <span className="text-sm font-semibold">
                {confirmedCount}/{groups.length} BPU dikonfirmasi
              </span>
              <div className="mt-1 h-1.5 w-40 overflow-hidden rounded-full bg-line">
                <div
                  className="h-full rounded-full bg-mint transition-all"
                  style={{ width: `${progress}%` }}
                />
              </div>
            </div>
          </div>
          <div className="flex flex-wrap gap-2">
            {readyCount > 0 && (
              <form action={confirmAllWithId}>
                <button
                  type="submit"
                  className="btn btn-teal"
                  title="Hanya mengonfirmasi BPU yang sarannya sudah lengkap (Kepada terisi). Yang tanpa saran atau masih perlu nama tetap menunggu review manual."
                >
                  ✓ Konfirmasi {readyCount} Saran Lengkap
                </button>
              </form>
            )}
            <form action={rerunMatchingWithId}>
              <button type="submit" className="btn btn-ghost">
                ↻ Cocokkan Ulang
              </button>
            </form>
            <Link
              href={`/schools/${schoolId}/import/${bkuImportId}/generate`}
              className="btn btn-primary"
            >
              Lanjut ke Generate &rarr;
            </Link>
          </div>
        </div>

        <div className="flex flex-wrap gap-1.5 border-t border-line pt-3">
          {chips.map((chip) => (
            <Link
              key={chip.key}
              href={`/schools/${schoolId}/import/${bkuImportId}/review${
                chip.key === "semua" ? "" : `?filter=${chip.key}`
              }`}
              className={`rounded-full px-3 py-1 text-xs font-semibold transition-colors ${
                filter === chip.key
                  ? "bg-primary text-white"
                  : "bg-cream text-muted hover:text-ink"
              }`}
            >
              {chip.label} ({chip.count})
            </Link>
          ))}
        </div>
      </div>

      {visibleGroups.length === 0 && (
        <div className="card p-8 text-center text-sm text-muted">
          Tidak ada BPU pada filter ini. 🎉
        </div>
      )}

      <div className="flex flex-col gap-4">
        {visibleGroups.map((group) => {
          const rows = rowsByGroup.get(group.bpuCode) ?? [];
          const computed = computeGroupFields(rows, group.matchedVendorRule);
          const displayRecipient = group.overrideRecipient ?? computed.recipient;
          const displayPaymentFor = group.overridePaymentFor ?? computed.paymentFor;
          const nomorSurat = buildNomorSurat(group.bpuNumber, school.formatCode, group.tanggal);
          const terbilang = amountToTerbilang(group.totalAmount);
          const mengetahui = formatFullIndonesianDate(group.tanggal);
          const isConfirmed = group.status === "CONFIRMED";
          const kind = kinds.get(group.id)!;
          const statusBadge =
            kind === "sudah"
              ? { className: "badge-success", label: "✓ Dikonfirmasi" }
              : kind === "siap"
                ? { className: "badge-info", label: "Siap dikonfirmasi" }
                : kind === "perlu-nama"
                  ? { className: "badge-warn", label: "Perlu isi nama" }
                  : { className: "badge-warn", label: "Perlu review" };

          const applyAction = applyVendorRule.bind(null, schoolId, bkuImportId, group.id);
          const confirmAction = confirmBPUGroup.bind(null, schoolId, bkuImportId, group.id);
          const unconfirmAction = unconfirmBPUGroup.bind(null, schoolId, bkuImportId, group.id);

          return (
            <div
              key={group.id}
              className={`card overflow-hidden p-0 ${isConfirmed ? "border-mint" : ""}`}
            >
              <div
                className={`flex flex-wrap items-center justify-between gap-2 border-b border-line px-4 py-3 ${
                  isConfirmed ? "bg-mint-soft/40" : "bg-cream"
                }`}
              >
                <div className="flex items-baseline gap-2">
                  <span className="font-mono text-xs text-muted">{group.bpuCode}</span>
                  <span className="font-semibold text-primary">{nomorSurat}</span>
                  <span className="text-xs text-muted">
                    {group.tanggal.toISOString().slice(0, 10)} · {rows.length} baris
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-sm font-semibold">
                    Rp {group.totalAmount.toLocaleString("id-ID")}
                  </span>
                  <span className={`badge ${statusBadge.className}`}>
                    {statusBadge.label}
                  </span>
                </div>
              </div>

              <div className="flex flex-col gap-3 p-4">
                <p className="text-xs text-muted">
                  Terbilang: <span className="italic">{terbilang}</span> · Mengetahui {mengetahui}
                </p>

                <details className="text-xs text-muted">
                  <summary className="cursor-pointer select-none hover:text-ink">
                    Lihat {rows.length} baris uraian sumber
                  </summary>
                  <ul className="mt-1.5 list-disc space-y-0.5 pl-5">
                    {rows.map((r) => (
                      <li key={r.id}>{r.uraian}</li>
                    ))}
                  </ul>
                </details>

                <form
                  action={applyAction}
                  className="flex flex-wrap items-center gap-2 rounded-lg bg-cream p-2.5"
                >
                  <span className="text-xs font-medium text-muted">Aturan vendor:</span>
                  <select
                    name="vendorRuleId"
                    defaultValue={group.matchedVendorRuleId ?? ""}
                    className="input-field max-w-xs flex-1 px-2 py-1.5 text-sm"
                  >
                    <option value="">(tidak ada — isi manual)</option>
                    {vendorRules.map((rule) => {
                      const label =
                        (rule.keyword.split(",")[0] || `keg ${rule.matchKodeKegiatan}`).trim();
                      const target = rule.recipient
                        ? rule.recipient
                        : rule.formatType === "NAME_FROM_URAIAN"
                          ? "(nama dari uraian)"
                          : "(isi nama)";
                      return (
                        <option key={rule.id} value={rule.id}>
                          {label} → {target}
                        </option>
                      );
                    })}
                  </select>
                  <button type="submit" className="btn btn-ghost px-2.5 py-1.5 text-xs">
                    Terapkan
                  </button>
                  {!group.matchedVendorRuleId && (
                    <span className="badge badge-warn">Tidak ada saran otomatis</span>
                  )}
                </form>

                <form action={confirmAction} className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                  <label className="flex flex-col gap-1">
                    <span className="field-label">Kepada</span>
                    <input
                      type="text"
                      name="recipient"
                      defaultValue={displayRecipient}
                      placeholder="nama penerima / toko"
                      className="input-field"
                    />
                  </label>
                  <label className="flex flex-col gap-1">
                    <span className="field-label">Untuk Pembayaran</span>
                    <input
                      type="text"
                      name="paymentFor"
                      defaultValue={displayPaymentFor}
                      className="input-field"
                    />
                  </label>
                  <div className="flex gap-2 sm:col-span-2">
                    <button type="submit" className="btn btn-primary">
                      {isConfirmed ? "Simpan Perubahan" : "Konfirmasi"}
                    </button>
                    {isConfirmed && (
                      <button
                        type="submit"
                        formAction={unconfirmAction}
                        className="btn btn-ghost"
                      >
                        Batalkan
                      </button>
                    )}
                  </div>
                </form>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
