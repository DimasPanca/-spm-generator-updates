import Link from "next/link";
import { notFound } from "next/navigation";
import { prisma } from "@/lib/db";
import { deleteRkasImport } from "@/lib/actions/rkas-import";
import { monthName } from "@/lib/indonesian/months";
import RkasImportForm from "./RkasImportForm";

export default async function RkasPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id: schoolId } = await params;
  const school = await prisma.school.findUnique({ where: { id: schoolId } });
  if (!school) notFound();

  const imports = await prisma.rkasImport.findMany({
    where: { schoolId },
    orderBy: [{ year: "desc" }, { month: "desc" }],
    include: {
      programs: {
        select: {
          included: true,
          items: { select: { jumlah: true, excluded: true } },
        },
      },
    },
  });

  return (
    <div className="flex flex-col gap-6">
      <div>
        <Link href="/schools" className="text-sm text-teal hover:underline">
          &larr; Kembali
        </Link>
        <h1 className="mt-2 text-2xl font-bold tracking-tight">
          Surat Lampiran &mdash; {school.name}
        </h1>
        <p className="mt-1 text-sm text-muted">
          Unggah RKAS bulanan, konfirmasi kode program mana yang masuk lampiran,
          lalu unduh Lampiran Belanja Tunai dalam bentuk PDF.
        </p>
      </div>

      <RkasImportForm schoolId={schoolId} />

      <div>
        <h2 className="mb-3 text-sm font-semibold">Riwayat RKAS</h2>
        {imports.length === 0 ? (
          <div className="card p-8 text-center text-sm text-muted">
            Belum ada RKAS yang diimpor untuk sekolah ini.
          </div>
        ) : (
          <ul className="grid gap-3 sm:grid-cols-2">
            {imports.map((imp) => {
              const deleteAction = deleteRkasImport.bind(null, schoolId, imp.id);
              const confirmedPrograms = imp.programs.filter((p) => p.included);
              const selectedTotal = confirmedPrograms.reduce(
                (sum, p) =>
                  sum +
                  p.items
                    .filter((i) => !i.excluded)
                    .reduce((s, i) => s + i.jumlah, 0),
                0
              );

              return (
                <li key={imp.id} className="card flex flex-col gap-3 p-4">
                  <div className="flex items-start justify-between gap-2">
                    <div className="min-w-0">
                      <p className="font-semibold">
                        {monthName(imp.month)} {imp.year}
                      </p>
                      <p className="truncate text-xs text-muted">
                        {imp.sourceFileName}
                        {imp.sourceSchoolName ? ` — ${imp.sourceSchoolName}` : ""}
                      </p>
                    </div>
                    <span
                      className={`badge shrink-0 ${
                        confirmedPrograms.length > 0 ? "badge-success" : "badge-warn"
                      }`}
                    >
                      {confirmedPrograms.length > 0
                        ? `${confirmedPrograms.length} dikonfirmasi`
                        : "Belum dikonfirmasi"}
                    </span>
                  </div>

                  <div className="flex flex-wrap gap-2 text-xs">
                    <span className="badge badge-muted">
                      {imp.programs.length} kode program
                    </span>
                    <span className="badge badge-muted">
                      Rp {selectedTotal.toLocaleString("id-ID")} masuk lampiran
                    </span>
                  </div>

                  <div className="mt-auto flex items-center gap-2 border-t border-line pt-3">
                    <Link
                      href={`/schools/${schoolId}/rkas/${imp.id}`}
                      className="btn btn-teal flex-1"
                    >
                      Konfirmasi &amp; Buat Lampiran
                    </Link>
                    <form action={deleteAction}>
                      <button type="submit" className="btn btn-danger px-3 py-2 text-xs">
                        Hapus
                      </button>
                    </form>
                  </div>
                </li>
              );
            })}
          </ul>
        )}
      </div>
    </div>
  );
}
