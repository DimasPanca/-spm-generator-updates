"use client";

import { useActionState } from "react";
import { useRouter } from "next/navigation";
import { importRkasFilesAction, type RkasImportResult } from "@/lib/actions/rkas-import";

export default function RkasImportForm({ schoolId }: { schoolId: string }) {
  const router = useRouter();
  const action = importRkasFilesAction.bind(null, schoolId);
  const [results, formAction, isPending] = useActionState<RkasImportResult[], FormData>(
    async (prevState, formData) => {
      const next = await action(prevState, formData);
      router.refresh();
      return next;
    },
    []
  );

  return (
    <div className="flex flex-col gap-4">
      <form action={formAction} className="card flex flex-col gap-4 p-5">
        <label className="flex flex-col gap-1.5">
          <span className="field-label">File RKAS bulanan (PDF)</span>
          <input
            type="file"
            name="files"
            accept="application/pdf"
            multiple
            required
            className="text-sm text-muted file:mr-3 file:rounded-md file:border-0 file:bg-primary file:px-3 file:py-1.5 file:text-sm file:font-medium file:text-white hover:file:bg-primary-dark"
          />
          <span className="text-xs text-muted">
            Yang dibaca adalah &ldquo;Rincian Kertas Kerja perBulan&rdquo;. Bulan,
            tahun, nama kepala &amp; bendahara diambil otomatis dari file.
          </span>
        </label>
        <button type="submit" disabled={isPending} className="btn btn-primary self-start">
          {isPending ? "Memproses…" : "Impor & Baca RKAS"}
        </button>
      </form>

      {results.length > 0 && (
        <ul className="flex flex-col gap-2">
          {results.map((r) => (
            <li
              key={r.fileName}
              className={`card p-4 text-sm ${
                r.status === "ok"
                  ? "border-mint bg-mint-soft/40"
                  : "border-red-200 bg-red-50/50"
              }`}
            >
              <p className="flex items-center gap-2 font-medium">
                <span>{r.status === "ok" ? "✓" : "✕"}</span>
                {r.fileName}
              </p>
              {r.status === "ok" ? (
                <p className="mt-0.5 text-ink/80">
                  {r.programCount} kode program, {r.itemCount} rincian belanja,
                  total Rp {r.totalAmount?.toLocaleString("id-ID")}.
                  {r.warnings && r.warnings.length > 0 && (
                    <span className="mt-0.5 block text-amber-700">
                      {r.warnings.join(" ")}
                    </span>
                  )}
                </p>
              ) : (
                <p className="mt-0.5 text-red-600">{r.error}</p>
              )}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
