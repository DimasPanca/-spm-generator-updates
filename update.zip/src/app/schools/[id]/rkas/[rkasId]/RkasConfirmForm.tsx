"use client";

import { useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import { useActionState } from "react";
import { saveRkasConfirmation } from "@/lib/actions/rkas-import";

export interface ConfirmItem {
  id: string;
  noUrut: number;
  uraian: string;
  volumeText: string;
  tarifHarga: number;
  jumlah: number;
  excluded: boolean;
}

export interface ConfirmProgram {
  id: string;
  kodeProgram: string;
  nama: string;
  standarName: string;
  kegiatanName: string;
  included: boolean;
  items: ConfirmItem[];
}

export interface ConfirmDefaults {
  namaPelaksana: string;
  programLabel: string;
  namaKegiatan: string;
  sumberDana: string;
  pekerjaanLabel: string;
  kepalaName: string;
  bendaharaName: string;
}

const rp = (n: number) => `Rp ${n.toLocaleString("id-ID")}`;

export default function RkasConfirmForm({
  schoolId,
  rkasId,
  programs,
  defaults,
}: {
  schoolId: string;
  rkasId: string;
  programs: ConfirmProgram[];
  defaults: ConfirmDefaults;
}) {
  const router = useRouter();

  const [programOn, setProgramOn] = useState<Record<string, boolean>>(() =>
    Object.fromEntries(programs.map((p) => [p.id, p.included]))
  );
  const [itemOn, setItemOn] = useState<Record<string, boolean>>(() =>
    Object.fromEntries(
      programs.flatMap((p) => p.items.map((i) => [i.id, !i.excluded]))
    )
  );

  // The lampiran's "Besar Dana Yang di butuhkan" is whatever is ticked right
  // now, so it is shown live rather than only after saving.
  const { total, itemCount, programCount } = useMemo(() => {
    let total = 0;
    let itemCount = 0;
    let programCount = 0;
    for (const program of programs) {
      if (!programOn[program.id]) continue;
      programCount++;
      for (const item of program.items) {
        if (!itemOn[item.id]) continue;
        total += item.jumlah;
        itemCount++;
      }
    }
    return { total, itemCount, programCount };
  }, [programs, programOn, itemOn]);

  // The download route renders from the database, so unsaved ticks would
  // silently produce the wrong lampiran. Block it until the state is saved.
  const dirty = useMemo(
    () =>
      programs.some(
        (p) =>
          programOn[p.id] !== p.included ||
          p.items.some((i) => itemOn[i.id] === i.excluded)
      ),
    [programs, programOn, itemOn]
  );

  const save = saveRkasConfirmation.bind(null, schoolId, rkasId);
  const [, formAction, isPending] = useActionState<null, FormData>(
    async (_prev, formData) => {
      await save(formData);
      router.refresh();
      return null;
    },
    null
  );

  const setAllPrograms = (value: boolean) =>
    setProgramOn(Object.fromEntries(programs.map((p) => [p.id, value])));

  const setProgramItems = (program: ConfirmProgram, value: boolean) =>
    setItemOn((prev) => ({
      ...prev,
      ...Object.fromEntries(program.items.map((i) => [i.id, value])),
    }));

  return (
    <form action={formAction} className="flex flex-col gap-5">
      <section className="card flex flex-col gap-4 p-5">
        <div>
          <h2 className="text-sm font-semibold">Penanda Tangan</h2>
          <p className="mt-0.5 text-xs text-muted">
            Terisi otomatis dari halaman tanda tangan RKAS &mdash; cek dan
            perbaiki bila perlu.
          </p>
        </div>
        <div className="grid gap-4 sm:grid-cols-2">
          <label className="flex flex-col gap-1.5">
            <span className="field-label">Nama Kepala Sekolah</span>
            <input
              name="kepalaName"
              defaultValue={defaults.kepalaName}
              className="input-field"
              placeholder="cth. Mala Widianti, S. Pd"
            />
          </label>
          <label className="flex flex-col gap-1.5">
            <span className="field-label">Nama Bendahara BOSP</span>
            <input
              name="bendaharaName"
              defaultValue={defaults.bendaharaName}
              className="input-field"
              placeholder="cth. Sri Margorini, S. Pd., M. Si"
            />
          </label>
        </div>
      </section>

      <details className="card p-5">
        <summary className="cursor-pointer text-sm font-semibold">
          Identitas Lampiran (opsional)
        </summary>
        <div className="mt-4 grid gap-4 sm:grid-cols-2">
          <label className="flex flex-col gap-1.5">
            <span className="field-label">Nama Pelaksana Teknis Kegiatan</span>
            <input
              name="namaPelaksana"
              defaultValue={defaults.namaPelaksana}
              className="input-field"
              placeholder="Kosongkan bila tidak diisi"
            />
          </label>
          <label className="flex flex-col gap-1.5">
            <span className="field-label">Program</span>
            <input name="programLabel" defaultValue={defaults.programLabel} className="input-field" />
          </label>
          <label className="flex flex-col gap-1.5">
            <span className="field-label">Nama Kegiatan</span>
            <input name="namaKegiatan" defaultValue={defaults.namaKegiatan} className="input-field" />
          </label>
          <label className="flex flex-col gap-1.5">
            <span className="field-label">Sumber Dana</span>
            <input name="sumberDana" defaultValue={defaults.sumberDana} className="input-field" />
          </label>
          <label className="flex flex-col gap-1.5">
            <span className="field-label">Pekerjaan (baris pertama tabel)</span>
            <input
              name="pekerjaanLabel"
              defaultValue={defaults.pekerjaanLabel}
              className="input-field"
            />
          </label>
        </div>
      </details>

      <section className="flex flex-col gap-3">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h2 className="text-sm font-semibold">Konfirmasi Kode Program</h2>
            <p className="mt-0.5 text-xs text-muted">
              Centang kode program yang masuk lampiran. Seluruh rinciannya ikut
              masuk &mdash; buka daftarnya kalau ada barang yang mau dikecualikan.
            </p>
          </div>
          <div className="flex gap-2">
            <button
              type="button"
              onClick={() => setAllPrograms(true)}
              className="btn btn-ghost px-3 py-1.5 text-xs"
            >
              Centang Semua
            </button>
            <button
              type="button"
              onClick={() => setAllPrograms(false)}
              className="btn btn-ghost px-3 py-1.5 text-xs"
            >
              Kosongkan Semua
            </button>
          </div>
        </div>

        <ul className="flex flex-col gap-2">
          {programs.map((program) => {
            const on = programOn[program.id];
            const included = program.items.filter((i) => itemOn[i.id]);
            const subtotal = included.reduce((s, i) => s + i.jumlah, 0);
            const excludedCount = program.items.length - included.length;

            return (
              <li
                key={program.id}
                className={`card overflow-hidden ${on ? "border-teal" : ""}`}
              >
                <div className="flex items-start gap-3 p-4">
                  <input
                    type="checkbox"
                    name={`program_${program.id}`}
                    checked={on}
                    onChange={(e) =>
                      setProgramOn((prev) => ({
                        ...prev,
                        [program.id]: e.target.checked,
                      }))
                    }
                    className="mt-1 h-4 w-4 shrink-0 accent-[#2E5077]"
                  />
                  <div className="min-w-0 flex-1">
                    <p className="font-semibold">
                      <span className="font-mono text-primary">
                        {program.kodeProgram}
                      </span>{" "}
                      {program.nama}
                    </p>
                    <p className="mt-0.5 text-xs text-muted">
                      {program.standarName}
                      {program.kegiatanName ? ` › ${program.kegiatanName}` : ""}
                    </p>
                    <div className="mt-2 flex flex-wrap gap-2 text-xs">
                      <span className="badge badge-muted">
                        {included.length} dari {program.items.length} barang
                      </span>
                      <span className={`badge ${on ? "badge-success" : "badge-muted"}`}>
                        {rp(subtotal)}
                      </span>
                      {excludedCount > 0 && (
                        <span className="badge badge-warn">
                          {excludedCount} dikecualikan
                        </span>
                      )}
                    </div>
                  </div>
                </div>

                <details className="border-t border-line bg-cream/60">
                  <summary className="cursor-pointer px-4 py-2 text-xs font-semibold text-primary">
                    Rincian barang ({program.items.length})
                  </summary>
                  <div className="px-4 pb-3">
                    <div className="mb-2 flex gap-2">
                      <button
                        type="button"
                        onClick={() => setProgramItems(program, true)}
                        className="btn btn-ghost px-2 py-1 text-[11px]"
                      >
                        Masukkan semua
                      </button>
                      <button
                        type="button"
                        onClick={() => setProgramItems(program, false)}
                        className="btn btn-ghost px-2 py-1 text-[11px]"
                      >
                        Kecualikan semua
                      </button>
                    </div>
                    <ul className="flex flex-col divide-y divide-line">
                      {program.items.map((item) => (
                        <li key={item.id} className="flex items-start gap-3 py-2">
                          <input
                            type="checkbox"
                            name={`item_${item.id}`}
                            checked={itemOn[item.id]}
                            onChange={(e) =>
                              setItemOn((prev) => ({
                                ...prev,
                                [item.id]: e.target.checked,
                              }))
                            }
                            className="mt-0.5 h-3.5 w-3.5 shrink-0 accent-[#4DA1A9]"
                          />
                          <span
                            className={`min-w-0 flex-1 text-sm ${
                              itemOn[item.id] ? "" : "text-muted line-through"
                            }`}
                          >
                            {item.uraian}
                          </span>
                          <span className="shrink-0 text-xs text-muted">
                            {item.volumeText} × {rp(item.tarifHarga)}
                          </span>
                          <span className="w-24 shrink-0 text-right text-sm font-medium">
                            {rp(item.jumlah)}
                          </span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </details>
              </li>
            );
          })}
        </ul>
      </section>

      <div className="sticky bottom-4 z-10">
        <div className="card flex flex-wrap items-center justify-between gap-3 border-teal p-4 shadow-lg">
          <div>
            <p className="text-sm font-semibold">
              {programCount} kode program &middot; {itemCount} rincian belanja
            </p>
            <p className="mt-0.5 text-xs text-muted">
              Besar dana yang dibutuhkan:{" "}
              <span className="font-semibold text-primary">{rp(total)}</span>
            </p>
            {dirty && (
              <p className="mt-0.5 text-xs text-amber-700">
                Ada perubahan yang belum disimpan — simpan dulu sebelum mengunduh.
              </p>
            )}
          </div>
          <div className="flex items-center gap-2">
            <button type="submit" disabled={isPending} className="btn btn-primary">
              {isPending ? "Menyimpan…" : "Simpan Konfirmasi"}
            </button>
            <a
              href={`/api/rkas/${rkasId}/lampiran`}
              className={`btn btn-teal ${
                itemCount === 0 || dirty ? "pointer-events-none opacity-45" : ""
              }`}
            >
              ⬇ Unduh Lampiran
            </a>
          </div>
        </div>
      </div>
    </form>
  );
}
