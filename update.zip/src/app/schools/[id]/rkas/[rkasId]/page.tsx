import Link from "next/link";
import { notFound } from "next/navigation";
import { prisma } from "@/lib/db";
import { monthName } from "@/lib/indonesian/months";
import RkasConfirmForm from "./RkasConfirmForm";

export default async function RkasConfirmPage({
  params,
}: {
  params: Promise<{ id: string; rkasId: string }>;
}) {
  const { id: schoolId, rkasId } = await params;

  const rkas = await prisma.rkasImport.findUnique({
    where: { id: rkasId },
    include: {
      programs: {
        orderBy: { urutan: "asc" },
        include: { items: { orderBy: { urutan: "asc" } } },
      },
    },
  });
  if (!rkas || rkas.schoolId !== schoolId) notFound();

  const grandTotal = rkas.programs.reduce(
    (sum, p) => sum + p.items.reduce((s, i) => s + i.jumlah, 0),
    0
  );

  return (
    <div className="flex flex-col gap-6">
      <div>
        <Link
          href={`/schools/${schoolId}/rkas`}
          className="text-sm text-teal hover:underline"
        >
          &larr; Kembali ke daftar RKAS
        </Link>
        <h1 className="mt-2 text-2xl font-bold tracking-tight">
          Lampiran Belanja Tunai &mdash; {monthName(rkas.month)} {rkas.year}
        </h1>
        <p className="mt-1 text-sm text-muted">
          {rkas.sourceSchoolName ?? rkas.sourceFileName}
          {rkas.npsn ? ` · NPSN ${rkas.npsn}` : ""} · {rkas.programs.length} kode
          program · total RKAS Rp {grandTotal.toLocaleString("id-ID")}
        </p>
      </div>

      <RkasConfirmForm
        schoolId={schoolId}
        rkasId={rkas.id}
        programs={rkas.programs.map((p) => ({
          id: p.id,
          kodeProgram: p.kodeProgram,
          nama: p.nama,
          standarName: p.standarName,
          kegiatanName: p.kegiatanName,
          included: p.included,
          items: p.items.map((i) => ({
            id: i.id,
            noUrut: i.noUrut,
            uraian: i.uraian,
            volumeText: i.volumeText,
            tarifHarga: i.tarifHarga,
            jumlah: i.jumlah,
            excluded: i.excluded,
          })),
        }))}
        defaults={{
          namaPelaksana: rkas.namaPelaksana,
          programLabel: rkas.programLabel,
          namaKegiatan: rkas.namaKegiatan,
          sumberDana: rkas.sumberDana,
          pekerjaanLabel: rkas.pekerjaanLabel,
          kepalaName: rkas.kepalaName,
          bendaharaName: rkas.bendaharaName,
        }}
      />
    </div>
  );
}
