import Link from "next/link";
import Image from "next/image";
import { notFound } from "next/navigation";
import { prisma } from "@/lib/db";
import { deleteSchool, updateSchool } from "@/lib/actions/school";

export default async function SchoolSetupPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const school = await prisma.school.findUnique({ where: { id } });
  if (!school) notFound();

  const updateSchoolWithId = updateSchool.bind(null, school.id);
  const deleteSchoolWithId = deleteSchool.bind(null, school.id);

  return (
    <div className="mx-auto flex max-w-2xl flex-col gap-6">
      <div>
        <Link href="/schools" className="text-sm text-teal hover:underline">
          &larr; Kembali
        </Link>
        <h1 className="mt-2 text-2xl font-bold tracking-tight">
          Setelan &mdash; {school.name}
        </h1>
        <p className="mt-1 text-sm text-muted">
          Semua teks di sini muncul langsung di dokumen SPM/Honor sekolah ini.
        </p>
      </div>

      <form
        action={updateSchoolWithId}
        className="flex flex-col gap-5"
      >
        <Section title="Profil & KOP Surat">
          <div className="grid gap-4 sm:grid-cols-2">
            <div className="flex items-start gap-3">
              {school.logoPath ? (
                <Image
                  src={school.logoPath}
                  alt="Logo sekolah"
                  width={56}
                  height={56}
                  className="h-14 w-14 shrink-0 rounded-lg border border-line object-contain p-1"
                />
              ) : (
                <span className="flex h-14 w-14 shrink-0 items-center justify-center rounded-lg border border-dashed border-line text-xl text-muted">
                  🏫
                </span>
              )}
              <label className="flex flex-1 flex-col gap-1.5">
                <span className="field-label">Logo Sekolah (kiri)</span>
                <input
                  type="file"
                  name="logo"
                  accept="image/*"
                  className="text-sm text-muted file:mr-3 file:rounded-md file:border-0 file:bg-primary file:px-3 file:py-1.5 file:text-sm file:font-medium file:text-white hover:file:bg-primary-dark"
                />
                <span className="text-xs text-muted">Kosongkan jika tidak diubah.</span>
              </label>
            </div>

            <div className="flex items-start gap-3">
              {school.regionalLogoPath ? (
                <Image
                  src={school.regionalLogoPath}
                  alt="Logo kota/kabupaten"
                  width={56}
                  height={56}
                  className="h-14 w-14 shrink-0 rounded-lg border border-line object-contain p-1"
                />
              ) : (
                <span className="flex h-14 w-14 shrink-0 items-center justify-center rounded-lg border border-dashed border-line text-xl text-muted">
                  🏛️
                </span>
              )}
              <label className="flex flex-1 flex-col gap-1.5">
                <span className="field-label">Logo Kota/Kabupaten (kanan)</span>
                <input
                  type="file"
                  name="regionalLogo"
                  accept="image/*"
                  className="text-sm text-muted file:mr-3 file:rounded-md file:border-0 file:bg-primary file:px-3 file:py-1.5 file:text-sm file:font-medium file:text-white hover:file:bg-primary-dark"
                />
                <span className="text-xs text-muted">Opsional. Kosongkan jika tidak diubah.</span>
              </label>
            </div>
          </div>

          <Field
            label="Baris Kecil di Atas KOP (opsional)"
            name="kopHeaderLine"
            defaultValue={school.kopHeaderLine ?? ""}
            placeholder="PUSAT KEGIATAN BELAJAR MASYARAKAT"
            hint='Ditampilkan kecil di atas nama sekolah di KOP, mis. "PUSAT KEGIATAN BELAJAR MASYARAKAT" di atas "PKBM ABDI PERTIWI".'
          />
          <Field label="Nama Sekolah/Lembaga" name="name" defaultValue={school.name} required />
          <div className="grid gap-4 sm:grid-cols-2">
            <Field label="NPSN" name="npsn" defaultValue={school.npsn ?? ""} />
            <Field label="Kontak" name="contact" defaultValue={school.contact ?? ""} />
          </div>
          <Field
            label="Alamat Lengkap"
            name="address"
            defaultValue={school.address}
            required
            textarea
          />
        </Section>

        <Section title="Nomor Surat & Tanda Tangan">
          <Field
            label="Kode Format Nomor Surat"
            name="formatCode"
            defaultValue={school.formatCode}
            required
            hint='Contoh hasil: "32/SPM.PKBM-AP/I/2026"'
          />
          <div className="grid gap-4 sm:grid-cols-2">
            <Field label="Nama Kepala" name="kepalaName" defaultValue={school.kepalaName} required />
            <Field
              label="Jabatan Kepala"
              name="kepalaJabatan"
              defaultValue={school.kepalaJabatan}
              required
            />
          </div>
        </Section>

        <Section title="Teks Surat SPM">
          <Field
            label="Kalimat Pembuka"
            name="openingSentenceTemplate"
            defaultValue={school.openingSentenceTemplate}
            required
            textarea
            hint="Gunakan {institutionName} untuk menyisipkan nama sekolah otomatis."
          />
          <div className="grid gap-4 sm:grid-cols-2">
            <Field
              label="Atas Dasar - Baris 1"
              name="atasDasarLine1"
              defaultValue={school.atasDasarLine1}
              required
            />
            <Field
              label="Atas Dasar - Baris 2"
              name="atasDasarLine2"
              defaultValue={school.atasDasarLine2}
              required
            />
          </div>
        </Section>

        <Section title="Rekap Honor">
          <Field
            label="Judul Rekap Honor"
            name="honorRecapTitle"
            defaultValue={school.honorRecapTitle ?? ""}
            placeholder="HONOR TUTOR PKBM ABDI PERTIWI"
          />
        </Section>

        <Section title="Struk Fraza Cell">
          <p className="-mt-1 text-sm text-muted">
            Nomor ini akan muncul otomatis pada kolom ID Pel di struk listrik atau internet.
          </p>
          <div className="grid gap-4 sm:grid-cols-2">
            <Field
              label="ID Pelanggan Listrik"
              name="frazaListrikCustomerId"
              defaultValue={school.frazaListrikCustomerId ?? ""}
              placeholder="Contoh: 1234567890"
            />
            <Field
              label="ID Pelanggan Internet"
              name="frazaInternetCustomerId"
              defaultValue={school.frazaInternetCustomerId ?? ""}
              placeholder="Contoh: 1234567890"
            />
          </div>
        </Section>

        <button type="submit" className="btn btn-primary self-start">
          Simpan Perubahan
        </button>
      </form>

      <form action={deleteSchoolWithId}>
        <details className="card border-red-200 bg-red-50/40 p-4">
          <summary className="cursor-pointer text-sm font-semibold text-red-700">
            Hapus sekolah ini
          </summary>
          <p className="mt-2 text-sm text-red-600">
            Semua aturan vendor, BKU, dan dokumen sekolah ini akan ikut
            terhapus. Tindakan ini tidak bisa dibatalkan.
          </p>
          <button type="submit" className="btn btn-danger mt-3">
            Ya, hapus sekolah
          </button>
        </details>
      </form>
    </div>
  );
}

function Section({
  title,
  children,
}: {
  title: string;
  children: React.ReactNode;
}) {
  return (
    <div className="card flex flex-col gap-4 p-6">
      <h2 className="text-xs font-semibold uppercase tracking-wide text-teal">
        {title}
      </h2>
      {children}
    </div>
  );
}

function Field({
  label,
  name,
  defaultValue,
  placeholder,
  required,
  textarea,
  hint,
}: {
  label: string;
  name: string;
  defaultValue?: string;
  placeholder?: string;
  required?: boolean;
  textarea?: boolean;
  hint?: string;
}) {
  return (
    <label className="flex flex-col gap-1.5">
      <span className="field-label">
        {label}
        {required && <span className="text-teal"> *</span>}
      </span>
      {textarea ? (
        <textarea
          name={name}
          required={required}
          defaultValue={defaultValue}
          placeholder={placeholder}
          rows={2}
          className="input-field"
        />
      ) : (
        <input
          type="text"
          name={name}
          required={required}
          defaultValue={defaultValue}
          placeholder={placeholder}
          className="input-field"
        />
      )}
      {hint && <span className="text-xs text-muted">{hint}</span>}
    </label>
  );
}
