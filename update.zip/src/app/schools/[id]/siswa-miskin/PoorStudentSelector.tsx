"use client";

import { useMemo, useState } from "react";

export interface SelectableStudent {
  id: string;
  sourceNumber: number | null;
  name: string;
  nik: string | null;
  gender: string | null;
  className: string | null;
  birthPlace: string | null;
  birthDate: string | null;
  parentName: string | null;
  parentRelation: string | null;
  address: string | null;
  isPipEligible: boolean;
  pipReason: string | null;
}

function formatDate(value: string | null): string {
  if (!value) return "—";
  return new Intl.DateTimeFormat("id-ID", {
    day: "2-digit",
    month: "long",
    year: "numeric",
    timeZone: "UTC",
  }).format(new Date(value));
}

export default function PoorStudentSelector({
  schoolId,
  importId,
  students,
  defaultYear,
}: {
  schoolId: string;
  importId: string;
  students: SelectableStudent[];
  defaultYear: number;
}) {
  const pipStudents = useMemo(
    () => students.filter((student) => student.isPipEligible),
    [students]
  );
  const [targetCount, setTargetCount] = useState(
    Math.max(1, Math.min(students.length, pipStudents.length || 1))
  );
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [search, setSearch] = useState("");

  const visibleStudents = useMemo(() => {
    const query = search.trim().toLocaleLowerCase("id-ID");
    if (!query) return students;
    return students.filter((student) =>
      [student.name, student.nik, student.className, student.parentName]
        .filter(Boolean)
        .some((value) => value!.toLocaleLowerCase("id-ID").includes(query))
    );
  }, [search, students]);

  const setCount = (raw: number) => {
    const next = Math.max(1, Math.min(students.length, raw || 1));
    setTargetCount(next);
    if (selected.size > next) {
      setSelected(new Set(students.filter((student) => selected.has(student.id)).slice(0, next).map((student) => student.id)));
    }
  };

  const toggle = (id: string) => {
    setSelected((current) => {
      const next = new Set(current);
      if (next.has(id)) next.delete(id);
      else if (next.size < targetCount) next.add(id);
      return next;
    });
  };

  const choosePipSuggestions = () => {
    if (pipStudents.length === 0) return;
    setTargetCount(pipStudents.length);
    setSelected(new Set(pipStudents.map((student) => student.id)));
  };

  const ready = selected.size === targetCount;
  const selectedIds = students
    .filter((student) => selected.has(student.id))
    .map((student) => student.id);

  return (
    <form
      action={`/api/school/${schoolId}/poor-students`}
      method="post"
      target="_blank"
      className="flex flex-col gap-5"
    >
      <input type="hidden" name="importId" value={importId} />
      <input type="hidden" name="expectedCount" value={targetCount} />
      {selectedIds.map((id) => (
        <input key={id} type="hidden" name="studentId" value={id} />
      ))}

      <section className="card grid gap-4 p-5 sm:grid-cols-3">
        <label className="flex flex-col gap-1.5">
          <span className="field-label">Jumlah siswa yang dimasukkan</span>
          <input
            type="number"
            min={1}
            max={students.length}
            value={targetCount}
            onChange={(event) => setCount(Number(event.target.value))}
            className="input-field"
          />
          <span className="text-xs text-muted">Maksimal {students.length} siswa.</span>
        </label>
        <label className="flex flex-col gap-1.5">
          <span className="field-label">Tahun dokumen</span>
          <input
            type="number"
            name="year"
            min={2000}
            max={2100}
            defaultValue={defaultYear}
            required
            className="input-field"
          />
        </label>
        <label className="flex flex-col gap-1.5">
          <span className="field-label">Keterangan</span>
          <input
            type="text"
            name="keterangan"
            defaultValue="Siswa Miskin"
            maxLength={100}
            required
            className="input-field"
          />
        </label>
        <fieldset className="flex flex-col gap-2 sm:col-span-3">
          <legend className="field-label">Format output</legend>
          <div className="flex flex-wrap gap-4 text-sm">
            <label className="flex items-center gap-2">
              <input
                type="radio"
                name="outputFormat"
                value="xlsx"
                defaultChecked
                className="h-4 w-4 accent-[var(--color-teal)]"
              />
              Excel (.xlsx)
            </label>
            <label className="flex items-center gap-2">
              <input
                type="radio"
                name="outputFormat"
                value="pdf"
                className="h-4 w-4 accent-[var(--color-teal)]"
              />
              PDF landscape
            </label>
          </div>
        </fieldset>
      </section>

      <section className="flex flex-col gap-3">
        <div className="flex flex-wrap items-end justify-between gap-3">
          <label className="flex min-w-64 flex-1 flex-col gap-1.5">
            <span className="field-label">Cari dan pilih nama siswa</span>
            <input
              type="search"
              value={search}
              onChange={(event) => setSearch(event.target.value)}
              placeholder="Cari nama, NIK, kelas, atau orang tua…"
              className="input-field"
            />
          </label>
          <div className="flex flex-wrap gap-2">
            {pipStudents.length > 0 && (
              <button
                type="button"
                onClick={choosePipSuggestions}
                className="btn btn-teal px-3 py-2 text-xs"
                title="Memilih siswa yang pada daftar_pd ditandai Layak PIP = Ya. Pilihan tetap bisa diubah."
              >
                Pilih {pipStudents.length} Saran PIP
              </button>
            )}
            <button
              type="button"
              onClick={() => setSelected(new Set())}
              className="btn btn-ghost px-3 py-2 text-xs"
            >
              Kosongkan Pilihan
            </button>
          </div>
        </div>

        <div className="card overflow-x-auto">
          <table className="w-full min-w-[1120px] text-sm">
            <thead>
              <tr className="border-b border-line bg-cream text-left text-xs uppercase tracking-wide text-muted">
                <th className="w-12 p-3"></th>
                <th className="w-20 p-3">No. sumber</th>
                <th className="p-3">Nama</th>
                <th className="w-40 p-3">NIK</th>
                <th className="w-14 p-3">JK</th>
                <th className="w-20 p-3">Kelas</th>
                <th className="w-52 p-3">Tempat, Tanggal Lahir</th>
                <th className="w-48 p-3">Orang Tua</th>
                <th className="p-3">Alamat</th>
              </tr>
            </thead>
            <tbody>
              {visibleStudents.map((student) => {
                const checked = selected.has(student.id);
                const disabled = !checked && selected.size >= targetCount;
                return (
                  <tr
                    key={student.id}
                    className={`border-b border-line/60 last:border-0 ${
                      checked ? "bg-mint-soft/50" : ""
                    }`}
                  >
                    <td className="p-3 text-center">
                      <input
                        type="checkbox"
                        checked={checked}
                        disabled={disabled}
                        onChange={() => toggle(student.id)}
                        aria-label={`Pilih ${student.name}`}
                        className="h-4 w-4 accent-[var(--color-teal)]"
                      />
                    </td>
                    <td className="p-3 text-muted">{student.sourceNumber ?? "—"}</td>
                    <td className="p-3 font-medium">
                      {student.name}
                      {student.isPipEligible && (
                        <span className="badge badge-success ml-2" title={student.pipReason ?? "Layak PIP"}>
                          Saran PIP
                        </span>
                      )}
                    </td>
                    <td className="p-3 font-mono text-xs">{student.nik ?? "—"}</td>
                    <td className="p-3">{student.gender ?? "—"}</td>
                    <td className="p-3">{student.className ?? "—"}</td>
                    <td className="p-3">
                      {[student.birthPlace, formatDate(student.birthDate)]
                        .filter((value) => value && value !== "—")
                        .join(", ") || "—"}
                    </td>
                    <td className="p-3">
                      {student.parentName ?? "—"}
                      {student.parentRelation && (
                        <span className="ml-1 text-xs text-muted">({student.parentRelation})</span>
                      )}
                    </td>
                    <td className="p-3">{student.address ?? "—"}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
          {visibleStudents.length === 0 && (
            <p className="p-8 text-center text-sm text-muted">Tidak ada siswa yang cocok.</p>
          )}
        </div>
      </section>

      <div className="sticky bottom-4 z-10">
        <div className="card flex flex-wrap items-center justify-between gap-3 border-teal p-4 shadow-lg">
          <div>
            <p className="text-sm font-semibold">
              {selected.size} dari {targetCount} siswa dipilih
            </p>
            <p className={`mt-0.5 text-xs ${ready ? "text-teal" : "text-amber-700"}`}>
              {ready
                ? "Data pendukung sudah lengkap dan siap dibuat."
                : `Pilih ${targetCount - selected.size} siswa lagi.`}
            </p>
          </div>
          <button type="submit" disabled={!ready} className="btn btn-primary">
            ⬇ Buat Daftar Siswa Miskin
          </button>
        </div>
      </div>
    </form>
  );
}
