"use client";

import { useActionState } from "react";
import { useRouter } from "next/navigation";
import {
  importStudentDataAction,
  type StudentDataImportResult,
} from "@/lib/actions/student-data";

export default function StudentDataImportForm({
  schoolId,
  destinationPath,
  description,
}: {
  schoolId: string;
  destinationPath: string;
  description: string;
}) {
  const router = useRouter();
  const action = importStudentDataAction.bind(null, schoolId);
  const [result, formAction, isPending] = useActionState<
    StudentDataImportResult | null,
    FormData
  >(
    async (previous, formData) => {
      const next = await action(previous, formData);
      if (next.status === "ok" && next.importId) {
        router.replace(`${destinationPath}?importId=${next.importId}`);
        router.refresh();
      }
      return next;
    },
    null
  );

  return (
    <div className="flex flex-col gap-3">
      <form action={formAction} className="card flex flex-col gap-4 p-5">
        <div>
          <h2 className="text-sm font-semibold">Unggah Daftar Peserta Didik</h2>
          <p className="mt-0.5 text-xs text-muted">
            {description}
          </p>
        </div>
        <label className="flex flex-col gap-1.5">
          <span className="field-label">File daftar_pd (.xlsx)</span>
          <input
            type="file"
            name="file"
            accept=".xlsx,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
            required
            className="text-sm text-muted file:mr-3 file:rounded-md file:border-0 file:bg-primary file:px-3 file:py-1.5 file:text-sm file:font-medium file:text-white hover:file:bg-primary-dark"
          />
          <span className="text-xs text-muted">Maksimal 15 MB, satu file setiap impor.</span>
        </label>
        <button type="submit" disabled={isPending} className="btn btn-primary self-start">
          {isPending ? "Membaca data…" : "Unggah & Baca Siswa"}
        </button>
      </form>

      {result && (
        <div
          className={`card p-4 text-sm ${
            result.status === "ok"
              ? "border-mint bg-mint-soft/40"
              : "border-red-200 bg-red-50/50"
          }`}
        >
          {result.status === "ok" ? (
            <>
              <p className="font-medium">✓ {result.studentCount} siswa berhasil dibaca.</p>
              {result.sourceSchoolName && (
                <p className="mt-0.5 text-xs text-muted">Sumber: {result.sourceSchoolName}</p>
              )}
              {result.warnings && result.warnings.length > 0 && (
                <ul className="mt-2 list-disc space-y-0.5 pl-5 text-xs text-amber-700">
                  {result.warnings.map((warning) => (
                    <li key={warning}>{warning}</li>
                  ))}
                </ul>
              )}
            </>
          ) : (
            <p className="text-red-700">✕ {result.error}</p>
          )}
        </div>
      )}
    </div>
  );
}
