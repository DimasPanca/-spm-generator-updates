"use client";

import { useMemo, useState } from "react";
import type { SelectableStudent } from "../siswa-miskin/PoorStudentSelector";

function formatDate(value: string | null): string {
  if (!value) return "-";
  return new Intl.DateTimeFormat("id-ID", {
    day: "2-digit",
    month: "long",
    year: "numeric",
    timeZone: "UTC",
  }).format(new Date(value));
}

export default function StudentListGenerator({
  schoolId,
  importId,
  students,
  defaultYear,
}: {
  schoolId: string;
  importId: string;
  students: SelectableStudent[];
  defaultYear: number;
}) {
  const [search, setSearch] = useState("");
  const [keterangan, setKeterangan] = useState("Siswa Aktif");
  const sequenceById = useMemo(
    () => new Map(students.map((student, index) => [student.id, index + 1])),
    [students]
  );
  const visibleStudents = useMemo(() => {
    const query = search.trim().toLocaleLowerCase("id-ID");
    if (!query) return students;
    return students.filter((student) =>
      [student.name, student.nik, student.className, student.parentName]
        .filter(Boolean)
        .some((value) => value!.toLocaleLowerCase("id-ID").includes(query))
    );
  }, [search, students]);

  return (
    <form
      action={`/api/school/${schoolId}/students`}
      method="post"
      target="_blank"
      className="flex flex-col gap-5"
    >
      <input type="hidden" name="importId" value={importId} />

      <section className="card grid gap-4 p-5 sm:grid-cols-2">
        <label className="flex flex-col gap-1.5">
          <span className="field-label">Tahun dokumen</span>
          <input
            type="number"
            name="year"
            min={2000}
            max={2100}
            defaultValue={defaultYear}
            required
            className="input-field"
          />
        </label>
        <label className="flex flex-col gap-1.5">
          <span className="field-label">Keterangan</span>
          <input
            type="text"
            name="keterangan"
            value={keterangan}
            onChange={(event) => setKeterangan(event.target.value)}
            maxLength={100}
            required
            className="input-field"
          />
        </label>
        <fieldset className="flex flex-col gap-2 sm:col-span-2">
          <legend className="field-label">Format output</legend>
          <div className="flex flex-wrap gap-4 text-sm">
            <label className="flex items-center gap-2">
              <input
                type="radio"
                name="outputFormat"
                value="xlsx"
                defaultChecked
                className="h-4 w-4 accent-[var(--color-teal)]"
              />
              Excel (.xlsx)
            </label>
            <label className="flex items-center gap-2">
              <input
                type="radio"
                name="outputFormat"
                value="pdf"
                className="h-4 w-4 accent-[var(--color-teal)]"
              />
              PDF landscape
            </label>
          </div>
        </fieldset>
      </section>

      <section className="flex flex-col gap-3">
        <div className="flex flex-wrap items-end justify-between gap-3">
          <label className="flex min-w-64 flex-1 flex-col gap-1.5">
            <span className="field-label">Cari data siswa</span>
            <input
              type="search"
              value={search}
              onChange={(event) => setSearch(event.target.value)}
              placeholder="Cari nama, NIK, kelas, atau orang tua..."
              className="input-field"
            />
          </label>
          <p className="text-sm font-medium">
            {students.length} siswa akan dimasukkan ke dokumen
          </p>
        </div>

        <div className="card overflow-x-auto">
          <table className="w-full min-w-[1280px] text-sm">
            <thead>
              <tr className="border-b border-line bg-cream text-left text-xs uppercase tracking-wide text-muted">
                <th className="w-14 p-3">No</th>
                <th className="min-w-64 p-3">Nama</th>
                <th className="w-40 p-3">NIK</th>
                <th className="w-14 p-3">JK</th>
                <th className="w-20 p-3">Kelas</th>
                <th className="w-56 p-3">Tempat, Tanggal Lahir</th>
                <th className="w-52 p-3">Nama Orang Tua</th>
                <th className="min-w-72 p-3">Alamat</th>
                <th className="w-36 p-3">Keterangan</th>
              </tr>
            </thead>
            <tbody>
              {visibleStudents.map((student) => (
                <tr
                  key={student.id}
                  className="border-b border-line/60 last:border-0"
                >
                  <td className="p-3 text-muted">{sequenceById.get(student.id)}</td>
                  <td className="p-3 font-medium">{student.name}</td>
                  <td className="p-3 font-mono text-xs">{student.nik ?? "-"}</td>
                  <td className="p-3">{student.gender ?? "-"}</td>
                  <td className="p-3">{student.className ?? "-"}</td>
                  <td className="p-3">
                    {[student.birthPlace, formatDate(student.birthDate)]
                      .filter((value) => value && value !== "-")
                      .join(", ") || "-"}
                  </td>
                  <td className="p-3">{student.parentName ?? "-"}</td>
                  <td className="p-3">{student.address ?? "-"}</td>
                  <td className="p-3">{keterangan || "-"}</td>
                </tr>
              ))}
            </tbody>
          </table>
          {visibleStudents.length === 0 && (
            <p className="p-8 text-center text-sm text-muted">
              Tidak ada siswa yang cocok.
            </p>
          )}
        </div>
      </section>

      <div className="sticky bottom-4 z-10">
        <div className="card flex flex-wrap items-center justify-between gap-3 border-teal p-4 shadow-lg">
          <div>
            <p className="text-sm font-semibold">Daftar seluruh siswa siap dibuat</p>
            <p className="mt-0.5 text-xs text-muted">
              Nomor output akan selalu berurutan dari 1 sampai {students.length}.
            </p>
          </div>
          <button type="submit" className="btn btn-primary">
            ⬇ Buat Daftar Siswa
          </button>
        </div>
      </div>
    </form>
  );
}

