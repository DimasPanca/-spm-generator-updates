import Link from "next/link";
import { notFound } from "next/navigation";
import { prisma } from "@/lib/db";
import { deleteStudentDataImport } from "@/lib/actions/student-data";
import StudentDataImportForm from "../siswa-miskin/StudentDataImportForm";
import StudentListGenerator from "./StudentListGenerator";

export default async function StudentDataPage({
  params,
  searchParams,
}: {
  params: Promise<{ id: string }>;
  searchParams: Promise<{ importId?: string }>;
}) {
  const { id: schoolId } = await params;
  const { importId: requestedImportId } = await searchParams;
  const school = await prisma.school.findUnique({ where: { id: schoolId } });
  if (!school) notFound();

  const imports = await prisma.studentDataImport.findMany({
    where: { schoolId },
    orderBy: { importedAt: "desc" },
    include: { _count: { select: { students: true } } },
  });
  const activeImport =
    imports.find((item) => item.id === requestedImportId) ?? imports[0] ?? null;
  const students = activeImport
    ? await prisma.studentRecord.findMany({
        where: { studentDataImportId: activeImport.id },
        orderBy: [{ sourceNumber: "asc" }, { name: "asc" }],
      })
    : [];

  return (
    <div className="flex flex-col gap-6">
      <div>
        <Link href="/schools" className="text-sm text-teal hover:underline">
          &larr; Kembali
        </Link>
        <h1 className="mt-2 text-2xl font-bold tracking-tight">
          Data Siswa &mdash; {school.name}
        </h1>
        <p className="mt-1 max-w-3xl text-sm text-muted">
          Buat daftar seluruh siswa dari file daftar_pd. Judul sekolah dan tanda
          tangan kepala sekolah otomatis mengikuti profil {school.name}.
        </p>
      </div>

      <div className="flex flex-wrap gap-2">
        <Link href={`/schools/${schoolId}/siswa-miskin`} className="btn btn-ghost">
          Pilih Siswa Miskin
        </Link>
      </div>

      <StudentDataImportForm
        schoolId={schoolId}
        destinationPath={`/schools/${schoolId}/data-siswa`}
        description="File asli tidak disimpan. Sistem hanya mengambil nama, NIK, JK, kelas, tempat/tanggal lahir, orang tua, alamat, dan data pendukung yang diperlukan."
      />

      {imports.length > 0 && (
        <section className="flex flex-col gap-3">
          <h2 className="text-sm font-semibold">Data yang Sudah Diimpor</h2>
          <div className="flex flex-wrap gap-2">
            {imports.map((item) => {
              const deleteAction = deleteStudentDataImport.bind(
                null,
                schoolId,
                item.id
              );
              return (
                <div
                  key={item.id}
                  className={`card flex items-center gap-2 p-2 ${
                    activeImport?.id === item.id
                      ? "border-teal bg-mint-soft/30"
                      : ""
                  }`}
                >
                  <Link
                    href={`/schools/${schoolId}/data-siswa?importId=${item.id}`}
                    className="px-2 py-1 text-sm"
                  >
                    <span className="font-medium">
                      {item.sourceSchoolName ?? item.sourceFileName}
                    </span>
                    <span className="ml-2 text-xs text-muted">
                      {item._count.students} siswa
                    </span>
                  </Link>
                  <form action={deleteAction}>
                    <button
                      type="submit"
                      className="btn btn-danger px-2 py-1 text-xs"
                    >
                      Hapus
                    </button>
                  </form>
                </div>
              );
            })}
          </div>
        </section>
      )}

      {activeImport && students.length > 0 ? (
        <StudentListGenerator
          schoolId={schoolId}
          importId={activeImport.id}
          defaultYear={new Date().getFullYear()}
          students={students.map((student) => ({
            ...student,
            birthDate: student.birthDate?.toISOString() ?? null,
          }))}
        />
      ) : (
        <div className="card p-8 text-center text-sm text-muted">
          Belum ada daftar siswa. Unggah file daftar_pd terlebih dahulu.
        </div>
      )}
    </div>
  );
}

