import Link from "next/link";
import { notFound } from "next/navigation";
import { prisma } from "@/lib/db";
import { buildStockOpnameData } from "@/lib/opname/buildOpnameData";
import { STOCK_CATEGORIES } from "@/lib/opname/categorize";

export default async function OpnamePage({
  params,
  searchParams,
}: {
  params: Promise<{ id: string }>;
  searchParams: Promise<{ year?: string; tahap?: string }>;
}) {
  const { id: schoolId } = await params;
  const sp = await searchParams;

  const school = await prisma.school.findUnique({ where: { id: schoolId } });
  if (!school) notFound();

  const latestImport = await prisma.bKUImport.findFirst({
    where: { schoolId },
    orderBy: [{ year: "desc" }, { month: "desc" }],
  });
  const year = Number(sp.year) || latestImport?.year || new Date().getFullYear();
  const tahap = sp.tahap === "2" ? 2 : 1;

  const data = await buildStockOpnameData(schoolId, year, tahap);

  const years = [year - 1, year, year + 1];
  const rp = (n: number) => `Rp ${n.toLocaleString("id-ID")}`;
  const periodLabel = tahap === 1 ? `Januari–Juni ${year}` : `Juli–Desember ${year}`;

  return (
    <div className="flex flex-col gap-6">
      <div>
        <Link href="/schools" className="text-sm text-teal hover:underline">
          &larr; Kembali
        </Link>
        <h1 className="mt-2 text-2xl font-bold tracking-tight">
          Stock &amp; Cash Opname &mdash; {school.name}
        </h1>
        <p className="mt-1 text-sm text-muted">
          Tahap {tahap} ({periodLabel}) &middot; belanja dana BOSP dikelompokkan
          otomatis ke 10 kategori standar untuk laporan Stock Opname; Cash
          Opname berisi berita acara pemeriksaan kas 5 halaman + rekap BKU
          tahunan.
        </p>
        <div className="mt-3 flex flex-wrap items-center gap-2">
          {[1, 2].map((t) => (
            <Link
              key={t}
              href={`/schools/${schoolId}/opname?year=${year}&tahap=${t}`}
              className={`btn px-3 py-1.5 text-xs ${tahap === t ? "btn-primary" : "btn-ghost"}`}
            >
              Tahap {t}
            </Link>
          ))}
          <span className="ml-2 text-xs text-muted">Tahun</span>
          {years.map((y) => (
            <Link
              key={y}
              href={`/schools/${schoolId}/opname?year=${y}&tahap=${tahap}`}
              className={`btn px-3 py-1.5 text-xs ${y === year ? "btn-primary" : "btn-ghost"}`}
            >
              {y}
            </Link>
          ))}
        </div>
      </div>

      {!data ? (
        <div className="card p-8 text-center text-sm text-muted">
          Belum ada BKU yang diimpor untuk periode ini.{" "}
          <Link href={`/schools/${schoolId}/import`} className="text-teal hover:underline">
            Impor BKU dulu
          </Link>{" "}
          lalu kembali ke sini.
        </div>
      ) : (
        <>
          <div className="grid gap-4 sm:grid-cols-2">
            <section className="card flex flex-col gap-3 p-5">
              <div>
                <h2 className="text-sm font-semibold">Stock Opname (Barang Habis Pakai)</h2>
                <p className="mt-0.5 text-xs text-muted">
                  10 kolom kategori &middot; format Excel (siap edit &amp; cetak).
                </p>
              </div>
              <div className="rounded-md bg-cream px-4 py-3 text-sm">
                <div className="flex justify-between">
                  <span>Total belanja terkategori</span>
                  <span className="font-semibold text-primary">{rp(data.totalPenerimaan)}</span>
                </div>
                <div className="mt-1 flex justify-between text-xs text-muted">
                  <span>Tidak masuk (honor / modal / tagihan / buku)</span>
                  <span>{rp(data.uncategorizedTotal)}</span>
                </div>
              </div>
              <a
                href={`/api/school/${schoolId}/opname?kind=stock&year=${year}&tahap=${tahap}`}
                className="btn btn-teal self-start"
              >
                ⬇ Unduh Stock Opname (XLSX)
              </a>
            </section>

            <section className="card flex flex-col gap-3 p-5">
              <div>
                <h2 className="text-sm font-semibold">Cash Opname (Pemeriksaan Kas)</h2>
                <p className="mt-0.5 text-xs text-muted">
                  Berita Acara &middot; Registrasi &middot; Hasil Perhitungan
                  &middot; Realisasi &middot; Rekap BKU 12 bulan.
                </p>
              </div>
              <div className="rounded-md bg-cream px-4 py-3 text-sm">
                <div className="flex justify-between">
                  <span>Kepala Sekolah</span>
                  <span className="font-medium">{data.kepalaName || "—"}</span>
                </div>
                <div className="mt-1 flex justify-between">
                  <span>Bendahara BOSP</span>
                  <span className="font-medium">{data.bendaharaName || "—"}</span>
                </div>
              </div>
              <div className="flex flex-wrap gap-2">
                <a
                  href={`/api/school/${schoolId}/opname?kind=cash&year=${year}&tahap=${tahap}&format=docx`}
                  className="btn btn-primary"
                >
                  ⬇ DOCX
                </a>
                <a
                  href={`/api/school/${schoolId}/opname?kind=cash&year=${year}&tahap=${tahap}&format=pdf`}
                  className="btn btn-ghost"
                  title="Butuh Microsoft Word terpasang."
                >
                  ⬇ PDF
                </a>
              </div>
              {!data.bendaharaName && (
                <p className="text-xs text-amber-700">
                  Nama Bendahara diambil dari Instrumen BOSP. Isi dulu di halaman
                  Instrumen BOSP supaya blok tanda tangan terisi lengkap.
                </p>
              )}
            </section>
          </div>

          <section className="card flex flex-col gap-3 p-5">
            <div>
              <h2 className="text-sm font-semibold">
                Ringkasan 10 Kategori Stock Opname
              </h2>
              <p className="mt-0.5 text-xs text-muted">
                Berdasarkan BPU yang sudah dikonfirmasi. Total per kolom yang
                masuk ke sheet Excel.
              </p>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full min-w-[560px] text-sm">
                <thead>
                  <tr className="border-b border-line text-left text-xs uppercase tracking-wide text-muted">
                    <th className="p-2">Kategori</th>
                    <th className="w-40 p-2 text-right">Jumlah (Rp)</th>
                  </tr>
                </thead>
                <tbody>
                  {STOCK_CATEGORIES.map((c) => (
                    <tr key={c} className="border-b border-line/60 last:border-0">
                      <td className="p-2">{c}</td>
                      <td className="p-2 text-right tabular-nums">
                        {rp(data.penerimaan[c] ?? 0)}
                      </td>
                    </tr>
                  ))}
                  <tr className="font-semibold">
                    <td className="p-2">JUMLAH</td>
                    <td className="p-2 text-right tabular-nums text-primary">
                      {rp(data.totalPenerimaan)}
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </section>

          {data.uncategorizedTotal > 0 && (
            <details className="card p-5">
              <summary className="cursor-pointer text-sm font-semibold">
                Rincian BPU yang tidak masuk Stock Opname ({rp(data.uncategorizedTotal)})
              </summary>
              <p className="mt-2 text-xs text-muted">
                Baris di bawah ini bukan barang habis pakai (honor, transport,
                tagihan listrik/internet, komputer, buku pelajaran, dsb), jadi
                sengaja dilewati.
              </p>
              <ul className="mt-3 flex flex-col divide-y divide-line/60 text-sm">
                {data.breakdown
                  .filter((b) => !b.category)
                  .map((b, i) => (
                    <li key={i} className="flex justify-between py-1.5">
                      <span className="truncate pr-4">{b.uraian}</span>
                      <span className="shrink-0 tabular-nums">{rp(b.amount)}</span>
                    </li>
                  ))}
              </ul>
            </details>
          )}
        </>
      )}
    </div>
  );
}
