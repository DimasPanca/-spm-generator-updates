"use client";

import { useActionState } from "react";
import { useRouter } from "next/navigation";
import {
  importVendorRulesAction,
  type ImportVendorRulesResult,
} from "@/lib/actions/vendor-rule";

export interface SourceSchoolOption {
  id: string;
  name: string;
  ruleCount: number;
}

export default function ImportVendorRulesForm({
  schoolId,
  sources,
  hasExistingRules,
}: {
  schoolId: string;
  sources: SourceSchoolOption[];
  hasExistingRules: boolean;
}) {
  const router = useRouter();
  const action = importVendorRulesAction.bind(null, schoolId);
  const [result, formAction, isPending] = useActionState<
    ImportVendorRulesResult | null,
    FormData
  >(async (prev, formData) => {
    const next = await action(prev, formData);
    router.refresh();
    return next;
  }, null);

  if (sources.length === 0) return null;

  return (
    <div className="card flex flex-col gap-3 p-4">
      <div>
        <h2 className="text-sm font-semibold">Salin Aturan dari Sekolah Lain</h2>
        <p className="mt-0.5 text-xs text-muted">
          Kalau vendornya sama persis, tarik saja aturan dari sekolah yang
          sudah lengkap &mdash; tidak perlu isi ulang satu per satu.
        </p>
      </div>

      <form action={formAction} className="flex flex-wrap items-end gap-3">
        <label className="flex min-w-56 flex-1 flex-col gap-1.5">
          <span className="field-label">Ambil dari</span>
          <select name="sourceSchoolId" required className="input-field">
            <option value="">— pilih sekolah —</option>
            {sources.map((s) => (
              <option key={s.id} value={s.id}>
                {s.name} ({s.ruleCount} aturan)
              </option>
            ))}
          </select>
        </label>

        <label className="flex min-w-56 flex-1 flex-col gap-1.5">
          <span className="field-label">Cara salin</span>
          <select name="mode" defaultValue="append" className="input-field">
            <option value="append">
              Tambahkan (aturan yang sudah ada tetap dipertahankan)
            </option>
            <option value="replace">
              Ganti semua (hapus aturan sekolah ini dulu)
            </option>
          </select>
        </label>

        <button type="submit" disabled={isPending} className="btn btn-teal">
          {isPending ? "Menyalin…" : "⤵ Salin Aturan"}
        </button>
      </form>

      {hasExistingRules && (
        <p className="text-xs text-muted">
          Mode <strong>Tambahkan</strong> otomatis melewati aturan yang isinya
          sudah sama persis, jadi aman dijalankan berkali-kali.
        </p>
      )}

      {result && (
        <div
          className={`rounded-lg border p-3 text-sm ${
            result.status === "ok"
              ? "border-mint bg-mint-soft/40"
              : "border-red-200 bg-red-50/50 text-red-700"
          }`}
        >
          {result.status === "ok" ? (
            <>
              <p className="font-medium">
                ✓ {result.copied} aturan disalin dari {result.sourceName}
              </p>
              <p className="mt-0.5 text-ink/80">
                {result.replaced ? `${result.replaced} aturan lama dihapus. ` : ""}
                {result.skipped
                  ? `${result.skipped} dilewati karena sudah ada. `
                  : ""}
                Cek kolom <strong>Kepada</strong> di bawah &mdash; nama penerima
                honor biasanya berbeda tiap sekolah dan perlu disesuaikan.
              </p>
            </>
          ) : (
            <p>{result.error}</p>
          )}
        </div>
      )}
    </div>
  );
}
