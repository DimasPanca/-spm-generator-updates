import Link from "next/link";
import { notFound } from "next/navigation";
import { prisma } from "@/lib/db";
import {
  createVendorRule,
  deleteVendorRule,
  seedDefaultVendorRules,
  updateVendorRule,
} from "@/lib/actions/vendor-rule";
import ImportVendorRulesForm from "./ImportVendorRulesForm";

export default async function VendorRulesPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id: schoolId } = await params;
  const school = await prisma.school.findUnique({ where: { id: schoolId } });
  if (!school) notFound();

  const rules = await prisma.vendorRule.findMany({
    where: { schoolId },
    orderBy: { priority: "asc" },
  });

  // Other schools that actually have rules worth copying.
  const otherSchools = await prisma.school.findMany({
    where: { id: { not: schoolId }, vendorRules: { some: {} } },
    select: { id: true, name: true, _count: { select: { vendorRules: true } } },
    orderBy: { name: "asc" },
  });
  const sources = otherSchools.map((s) => ({
    id: s.id,
    name: s.name,
    ruleCount: s._count.vendorRules,
  }));

  const createVendorRuleWithId = createVendorRule.bind(null, schoolId);
  const seedDefaultVendorRulesWithId = seedDefaultVendorRules.bind(null, schoolId);

  // Honor/service rules whose "Kepada" is a person the user should register once.
  const needsName = rules.filter(
    (r) => r.formatType === "STANDARD" && r.recipient.trim() === ""
  );

  return (
    <div className="flex flex-col gap-6">
      <div>
        <Link href="/schools" className="text-sm text-teal hover:underline">
          &larr; Kembali
        </Link>
        <h1 className="mt-2 text-2xl font-bold tracking-tight">
          Aturan Vendor &mdash; {school.name}
        </h1>
        <p className="mt-1 max-w-2xl text-sm text-muted">
          Tiap uraian di BKU dicocokkan dengan kata kunci di bawah (boleh
          beberapa, pisahkan dengan koma). Ini cuma <strong>saran otomatis</strong>{" "}
          &mdash; semua tetap bisa diedit saat review sebelum SPM dibuat.
        </p>
      </div>

      {needsName.length > 0 && (
        <div className="card border-teal/30 bg-mint-soft/40 p-4">
          <p className="text-sm font-semibold text-teal-dark">
            Isi nama penerima honor
          </p>
          <p className="mt-1 text-sm text-ink/80">
            {needsName.length} aturan honor/jasa belum punya nama penerima
            (kolom <em>Kepada</em> kosong):{" "}
            <span className="font-medium">
              {needsName.map((r) => r.paymentPrefix).join(", ")}
            </span>
            . Isi nama orangnya di baris masing-masing lalu klik Simpan &mdash;
            cukup sekali, nanti otomatis dipakai tiap bulan.
          </p>
        </div>
      )}

      <ImportVendorRulesForm
        schoolId={schoolId}
        sources={sources}
        hasExistingRules={rules.length > 0}
      />

      {rules.length === 0 && (
        <form action={seedDefaultVendorRulesWithId}>
          <button
            type="submit"
            className="card w-full border-dashed p-8 text-center text-sm text-muted transition-colors hover:border-teal hover:text-ink"
          >
            <span className="text-2xl">✨</span>
            <span className="mt-2 block font-medium text-ink">
              Isi dengan contoh aturan PKBM ABDI PERTIWI
            </span>
            <span className="mt-1 block">
              Barang &rarr; toko, honor/jasa &rarr; nama orang. Bisa
              diedit/dihapus setelahnya.
            </span>
          </button>
        </form>
      )}

      {rules.length > 0 && (
        <div className="card overflow-x-auto">
          <table className="w-full min-w-[1000px] text-sm">
            <thead>
              <tr className="border-b border-line bg-cream text-left text-xs uppercase tracking-wide text-muted">
                <th className="w-16 p-3">Prio</th>
                <th className="p-3">Kata Kunci (uraian)</th>
                <th className="w-28 p-3">Kode Keg.</th>
                <th className="w-40 p-3">Format</th>
                <th className="w-16 p-3 text-center">Honor</th>
                <th className="w-16 p-3 text-center">Transport</th>
                <th className="p-3">Kepada</th>
                <th className="p-3">Untuk Pembayaran</th>
                <th className="w-12 p-3 text-center">Aktif</th>
                <th className="w-28 p-3"></th>
              </tr>
            </thead>
            <tbody>
              {rules.map((rule) => {
                const updateAction = updateVendorRule.bind(null, schoolId, rule.id);
                const deleteAction = deleteVendorRule.bind(null, schoolId, rule.id);
                const wantsName =
                  rule.formatType === "STANDARD" && rule.recipient.trim() === "";
                return (
                  <tr key={rule.id} className="border-b border-line/60 align-top last:border-0">
                    <td className="p-2">
                      <input
                        type="number"
                        name="priority"
                        form={`rule-${rule.id}`}
                        defaultValue={rule.priority}
                        className="input-field px-2 py-1.5"
                      />
                    </td>
                    <td className="p-2">
                      <input
                        type="text"
                        name="keyword"
                        form={`rule-${rule.id}`}
                        defaultValue={rule.keyword}
                        placeholder="mis. Listrik, Internet"
                        className="input-field px-2 py-1.5"
                      />
                    </td>
                    <td className="p-2">
                      <input
                        type="text"
                        name="matchKodeKegiatan"
                        form={`rule-${rule.id}`}
                        defaultValue={rule.matchKodeKegiatan ?? ""}
                        placeholder="07.12.01"
                        className="input-field px-2 py-1.5 font-mono text-xs"
                      />
                    </td>
                    <td className="p-2">
                      <select
                        name="formatType"
                        form={`rule-${rule.id}`}
                        defaultValue={rule.formatType}
                        className="input-field px-2 py-1.5"
                      >
                        <option value="STANDARD">Standar</option>
                        <option value="NAME_FROM_URAIAN">Nama dari uraian</option>
                      </select>
                    </td>
                    <td className="p-2 text-center">
                      <input
                        type="checkbox"
                        name="isHonor"
                        form={`rule-${rule.id}`}
                        defaultChecked={rule.isHonor}
                        className="h-4 w-4 accent-[var(--color-teal)]"
                      />
                    </td>
                    <td className="p-2 text-center">
                      <input
                        type="checkbox"
                        name="isTransport"
                        form={`rule-${rule.id}`}
                        defaultChecked={rule.isTransport}
                        title="Total dipecah ~Rp200rb/orang, nama diambil acak dari penerima honor bulan yang sama."
                        className="h-4 w-4 accent-[var(--color-teal)]"
                      />
                    </td>
                    <td className="p-2">
                      <input
                        type="text"
                        name="recipient"
                        form={`rule-${rule.id}`}
                        defaultValue={rule.recipient}
                        placeholder={wantsName ? "⚠ isi nama orang" : "nama toko"}
                        className={`input-field px-2 py-1.5 ${
                          wantsName ? "border-amber-300 bg-amber-50" : ""
                        }`}
                      />
                    </td>
                    <td className="p-2">
                      <input
                        type="text"
                        name="paymentPrefix"
                        form={`rule-${rule.id}`}
                        defaultValue={rule.paymentPrefix}
                        className="input-field px-2 py-1.5"
                      />
                    </td>
                    <td className="p-2 text-center">
                      <input
                        type="checkbox"
                        name="isActive"
                        form={`rule-${rule.id}`}
                        defaultChecked={rule.isActive}
                        className="h-4 w-4 accent-[var(--color-teal)]"
                      />
                    </td>
                    <td className="p-2">
                      <div className="flex gap-1.5">
                        <form action={updateAction} id={`rule-${rule.id}`}>
                          <button type="submit" className="btn btn-primary px-2.5 py-1.5 text-xs">
                            Simpan
                          </button>
                        </form>
                        <form action={deleteAction}>
                          <button type="submit" className="btn btn-danger px-2.5 py-1.5 text-xs">
                            Hapus
                          </button>
                        </form>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}

      <div className="card p-4">
        <h2 className="mb-3 text-sm font-semibold">Tambah Aturan Baru</h2>
        <form
          action={createVendorRuleWithId}
          className="grid grid-cols-2 gap-3 md:grid-cols-6"
        >
          <input
            type="number"
            name="priority"
            defaultValue={(rules.length + 1) * 10}
            placeholder="Prio"
            className="input-field px-2 py-1.5"
          />
          <input
            type="text"
            name="keyword"
            placeholder="Kata kunci (koma)"
            className="input-field col-span-2 px-2 py-1.5 md:col-span-2"
          />
          <input
            type="text"
            name="matchKodeKegiatan"
            placeholder="Kode keg. (opsional)"
            className="input-field px-2 py-1.5 font-mono text-xs"
          />
          <select name="formatType" defaultValue="STANDARD" className="input-field px-2 py-1.5">
            <option value="STANDARD">Standar</option>
            <option value="NAME_FROM_URAIAN">Nama dari uraian</option>
          </select>
          <input
            type="text"
            name="recipient"
            placeholder="Kepada (toko/nama)"
            className="input-field px-2 py-1.5"
          />
          <label className="flex items-center gap-2 text-sm">
            <input
              type="checkbox"
              name="isHonor"
              className="h-4 w-4 accent-[var(--color-teal)]"
            />
            Honor (orang)
          </label>
          <label
            className="flex items-center gap-2 text-sm"
            title="Total dipecah ~Rp200rb/orang, nama diambil acak dari penerima honor bulan yang sama."
          >
            <input
              type="checkbox"
              name="isTransport"
              className="h-4 w-4 accent-[var(--color-teal)]"
            />
            Transport (bagi rata)
          </label>
          <input
            type="text"
            name="paymentPrefix"
            required
            placeholder="Untuk pembayaran"
            className="input-field col-span-2 px-2 py-1.5 md:col-span-4"
          />
          <button type="submit" className="btn btn-teal md:col-span-2">
            + Tambah Aturan
          </button>
        </form>
      </div>
    </div>
  );
}
