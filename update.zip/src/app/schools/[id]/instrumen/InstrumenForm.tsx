"use client";

import { useActionState, useState } from "react";
import { useRouter } from "next/navigation";
import { saveInstrumen } from "@/lib/actions/instrumen";

export interface HonorPreview {
  nama: string;
  jumlahBulan: number;
  honorPerBulan: number;
  jumlahDiterima: number;
}
export interface BukuPreview {
  namaPenyedia: string;
  judulBuku: string;
  jumlah: number;
}
export interface PeriodPreview {
  label: string;
  saldoBulanLalu: number;
  penerimaan: number;
  pengeluaran: number;
  saldo: number;
}

export interface InstrumenDefaults {
  jenisSatuan: string;
  statusSatuan: string;
  kelurahan: string;
  kecamatan: string;
  jenisDanaBosp: string;
  skNomor: string;
  skTanggal: string;
  kepalaName: string;
  bendaharaName: string;
  komiteName: string;
  adaBku: boolean;
  adaBukuPembantuKas: boolean;
  adaBukuPembantuPajak: boolean;
  adaBukuPembantuBank: boolean;
  adaLaporanRealisasi: boolean;
  totalAlokasiTahunan: number;
  saldoAwalOverride: number | null;
  operasionalOverride: number | null;
  honorSesuaiRkas: boolean;
  honorBuktiLengkap: boolean;
  honorPenerimaSesuai: boolean;
  metodePengadaanBuku: string;
  metodePengadaanLain: string;
  tanggalDokumen: string;
  belanjaModal: {
    namaBarang: string;
    volume: string;
    hargaSatuan: number;
    jumlah: number;
    kondisi: string;
    keterangan: string;
  }[];
  pemeliharaan: {
    namaKegiatan: string;
    jumlahBarang: string;
    biaya: number;
    keterangan: string;
  }[];
  bukuOverride: { banyakBuku: string; hargaSatuan: string }[];
}

const rp = (n: number) => `Rp ${n.toLocaleString("id-ID")}`;

const JENIS_SATUAN = ["TK", "KB", "TPA", "SPS", "PKBM", "SKB"];
const JENIS_DANA = [
  "BOP PAUD Reguler",
  "BOP PAUD Kinerja",
  "BOP PAUD Afirmasi",
  "BOP Kesetaraan Reguler",
  "BOP Kesetaraan Kinerja",
  "BOP Kesetaraan Afirmasi",
];

const EXTRA_BLANK_ROWS = 3;

export default function InstrumenForm({
  schoolId,
  year,
  tahap,
  defaults,
  honor,
  buku,
  periods,
  totalPengeluaran,
  totalHonor,
  totalBuku,
  saldoAwalHitung,
  sisaBelanja,
}: {
  schoolId: string;
  year: number;
  tahap: number;
  defaults: InstrumenDefaults;
  honor: HonorPreview[];
  buku: BukuPreview[];
  periods: PeriodPreview[];
  totalPengeluaran: number;
  totalHonor: number;
  totalBuku: number;
  saldoAwalHitung: number;
  sisaBelanja: number;
}) {
  const router = useRouter();
  const save = saveInstrumen.bind(null, schoolId, year, tahap);

  const [, formAction, isPending] = useActionState<null, FormData>(
    async (_prev, formData) => {
      await save(formData);
      router.refresh();
      return null;
    },
    null
  );

  const [totalAlokasi, setTotalAlokasi] = useState(defaults.totalAlokasiTahunan);
  const [metode, setMetode] = useState(defaults.metodePengadaanBuku);

  const batasHonor = Math.round(totalAlokasi * 0.4);
  const persenHonor = totalAlokasi > 0 ? (totalHonor / totalAlokasi) * 100 : 0;
  const melebihiBatas = totalAlokasi > 0 && totalHonor > batasHonor;

  const modalRows = [...defaults.belanjaModal];
  while (modalRows.length < EXTRA_BLANK_ROWS) {
    modalRows.push({ namaBarang: "", volume: "", hargaSatuan: 0, jumlah: 0, kondisi: "", keterangan: "" });
  }
  const rawatRows = [...defaults.pemeliharaan];
  while (rawatRows.length < EXTRA_BLANK_ROWS) {
    rawatRows.push({ namaKegiatan: "", jumlahBarang: "", biaya: 0, keterangan: "" });
  }

  return (
    <form action={formAction} className="flex flex-col gap-5">
      {/* ---- Data umum ---- */}
      <section className="card flex flex-col gap-4 p-5">
        <div>
          <h2 className="text-sm font-semibold">Data Umum Satuan Pendidikan</h2>
          <p className="mt-0.5 text-xs text-muted">
            Nama, NPSN, dan alamat diambil otomatis dari profil sekolah. Yang di
            bawah ini tidak ada di BKU maupun RKAS.
          </p>
        </div>
        <div className="grid gap-4 sm:grid-cols-2">
          <label className="flex flex-col gap-1.5">
            <span className="field-label">Jenis Satuan Pendidikan</span>
            <select name="jenisSatuan" defaultValue={defaults.jenisSatuan} className="input-field">
              {JENIS_SATUAN.map((j) => (
                <option key={j} value={j}>{j}</option>
              ))}
            </select>
          </label>
          <label className="flex flex-col gap-1.5">
            <span className="field-label">Status</span>
            <select name="statusSatuan" defaultValue={defaults.statusSatuan} className="input-field">
              <option value="Negeri">Negeri</option>
              <option value="Swasta">Swasta</option>
            </select>
          </label>
          <label className="flex flex-col gap-1.5">
            <span className="field-label">Kelurahan</span>
            <input name="kelurahan" defaultValue={defaults.kelurahan} className="input-field" />
          </label>
          <label className="flex flex-col gap-1.5">
            <span className="field-label">Kecamatan</span>
            <input name="kecamatan" defaultValue={defaults.kecamatan} className="input-field" />
          </label>
          <label className="flex flex-col gap-1.5 sm:col-span-2">
            <span className="field-label">Jenis Dana BOSP</span>
            <select name="jenisDanaBosp" defaultValue={defaults.jenisDanaBosp} className="input-field">
              {JENIS_DANA.map((j) => (
                <option key={j} value={j}>{j}</option>
              ))}
            </select>
          </label>
        </div>
      </section>

      {/* ---- Tim manajemen ---- */}
      <section className="card flex flex-col gap-4 p-5">
        <h2 className="text-sm font-semibold">Tim Manajemen BOSP</h2>
        <div className="grid gap-4 sm:grid-cols-2">
          <label className="flex flex-col gap-1.5">
            <span className="field-label">Nomor SK / Surat Tugas</span>
            <input name="skNomor" defaultValue={defaults.skNomor} className="input-field" placeholder="cth. 421/12/TK-AP/2026" />
          </label>
          <label className="flex flex-col gap-1.5">
            <span className="field-label">Tanggal SK</span>
            <input name="skTanggal" defaultValue={defaults.skTanggal} className="input-field" placeholder="cth. 5 Januari 2026" />
          </label>
          <label className="flex flex-col gap-1.5">
            <span className="field-label">Nama Kepala Satuan Pendidikan</span>
            <input name="kepalaName" defaultValue={defaults.kepalaName} className="input-field" />
          </label>
          <label className="flex flex-col gap-1.5">
            <span className="field-label">Nama Bendahara BOSP</span>
            <input name="bendaharaName" defaultValue={defaults.bendaharaName} className="input-field" />
          </label>
          <label className="flex flex-col gap-1.5">
            <span className="field-label">Nama Ketua Komite</span>
            <input name="komiteName" defaultValue={defaults.komiteName} className="input-field" />
          </label>
          <label className="flex flex-col gap-1.5">
            <span className="field-label">Tanggal Dokumen</span>
            <input name="tanggalDokumen" defaultValue={defaults.tanggalDokumen} className="input-field" placeholder="cth. 25 Agustus 2026" />
          </label>
        </div>
      </section>

      {/* ---- Checklist administrasi ---- */}
      <section className="card flex flex-col gap-3 p-5">
        <div>
          <h2 className="text-sm font-semibold">Administrasi Keuangan</h2>
          <p className="mt-0.5 text-xs text-muted">
            Dicentang = &ldquo;Ada&rdquo;, tidak dicentang = &ldquo;Tidak Ada&rdquo;.
          </p>
        </div>
        <div className="grid gap-2 sm:grid-cols-2">
          {[
            ["adaBku", "Buku Kas Umum (BKU)", defaults.adaBku],
            ["adaBukuPembantuKas", "Buku Pembantu Kas", defaults.adaBukuPembantuKas],
            ["adaBukuPembantuPajak", "Buku Pembantu Pajak", defaults.adaBukuPembantuPajak],
            ["adaBukuPembantuBank", "Buku Pembantu Bank", defaults.adaBukuPembantuBank],
            ["adaLaporanRealisasi", "Laporan Realisasi per Jenis Anggaran", defaults.adaLaporanRealisasi],
          ].map(([name, label, checked]) => (
            <label key={name as string} className="flex items-center gap-2 text-sm">
              <input
                type="checkbox"
                name={name as string}
                defaultChecked={checked as boolean}
                className="h-4 w-4 accent-[var(--color-teal)]"
              />
              {label as string}
            </label>
          ))}
        </div>
      </section>

      {/* ---- Angka dari RKAS ---- */}
      <section className="card flex flex-col gap-4 p-5">
        <div>
          <h2 className="text-sm font-semibold">Angka dari RKAS</h2>
          <p className="mt-0.5 text-xs text-muted">
            Tidak ada di BKU &mdash; ambil dari &ldquo;Total Penerimaan&rdquo; pada RKAS Tahunan.
          </p>
        </div>
        <div className="grid gap-4 sm:grid-cols-2">
          <label className="flex flex-col gap-1.5">
            <span className="field-label">Total Alokasi Dana BOSP setahun (Rp)</span>
            <input
              name="totalAlokasiTahunan"
              value={totalAlokasi || ""}
              onChange={(e) => setTotalAlokasi(Number(e.target.value.replace(/[^\d]/g, "")) || 0)}
              className="input-field"
              inputMode="numeric"
              placeholder="cth. 8400000"
            />
          </label>
          <div className="flex flex-col gap-1.5">
            <span className="field-label">Batas maksimal honor (40%)</span>
            <div
              className={`input-field flex items-center justify-between ${
                melebihiBatas ? "border-red-300 bg-red-50" : "bg-cream"
              }`}
            >
              <span>{rp(batasHonor)}</span>
              <span className={`text-xs font-semibold ${melebihiBatas ? "text-red-600" : "text-muted"}`}>
                realisasi {persenHonor.toFixed(1).replace(".", ",")}%
              </span>
            </div>
          </div>
        </div>
        {melebihiBatas && (
          <p className="text-xs font-medium text-red-600">
            Realisasi honor {rp(totalHonor)} melebihi batas 40% ({rp(batasHonor)}).
            Cek lagi angka alokasi atau data honornya sebelum dokumen ditandatangani.
          </p>
        )}
      </section>

      {/* ---- Hasil monitoring honor ---- */}
      <section className="card flex flex-col gap-3 p-5">
        <h2 className="text-sm font-semibold">Hasil Monitoring Belanja Honor</h2>
        <div className="flex flex-col gap-2">
          {[
            ["honorSesuaiRkas", "Kesesuaian dengan RKAS — Ya", defaults.honorSesuaiRkas],
            ["honorBuktiLengkap", "Bukti Pembayaran Honor — Lengkap", defaults.honorBuktiLengkap],
            ["honorPenerimaSesuai", "Penerima Honor Sesuai Ketentuan — Ya", defaults.honorPenerimaSesuai],
          ].map(([name, label, checked]) => (
            <label key={name as string} className="flex items-center gap-2 text-sm">
              <input
                type="checkbox"
                name={name as string}
                defaultChecked={checked as boolean}
                className="h-4 w-4 accent-[var(--color-teal)]"
              />
              {label as string}
            </label>
          ))}
        </div>
      </section>

      {/* ---- Operasional ---- */}
      <section className="card flex flex-col gap-4 p-5">
        <div>
          <h2 className="text-sm font-semibold">Operasional</h2>
          <p className="mt-0.5 text-xs text-muted">
            Kosongkan untuk memakai hitungan otomatis: total pengeluaran{" "}
            {rp(totalPengeluaran)} dikurangi honor, buku, belanja modal, dan
            pemeliharaan &mdash; saat ini {rp(sisaBelanja)}.
          </p>
        </div>
        <label className="flex max-w-xs flex-col gap-1.5">
          <span className="field-label">Jumlah Realisasi (Rp)</span>
          <input
            name="operasionalOverride"
            defaultValue={defaults.operasionalOverride ?? ""}
            className="input-field"
            inputMode="numeric"
            placeholder={String(sisaBelanja)}
          />
        </label>
        <label className="flex max-w-xs flex-col gap-1.5">
          <span className="field-label">Saldo awal Tahap (Rp)</span>
          <input
            name="saldoAwalOverride"
            defaultValue={defaults.saldoAwalOverride ?? ""}
            className="input-field"
            inputMode="numeric"
            placeholder={String(saldoAwalHitung)}
          />
          <span className="text-xs text-muted">
            Kosongkan untuk memakai hasil hitungan dari BKU ({rp(saldoAwalHitung)}).
          </span>
        </label>
      </section>

      {/* ---- Pemeliharaan ---- */}
      <section className="card flex flex-col gap-3 p-5">
        <div>
          <h2 className="text-sm font-semibold">Pemeliharaan Sarana &amp; Prasarana</h2>
          <p className="mt-0.5 text-xs text-muted">
            Kosongkan kalau tidak ada. Baris yang nama kegiatannya kosong tidak ikut dicetak.
          </p>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full min-w-[640px] text-sm">
            <thead>
              <tr className="border-b border-line text-left text-xs uppercase tracking-wide text-muted">
                <th className="p-2">Nama Kegiatan</th>
                <th className="w-28 p-2">Jumlah Barang</th>
                <th className="w-32 p-2">Biaya (Rp)</th>
                <th className="w-32 p-2">Keterangan</th>
              </tr>
            </thead>
            <tbody>
              {rawatRows.map((row, i) => (
                <tr key={i}>
                  <td className="p-1.5">
                    <input name={`rawat_${i}_namaKegiatan`} defaultValue={row.namaKegiatan} className="input-field px-2 py-1.5" />
                  </td>
                  <td className="p-1.5">
                    <input name={`rawat_${i}_jumlahBarang`} defaultValue={row.jumlahBarang} className="input-field px-2 py-1.5" />
                  </td>
                  <td className="p-1.5">
                    <input name={`rawat_${i}_biaya`} defaultValue={row.biaya || ""} inputMode="numeric" className="input-field px-2 py-1.5" />
                  </td>
                  <td className="p-1.5">
                    <input name={`rawat_${i}_keterangan`} defaultValue={row.keterangan} className="input-field px-2 py-1.5" />
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>

      {/* ---- Belanja modal ---- */}
      <section className="card flex flex-col gap-3 p-5">
        <div>
          <h2 className="text-sm font-semibold">Belanja Modal &mdash; Peralatan &amp; Mesin</h2>
          <p className="mt-0.5 text-xs text-muted">
            Volume dan harga satuan hanya ada di RKAS, bukan di BKU &mdash; jadi
            diisi manual di sini.
          </p>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full min-w-[800px] text-sm">
            <thead>
              <tr className="border-b border-line text-left text-xs uppercase tracking-wide text-muted">
                <th className="p-2">Nama Barang</th>
                <th className="w-24 p-2">Volume</th>
                <th className="w-28 p-2">Harga Satuan</th>
                <th className="w-28 p-2">Jumlah</th>
                <th className="w-24 p-2">Kondisi</th>
                <th className="w-28 p-2">Keterangan</th>
              </tr>
            </thead>
            <tbody>
              {modalRows.map((row, i) => (
                <tr key={i}>
                  <td className="p-1.5">
                    <input name={`modal_${i}_namaBarang`} defaultValue={row.namaBarang} className="input-field px-2 py-1.5" />
                  </td>
                  <td className="p-1.5">
                    <input name={`modal_${i}_volume`} defaultValue={row.volume} className="input-field px-2 py-1.5" placeholder="1 set" />
                  </td>
                  <td className="p-1.5">
                    <input name={`modal_${i}_hargaSatuan`} defaultValue={row.hargaSatuan || ""} inputMode="numeric" className="input-field px-2 py-1.5" />
                  </td>
                  <td className="p-1.5">
                    <input name={`modal_${i}_jumlah`} defaultValue={row.jumlah || ""} inputMode="numeric" className="input-field px-2 py-1.5" />
                  </td>
                  <td className="p-1.5">
                    <input name={`modal_${i}_kondisi`} defaultValue={row.kondisi} className="input-field px-2 py-1.5" placeholder="Baik" />
                  </td>
                  <td className="p-1.5">
                    <input name={`modal_${i}_keterangan`} defaultValue={row.keterangan} className="input-field px-2 py-1.5" />
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>

      {/* ---- Buku ---- */}
      <section className="card flex flex-col gap-3 p-5">
        <div>
          <h2 className="text-sm font-semibold">
            Belanja Modal Aset Tetap Lainnya (Buku)
          </h2>
          <p className="mt-0.5 text-xs text-muted">
            Penyedia, judul, dan jumlah diambil otomatis dari BKU. BKU tidak
            mencatat banyak buku dan harga satuannya, jadi dua kolom itu diisi
            di sini.
          </p>
        </div>
        <label className="flex max-w-sm flex-col gap-1.5">
          <span className="field-label">Metode Pengadaan Buku</span>
          <select
            name="metodePengadaanBuku"
            value={metode}
            onChange={(e) => setMetode(e.target.value)}
            className="input-field"
          >
            <option value="Pembelian langsung">Pembelian langsung</option>
            <option value="SIPLah">Pengadaan melalui SIPLah</option>
            <option value="Lainnya">Pengadaan lainnya</option>
          </select>
        </label>
        {metode === "Lainnya" && (
          <label className="flex max-w-sm flex-col gap-1.5">
            <span className="field-label">Sebutkan metode lainnya</span>
            <input name="metodePengadaanLain" defaultValue={defaults.metodePengadaanLain} className="input-field" />
          </label>
        )}

        {buku.length === 0 ? (
          <p className="text-sm text-muted">
            Belum ada pembelian buku yang dikonfirmasi pada periode ini.
          </p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full min-w-[720px] text-sm">
              <thead>
                <tr className="border-b border-line text-left text-xs uppercase tracking-wide text-muted">
                  <th className="p-2">Penyedia</th>
                  <th className="p-2">Judul Buku</th>
                  <th className="w-28 p-2">Banyak Buku</th>
                  <th className="w-32 p-2">Harga Satuan</th>
                  <th className="w-32 p-2 text-right">Jumlah</th>
                </tr>
              </thead>
              <tbody>
                {buku.map((b, i) => (
                  <tr key={i} className="border-b border-line/60 last:border-0">
                    <td className="p-2">{b.namaPenyedia}</td>
                    <td className="p-2">{b.judulBuku}</td>
                    <td className="p-1.5">
                      <input
                        name={`buku_${i}_banyakBuku`}
                        defaultValue={defaults.bukuOverride[i]?.banyakBuku ?? ""}
                        className="input-field px-2 py-1.5"
                      />
                    </td>
                    <td className="p-1.5">
                      <input
                        name={`buku_${i}_hargaSatuan`}
                        defaultValue={defaults.bukuOverride[i]?.hargaSatuan ?? ""}
                        inputMode="numeric"
                        className="input-field px-2 py-1.5"
                      />
                    </td>
                    <td className="p-2 text-right tabular-nums">{rp(b.jumlah)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </section>

      {/* ---- Preview otomatis ---- */}
      <section className="card flex flex-col gap-4 p-5">
        <div>
          <h2 className="text-sm font-semibold">Terisi Otomatis dari BKU</h2>
          <p className="mt-0.5 text-xs text-muted">
            Tidak bisa diedit di sini &mdash; kalau ada yang salah, perbaiki di
            Review BKU atau Aturan Vendor.
          </p>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full min-w-[560px] text-sm">
            <thead>
              <tr className="border-b border-line text-left text-xs uppercase tracking-wide text-muted">
                <th className="p-2">Periode</th>
                <th className="p-2 text-right">Saldo Lalu</th>
                <th className="p-2 text-right">Penerimaan</th>
                <th className="p-2 text-right">Pengeluaran</th>
                <th className="p-2 text-right">Saldo</th>
              </tr>
            </thead>
            <tbody>
              {periods.map((p) => (
                <tr key={p.label} className="border-b border-line/60 last:border-0">
                  <td className="p-2">{p.label}</td>
                  <td className="p-2 text-right tabular-nums">{rp(p.saldoBulanLalu)}</td>
                  <td className="p-2 text-right tabular-nums">{rp(p.penerimaan)}</td>
                  <td className="p-2 text-right tabular-nums">{rp(p.pengeluaran)}</td>
                  <td className="p-2 text-right tabular-nums">{rp(p.saldo)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="overflow-x-auto border-t border-line pt-3">
          <table className="w-full min-w-[520px] text-sm">
            <thead>
              <tr className="border-b border-line text-left text-xs uppercase tracking-wide text-muted">
                <th className="p-2">Nama Honorer</th>
                <th className="w-24 p-2 text-right">Bulan</th>
                <th className="w-32 p-2 text-right">Per Bulan</th>
                <th className="w-32 p-2 text-right">Diterima</th>
              </tr>
            </thead>
            <tbody>
              {honor.map((h) => (
                <tr key={h.nama} className="border-b border-line/60 last:border-0">
                  <td className="p-2">{h.nama}</td>
                  <td className="p-2 text-right tabular-nums">{h.jumlahBulan}</td>
                  <td className="p-2 text-right tabular-nums">{rp(h.honorPerBulan)}</td>
                  <td className="p-2 text-right tabular-nums">{rp(h.jumlahDiterima)}</td>
                </tr>
              ))}
              <tr className="font-semibold">
                <td className="p-2">Jumlah</td>
                <td />
                <td />
                <td className="p-2 text-right tabular-nums">{rp(totalHonor)}</td>
              </tr>
            </tbody>
          </table>
        </div>
      </section>

      <div className="sticky bottom-4 z-10">
        <div className="card flex flex-wrap items-center justify-between gap-3 border-teal p-4 shadow-lg">
          <p className="text-xs text-muted">
            Halaman <strong>Daftar Dokumen Persiapan</strong> dan{" "}
            <strong>Kuesioner 35 soal</strong> sengaja dibiarkan kosong untuk
            dicentang manual setelah dicetak.
          </p>
          <div className="flex items-center gap-2">
            <button type="submit" disabled={isPending} className="btn btn-primary">
              {isPending ? "Menyimpan…" : "Simpan Isian"}
            </button>
            <a
              href={`/api/school/${schoolId}/instrumen?year=${year}&tahap=${tahap}&format=docx`}
              className="btn btn-teal"
            >
              ⬇ DOCX
            </a>
            <a
              href={`/api/school/${schoolId}/instrumen?year=${year}&tahap=${tahap}&format=pdf`}
              className="btn btn-ghost"
              title="Butuh Microsoft Word terpasang di komputer ini."
            >
              ⬇ PDF
            </a>
          </div>
        </div>
      </div>
    </form>
  );
}
