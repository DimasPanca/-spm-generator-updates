import Link from "next/link";
import { notFound } from "next/navigation";
import { prisma } from "@/lib/db";
import { buildInstrumenData } from "@/lib/instrumen/buildInstrumenData";
import { monthName } from "@/lib/indonesian/months";
import InstrumenForm, { type InstrumenDefaults } from "./InstrumenForm";

function parseJson<T>(raw: string | undefined, fallback: T): T {
  if (!raw) return fallback;
  try {
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? (parsed as T) : fallback;
  } catch {
    return fallback;
  }
}

export default async function InstrumenPage({
  params,
  searchParams,
}: {
  params: Promise<{ id: string }>;
  searchParams: Promise<{ year?: string; tahap?: string }>;
}) {
  const { id: schoolId } = await params;
  const sp = await searchParams;

  const school = await prisma.school.findUnique({ where: { id: schoolId } });
  if (!school) notFound();

  // Default to the most recent year that actually has BKU data.
  const latestImport = await prisma.bKUImport.findFirst({
    where: { schoolId },
    orderBy: [{ year: "desc" }, { month: "desc" }],
  });

  const year = Number(sp.year) || latestImport?.year || new Date().getFullYear();
  const tahap = sp.tahap === "2" ? 2 : 1;

  const computed = await buildInstrumenData(schoolId, year, tahap);
  const saved = await prisma.instrumenBosp.findUnique({
    where: { schoolId_year_tahap: { schoolId, year, tahap } },
  });

  const periodLabel =
    tahap === 1
      ? `${monthName(1)}–${monthName(6)} ${year}`
      : `${monthName(7)}–${monthName(12)} ${year}`;

  const switcher = (
    <div className="flex flex-wrap items-center gap-2">
      {([1, 2] as const).map((t) => (
        <Link
          key={t}
          href={`/schools/${schoolId}/instrumen?year=${year}&tahap=${t}`}
          className={`btn px-3 py-1.5 text-xs ${tahap === t ? "btn-primary" : "btn-ghost"}`}
        >
          Tahap {t}
        </Link>
      ))}
      <span className="ml-2 text-xs text-muted">Tahun</span>
      {[year - 1, year, year + 1].map((y) => (
        <Link
          key={y}
          href={`/schools/${schoolId}/instrumen?year=${y}&tahap=${tahap}`}
          className={`btn px-3 py-1.5 text-xs ${y === year ? "btn-primary" : "btn-ghost"}`}
        >
          {y}
        </Link>
      ))}
    </div>
  );

  const header = (
    <div>
      <Link href="/schools" className="text-sm text-teal hover:underline">
        &larr; Kembali
      </Link>
      <h1 className="mt-2 text-2xl font-bold tracking-tight">
        Instrumen Monev BOSP &mdash; {school.name}
      </h1>
      <p className="mt-1 text-sm text-muted">
        Tahap {tahap} ({periodLabel}) &middot; diisi otomatis dari BKU yang sudah
        diimpor, sisanya dilengkapi di form ini.
      </p>
      <div className="mt-3">{switcher}</div>
    </div>
  );

  if (!computed) {
    return (
      <div className="flex flex-col gap-6">
        {header}
        <div className="card p-8 text-center text-sm text-muted">
          Belum ada BKU yang diimpor untuk Tahap {tahap} tahun {year}.{" "}
          <Link href={`/schools/${schoolId}/import`} className="text-teal hover:underline">
            Impor BKU dulu
          </Link>
          , lalu kembali ke sini.
        </div>
      </div>
    );
  }

  const defaults: InstrumenDefaults = {
    jenisSatuan: saved?.jenisSatuan ?? "TK",
    statusSatuan: saved?.statusSatuan ?? "Swasta",
    kelurahan: saved?.kelurahan ?? "",
    kecamatan: saved?.kecamatan ?? "",
    jenisDanaBosp: saved?.jenisDanaBosp ?? "BOP PAUD Reguler",
    skNomor: saved?.skNomor ?? "",
    skTanggal: saved?.skTanggal ?? "",
    kepalaName: saved?.kepalaName || school.kepalaName,
    bendaharaName: saved?.bendaharaName ?? "",
    komiteName: saved?.komiteName ?? "",
    adaBku: saved?.adaBku ?? true,
    adaBukuPembantuKas: saved?.adaBukuPembantuKas ?? true,
    adaBukuPembantuPajak: saved?.adaBukuPembantuPajak ?? true,
    adaBukuPembantuBank: saved?.adaBukuPembantuBank ?? true,
    adaLaporanRealisasi: saved?.adaLaporanRealisasi ?? false,
    totalAlokasiTahunan: saved?.totalAlokasiTahunan ?? 0,
    saldoAwalOverride: saved?.saldoAwalOverride ?? null,
    operasionalOverride: saved?.operasionalOverride ?? null,
    honorSesuaiRkas: saved?.honorSesuaiRkas ?? true,
    honorBuktiLengkap: saved?.honorBuktiLengkap ?? true,
    honorPenerimaSesuai: saved?.honorPenerimaSesuai ?? true,
    metodePengadaanBuku: saved?.metodePengadaanBuku ?? "Pembelian langsung",
    metodePengadaanLain: saved?.metodePengadaanLain ?? "",
    tanggalDokumen: saved?.tanggalDokumen ?? "",
    belanjaModal: parseJson(saved?.belanjaModalJson, []),
    pemeliharaan: parseJson(saved?.pemeliharaanJson, []),
    bukuOverride: parseJson(saved?.bukuOverrideJson, []),
  };

  return (
    <div className="flex flex-col gap-6">
      {header}

      {(computed.missingMonths.length > 0 || computed.duplicateMonths.length > 0) && (
        <div className="card border-amber-300 bg-amber-50/60 p-4 text-sm">
          {computed.missingMonths.length > 0 && (
            <p>
              <strong>BKU belum lengkap.</strong> Bulan{" "}
              {computed.missingMonths.map(monthName).join(", ")} belum diimpor,
              jadi angkanya belum mencakup periode penuh.
            </p>
          )}
          {computed.duplicateMonths.length > 0 && (
            <p className={computed.missingMonths.length > 0 ? "mt-1.5" : ""}>
              <strong>Ada BKU dobel.</strong> Bulan{" "}
              {computed.duplicateMonths.map(monthName).join(", ")} diimpor lebih
              dari sekali &mdash; yang dipakai hanya impor terbaru. Sebaiknya
              hapus yang lama di halaman Impor BKU.
            </p>
          )}
        </div>
      )}

      {computed.saldoAwalTercatat !== null &&
        computed.saldoAwalTercatat !== computed.saldoAwal && (
          <div className="card border-amber-300 bg-amber-50/60 p-4 text-sm">
            <strong>Saldo awal perlu dicek.</strong> Hitungan dari mutasi BKU
            menghasilkan Rp {computed.saldoAwal.toLocaleString("id-ID")},
            sedangkan baris &ldquo;Saldo Bulan Lalu&rdquo; di BKU tertulis Rp{" "}
            {computed.saldoAwalTercatat.toLocaleString("id-ID")}. Yang dipakai
            adalah hasil hitungan, karena itu yang membuat saldo akhir cocok.
          </div>
        )}

      <InstrumenForm
        schoolId={schoolId}
        year={year}
        tahap={tahap}
        defaults={defaults}
        honor={computed.honor}
        buku={computed.buku.map((b) => ({
          namaPenyedia: b.namaPenyedia,
          judulBuku: b.judulBuku,
          jumlah: b.jumlah,
        }))}
        periods={computed.periods}
        totalPengeluaran={computed.totalPengeluaran}
        totalHonor={computed.totalHonor}
        totalBuku={computed.totalBuku}
        saldoAwalHitung={computed.saldoAwal}
        sisaBelanja={computed.sisaBelanja}
      />
    </div>
  );
}
