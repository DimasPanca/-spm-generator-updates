"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { useActionState } from "react";
import { saveSk } from "@/lib/actions/sk";

export interface SkTeamRow {
  nama: string;
  jabatan: string;
  keterangan: string;
}
export interface SkDefaults {
  nomorUrut: string;
  kodeSurat: string;
  tanggalRapat: number;
  tanggalTetap: number;
  kecamatan: string;
  kota: string;
  provinsi: string;
  kepalaName: string;
  team: SkTeamRow[];
}

const JABATAN = ["Penanggung Jawab", "Bendahara", "Anggota"];
const KETERANGAN = [
  "Kepala Sekolah",
  "Guru",
  "Komite Sekolah",
  "Orang tua/wali peserta didik di luar Komite Sekolah",
];

export default function SkForm({
  schoolId,
  year,
  schoolName,
  defaults,
}: {
  schoolId: string;
  year: number;
  schoolName: string;
  defaults: SkDefaults;
}) {
  const router = useRouter();
  const save = saveSk.bind(null, schoolId, year);

  const [team, setTeam] = useState<SkTeamRow[]>(
    defaults.team.length > 0
      ? defaults.team
      : [{ nama: "", jabatan: "Penanggung Jawab", keterangan: "Kepala Sekolah" }]
  );
  const [nomorUrut, setNomorUrut] = useState(defaults.nomorUrut);

  const [, formAction, isPending] = useActionState<null, FormData>(
    async (_prev, formData) => {
      await save(formData);
      router.refresh();
      return null;
    },
    null
  );

  const nomorPreview = `${nomorUrut || "05"}/${defaults.kodeSurat}/${schoolName}/I/${year}`;

  const updateRow = (i: number, patch: Partial<SkTeamRow>) =>
    setTeam((prev) => prev.map((r, idx) => (idx === i ? { ...r, ...patch } : r)));
  const removeRow = (i: number) => setTeam((prev) => prev.filter((_, idx) => idx !== i));
  const addRow = () =>
    setTeam((prev) => [...prev, { nama: "", jabatan: "Anggota", keterangan: "Guru" }]);

  return (
    <form action={formAction} className="flex flex-col gap-5">
      <section className="card flex flex-col gap-4 p-5">
        <div>
          <h2 className="text-sm font-semibold">Identitas Surat</h2>
          <p className="mt-0.5 text-xs text-muted">
            SK selalu bertanggal Januari {year}. Nomor, nama sekolah, dan kepala
            terisi otomatis &mdash; tinggal cek.
          </p>
        </div>
        <div className="grid gap-4 sm:grid-cols-2">
          <label className="flex flex-col gap-1.5">
            <span className="field-label">Nomor Urut</span>
            <input
              name="nomorUrut"
              value={nomorUrut}
              onChange={(e) => setNomorUrut(e.target.value.replace(/[^\d]/g, ""))}
              className="input-field"
              inputMode="numeric"
              placeholder="05"
            />
            <span className="break-all font-mono text-[11px] text-muted">{nomorPreview}</span>
          </label>
          <label className="flex flex-col gap-1.5">
            <span className="field-label">Nama Kepala Sekolah</span>
            <input name="kepalaName" defaultValue={defaults.kepalaName} className="input-field" />
          </label>
          <label className="flex flex-col gap-1.5">
            <span className="field-label">Tanggal Rapat Pembentukan (Januari)</span>
            <input
              name="tanggalRapat"
              defaultValue={defaults.tanggalRapat}
              className="input-field"
              inputMode="numeric"
            />
          </label>
          <label className="flex flex-col gap-1.5">
            <span className="field-label">Tanggal Penetapan SK (Januari)</span>
            <input
              name="tanggalTetap"
              defaultValue={defaults.tanggalTetap}
              className="input-field"
              inputMode="numeric"
            />
          </label>
          <label className="flex flex-col gap-1.5">
            <span className="field-label">Kecamatan</span>
            <input name="kecamatan" defaultValue={defaults.kecamatan} className="input-field" />
          </label>
          <label className="flex flex-col gap-1.5">
            <span className="field-label">Kota/Kabupaten</span>
            <input name="kota" defaultValue={defaults.kota} className="input-field" />
          </label>
        </div>
        <input type="hidden" name="kodeSurat" value={defaults.kodeSurat} />
        <input type="hidden" name="provinsi" value={defaults.provinsi} />
      </section>

      <section className="flex flex-col gap-3">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h2 className="text-sm font-semibold">Susunan Tim BOSP</h2>
            <p className="mt-0.5 text-xs text-muted">
              Terisi otomatis dari Kepala, Bendahara, dan penerima honor di BKU.
              Tambah/hapus dan ubah sesuai kebutuhan.
            </p>
          </div>
          <button type="button" onClick={addRow} className="btn btn-ghost px-3 py-1.5 text-xs">
            + Tambah Anggota
          </button>
        </div>

        <div className="card overflow-x-auto">
          <table className="w-full min-w-[720px] text-sm">
            <thead>
              <tr className="border-b border-line bg-cream text-left text-xs uppercase tracking-wide text-muted">
                <th className="w-10 p-3">No</th>
                <th className="p-3">Nama</th>
                <th className="w-44 p-3">Jabatan dalam Tim</th>
                <th className="p-3">Keterangan</th>
                <th className="w-12 p-3"></th>
              </tr>
            </thead>
            <tbody>
              {team.map((row, i) => (
                <tr key={i} className="border-b border-line/60 align-top last:border-0">
                  <td className="p-2 text-center text-muted">{i + 1}</td>
                  <td className="p-2">
                    <input
                      name={`team_${i}_nama`}
                      value={row.nama}
                      onChange={(e) => updateRow(i, { nama: e.target.value })}
                      placeholder="Nama lengkap"
                      className="input-field px-2 py-1.5"
                    />
                  </td>
                  <td className="p-2">
                    <select
                      name={`team_${i}_jabatan`}
                      value={row.jabatan}
                      onChange={(e) => updateRow(i, { jabatan: e.target.value })}
                      className="input-field px-2 py-1.5"
                    >
                      {JABATAN.map((j) => (
                        <option key={j} value={j}>{j}</option>
                      ))}
                    </select>
                  </td>
                  <td className="p-2">
                    <input
                      name={`team_${i}_keterangan`}
                      value={row.keterangan}
                      onChange={(e) => updateRow(i, { keterangan: e.target.value })}
                      list="ket-options"
                      placeholder="Guru / Komite / dll"
                      className="input-field px-2 py-1.5"
                    />
                  </td>
                  <td className="p-2 text-center">
                    <button
                      type="button"
                      onClick={() => removeRow(i)}
                      className="btn btn-danger px-2 py-1 text-xs"
                      title="Hapus anggota"
                    >
                      &times;
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <datalist id="ket-options">
          {KETERANGAN.map((k) => (
            <option key={k} value={k} />
          ))}
        </datalist>
      </section>

      <div className="sticky bottom-4 z-10">
        <div className="card flex flex-wrap items-center justify-between gap-3 border-teal p-4 shadow-lg">
          <p className="text-xs text-muted">
            {team.filter((t) => t.nama.trim()).length} anggota tim akan masuk ke lampiran SK.
          </p>
          <div className="flex items-center gap-2">
            <button type="submit" disabled={isPending} className="btn btn-primary">
              {isPending ? "Menyimpan…" : "Simpan"}
            </button>
            <a
              href={`/api/school/${schoolId}/sk?year=${year}&format=docx`}
              className="btn btn-teal"
            >
              ⬇ DOCX
            </a>
            <a
              href={`/api/school/${schoolId}/sk?year=${year}&format=pdf`}
              className="btn btn-ghost"
              title="Butuh Microsoft Word terpasang di komputer ini."
            >
              ⬇ PDF
            </a>
          </div>
        </div>
      </div>
    </form>
  );
}
