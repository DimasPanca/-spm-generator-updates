import Link from "next/link";
import { notFound } from "next/navigation";
import { prisma } from "@/lib/db";
import { buildSkTeamPrefill } from "@/lib/sk/buildSkData";
import SkForm, { type SkDefaults, type SkTeamRow } from "./SkForm";

export default async function SkPage({
  params,
  searchParams,
}: {
  params: Promise<{ id: string }>;
  searchParams: Promise<{ year?: string }>;
}) {
  const { id: schoolId } = await params;
  const sp = await searchParams;

  const school = await prisma.school.findUnique({ where: { id: schoolId } });
  if (!school) notFound();

  const latestImport = await prisma.bKUImport.findFirst({
    where: { schoolId },
    orderBy: [{ year: "desc" }, { month: "desc" }],
  });
  const year = Number(sp.year) || latestImport?.year || new Date().getFullYear();

  const saved = await prisma.skBosp.findUnique({
    where: { schoolId_year: { schoolId, year } },
  });

  const savedTeam: SkTeamRow[] =
    saved && saved.teamJson !== "[]" ? JSON.parse(saved.teamJson) : [];
  const team = savedTeam.length > 0 ? savedTeam : await buildSkTeamPrefill(schoolId, year);

  const defaults: SkDefaults = {
    nomorUrut: saved?.nomorUrut ?? "05",
    kodeSurat: saved?.kodeSurat ?? "SK.PTB",
    tanggalRapat: saved?.tanggalRapat ?? 2,
    tanggalTetap: saved?.tanggalTetap ?? 4,
    kecamatan: saved?.kecamatan ?? "Walantaka",
    kota: saved?.kota ?? "Kota Serang",
    provinsi: saved?.provinsi ?? "Banten",
    kepalaName: saved?.kepalaName || school.kepalaName,
    team,
  };

  const years = [year - 1, year, year + 1];

  return (
    <div className="flex flex-col gap-6">
      <div>
        <Link href="/schools" className="text-sm text-teal hover:underline">
          &larr; Kembali
        </Link>
        <h1 className="mt-2 text-2xl font-bold tracking-tight">
          SK Tim BOSP &mdash; {school.name}
        </h1>
        <p className="mt-1 text-sm text-muted">
          Surat Keputusan pembentukan Tim BOSP, tahun {year}. Format &amp; dasar
          hukum mengikuti template resmi; header, nama, dan susunan tim
          menyesuaikan sekolah ini.
        </p>
        <div className="mt-3 flex items-center gap-2">
          <span className="text-xs text-muted">Tahun</span>
          {years.map((y) => (
            <Link
              key={y}
              href={`/schools/${schoolId}/sk?year=${y}`}
              className={`btn px-3 py-1.5 text-xs ${y === year ? "btn-primary" : "btn-ghost"}`}
            >
              {y}
            </Link>
          ))}
        </div>
      </div>

      <SkForm schoolId={schoolId} year={year} schoolName={school.name} defaults={defaults} />
    </div>
  );
}
