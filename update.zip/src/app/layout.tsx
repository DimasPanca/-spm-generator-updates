import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import Link from "next/link";
import "./globals.css";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "SPM Generator",
  description: "Generator SPM otomatis dari BKU bulanan",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html
      lang="id"
      className={`${geistSans.variable} ${geistMono.variable} h-full antialiased`}
    >
      <body className="min-h-full flex flex-col">
        <header className="bg-primary text-white shadow-sm">
          <div className="mx-auto flex max-w-5xl items-center gap-3 px-6 py-3.5">
            <Link href="/schools" className="flex items-center gap-2.5">
              <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-white/15 text-base font-bold">
                S
              </span>
              <span className="text-[15px] font-semibold tracking-tight">
                SPM Generator
              </span>
            </Link>
            <nav className="ml-4 flex gap-1 text-sm">
              <Link
                href="/schools"
                className="rounded-md px-3 py-1.5 text-white/85 transition-colors hover:bg-white/10 hover:text-white"
              >
                Sekolah
              </Link>
            </nav>
          </div>
        </header>
        <main className="mx-auto w-full max-w-5xl flex-1 px-6 py-8">
          {children}
        </main>
        <footer className="border-t border-line py-4 text-center text-xs text-muted">
          SPM Generator &middot; dari BKU bulanan ke Surat Perintah Membayar
        </footer>
      </body>
    </html>
  );
}
