import { renderToBuffer } from "@react-pdf/renderer";
import { prisma } from "@/lib/db";
import { computeGroupFields } from "@/lib/spm/paymentFormatter";
import {
  buildFrazaReceiptData,
  buildMonthlyFrazaReceiptData,
  frazaPaymentKind,
  type FrazaPaymentKind,
} from "@/lib/receipt/buildFrazaReceiptData";
import { FrazaReceiptBundleDocument, FrazaReceiptDocument } from "@/templates/frazaReceipt";

function isFrazaCellPayment(recipient: string | null, paymentFor: string) {
  return /fraza\s*cell/i.test(recipient ?? "") && /listrik|internet|kawat|faksimili/i.test(paymentFor);
}

export interface FrazaReceiptResult {
  buffer: Buffer;
  bpuCode: string;
}

export interface FrazaReceiptBundleResult {
  buffer: Buffer;
  count: number;
  semester: 1 | 2;
}

/** Renders one Fraza Cell receipt for one confirmed electricity/internet BPU. */
export async function renderFrazaReceipt(bpuGroupId: string): Promise<FrazaReceiptResult | null> {
  const group = await prisma.bPUGroup.findUnique({
    where: { id: bpuGroupId },
    include: {
      bkuImport: { include: { school: true } },
      matchedVendorRule: true,
    },
  });
  if (!group || group.status !== "CONFIRMED") return null;

  const rows = await prisma.bKURow.findMany({
    where: { bkuImportId: group.bkuImportId, bpuCode: group.bpuCode },
    select: { uraian: true },
  });
  const computed = computeGroupFields(rows, group.matchedVendorRule);
  const recipient = group.overrideRecipient ?? computed.recipient;
  const paymentFor = group.overridePaymentFor ?? computed.paymentFor;

  if (!isFrazaCellPayment(recipient, paymentFor)) return null;

  const data = buildFrazaReceiptData(group.bkuImport.school, group.bkuImport, group, paymentFor);
  const buffer = await renderToBuffer(<FrazaReceiptDocument data={data} />);
  return { buffer, bpuCode: group.bpuCode };
}

interface ReceiptCandidate {
  month: number;
  year: number;
  tanggal: Date;
  totalAmount: number;
  kind: FrazaPaymentKind;
}

function kindSortOrder(kind: FrazaPaymentKind) {
  if (kind === "LISTRIK") return 0;
  if (kind === "INTERNET") return 1;
  return 2;
}

/**
 * Renders all Fraza Cell utility receipts for a semester. Payments are
 * grouped by BKU month and service type before the single admin fee is
 * applied, preserving the monthly totals recorded in BKU/SPM.
 */
export async function renderFrazaReceiptSemester(
  schoolId: string,
  year: number,
  semester: 1 | 2
): Promise<FrazaReceiptBundleResult | null> {
  const startMonth = semester === 1 ? 1 : 7;
  const endMonth = semester === 1 ? 6 : 12;
  const school = await prisma.school.findUnique({ where: { id: schoolId } });
  if (!school) return null;

  const groups = await prisma.bPUGroup.findMany({
    where: {
      status: "CONFIRMED",
      bkuImport: { schoolId, year, month: { gte: startMonth, lte: endMonth } },
    },
    include: { bkuImport: true, matchedVendorRule: true },
    orderBy: [{ bkuImport: { month: "asc" } }, { tanggal: "asc" }, { bpuNumber: "asc" }],
  });

  const candidates: ReceiptCandidate[] = [];
  for (const group of groups) {
    const rows = await prisma.bKURow.findMany({
      where: { bkuImportId: group.bkuImportId, bpuCode: group.bpuCode },
      select: { uraian: true },
    });
    const computed = computeGroupFields(rows, group.matchedVendorRule);
    const recipient = group.overrideRecipient ?? computed.recipient;
    const paymentFor = group.overridePaymentFor ?? computed.paymentFor;
    const kind = frazaPaymentKind(paymentFor);
    if (!isFrazaCellPayment(recipient, paymentFor) || !kind) continue;

    candidates.push({
      month: group.bkuImport.month,
      year: group.bkuImport.year,
      tanggal: group.tanggal,
      totalAmount: group.totalAmount,
      kind,
    });
  }
  if (candidates.length === 0) return null;

  const byMonthAndService = new Map<string, ReceiptCandidate>();
  for (const candidate of candidates) {
    const key = `${candidate.year}-${candidate.month}-${candidate.kind}`;
    const existing = byMonthAndService.get(key);
    if (existing) {
      existing.totalAmount += candidate.totalAmount;
      if (candidate.tanggal > existing.tanggal) existing.tanggal = candidate.tanggal;
    } else {
      byMonthAndService.set(key, { ...candidate });
    }
  }

  const data = [...byMonthAndService.values()]
    // The page template is filled top-to-bottom in each column, so this keeps
    // one month's electricity and internet receipt together before moving on.
    .sort((a, b) => a.month - b.month || kindSortOrder(a.kind) - kindSortOrder(b.kind))
    .map((item) =>
      buildMonthlyFrazaReceiptData({
        schoolName: school.name,
        month: item.month,
        year: item.year,
        transactionDate: item.tanggal,
        totalAmount: item.totalAmount,
        kind: item.kind,
        electricityCustomerId: school.frazaListrikCustomerId,
        internetCustomerId: school.frazaInternetCustomerId,
      })
    );
  const buffer = await renderToBuffer(<FrazaReceiptBundleDocument data={data} />);
  return { buffer, count: data.length, semester };
}
