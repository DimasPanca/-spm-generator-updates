import { renderToBuffer } from "@react-pdf/renderer";
import { buildLampiranData } from "@/lib/lampiran/buildLampiranData";
import { LampiranDocument } from "@/templates/lampiran";

export interface LampiranRenderResult {
  buffer: Buffer;
  total: number;
  itemCount: number;
  month: number;
  year: number;
}

/** Renders the lampiran on demand. Null when no kode program is confirmed. */
export async function renderLampiranPdf(
  rkasImportId: string
): Promise<LampiranRenderResult | null> {
  const built = await buildLampiranData(rkasImportId);
  if (!built) return null;

  const buffer = await renderToBuffer(LampiranDocument(built.data));
  return {
    buffer,
    total: built.total,
    itemCount: built.itemCount,
    month: built.month,
    year: built.year,
  };
}
