import path from "node:path";
import { renderToBuffer } from "@react-pdf/renderer";
import { prisma } from "@/lib/db";
import { buildA2MandiriInvoiceData } from "@/lib/invoice/buildA2MandiriInvoiceData";
import {
  A2MandiriInvoiceBundleDocument,
  A2MandiriInvoiceDocument,
  type A2MandiriInvoiceTemplateData,
} from "@/templates/a2MandiriInvoice";
import { loadAssetLogoBuffer } from "./loadLogo";

const LOGO_PATH = path.join(process.cwd(), "src", "Logo", "a2-mandiri-emblem.png");

export interface A2MandiriInvoiceRenderResult {
  buffer: Buffer;
  month: number;
  year: number;
  lineCount: number;
}

/** Renders one month's A2 Mandiri (buku pelajaran) invoice. Null when that
 *  BKU month has no confirmed book purchase. */
export async function renderA2MandiriInvoice(
  bkuImportId: string
): Promise<A2MandiriInvoiceRenderResult | null> {
  const bkuImport = await prisma.bKUImport.findUnique({ where: { id: bkuImportId } });
  if (!bkuImport) return null;

  const data = await buildA2MandiriInvoiceData(bkuImport.schoolId, bkuImportId);
  if (!data) return null;

  const logo = await loadAssetLogoBuffer(LOGO_PATH);
  const buffer = await renderToBuffer(
    <A2MandiriInvoiceDocument data={{ ...data, logo }} />
  );
  return { buffer, month: data.month, year: data.year, lineCount: data.lines.length };
}

export interface A2MandiriInvoiceBundleResult {
  buffer: Buffer;
  invoiceCount: number;
  lineCount: number;
}

/**
 * Renders every BKU month that has a confirmed book purchase into one PDF,
 * one invoice per page, skipping months with none entirely.
 */
export async function renderA2MandiriInvoicesForSchool(
  schoolId: string
): Promise<A2MandiriInvoiceBundleResult | null> {
  const imports = await prisma.bKUImport.findMany({
    where: { schoolId },
    orderBy: [{ year: "asc" }, { month: "asc" }],
  });

  const logo = await loadAssetLogoBuffer(LOGO_PATH);
  const pages: A2MandiriInvoiceTemplateData[] = [];

  for (const imp of imports) {
    const data = await buildA2MandiriInvoiceData(schoolId, imp.id);
    if (!data) continue;
    pages.push({ ...data, logo });
  }

  if (pages.length === 0) return null;

  const buffer = await renderToBuffer(<A2MandiriInvoiceBundleDocument pages={pages} />);
  return {
    buffer,
    invoiceCount: pages.length,
    lineCount: pages.reduce((n, p) => n + p.lines.length, 0),
  };
}
