import { renderToBuffer } from "@react-pdf/renderer";
import { CombinedSpmDocument, type SpmTemplateData } from "@/templates/spm";
import { prisma } from "@/lib/db";
import { buildSpmTemplateData } from "@/lib/spm/buildSpmData";
import { loadLogoBuffer } from "./loadLogo";

export interface CombinedSpmResult {
  buffer: Buffer;
  count: number;
}

/**
 * Renders every CONFIRMED BPU group of a BKU import as one multi-page PDF
 * ("SPM Keseluruhan"), one letter per A4 page, ordered by BPU number.
 * Returns null when nothing is confirmed yet -- the caller decides how to
 * surface that (the download route responds 404 with a readable message).
 */
export async function renderCombinedSpm(
  schoolId: string,
  bkuImportId: string
): Promise<CombinedSpmResult | null> {
  const school = await prisma.school.findUniqueOrThrow({ where: { id: schoolId } });
  const groups = await prisma.bPUGroup.findMany({
    where: { bkuImportId, status: "CONFIRMED" },
    include: { matchedVendorRule: true },
    orderBy: { bpuNumber: "asc" },
  });
  if (groups.length === 0) return null;

  const [schoolLogo, regionalLogo] = await Promise.all([
    loadLogoBuffer(school.logoPath),
    loadLogoBuffer(school.regionalLogoPath),
  ]);

  const pages: SpmTemplateData[] = [];
  for (const group of groups) {
    const rows = await prisma.bKURow.findMany({
      where: { bkuImportId, bpuCode: group.bpuCode },
    });
    pages.push(buildSpmTemplateData(school, group, rows, { schoolLogo, regionalLogo }));
  }

  const buffer = await renderToBuffer(<CombinedSpmDocument pages={pages} />);
  return { buffer, count: pages.length };
}
