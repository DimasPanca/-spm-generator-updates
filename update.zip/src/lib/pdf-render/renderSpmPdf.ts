import path from "node:path";
import { mkdir, writeFile } from "node:fs/promises";
import { renderToBuffer } from "@react-pdf/renderer";
import { SpmDocument, type SpmTemplateData } from "@/templates/spm";

export async function renderSpmPdf(
  data: SpmTemplateData,
  outputPath: string
): Promise<void> {
  const buffer = await renderToBuffer(SpmDocument(data));
  await mkdir(path.dirname(outputPath), { recursive: true });
  await writeFile(outputPath, buffer);
}
