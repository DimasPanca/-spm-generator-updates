import { readFile } from "node:fs/promises";
import path from "node:path";
import sharp from "sharp";

/**
 * The KOP prints logos at 76pt (~1.05 inch). 320px covers that at ~300 DPI
 * with room to spare, so anything larger is wasted bytes -- and the cost is
 * multiplied because every page of a multi-letter PDF embeds its own copy
 * (a 20-page "SPM Keseluruhan" would otherwise carry 20x the full-size logo).
 */
const MAX_LOGO_PX = 320;

const cache = new Map<string, Buffer | null>();

/** Reads a School.logoPath/regionalLogoPath (e.g. "/uploads/{id}/logo.png"),
 *  downscaled for print. Returns null if unset or unreadable (e.g. the file was
 *  deleted) rather than throwing -- a missing logo shouldn't block generation. */
export async function loadLogoBuffer(logoPath: string | null): Promise<Buffer | null> {
  if (!logoPath) return null;

  const cached = cache.get(logoPath);
  if (cached !== undefined) return cached;

  let result: Buffer | null = null;
  try {
    const raw = await readFile(path.join(process.cwd(), "public", logoPath));
    result = await sharp(raw)
      .resize({
        width: MAX_LOGO_PX,
        height: MAX_LOGO_PX,
        fit: "inside",
        withoutEnlargement: true,
      })
      .png({ compressionLevel: 9 })
      .toBuffer();
  } catch {
    result = null;
  }

  cache.set(logoPath, result);
  return result;
}

/** Called after a logo upload so the next render picks up the new file. */
export function clearLogoCache(logoPath?: string | null) {
  if (logoPath) cache.delete(logoPath);
  else cache.clear();
}

/** Same downscale-and-cache treatment as loadLogoBuffer, but for a logo that
 *  ships as a fixed project asset (e.g. src/Logo/*.png) rather than a
 *  per-school upload under public/uploads -- so the caller passes an
 *  absolute path directly instead of a School.logoPath. */
export async function loadAssetLogoBuffer(absolutePath: string): Promise<Buffer | null> {
  const cached = cache.get(absolutePath);
  if (cached !== undefined) return cached;

  let result: Buffer | null = null;
  try {
    const raw = await readFile(absolutePath);
    result = await sharp(raw)
      .resize({
        width: MAX_LOGO_PX,
        height: MAX_LOGO_PX,
        fit: "inside",
        withoutEnlargement: true,
      })
      .png({ compressionLevel: 9 })
      .toBuffer();
  } catch {
    result = null;
  }

  cache.set(absolutePath, result);
  return result;
}
