import { renderToBuffer } from "@react-pdf/renderer";
import { prisma } from "@/lib/db";
import {
  buildHonorRecapData,
  buildMonthlyHonorRecapData,
} from "@/lib/honor-recap/recapBuilder";
import { formatFullIndonesianDate } from "@/lib/spm/nomorSurat";
import { monthName } from "@/lib/indonesian/months";
import {
  HonorRecapDocumentTemplate,
  type HonorRecapTemplateData,
} from "@/templates/honorRecap";
import { loadLogoBuffer } from "./loadLogo";

export interface HonorRecapRenderResult {
  buffer: Buffer;
  sheetCount: number;
  rowCount: number;
}

function formatShortDate(date: Date): string {
  const dd = String(date.getUTCDate()).padStart(2, "0");
  const mm = String(date.getUTCMonth() + 1).padStart(2, "0");
  return `${dd}-${mm}-${date.getUTCFullYear()}`;
}

/**
 * Renders the honor recap on demand. A single import produces its monthly
 * recap; a school-wide request produces one PDF containing separate monthly
 * sections, never one table spanning several BKU months.
 */
export async function renderHonorRecapPdf(
  schoolId: string,
  bkuImportId?: string
): Promise<HonorRecapRenderResult | null> {
  const school = await prisma.school.findUniqueOrThrow({ where: { id: schoolId } });
  const recaps = bkuImportId
    ? [{ data: await buildHonorRecapData(schoolId, bkuImportId) }]
    : await buildMonthlyHonorRecapData(schoolId);

  if (recaps.length === 0 || recaps.every(({ data }) => data.sheets.length === 0)) {
    return null;
  }

  const [schoolLogo, regionalLogo] = await Promise.all([
    loadLogoBuffer(school.logoPath),
    loadLogoBuffer(school.regionalLogoPath),
  ]);

  const data: HonorRecapTemplateData = {
    schoolName: school.name,
    kopHeaderLine: school.kopHeaderLine,
    schoolAddress: school.address,
    schoolContact: school.contact,
    schoolNpsn: school.npsn,
    schoolLogo,
    regionalLogo,
    periodLabel: "",
    showMonthColumn: false,
    kepalaJabatan: school.kepalaJabatan,
    kepalaName: school.kepalaName,
    mengetahuiDate: formatFullIndonesianDate(new Date()),
    sheets: recaps.flatMap(({ data: recap }) =>
      recap.sheets.map((sheet) => ({
        title: sheet.title,
        periodLabel: sheet.periodLabel ?? recap.periodLabel,
        // Each section represents exactly one BKU month, so a separate BULAN
        // column is redundant and would make it look like a mixed-month table.
        showMonthColumn: false,
        mengetahuiDate: formatFullIndonesianDate(recap.lastDate ?? new Date()),
        totalFormatted: `Rp ${sheet.total.toLocaleString("id-ID")}`,
        rows: sheet.rows.map((row, idx) => ({
          no: idx + 1,
          tanggal: formatShortDate(row.tanggal),
          bulan: monthName(row.month),
          nama: row.nama,
          nominalFormatted: `Rp ${row.nominal.toLocaleString("id-ID")}`,
        })),
      }))
    ),
  };

  const buffer = await renderToBuffer(HonorRecapDocumentTemplate(data));
  return {
    buffer,
    sheetCount: data.sheets.length,
    rowCount: data.sheets.reduce((n, s) => n + s.rows.length, 0),
  };
}
