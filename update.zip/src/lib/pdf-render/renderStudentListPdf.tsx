import { renderToBuffer } from "@react-pdf/renderer";
import { StudentListDocumentTemplate } from "@/templates/studentList";
import type { StudentListDocumentInput } from "@/lib/student-lists/report";

export async function renderStudentListPdf(
  input: StudentListDocumentInput
): Promise<Buffer> {
  if (input.students.length === 0) throw new Error("Tidak ada siswa untuk dibuat.");
  return renderToBuffer(StudentListDocumentTemplate(input));
}

