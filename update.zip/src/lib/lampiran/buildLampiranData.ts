import { prisma } from "@/lib/db";
import { monthName } from "@/lib/indonesian/months";
import { amountToTerbilang } from "@/lib/terbilang/terbilang";
import type { LampiranTemplateData } from "@/templates/lampiran";

/** Table figures follow the reference sheet's Excel formatting: "130,000". */
function money(value: number): string {
  return value.toLocaleString("en-US");
}

/** The total band prints two decimals: "6,726,500.00". */
function moneyWithDecimals(value: number): string {
  return value.toLocaleString("en-US", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  });
}

/** The header line uses Indonesian separators: "6.726.500". */
function amountId(value: number): string {
  return value.toLocaleString("id-ID");
}

/** The reference sheet ends the terbilang with a lower-case "rupiah". */
function terbilangSentence(value: number): string {
  return amountToTerbilang(value).replace(/\s*Rupiah$/, " rupiah");
}

export interface LampiranBuildResult {
  data: LampiranTemplateData;
  total: number;
  itemCount: number;
  programCount: number;
  month: number;
  year: number;
}

/**
 * Builds the lampiran from whatever is currently confirmed: every item of
 * every confirmed kode program, minus the individually excluded ones. Nothing
 * is stored, so the sheet always matches the latest state of the review
 * screen. Returns null when nothing is selected yet.
 */
export async function buildLampiranData(
  rkasImportId: string
): Promise<LampiranBuildResult | null> {
  const rkas = await prisma.rkasImport.findUnique({
    where: { id: rkasImportId },
    include: {
      programs: {
        where: { included: true },
        orderBy: { urutan: "asc" },
        include: {
          items: { where: { excluded: false }, orderBy: { urutan: "asc" } },
        },
      },
    },
  });
  if (!rkas) return null;

  const bulan = monthName(rkas.month);
  const periodUpper = `${bulan} ${rkas.year}`.toUpperCase();

  const rows: LampiranTemplateData["rows"] = [];
  let total = 0;

  for (const program of rkas.programs) {
    for (const item of program.items) {
      total += item.jumlah;
      rows.push({
        no: rows.length + 1,
        kegiatan: "",
        // As in the reference sheet, the pekerjaan is named once at the top
        // rather than repeated on all 40-odd lines.
        pekerjaan: rows.length === 0 ? rkas.pekerjaanLabel : "",
        kodeRekeningBelanja: program.kodeProgram,
        bulan,
        rincianBelanja: item.uraian,
        volume: item.volumeText,
        tarifHarga: money(item.tarifHarga),
        jumlahBelanja: money(item.jumlah),
        jumlahTarik: money(item.jumlah),
        keterangan: "",
      });
    }
  }

  if (rows.length === 0) return null;

  return {
    data: {
      namaPelaksana: rkas.namaPelaksana,
      programLabel: rkas.programLabel,
      namaKegiatan: rkas.namaKegiatan,
      sumberDana: rkas.sumberDana,
      besarDana: amountId(total),
      waktuPelaksanaan: periodUpper,
      bosPeriodLabel: `${rkas.sumberDana} ${periodUpper}`.toUpperCase(),
      rows,
      total: moneyWithDecimals(total),
      terbilang: terbilangSentence(total),
      kepalaName: rkas.kepalaName,
      bendaharaName: rkas.bendaharaName,
    },
    total,
    itemCount: rows.length,
    programCount: rkas.programs.length,
    month: rkas.month,
    year: rkas.year,
  };
}
