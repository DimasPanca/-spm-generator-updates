import { readFile } from "node:fs/promises";
import path from "node:path";
import { prisma } from "@/lib/db";
import { DocxTemplate } from "@/lib/docx/docxTemplate";
import { buildStockOpnameData } from "./buildOpnameData";

const TEMPLATE_PATH = path.join(process.cwd(), "src", "templates", "docx", "cash-opname.docx");

// Anchors -- literal strings unique to the SDIT-Al-Husna-turned-TK sample
// template that identify what to overwrite. These are the target school's
// values in the template we ship (TK Abdi Pertiwi).
const TPL = {
  kopHeader1: "TAMAN KANAK-KANAK", // first KOP line (repeats 3x)
  kopHeader2: "ABDI PERTIWI", // second KOP line (repeats 3x)
  address: "Graha Walantaka Blok F4", // KOP address (repeats 3x)
  email: "Email:", // email + kode pos (repeats 3x)
  kepalaFull: "Khumaemah, S. Hum",
  bendaharaFull: "Dimas Panca Pamungkas",
  jabatanKepala: "Jabatan: Kepala TK Abdi Pertiwi",
  unitKerja: "Unit Kerja: TK Abdi Pertiwi",
  kepunyaanLine: "Dengan ini saya menyatakan", // last narrative
};

const MONTH_ID = [
  "Januari", "Februari", "Maret", "April", "Mei", "Juni",
  "Juli", "Agustus", "September", "Oktober", "November", "Desember",
];
const DAY_ID = [
  "Ahad", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu",
];
const TERBILANG_UNITS = [
  "Nol", "Satu", "Dua", "Tiga", "Empat", "Lima", "Enam", "Tujuh", "Delapan",
  "Sembilan", "Sepuluh", "Sebelas", "Dua Belas", "Tiga Belas", "Empat Belas",
  "Lima Belas", "Enam Belas", "Tujuh Belas", "Delapan Belas", "Sembilan Belas",
  "Dua Puluh", "Dua Puluh Satu", "Dua Puluh Dua", "Dua Puluh Tiga",
  "Dua Puluh Empat", "Dua Puluh Lima", "Dua Puluh Enam", "Dua Puluh Tujuh",
  "Dua Puluh Delapan", "Dua Puluh Sembilan", "Tiga Puluh", "Tiga Puluh Satu",
];

function terbilangDay(n: number): string {
  return TERBILANG_UNITS[n] ?? String(n);
}

function terbilangYear(year: number): string {
  // Simple year phrasing for 2020-2099.
  if (year < 2000 || year > 2099) return String(year);
  const y = year - 2000;
  const thousands = "Dua Ribu";
  if (y === 0) return thousands;
  if (y < 20) return `${thousands} ${TERBILANG_UNITS[y]}`;
  const tens = Math.floor(y / 10);
  const ones = y % 10;
  const tensWords = ["", "", "Dua Puluh", "Tiga Puluh", "Empat Puluh", "Lima Puluh", "Enam Puluh", "Tujuh Puluh", "Delapan Puluh", "Sembilan Puluh"];
  return ones === 0
    ? `${thousands} ${tensWords[tens]}`
    : `${thousands} ${tensWords[tens]} ${TERBILANG_UNITS[ones]}`;
}

function rp(n: number): string {
  return `Rp. ${n.toLocaleString("id-ID")}`;
}

export interface CashOpnameRenderResult {
  buffer: Buffer;
  fileName: string;
}

/**
 * Fills the cash-opname template for one school. Amounts on the Berita Acara,
 * Registrasi, and Hasil Perhitungan pages stay at zero (per the user's
 * instruction). The monthly Penerimaan/Pengeluaran/Saldo table on page 5 is
 * filled from the school's own BKU so an auditor can see the year's flow.
 */
export async function renderCashOpnameDocx(
  schoolId: string,
  year: number,
  tahap: 1 | 2
): Promise<CashOpnameRenderResult | null> {
  const school = await prisma.school.findUnique({ where: { id: schoolId } });
  if (!school) return null;

  const data = await buildStockOpnameData(schoolId, year, tahap);
  if (!data) return null;

  // Header layout: prefer School.kopHeaderLine + School.name (two-line KOP);
  // fall back to school.name alone if no header line is set.
  const kopLine1 = (school.kopHeaderLine ?? "").trim();
  const kopLine2 = school.name;
  const address = school.address;
  const email = school.contact ? `Kontak: ${school.contact}` : " ";

  // Sign-off date: 30 Juni for Tahap 1, 31 Desember for Tahap 2 (matches the
  // template's convention).
  const signDay = tahap === 1 ? 30 : 31;
  const signMonth = tahap === 1 ? "Juni" : "Desember";
  const dayIdx = new Date(Date.UTC(year, tahap === 1 ? 5 : 11, signDay)).getUTCDay();
  const dayName = DAY_ID[dayIdx];
  const dateStr = `${signDay} ${signMonth} ${year}`;
  const openingLine = `Pada hari ini ${dayName} tanggal ${terbilangDay(signDay)} bulan ${signMonth} tahun ${terbilangYear(year)}, yang bertanda tangan dibawah ini :`;

  const kepala = school.kepalaName || "-";
  const bendahara = data.bendaharaName || "-";
  const jabatanKepala = `Jabatan: Kepala ${school.name}`;
  const unitKerja = `Unit Kerja: ${school.name}`;

  const doc = await DocxTemplate.load(await readFile(TEMPLATE_PATH));

  // --- KOP (repeated on 3 pages) ---
  // Replace ALL occurrences of each anchor by using replaceInParagraph which
  // walks every paragraph and does global replacements per-paragraph.
  doc.replaceInParagraph(TPL.kopHeader1, () => kopLine1 || kopLine2);
  doc.replaceInParagraph(TPL.kopHeader2, () => (kopLine1 ? kopLine2 : " "));
  doc.replaceInParagraph(TPL.address, () => address);
  doc.replaceInParagraph(TPL.email, () => email);

  // --- Opening narrative (Berita Acara page 1) ---
  doc.replaceInParagraph("Pada hari ini", () => openingLine);

  // Nama & Jabatan blocks
  doc.replaceInParagraph(`Nama : ${TPL.kepalaFull}`, () => `Nama : ${kepala}`);
  doc.replaceInParagraph(TPL.jabatanKepala, () => jabatanKepala);
  doc.replaceInParagraph(`Nama: ${TPL.bendaharaFull}`, () => `Nama: ${bendahara}`);
  doc.replaceInParagraph(TPL.unitKerja, () => unitKerja);

  // "Berdasarkan Surat Keputusan Walikota ... tahun anggaran 2025"
  doc.replaceInParagraph("Berdasarkan Surat Keputusan Walikota", (t) =>
    t.replace(/tanggal 31 Desember 2025/, `tanggal ${dateStr}`)
      .replace(/Tahun Anggaran 2025/, `Tahun Anggaran ${year}`)
  );

  // --- Sign-off date (5 places) ---
  doc.replaceInParagraph("Serang, 31 Desember 2025", () => `Serang, ${dateStr}`);

  // Registrasi Pemeriksaan Kas header date
  doc.replaceInParagraph("31 DESEMBER 2025", () => `${signDay} ${signMonth.toUpperCase()} ${year}`);

  // "Tanggal Pemeriksaan Kas: 31 Desember 2025" appears twice
  doc.replaceInParagraph("Tanggal Pemeriksaan Kas", () => `Tanggal Pemeriksaan Kas: ${dateStr}`);

  // --- Sign-off names ---
  // The template glues the two names together in the same paragraph, e.g.
  // "Dimas Panca PamungkasKhumaemah, S. Hum". Insert a wide gap so the
  // Bendahara sits under its column and the Kepala under its own -- a plain
  // space would just look like one long name.
  const wideGap = "\t\t\t\t";
  const bendaharaThenKepala = `${bendahara}${wideGap}${kepala}`;
  const kepalaThenBendahara = `${kepala}${wideGap}${bendahara}`;

  doc.replaceInParagraph(TPL.bendaharaFull, (t) => {
    // Order-preserving replace: whichever name comes first stays first.
    const glued1 = `${TPL.bendaharaFull}${TPL.kepalaFull}`;
    const glued2 = `${TPL.kepalaFull}${TPL.bendaharaFull}`;
    if (t.includes(glued1)) return t.split(glued1).join(bendaharaThenKepala);
    if (t.includes(glued2)) return t.split(glued2).join(kepalaThenBendahara);
    return t
      .split(TPL.bendaharaFull).join(bendahara)
      .split(TPL.kepalaFull).join(kepala);
  });
  doc.replaceInParagraph(TPL.kepalaFull, (t) => t.split(TPL.kepalaFull).join(kepala));

  // --- "kepunyaan PKBM ..." on page 3 ---
  doc.replaceInParagraph(TPL.kepunyaanLine, (t) =>
    t.replace(/kepunyaan\s+PKBM\s*\.+/, `kepunyaan ${school.name}`)
      .replace(/Sdr\.\s*\.+/, `Sdr. ${bendahara}`)
      .replace(/pada 31 Desember 2025/, `pada ${dateStr}`)
  );

  // --- Laporan Realisasi header / Anggaran Tahun ---
  doc.replaceInParagraph("LAPORAN REALISASI BELANJA TAHUN ANGGARAN", () => `LAPORAN REALISASI BELANJA TAHUN ANGGARAN ${year}`);

  // --- BKU monthly table header: type of school + year ---
  // Template header is "PENERIMAAN DAN PENGELUARAN BKU BENDAHARA BOS
  // KB/SPS/TPA/TK" -- keep the category tag list intact (dinas prints these
  // as generic types) but ensure the paragraph is present, and follow it
  // with the real "TAHUN ANGGARAN {year}" line.
  doc.replaceInParagraph("PENERIMAAN DAN PENGELUARAN BKU BENDAHARA BOS", () =>
    "PENERIMAAN DAN PENGELUARAN BKU BENDAHARA BOSP"
  );
  // The "TAHUN ANGGARAN 2025" heading right after it (kept as its own line).
  doc.replaceInParagraph("TAHUN ANGGARAN 2025", () => `TAHUN ANGGARAN ${year}`);
  // Rekapitulasi Pengembalian date range on the last page.
  doc.replaceInParagraph("1 Januari 2025 s.d. 31 Desember 2025", () =>
    `1 Januari ${year} s.d. 31 Desember ${year}`
  );

  // Duration on realisasi table row 2
  doc.replaceInParagraph("01 Januari 2025 s.d.", () => `Realisasi Belanja 01 Januari ${year} s.d. ${signDay} ${signMonth} ${year}`);

  // Yearly total for that row -- fill both BKU and OPNAME columns with the
  // school's total pengeluaran (they should reconcile).
  // The template has "Rp. 6.600.000" in three places on row 2 of table 0.
  // We'll rewrite the whole cell via setCell.
  doc.setCell(0, 2, 1, `Realisasi Belanja 01 Januari ${year} s.d. ${signDay} ${signMonth} ${year}`);
  doc.setCell(0, 2, 2, rp(data.totalPengeluaran));
  doc.setCell(0, 2, 3, rp(data.totalPengeluaran));
  doc.setCell(0, 2, 4, "Rp. 0");

  // --- Monthly BKU table (Table 1) ---
  // Compute per-month penerimaan/pengeluaran from the school's confirmed BKU
  // for the WHOLE year (both tahaps) so the table shows the full year.
  const yearImports = await prisma.bKUImport.findMany({
    where: { schoolId, year },
    orderBy: [{ month: "asc" }, { importedAt: "desc" }],
  });
  const uniqueImports: typeof yearImports = [];
  for (const imp of yearImports) {
    if (!uniqueImports.some((k) => k.month === imp.month)) uniqueImports.push(imp);
  }

  const monthly: { penerimaan: number; pengeluaran: number }[] = Array.from(
    { length: 12 },
    () => ({ penerimaan: 0, pengeluaran: 0 })
  );
  // The "Saldo Bank/Tunai Bulan XYZ" rows echo the prior balance and would
  // triple-count if summed as penerimaan; the transfer rows do the same for
  // internal bank↔tunai moves. Both are pure bookkeeping noise here.
  const isNoise = (u: string) =>
    /^Saldo\s+(Bank|Tunai)\s+Bulan/i.test(u.trim()) ||
    /Pergeseran|Tarik\s*Tunai|Setor\s*Tunai|Setor\s*Bank/i.test(u);

  for (const imp of uniqueImports) {
    const rows = await prisma.bKURow.findMany({ where: { bkuImportId: imp.id } });
    const clean = rows.filter((r) => !isNoise(r.uraian));
    monthly[imp.month - 1].penerimaan = clean.reduce((s, r) => s + r.penerimaan, 0);
    monthly[imp.month - 1].pengeluaran = clean.reduce((s, r) => s + r.pengeluaran, 0);
  }

  // The opening balance -- money already in hand when the year started --
  // isn't recorded as a penerimaan row in BKU. We derive it by requiring the
  // saldo akhir Desember to match what the BKU's own last row printed, same
  // trick used by buildInstrumenData.
  let saldoAkhirTercatat = 0;
  const lastImport = uniqueImports.at(-1);
  if (lastImport) {
    const lastRows = await prisma.bKURow.findMany({
      where: { bkuImportId: lastImport.id },
      orderBy: { tanggal: "asc" },
    });
    if (lastRows.length > 0) saldoAkhirTercatat = lastRows[lastRows.length - 1].saldo;
  }
  const totalNet = monthly.reduce((s, m) => s + m.penerimaan - m.pengeluaran, 0);
  const openingBalance = saldoAkhirTercatat - totalNet;

  // Roll the opening balance into January's penerimaan so the running saldo
  // matches BKU's own final row without needing a separate "saldo awal" line.
  monthly[0].penerimaan += openingBalance;

  let running = 0;
  let totalPenerimaan = 0;
  let totalPengeluaran = 0;
  for (let m = 0; m < 12; m++) {
    running += monthly[m].penerimaan - monthly[m].pengeluaran;
    totalPenerimaan += monthly[m].penerimaan;
    totalPengeluaran += monthly[m].pengeluaran;
    const row = m + 1;
    doc.setCell(1, row, 2, monthly[m].penerimaan.toLocaleString("id-ID"));
    doc.setCell(1, row, 3, monthly[m].pengeluaran.toLocaleString("id-ID"));
    doc.setCell(1, row, 4, running.toLocaleString("id-ID"));
  }
  doc.setCell(1, 13, 0, "Jumlah");
  doc.setCell(1, 13, 2, totalPenerimaan.toLocaleString("id-ID"));
  doc.setCell(1, 13, 3, totalPengeluaran.toLocaleString("id-ID"));

  const safeName = school.name.replace(/[^a-z0-9]+/gi, "_");
  return {
    buffer: await doc.toBuffer(),
    fileName: `Cash_Opname_${safeName}_Tahap_${tahap}_${year}.docx`,
  };
}
