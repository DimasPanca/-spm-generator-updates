import { prisma } from "@/lib/db";
import { computeGroupFields } from "@/lib/spm/paymentFormatter";
import { STOCK_CATEGORIES, categorize, type StockCategory } from "./categorize";

export interface StockAmounts {
  [cat: string]: number; // 10 category totals in Rupiah
}
export interface StockBreakdownEntry {
  uraian: string;
  amount: number;
  category: StockCategory | null;
}
export interface StockOpnameData {
  schoolName: string;
  kepalaName: string;
  bendaharaName: string;
  pengurusName: string;
  year: number;
  tahap: 1 | 2;
  periodLabel: string; // "Per 30 Juni 2025" or "Per 31 Desember 2025"
  signDateLabel: string; // "Serang,     Juli 2026"
  penerimaan: StockAmounts;
  pengeluaran: StockAmounts;
  saldo: StockAmounts;
  totalPenerimaan: number;
  totalPengeluaran: number;
  totalSaldo: number;
  breakdown: StockBreakdownEntry[]; // for showing user how BKU rows were binned
  uncategorizedTotal: number;
}

const MONTH_ID = [
  "Januari", "Februari", "Maret", "April", "Mei", "Juni",
  "Juli", "Agustus", "September", "Oktober", "November", "Desember",
];

function emptyAmounts(): StockAmounts {
  const out: StockAmounts = {};
  for (const c of STOCK_CATEGORIES) out[c] = 0;
  return out;
}

/**
 * Reads all confirmed BPU rows in a school's BKU for the given tahap, sorts
 * them into the 10 Stock Opname columns, and returns per-column totals.
 *
 * The sheet models Penerimaan (what was bought / entered stock) and
 * Pengeluaran (what was used up) separately, with a running Saldo. The user
 * asked to treat both figures as the same running total per category; this
 * matches the reference sheet where the two rows carry identical numbers and
 * saldo is zero. If the user later wants to record actual physical remnants
 * per category, this is where a `saldoOverride` map would slot in.
 */
export async function buildStockOpnameData(
  schoolId: string,
  year: number,
  tahap: 1 | 2
): Promise<StockOpnameData | null> {
  const school = await prisma.school.findUnique({ where: { id: schoolId } });
  if (!school) return null;

  const startMonth = tahap === 1 ? 1 : 7;
  const endMonth = tahap === 1 ? 6 : 12;
  const periodMonth = tahap === 1 ? 6 : 12;
  const periodDay = tahap === 1 ? 30 : 31;
  const periodLabel = `Per ${periodDay} ${MONTH_ID[periodMonth - 1]} ${year}`;
  const signMonth = tahap === 1 ? "Juli" : "Desember";
  const signDateLabel = `Serang,     ${signMonth} ${year}`;

  const allImports = await prisma.bKUImport.findMany({
    where: { schoolId, year, month: { gte: startMonth, lte: endMonth } },
    orderBy: [{ month: "asc" }, { importedAt: "desc" }],
  });
  // Same de-duplication as buildInstrumenData: newest import per month wins.
  const imports: typeof allImports = [];
  for (const imp of allImports) {
    if (!imports.some((k) => k.month === imp.month)) imports.push(imp);
  }

  const penerimaan = emptyAmounts();
  const pengeluaran = emptyAmounts();
  const saldo = emptyAmounts();
  const breakdown: StockBreakdownEntry[] = [];
  let uncategorizedTotal = 0;

  if (imports.length > 0) {
    const groups = await prisma.bPUGroup.findMany({
      where: {
        status: "CONFIRMED",
        bkuImportId: { in: imports.map((i) => i.id) },
      },
      include: { matchedVendorRule: true },
      orderBy: [{ tanggal: "asc" }, { bpuNumber: "asc" }],
    });

    for (const group of groups) {
      const rows = await prisma.bKURow.findMany({
        where: { bkuImportId: group.bkuImportId, bpuCode: group.bpuCode },
      });
      const computed = computeGroupFields(rows, group.matchedVendorRule);
      const paymentFor = group.overridePaymentFor ?? computed.paymentFor;

      const cat = categorize(paymentFor);
      breakdown.push({ uraian: paymentFor, amount: group.totalAmount, category: cat });

      if (cat) {
        penerimaan[cat] += group.totalAmount;
        pengeluaran[cat] += group.totalAmount;
      } else {
        uncategorizedTotal += group.totalAmount;
      }
    }
  }

  const totalPenerimaan = Object.values(penerimaan).reduce((s, n) => s + n, 0);
  const totalPengeluaran = Object.values(pengeluaran).reduce((s, n) => s + n, 0);
  const totalSaldo = totalPenerimaan - totalPengeluaran;

  // Roles: user asked for pengurus barang to come from BKU honor recipients.
  // The convention chosen: the first non-kepala honor recipient serves as
  // the default Pengurus Barang. Bendahara stays what the school's Instrumen
  // BOSP form registered.
  const instrumen = await prisma.instrumenBosp.findFirst({
    where: { schoolId, year, bendaharaName: { not: "" } },
    orderBy: { tahap: "asc" },
  });
  const bendaharaName = instrumen?.bendaharaName ?? "";

  let pengurusName = "";
  if (imports.length > 0) {
    const honorGroups = await prisma.bPUGroup.findMany({
      where: {
        status: "CONFIRMED",
        bkuImportId: { in: imports.map((i) => i.id) },
        matchedVendorRule: { isHonor: true },
      },
      include: { matchedVendorRule: true },
      orderBy: [{ tanggal: "asc" }, { bpuNumber: "asc" }],
    });
    for (const g of honorGroups) {
      let nama = g.overrideRecipient ?? "";
      if (nama.trim() === "") {
        const rows = await prisma.bKURow.findMany({
          where: { bkuImportId: g.bkuImportId, bpuCode: g.bpuCode },
        });
        nama = computeGroupFields(rows, g.matchedVendorRule).recipient;
      }
      nama = nama.trim();
      if (
        nama === "" ||
        nama.toLocaleLowerCase("id-ID") === school.kepalaName.toLocaleLowerCase("id-ID") ||
        nama.toLocaleLowerCase("id-ID") === bendaharaName.toLocaleLowerCase("id-ID")
      ) {
        continue;
      }
      pengurusName = nama;
      break;
    }
  }

  return {
    schoolName: school.name,
    kepalaName: school.kepalaName,
    bendaharaName,
    pengurusName,
    year,
    tahap,
    periodLabel,
    signDateLabel,
    penerimaan,
    pengeluaran,
    saldo,
    totalPenerimaan,
    totalPengeluaran,
    totalSaldo,
    breakdown,
    uncategorizedTotal,
  };
}
