/**
 * Rules that route a BPU's payment-for text (or its recipient/vendor) into
 * one of the 10 columns on the Stock Opname sheet: ATK, Alat & Bahan
 * Kebersihan, Alat Olahraga, Alat Listrik, Materai, Bahan Cetak, Foto
 * Copy/Penggandaan, Bahan & Alat Kesehatan, Bahan & Alat Bangunan, Makan
 * Minum. Anything that doesn't match a category (honor, transport, listrik
 * tagihan yang bukan alat, dsb) is deliberately excluded -- Stock Opname
 * only counts consumable goods.
 */

export const STOCK_CATEGORIES = [
  "ATK",
  "Alat dan Bahan Kebersihan",
  "Alat Olahraga",
  "Alat Listrik",
  "Materai",
  "Bahan Cetak",
  "Foto Copy/Penggandaan",
  "Bahan dan Alat Kesehatan",
  "Bahan dan Alat Bangunan",
  "Makan Minum",
] as const;

export type StockCategory = (typeof STOCK_CATEGORIES)[number];

interface CategoryRule {
  cat: StockCategory;
  // Any of these substrings hitting the haystack (case-insensitive) matches.
  keywords: string[];
}

// Order matters: the first match wins. More specific rules go first
// ("Materai" before "ATK", "Foto Copy" before "Bahan Cetak" -- Foto Copy is
// technically printing but the sheet keeps them apart).
const RULES: CategoryRule[] = [
  { cat: "Foto Copy/Penggandaan", keywords: ["foto copy", "fotocopy", "fotokopi", "penggandaan"] },
  { cat: "Materai", keywords: ["materai", "meterai"] },
  { cat: "Bahan Cetak", keywords: ["cetak", "banner", "spanduk", "baliho", "sertifikat", "piagam", "blanko", "percetakan"] },
  {
    cat: "Alat Olahraga",
    keywords: [
      "olahraga", "bola basket", "bola voli", "bola volley", "bola futsal",
      "bola kaki", "bola tangan", "bola kasti", "raket", "net volley", "net badminton",
    ],
  },
  {
    cat: "Alat Listrik",
    keywords: [
      "kabel", "saklar", "stop kontak", "lampu", "fitting", "fiting", "mcb",
      "listrik-", "alat listrik", "panel", "isolasi", "wireless", "switch hub",
    ],
  },
  {
    cat: "Bahan dan Alat Kesehatan",
    keywords: [
      "obat", "masker", "hand sanitizer", "handsanitizer", "disinfektan",
      "betadine", "revanol", "kasa steril", "hansaplas", "plester",
      "balsem", "minyak gosok", "minyak kayu", "bodrex", "paracetamol",
      "p3k", "kotak obat", "alkohol",
    ],
  },
  {
    cat: "Bahan dan Alat Bangunan",
    keywords: [
      "semen", "pasir", "bata", "cat tembok", "cat besi", "cat metrolit",
      "kuas", "kompon", "amplas", "keramik", "besi ", "paku", "triplek",
      "holo ", "kanal", "metaroof", "eternit", "gipsum", "pipa", "gagang",
      "material", "konstruksi", "lispang", "lis profil", "lem fox",
    ],
  },
  {
    cat: "Makan Minum",
    keywords: [
      "makan", "minum", "nasi box", "snack", "konsumsi", "jamuan",
      "nasi kotak", "coffee break", "kantin",
    ],
  },
  {
    cat: "Alat dan Bahan Kebersihan",
    keywords: [
      "sapu", "pel", "sikat", "kemoceng", "ember", "gayung", "keset",
      "tempat sampah", "serok", "kanebo", "tissue", "tisu", "sabun",
      "sunlight", "vixal", "wipol", "karbol", "pengharum", "kamper",
      "pembasmi", "cairan pembersih", "pembersih lantai", "pembersih kaca",
      "pembersih kloset", "spoon/sabut", "scotch-brite", "serbet",
      "kebersihan",
    ],
  },
  {
    // ATK last -- almost anything office-ish falls here as a fallback.
    cat: "ATK",
    keywords: [
      "atk", "pulpen", "ballpoint", "pensil", "spidol", "buku tulis",
      "kertas hvs", "kertas f4", "kertas a4", "kertas folio", "kertas lipat",
      "sampul", "map", "stofmap", "amplop", "stempel", "tinta printer",
      "tinta stempel", "penghapus", "penggaris", "hard cover", "buku tulis",
      "kertas krep", "isi staples", "gunting", "cutter", "kater",
      "post it", "kalkulator", "kwitansi", "stabilo", "binder clip",
      "paper clip", "double tape", "lakban", "printer", "isi ulang tinta",
      "refill tinta",
    ],
  },
];

/**
 * Returns the Stock Opname column this payment belongs in, or null when it
 * shouldn't appear there at all (honor, transport, listrik tagihan bulanan,
 * pembelian alat modal seperti komputer/laptop, buku pelajaran, dsb).
 */
export function categorize(uraian: string): StockCategory | null {
  const hay = uraian.toLowerCase();

  // Hard excludes -- payments that never belong on this sheet even if their
  // wording brushes near a rule (e.g. "listrik" -> tagihan bulanan, not alat).
  if (/\btagihan (listrik|internet)|belanja tagihan listrik|beban kawat|internet--|langganan/i.test(uraian)) return null;
  if (/honor\b|transport|upah|pemeliharaan|instruktur/i.test(uraian)) return null;
  if (/pengadaan komputer|laptop|axioo|ssd|ram\b|processor|motherboard|psu\b|proyektor/i.test(uraian)) return null;
  if (/buku (siswa|guru|paket|pelajaran|teks|pendamping)|modul \b|paket c\b|kls\.\s*\d+|klas \d+/i.test(uraian)) return null;
  if (/bahan (budidaya|praktek|praktik)|budidaya jamur|jamur tiram|kartu huruf|puzzle|balok rongga|ape\b/i.test(uraian)) return null;

  for (const rule of RULES) {
    for (const kw of rule.keywords) {
      if (hay.includes(kw)) return rule.cat;
    }
  }
  return null;
}
