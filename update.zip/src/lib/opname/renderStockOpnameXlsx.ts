import { readFile } from "node:fs/promises";
import path from "node:path";
import JSZip from "jszip";
import { buildStockOpnameData } from "./buildOpnameData";
import { STOCK_CATEGORIES } from "./categorize";

const TEMPLATE_PATH = path.join(process.cwd(), "src", "templates", "docx", "stock-opname.xlsx");

// Sheet 7 of the template holds the summary layout the school prints. Every
// other sheet stays untouched -- the template ships with them so schools who
// want to see the older per-item working can still open the file in Excel.
const SUMMARY_SHEET = "xl/worksheets/sheet7.xml";
const SHARED_STRINGS = "xl/sharedStrings.xml";

function escapeXml(v: string): string {
  return v
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&apos;");
}

/**
 * Rewrites two kinds of cells:
 *   - Inline strings (like the school name and sign-off names) go straight
 *     into the sheet as `<is><t>…</t></is>` -- simpler than allocating a new
 *     shared-string id and re-referencing it, and Excel accepts both.
 *   - Numbers replace the existing <v> so column totals reflect the current
 *     BKU rather than the previous school's sample data.
 */
/**
 * Excel rejects a file whose cell drops a style id that the file's
 * `styles.xml` uses: the referenced format vanishes and the workbook is
 * flagged corrupt. We therefore keep whatever `s="…"` attribute the original
 * cell had and just swap the type and value inside.
 */
function findCellStyle(sheetXml: string, ref: string): string {
  const re = new RegExp(`<c r="${ref}"([^>]*)(?:/>|>[\\s\\S]*?</c>)`);
  const m = re.exec(sheetXml);
  if (!m) return "";
  const s = /\ss="\d+"/.exec(m[1]);
  return s ? s[0] : "";
}

function setInlineString(sheetXml: string, ref: string, value: string): string {
  const style = findCellStyle(sheetXml, ref);
  const re = new RegExp(`<c r="${ref}"[^>]*(?:/>|>[\\s\\S]*?</c>)`);
  return sheetXml.replace(re, () =>
    `<c r="${ref}"${style} t="inlineStr"><is><t xml:space="preserve">${escapeXml(value)}</t></is></c>`
  );
}

function setNumber(sheetXml: string, ref: string, value: number): string {
  const style = findCellStyle(sheetXml, ref);
  const re = new RegExp(`<c r="${ref}"[^>]*(?:/>|>[\\s\\S]*?</c>)`);
  return sheetXml.replace(re, () => `<c r="${ref}"${style}><v>${value}</v></c>`);
}

// Columns C..M carry the 10 category totals + Jumlah in the summary sheet.
const CATEGORY_COLS = ["C", "D", "E", "F", "G", "H", "I", "J", "K", "L"] as const;
const JUMLAH_COL = "M";

export interface StockOpnameRenderResult {
  buffer: Buffer;
  fileName: string;
  uncategorizedTotal: number;
}

export async function renderStockOpnameXlsx(
  schoolId: string,
  year: number,
  tahap: 1 | 2
): Promise<StockOpnameRenderResult | null> {
  const data = await buildStockOpnameData(schoolId, year, tahap);
  if (!data) return null;

  const zip = await JSZip.loadAsync(await readFile(TEMPLATE_PATH));
  const sheetFile = zip.file(SUMMARY_SHEET);
  if (!sheetFile) throw new Error("REKAP STOCK OPNAME sheet tidak ditemukan di template.");
  let sheet = await sheetFile.async("string");

  // Title lines (rows 1 and 2).
  sheet = setInlineString(
    sheet,
    "A1",
    "LAPORAN STOCK OPNAME PERSEDIAAN BARANG PAKAI HABIS "
  );
  sheet = setInlineString(
    sheet,
    "A2",
    `BELANJA DANA BOSP TAHUN ANGGARAN ${year} TAHAP ${tahap === 1 ? "I" : "II"}`
  );

  // Period label appears in row 4 (Penerimaan header), row 9 (Pengeluaran
  // header) and row 15 (Saldo Akhir header).
  sheet = setInlineString(sheet, "C4", `Penerimaan menurut Buku ${data.periodLabel}`);
  sheet = setInlineString(sheet, "C9", `Pengeluaran hasil Stock Opname ${data.periodLabel}`);
  sheet = setInlineString(sheet, "A14", `SALDO AKHIR ${year}`);
  sheet = setInlineString(sheet, "C15", `Saldo hasil Stock Opname ${data.periodLabel}`);

  // School name in each of the three data rows.
  for (const ref of ["B6", "B11", "B17"] as const) {
    sheet = setInlineString(sheet, ref, data.schoolName);
  }

  // Category totals -- Penerimaan (row 6), Pengeluaran (row 11), Saldo (row 17).
  CATEGORY_COLS.forEach((col, i) => {
    const cat = STOCK_CATEGORIES[i];
    sheet = setNumber(sheet, `${col}6`, data.penerimaan[cat] ?? 0);
    sheet = setNumber(sheet, `${col}11`, data.pengeluaran[cat] ?? 0);
    sheet = setNumber(sheet, `${col}17`, data.saldo[cat] ?? 0);
  });
  sheet = setNumber(sheet, `${JUMLAH_COL}6`, data.totalPenerimaan);
  sheet = setNumber(sheet, `${JUMLAH_COL}11`, data.totalPengeluaran);
  sheet = setNumber(sheet, `${JUMLAH_COL}17`, data.totalSaldo);

  // Sign block: date, roles, names.
  sheet = setInlineString(sheet, "J19", data.signDateLabel);
  sheet = setInlineString(sheet, "B20", "Kepala Sekolah");
  sheet = setInlineString(sheet, "J20", "Pengurus Barang");
  sheet = setInlineString(sheet, "B24", data.kepalaName);
  sheet = setInlineString(sheet, "J24", data.pengurusName || " ");
  sheet = setInlineString(sheet, "B25", "NIP. ");
  sheet = setInlineString(sheet, "J25", "NIP. ");

  // Optional: strip the calcChain so Excel recomputes formulas without
  // complaining about stale references to the rows we just overwrote. Safe to
  // drop entirely -- Excel rebuilds it on next save.
  zip.remove("xl/calcChain.xml");

  zip.file(SUMMARY_SHEET, sheet);

  // The bundled sharedStrings.xml still names old sample values ("SDIT
  // Al-Husna", "PKBM Abdi Pertiwi"). We're not referencing them any more, but
  // leaving them causes no harm -- Excel just keeps them as unused entries.
  void SHARED_STRINGS;

  const buffer = await zip.generateAsync({
    type: "nodebuffer",
    compression: "DEFLATE",
    compressionOptions: { level: 6 },
  });

  const safeName = data.schoolName.replace(/[^a-z0-9]+/gi, "_");
  return {
    buffer,
    fileName: `Stock_Opname_${safeName}_Tahap_${tahap}_${year}.xlsx`,
    uncategorizedTotal: data.uncategorizedTotal,
  };
}
