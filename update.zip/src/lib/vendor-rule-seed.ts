import type { VendorRuleFormatType } from "@/generated/prisma";

export interface VendorRuleSeed {
  keyword: string; // comma-separated alternatives; may be "" if matchKodeKegiatan is set
  recipient: string; // for honor/services, "" means the user must fill in the person's name
  paymentPrefix: string;
  formatType: VendorRuleFormatType;
  matchKodeKegiatan?: string;
  /** Payment to a person -- gets its own "DAFTAR PENERIMAAN ..." honor sheet
   *  and the recipient is a name the user registers once. */
  isHonor?: boolean;
  /** Lump-sum transport payment with no individual names in the BKU -- also
   *  gets a recap sheet, but split into shares and attributed to names
   *  borrowed from that period's honor recipients. */
  isTransport?: boolean;
}

/**
 * Starter vendor rules for PKBM ABDI PERTIWI, based on the user's description
 * of each toko/kategori. Offered as an editable example -- goods always go to
 * a toko, while honor/services go to a named person the user fills in once.
 * Every school can edit/delete these freely.
 *
 * Priority ascending = evaluated first, so specific/honor keywords outrank the
 * broad goods keywords.
 */
export const PKBM_ABDI_PERTIWI_VENDOR_RULES: VendorRuleSeed[] = [
  // --- Honor guru: matched by KODE KEGIATAN, because the uraian is a bare
  //     person name (extracted per-person into "Kepada"). ---
  {
    keyword: "",
    matchKodeKegiatan: "07.12.01",
    recipient: "",
    paymentPrefix: "Honor Tutor PKBM ABDI PERTIWI",
    formatType: "NAME_FROM_URAIAN",
    isHonor: true,
  },

  // --- Honor / jasa (Kepada = nama orang yang diisi user sekali di sini) ---
  { keyword: "Honor Tenaga Administrasi", recipient: "", paymentPrefix: "Honor Tenaga Administrasi", formatType: "STANDARD", isHonor: true },
  { keyword: "Honor Operator, Operator/Proktor", recipient: "", paymentPrefix: "Honor Operator/Proktor", formatType: "STANDARD", isHonor: true },
  { keyword: "Honor Tenaga Perpustakaan", recipient: "", paymentPrefix: "Honor Tenaga Perpustakaan", formatType: "STANDARD", isHonor: true },
  { keyword: "Honor Tenaga Kebersihan", recipient: "", paymentPrefix: "Honor Tenaga Kebersihan", formatType: "STANDARD", isHonor: true },
  { keyword: "Honor Instruktur Keterampilan", recipient: "", paymentPrefix: "Honor Instruktur Keterampilan", formatType: "STANDARD", isHonor: true },
  { keyword: "Pemeliharaan Komputer, Teknisi, Jaringan", recipient: "", paymentPrefix: "Pemeliharaan Komputer dan Jaringan", formatType: "STANDARD", isHonor: true },
  { keyword: "Upah Harian, Jasa Konstruksi, Pertukang, Petukang", recipient: "", paymentPrefix: "Upah Harian Jasa Konstruksi", formatType: "STANDARD", isHonor: true },

  // --- Ujian: Kepada = Bendahara ---
  { keyword: "Penyelenggara Ujian, Penyelenggaraan Ujian", recipient: "Bendahara", paymentPrefix: "Pembayaran Penyelenggara Ujian", formatType: "STANDARD" },
  { keyword: "Pengawas Ujian", recipient: "Bendahara", paymentPrefix: "Honor Pengawas Ujian Kesetaraan", formatType: "STANDARD" },
  { keyword: "Transport", recipient: "Bendahara", paymentPrefix: "Transport Kegiatan", formatType: "STANDARD", isTransport: true },

  // --- Barang: selalu ke toko ---
  { keyword: "Tinta, Laptop, Notebook, Processor, Motherboard, Komputer Desktop, Komputer Laptop, SSD, RAM, PSU, Axioo, Rakit Komputer", recipient: "Diamond Komputer", paymentPrefix: "Pengadaan Komputer/Elektronik", formatType: "STANDARD" },
  { keyword: "APE, Alat Permainan Edukatif, Alat Peraga", recipient: "Data Grafika", paymentPrefix: "Alat Permainan Edukatif (APE)", formatType: "STANDARD" },
  { keyword: "Buku Teks, Buku Pelajaran, Buku Siswa, Buku Guru, Buku Pendamping, Modul", recipient: "A2 Mandiri", paymentPrefix: "Pembelian Buku", formatType: "STANDARD" },
  { keyword: "Listrik, Internet, Kawat/Faksimili, Berlangganan", recipient: "Fraza Cell", paymentPrefix: "Pembayaran Listrik dan Internet", formatType: "STANDARD" },
  { keyword: "Semen, Pasir, Cat Water, Kuas, Bahan Material, Besi, Paku, Bata, Konstruksi", recipient: "PD Pesanggrahan Jaya", paymentPrefix: "Pembelian Bahan Material", formatType: "STANDARD" },
  { keyword: "Fotocopy, Foto Copy, Kuarto, Filio, Folio, ATK, Kertas HVS, HVS, Pulpen, Pensil, Spidol, Ballpoint, Buku Tulis, Stofmap, Amplop, Tinta Stempel, Penghapus, Penggaris", recipient: "Foto Copy Dimas", paymentPrefix: "Pembelian ATK", formatType: "STANDARD" },
  { keyword: "Furniture, Meja, Lemari, Sofa, Kursi, Rak Buku", recipient: "Jannata Furniture", paymentPrefix: "Pembelian Furniture", formatType: "STANDARD" },
  { keyword: "Karpet, Keset, Sapu, Prabotan, Perabotan, Tikar, Ember, Kemoceng, Alat Pel, Tempat Sampah, Gayung, Sikat", recipient: "Toko Zara", paymentPrefix: "Pembelian Prabotan", formatType: "STANDARD" },
  { keyword: "Spanduk, Blanko, Banner, Baliho, Sertifikat, Piagam", recipient: "Sehati Grafika", paymentPrefix: "Percetakan Spanduk, Blanko, dll", formatType: "STANDARD" },
  { keyword: "Makan, Minum, Nasi Box, Snack, Konsumsi, Jamuan", recipient: "Kantin Ananda", paymentPrefix: "Pembelian Makan dan Minum", formatType: "STANDARD" },
  { keyword: "Bahan Baku, Bumbu, Bahan Masakan, Bahan Olahan, Bahan Praktek, Bahan Praktik", recipient: "Koperasi Abdi Pertiwi", paymentPrefix: "Pembelian Bahan", formatType: "STANDARD" },
];
