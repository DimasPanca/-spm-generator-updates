import { prisma } from "@/lib/db";
import { computeGroupFields } from "@/lib/spm/paymentFormatter";

/** A2 Mandiri's own vendor-rule keyword ("Buku Teks, Buku Pelajaran, Buku
 *  Siswa, ...") already keeps notebooks/kertas folio out -- those match Foto
 *  Copy Dimas's ATK rule instead. So "confirmed BPU resolved to A2 Mandiri"
 *  already means "buku pelajaran", with no extra text filtering needed here. */
function isA2MandiriPayment(recipient: string | null): boolean {
  return /a\s*2\s*mandiri/i.test(recipient ?? "");
}

/** BKU uraian text often ends in a trailing "--" placeholder artifact. */
function cleanUraian(uraian: string): string {
  return uraian.replace(/-+\s*$/, "").trim();
}

function formatDdMmYyyy(date: Date): string {
  const dd = String(date.getUTCDate()).padStart(2, "0");
  const mm = String(date.getUTCMonth() + 1).padStart(2, "0");
  return `${dd}-${mm}-${date.getUTCFullYear()}`;
}

export interface A2MandiriInvoiceLine {
  keterangan: string;
  harga: number;
  jml: number;
  total: number;
}

export interface A2MandiriInvoiceData {
  schoolName: string;
  tanggal: string; // "13-03-2026"
  noInvoice: string; // "025/03/2026"
  lines: A2MandiriInvoiceLine[];
  subTotal: number;
  total: number;
  month: number;
  year: number;
}

/**
 * Gathers every confirmed A2 Mandiri (buku pelajaran) purchase within one BKU
 * month into a single invoice, one line per BKU row. The BKU only records a
 * lump sum per purchase (no separate unit price/qty), so each line is priced
 * as 1 x its own total rather than a fabricated quantity. Returns null when
 * the month has no book purchase, so the caller can skip it entirely.
 */
export async function buildA2MandiriInvoiceData(
  schoolId: string,
  bkuImportId: string
): Promise<A2MandiriInvoiceData | null> {
  const bkuImport = await prisma.bKUImport.findUniqueOrThrow({
    where: { id: bkuImportId },
    include: { school: { select: { name: true } } },
  });
  if (bkuImport.schoolId !== schoolId) return null;

  const groups = await prisma.bPUGroup.findMany({
    where: { bkuImportId, status: "CONFIRMED" },
    include: { matchedVendorRule: true },
    orderBy: [{ tanggal: "asc" }, { bpuNumber: "asc" }],
  });

  const lines: A2MandiriInvoiceLine[] = [];
  let latestDate: Date | null = null;
  let minBpuNumber: number | null = null;

  for (const group of groups) {
    const rows = await prisma.bKURow.findMany({
      where: { bkuImportId, bpuCode: group.bpuCode },
      orderBy: { tanggal: "asc" },
    });
    const computed = computeGroupFields(rows, group.matchedVendorRule);
    const recipient = group.overrideRecipient ?? computed.recipient;
    if (!isA2MandiriPayment(recipient)) continue;

    for (const row of rows) {
      if (row.pengeluaran <= 0) continue;
      lines.push({
        keterangan: cleanUraian(row.uraian),
        harga: row.pengeluaran,
        jml: 1,
        total: row.pengeluaran,
      });
      if (!latestDate || row.tanggal > latestDate) latestDate = row.tanggal;
    }
    if (minBpuNumber === null || group.bpuNumber < minBpuNumber) {
      minBpuNumber = group.bpuNumber;
    }
  }

  if (lines.length === 0) return null;

  const subTotal = lines.reduce((sum, l) => sum + l.total, 0);

  return {
    schoolName: bkuImport.school.name,
    tanggal: formatDdMmYyyy(latestDate!),
    // No real invoice sequence exists in the BKU, so the number is derived
    // deterministically from data that's already there: the lowest BPU
    // number that month, plus month/year. Stable across re-downloads, unique
    // per school per month, and never collides across different months.
    noInvoice: `${String(minBpuNumber).padStart(3, "0")}/${String(bkuImport.month).padStart(2, "0")}/${bkuImport.year}`,
    lines,
    subTotal,
    total: subTotal,
    month: bkuImport.month,
    year: bkuImport.year,
  };
}
