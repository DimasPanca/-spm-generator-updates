import { prisma } from "@/lib/db";
import { computeGroupFields } from "@/lib/spm/paymentFormatter";

export interface SkTeamMember {
  nama: string;
  jabatan: string; // "Penanggung Jawab" | "Bendahara" | "Anggota"
  keterangan: string; // "Kepala Sekolah" | "Guru" | "Komite Sekolah" | ...
}

/** Title-cases a name that the honor rules may have stored in ALL CAPS, so the
 *  roster reads like a name list rather than a shout. Words already mixed-case
 *  (e.g. "Sri Margorini, S. Pd") are left untouched. */
function tidyName(raw: string): string {
  const name = raw.trim();
  if (name === "") return name;
  if (name !== name.toUpperCase()) return name; // already mixed case
  return name
    .toLocaleLowerCase("id-ID")
    .replace(/\b\p{L}/gu, (ch) => ch.toLocaleUpperCase("id-ID"));
}

/**
 * Builds the default BOSP team for a school's SK from data already in the app:
 * the head (Penanggung Jawab), the treasurer (Bendahara, from the Instrumen
 * form if it was filled), and every distinct person who received an honor in
 * that year's confirmed BKU (Anggota). Komite and wali seats aren't in the BKU
 * and are added by the user. The user can freely edit the result afterwards.
 */
export async function buildSkTeamPrefill(
  schoolId: string,
  year: number
): Promise<SkTeamMember[]> {
  const school = await prisma.school.findUniqueOrThrow({ where: { id: schoolId } });

  // Dedup on the bare name: the same teacher is the head as "Drs. M. Yusuf"
  // but a bare "M. Yusuf" among the honor rows, so titles and degrees are
  // stripped before comparing to avoid listing one person twice.
  const bareKey = (name: string): string =>
    name
      .toLocaleLowerCase("id-ID")
      .replace(/\b(drs|dra|s\.?\s*pd|s\.?\s*ag|s\.?\s*e|s\.?\s*sos|s\.?\s*kom|m\.?\s*pd|m\.?\s*si|m\.?\s*m|a\.?\s*ma|spd|mpd)\b\.?/g, "")
      .replace(/[.,]/g, " ")
      .replace(/\s+/g, " ")
      .trim();

  const team: SkTeamMember[] = [];
  const seen = new Set<string>();
  const add = (nama: string, jabatan: string, keterangan: string) => {
    const clean = tidyName(nama);
    if (clean === "") return;
    const key = bareKey(clean);
    if (key === "" || seen.has(key)) return;
    seen.add(key);
    team.push({ nama: clean, jabatan, keterangan });
  };

  // 1. Kepala Sekolah -> Penanggung Jawab.
  add(school.kepalaName, "Penanggung Jawab", "Kepala Sekolah");

  // 2. Bendahara, taken from whichever tahap's Instrumen form is filled in.
  const instrumen = await prisma.instrumenBosp.findFirst({
    where: { schoolId, year, bendaharaName: { not: "" } },
    orderBy: { tahap: "asc" },
  });
  if (instrumen?.bendaharaName) {
    add(instrumen.bendaharaName, "Bendahara", "Guru");
  }

  // 3. Every distinct honor recipient of the year -> Anggota (Guru).
  const imports = await prisma.bKUImport.findMany({
    where: { schoolId, year },
    select: { id: true },
  });
  if (imports.length > 0) {
    const honorGroups = await prisma.bPUGroup.findMany({
      where: {
        status: "CONFIRMED",
        bkuImportId: { in: imports.map((i) => i.id) },
        matchedVendorRule: { isHonor: true },
      },
      include: { matchedVendorRule: true },
      orderBy: [{ tanggal: "asc" }, { bpuNumber: "asc" }],
    });

    for (const group of honorGroups) {
      let nama = group.overrideRecipient ?? "";
      if (nama.trim() === "") {
        const rows = await prisma.bKURow.findMany({
          where: { bkuImportId: group.bkuImportId, bpuCode: group.bpuCode },
        });
        nama = computeGroupFields(rows, group.matchedVendorRule).recipient;
      }
      add(nama, "Anggota", "Guru");
    }
  }

  // 4. Komite + wali seats the BKU can't supply -- left blank for the user.
  if (instrumen?.komiteName) {
    add(instrumen.komiteName, "Anggota", "Komite Sekolah");
  } else {
    team.push({ nama: "", jabatan: "Anggota", keterangan: "Komite Sekolah" });
  }
  team.push({
    nama: "",
    jabatan: "Anggota",
    keterangan: "Orang tua/wali peserta didik di luar Komite Sekolah",
  });

  return team;
}
