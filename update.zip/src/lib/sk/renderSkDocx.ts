import { readFile } from "node:fs/promises";
import path from "node:path";
import sharp from "sharp";
import { prisma } from "@/lib/db";
import { DocxTemplate } from "@/lib/docx/docxTemplate";
import { buildSkTeamPrefill, type SkTeamMember } from "./buildSkData";

const TEMPLATE_PATH = path.join(process.cwd(), "src", "templates", "docx", "sk-tim-bosp.docx");

// The bundled template is SDIT AL-HUSNA's SK; these are the literal strings in
// it that identify that school and are swapped for the target school's.
const TPL = {
  schoolName: "SDIT AL-HUSNA",
  titleAnchor: "ISLAM TERPADU", // unique to the KOP title paragraph
  addressAnchor: "Taman Pipitan", // KOP address line
  contactAnchor: "Kecamatan Walantaka Kota Serang Provinsi", // KOP line 3
  kepalaUpper: "MALA WIDIANTI, S.Pd",
  kepalaTitle: "Mala Widianti, S.Pd",
  kecKotaUpper: "KECAMATAN WALANTAKA KOTA SERANG",
  ditetapkan: "Ditetapkan di: Walantaka",
  year: 2026,
};

function pad2(n: number): string {
  return String(n).padStart(2, "0");
}

async function logoPng(logoPath: string | null): Promise<Buffer | null> {
  if (!logoPath) return null;
  try {
    const raw = await readFile(path.join(process.cwd(), "public", logoPath));
    // The template's image is PNG; normalise whatever the school uploaded
    // (often JPG) to PNG at a print-friendly size so it drops in cleanly.
    return await sharp(raw)
      .resize({ width: 480, height: 480, fit: "inside", withoutEnlargement: true })
      .png({ compressionLevel: 9 })
      .toBuffer();
  } catch {
    return null;
  }
}

export interface SkRenderResult {
  buffer: Buffer;
  fileName: string;
  team: SkTeamMember[];
}

export async function renderSkDocx(schoolId: string, year: number): Promise<SkRenderResult | null> {
  const school = await prisma.school.findUnique({ where: { id: schoolId } });
  if (!school) return null;

  const saved = await prisma.skBosp.findUnique({
    where: { schoolId_year: { schoolId, year } },
  });

  const team: SkTeamMember[] =
    saved && saved.teamJson !== "[]"
      ? (JSON.parse(saved.teamJson) as SkTeamMember[]).filter((m) => m.nama.trim() !== "")
      : (await buildSkTeamPrefill(schoolId, year)).filter((m) => m.nama.trim() !== "");

  const nomorUrut = saved?.nomorUrut ?? "05";
  const kodeSurat = saved?.kodeSurat ?? "SK.PTB";
  const rapatDay = saved?.tanggalRapat ?? 2;
  const tetapDay = saved?.tanggalTetap ?? 4;
  const kecamatan = saved?.kecamatan ?? "Walantaka";
  const kota = saved?.kota ?? "Kota Serang";
  const provinsi = saved?.provinsi ?? "Banten";
  const kepala = (saved?.kepalaName || school.kepalaName || "").trim();

  const nomor = `${nomorUrut}/${kodeSurat}/${school.name}/I/${year}`;
  const tetapStr = `${pad2(tetapDay)} Januari ${year}`;

  const doc = await DocxTemplate.load(await readFile(TEMPLATE_PATH));

  // --- Logo (KOP) ---
  const logo = await logoPng(school.logoPath);
  if (logo) doc.replaceMedia("image1.png", logo);

  // --- KOP header text (title / address / contact) ---
  const titleLines = [school.kopHeaderLine, school.name].filter(
    (l): l is string => Boolean(l && l.trim())
  );
  doc.setParagraphLines(TPL.titleAnchor, titleLines);
  // School.address already carries kecamatan/kota/provinsi, so the template's
  // second address line (which repeated those) becomes NPSN + phone to avoid
  // printing the district twice.
  doc.replaceInParagraph(TPL.addressAnchor, () => school.address);
  const line3 = [school.npsn ? `NPSN. ${school.npsn}` : null, school.contact ? `Telp. ${school.contact}` : null]
    .filter(Boolean)
    .join("   ");
  doc.replaceInParagraph(TPL.contactAnchor, () => line3 || " ");

  // --- School name everywhere in the body + lampiran ---
  doc.replaceInParagraph(TPL.schoolName, (t) => t.split(TPL.schoolName).join(school.name));

  // --- Year (template is 2026; safe global swap -- no law citation is 2026) ---
  if (year !== TPL.year) {
    doc.replaceInParagraph(String(TPL.year), (t) => t.split(String(TPL.year)).join(String(year)));
  }

  // --- Nomor surat (both the main decree and the lampiran header) ---
  const nomorRe = /\d+\/[A-Za-z.]+\/.+?\/I\/\d{4}/;
  doc.replaceInParagraph("/I/", (t) => (nomorRe.test(t) ? t.replace(nomorRe, nomor) : t));
  doc.replaceInParagraph("/I/", (t) => (nomorRe.test(t) ? t.replace(nomorRe, nomor) : t));

  // --- Dates ---
  doc.replaceInParagraph("bulan Januari", (t) =>
    t.replace(/\d+\s+bulan\s+Januari/, `${pad2(rapatDay)} bulan Januari`)
  );
  doc.replaceInParagraph("Pada tanggal:", () => `Pada tanggal: ${tetapStr}`);
  doc.replaceInParagraph("TANGGAL:", () => `TANGGAL: ${tetapStr}`);

  // --- Kecamatan / kota ---
  doc.replaceInParagraph(
    TPL.kecKotaUpper,
    () => `KECAMATAN ${kecamatan.toUpperCase()} ${kota.toUpperCase()}`
  );
  doc.replaceInParagraph("Ditetapkan di:", () => `Ditetapkan di: ${kecamatan}`);
  // Final lampiran signature line "Walantaka, 04 Januari 2026".
  doc.replaceInParagraph(", ", (t) =>
    /^[A-Za-z ]+,\s+\d+\s+Januari\s+\d{4}$/.test(t.trim())
      ? `${kecamatan}, ${tetapStr}`
      : t
  );

  // --- Kepala name (signatures) ---
  if (kepala) {
    doc.replaceInParagraph(TPL.kepalaUpper, () => kepala.toUpperCase());
    doc.replaceInParagraph(TPL.kepalaTitle, () => kepala);
  }

  // --- Roster (Table 2) ---
  fillRoster(doc, team);

  const safeName = school.name.replace(/[^a-z0-9]+/gi, "_");
  return {
    buffer: await doc.toBuffer(),
    fileName: `SK_Tim_BOSP_${safeName}_${year}.docx`,
    team,
  };
}

/**
 * The roster is the third table. It ships with a header row and five data
 * rows; extra members clone the last data row, unused rows are blanked, and
 * every cell is rewritten so no template name lingers.
 */
function fillRoster(doc: DocxTemplate, team: SkTeamMember[]) {
  const TABLE = 2;
  const TEMPLATE_ROWS = 5;
  const need = Math.max(team.length, 1);

  if (need > TEMPLATE_ROWS) {
    doc.cloneRow(TABLE, TEMPLATE_ROWS, need - TEMPLATE_ROWS); // clone last data row
  }

  for (let i = 0; i < Math.max(need, TEMPLATE_ROWS); i++) {
    const row = i + 1; // row 0 is the header
    const m = team[i];
    doc.setCell(TABLE, row, 0, m ? `${i + 1}.` : "");
    doc.setCell(TABLE, row, 1, m ? m.nama : "");
    doc.setCell(TABLE, row, 2, ""); // Pangkat/Golongan -- swasta: kosong
    doc.setCell(TABLE, row, 3, m ? m.jabatan : "");
    doc.setCell(TABLE, row, 4, m ? m.keterangan : "");
  }
}
