import type { BKUImport, BPUGroup, School } from "@/generated/prisma";
import { formatFullIndonesianDate } from "@/lib/spm/nomorSurat";
import { monthName } from "@/lib/indonesian/months";

const ADMIN_FEE = 2_000;

export interface FrazaReceiptData {
  schoolName: string;
  paymentTitle: string;
  transactionDate: string;
  customerId: string;
  tariff: string;
  billingPeriod: string;
  billAmount: number;
  adminAmount: number;
  totalAmount: number;
}

export type FrazaPaymentKind = "LISTRIK" | "INTERNET" | "GABUNGAN";

/**
 * Returns the receipt type from the reviewed SPM wording. A BPU that names
 * both services deliberately stays in its own combined type so its amount is
 * never guessed or split between electricity and internet.
 */
export function frazaPaymentKind(paymentFor: string): FrazaPaymentKind | null {
  const value = paymentFor.toLocaleLowerCase("id-ID");
  const hasListrik = value.includes("listrik");
  const hasInternet = value.includes("internet") || value.includes("kawat") || value.includes("faksimili");

  if (hasListrik && hasInternet) return "GABUNGAN";
  if (hasListrik) return "LISTRIK";
  if (hasInternet) return "INTERNET";
  return null;
}

function titleFromKind(kind: FrazaPaymentKind) {
  if (kind === "GABUNGAN") return "TAGIHAN LISTRIK / INTERNET";
  return `TAGIHAN ${kind}`;
}

/**
 * Turns one Fraza Cell BPU into the fixed receipt fields. The BKU's total is
 * authoritative: the Rp2.000 administration cost is split out of it, never
 * added on top of it.
 */
export function buildFrazaReceiptData(
  school: Pick<School, "name" | "frazaListrikCustomerId" | "frazaInternetCustomerId">,
  bkuImport: Pick<BKUImport, "month" | "year">,
  group: Pick<BPUGroup, "tanggal" | "totalAmount">,
  paymentFor: string
): FrazaReceiptData {
  const kind = frazaPaymentKind(paymentFor);
  if (!kind) throw new Error("BPU Fraza Cell bukan pembayaran listrik atau internet.");

  return buildMonthlyFrazaReceiptData({
    schoolName: school.name,
    month: bkuImport.month,
    year: bkuImport.year,
    transactionDate: group.tanggal,
    totalAmount: group.totalAmount,
    kind,
    electricityCustomerId: school.frazaListrikCustomerId,
    internetCustomerId: school.frazaInternetCustomerId,
  });
}

export interface MonthlyFrazaReceiptInput {
  schoolName: string;
  month: number;
  year: number;
  /** The final BKU transaction date for this monthly receipt. */
  transactionDate: Date;
  /** Sum of all matching BKU BPUs for the same month and service. */
  totalAmount: number;
  kind: FrazaPaymentKind;
  electricityCustomerId?: string | null;
  internetCustomerId?: string | null;
}

function customerIdFromKind(input: MonthlyFrazaReceiptInput) {
  if (input.kind === "LISTRIK") return input.electricityCustomerId || "-";
  if (input.kind === "INTERNET") return input.internetCustomerId || "-";

  const ids = [input.electricityCustomerId, input.internetCustomerId].filter(
    (id): id is string => Boolean(id)
  );
  return ids.length > 0 ? ids.join(" / ") : "-";
}

/**
 * Builds one receipt after all BKU payments in its month have been combined.
 * Rp2.000 is taken out only once, so the receipt total always remains equal
 * to the BKU/SPM total.
 */
export function buildMonthlyFrazaReceiptData(input: MonthlyFrazaReceiptInput): FrazaReceiptData {
  const adminAmount = Math.min(ADMIN_FEE, input.totalAmount);

  return {
    schoolName: input.schoolName,
    paymentTitle: titleFromKind(input.kind),
    transactionDate: formatFullIndonesianDate(input.transactionDate),
    customerId: customerIdFromKind(input),
    tariff: "R1/900 VA",
    billingPeriod: `${monthName(input.month)} ${input.year}`,
    billAmount: input.totalAmount - adminAmount,
    adminAmount,
    totalAmount: input.totalAmount,
  };
}

export function formatReceiptRupiah(amount: number) {
  return `Rp. ${amount.toLocaleString("id-ID")}`;
}
