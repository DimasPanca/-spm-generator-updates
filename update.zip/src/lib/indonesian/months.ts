export const MONTH_NAMES_ID = [
  "Januari",
  "Februari",
  "Maret",
  "April",
  "Mei",
  "Juni",
  "Juli",
  "Agustus",
  "September",
  "Oktober",
  "November",
  "Desember",
] as const;

export const MONTH_ROMAN = [
  "I",
  "II",
  "III",
  "IV",
  "V",
  "VI",
  "VII",
  "VIII",
  "IX",
  "X",
  "XI",
  "XII",
] as const;

/** 1-12 -> roman numeral, matching the VBA bulanRomawiArray convention. */
export function monthToRoman(month: number): string {
  return MONTH_ROMAN[month - 1];
}

/** 1-12 -> "Januari".."Desember". */
export function monthName(month: number): string {
  return MONTH_NAMES_ID[month - 1];
}

/** Case-insensitive Indonesian month name -> 1-12, or null if unrecognized. */
export function monthNameToNumber(name: string): number | null {
  const normalized = name.trim().toLowerCase();
  const index = MONTH_NAMES_ID.findIndex(
    (m) => m.toLowerCase() === normalized
  );
  return index === -1 ? null : index + 1;
}
