import { prisma } from "@/lib/db";
import { computeGroupFields } from "@/lib/spm/paymentFormatter";
import { monthName } from "@/lib/indonesian/months";
import { formatFullIndonesianDate } from "@/lib/spm/nomorSurat";

/** Fixed transport rate observed in the real BKU data ("1 orang 200rb").
 *  A lump "Uang Transport Peserta Kegiatan" total is split into this many
 *  Rupiah per share -- there is no per-person amount recorded in the BKU. */
const TRANSPORT_RATE_PER_PERSON = 200_000;

/** Splits a lump transport total into ~Rp200.000 shares, one per person,
 *  with any remainder as a final smaller share so the shares always sum
 *  back to the exact recorded total. */
function splitTransportShares(total: number, rate: number): number[] {
  if (total <= 0) return [];
  const fullShares = Math.floor(total / rate);
  const remainder = total - fullShares * rate;
  const shares = Array<number>(fullShares).fill(rate);
  if (remainder > 0) shares.push(remainder);
  return shares;
}

/** Tiny deterministic PRNG (mulberry32) seeded from a string hash -- NOT
 *  Math.random(). The same BPU must always "shuffle" to the same names on
 *  every re-render, since this is an on-demand document with nothing stored. */
function seededShuffle<T>(items: T[], seed: string): T[] {
  let h = 0;
  for (let i = 0; i < seed.length; i++) {
    h = (Math.imul(31, h) + seed.charCodeAt(i)) | 0;
  }
  let state = h >>> 0 || 1;
  const next = () => {
    state ^= state << 13;
    state ^= state >>> 17;
    state ^= state << 5;
    state >>>= 0;
    return state / 0xffffffff;
  };

  const result = [...items];
  for (let i = result.length - 1; i > 0; i--) {
    const j = Math.floor(next() * (i + 1));
    [result[i], result[j]] = [result[j], result[i]];
  }
  return result;
}

export interface HonorRecapRow {
  tanggal: Date;
  month: number;
  year: number;
  nama: string;
  nominal: number;
}

export interface HonorRecapSheet {
  /** Vendor-rule payment prefix, e.g. "Honor Tenaga Kebersihan". */
  category: string;
  /** Full document heading, e.g. "DAFTAR PENERIMAAN HONOR TENAGA KEBERSIHAN". */
  title: string;
  /** Overrides the document-wide periodLabel for just this sheet. Used by
   *  Transport Kegiatan: each trip is its own separate disbursement with its
   *  own participants, so it must never read as merged with another trip's
   *  date just because both fall inside the same recap's date range. */
  periodLabel?: string;
  /** Overrides the document-wide showMonthColumn for just this sheet. */
  showMonthColumn?: boolean;
  rows: HonorRecapRow[];
  total: number;
}

export interface HonorRecapData {
  sheets: HonorRecapSheet[];
  /** "FEBRUARI 2026" or "JANUARI - JUNI 2026" for the all-months recap. */
  periodLabel: string;
  /** All-months recaps add a BULAN column so each payment stays traceable. */
  showMonthColumn: boolean;
  /** Date used for the "Mengetahui, ..." line: the latest payment date. */
  lastDate: Date | null;
}

export interface MonthlyHonorRecapData {
  month: number;
  year: number;
  data: HonorRecapData;
}

function buildPeriodLabel(
  entries: { month: number; year: number }[],
  fallback: { month: number; year: number } | null
): string {
  if (entries.length === 0) {
    return fallback
      ? `${monthName(fallback.month).toUpperCase()} ${fallback.year}`
      : "";
  }
  const sorted = [...entries].sort((a, b) =>
    a.year !== b.year ? a.year - b.year : a.month - b.month
  );
  const first = sorted[0];
  const last = sorted[sorted.length - 1];
  if (first.year === last.year && first.month === last.month) {
    return `${monthName(first.month).toUpperCase()} ${first.year}`;
  }
  if (first.year === last.year) {
    return `${monthName(first.month).toUpperCase()} - ${monthName(
      last.month
    ).toUpperCase()} ${first.year}`;
  }
  return `${monthName(first.month).toUpperCase()} ${first.year} - ${monthName(
    last.month
  ).toUpperCase()} ${last.year}`;
}

/**
 * Builds the honor recap sheets for a school: one sheet per honor category
 * (each vendor rule flagged `isHonor`), listing every CONFIRMED BPU group that
 * matched it, plus one sheet per individual `isTransport` trip/BPU (see
 * splitTransportShares/seededShuffle above for how those rows are derived --
 * unlike honor, each transport trip is its own sheet rather than a shared
 * table, since different trips have unrelated participants and dates).
 *
 * Deliberately NOT aggregated: if the same person appears in several BPU codes
 * they get one row per occurrence, because each row corresponds to a real
 * payment the recipient signs for individually.
 *
 * @param bkuImportId when given, restrict to that month; otherwise cover every
 *        import of the school ("Rekap Honor Keseluruhan").
 */
export async function buildHonorRecapData(
  schoolId: string,
  bkuImportId?: string
): Promise<HonorRecapData> {
  const [honorRules, transportRules] = await Promise.all([
    prisma.vendorRule.findMany({ where: { schoolId, isHonor: true }, orderBy: { priority: "asc" } }),
    prisma.vendorRule.findMany({ where: { schoolId, isTransport: true }, orderBy: { priority: "asc" } }),
  ]);
  if (honorRules.length === 0 && transportRules.length === 0) {
    return { sheets: [], periodLabel: "", showMonthColumn: !bkuImportId, lastDate: null };
  }

  const rowsByRule = new Map<string, HonorRecapRow[]>();

  if (honorRules.length > 0) {
    const honorGroups = await prisma.bPUGroup.findMany({
      where: {
        status: "CONFIRMED",
        matchedVendorRuleId: { in: honorRules.map((r) => r.id) },
        bkuImport: bkuImportId ? { id: bkuImportId } : { schoolId },
      },
      include: { matchedVendorRule: true, bkuImport: true },
      orderBy: [{ tanggal: "asc" }, { bpuNumber: "asc" }],
    });

    for (const group of honorGroups) {
      const rule = group.matchedVendorRule!;
      let nama = group.overrideRecipient ?? "";
      if (nama.trim() === "") {
        const bkuRows = await prisma.bKURow.findMany({
          where: { bkuImportId: group.bkuImportId, bpuCode: group.bpuCode },
        });
        nama = computeGroupFields(bkuRows, rule).recipient;
      }
      if (nama.trim() === "") continue; // no name to sign for -- skip

      const list = rowsByRule.get(rule.id) ?? [];
      list.push({
        tanggal: group.tanggal,
        month: group.bkuImport.month,
        year: group.bkuImport.year,
        nama: nama.trim(),
        nominal: group.totalAmount,
      });
      rowsByRule.set(rule.id, list);
    }
  }

  // Transport Kegiatan has no recorded names in the BKU (unlike Honor rows).
  // Its lump total is split into ~Rp200.000 shares and each share is
  // attributed to a name borrowed from this same scope's honor recipients,
  // picked with a deterministic shuffle (not Math.random()) so a re-download
  // of the same month always reproduces the identical assignment.
  //
  // Each trip gets its OWN sheet (not merged into a shared table with other
  // months' trips): they're separate disbursements to different people on
  // different dates, and a combined table would misread as one shared event.
  const transportSheets: HonorRecapSheet[] = [];
  if (transportRules.length > 0) {
    // Always drawn from the school's FULL honor history (never just the
    // current report's scope): a per-month recap and the all-months recap
    // must assign the exact same name to the exact same BPU, since both are
    // just different views over the same underlying payment.
    let namePool: string[] = [];
    if (honorRules.length > 0) {
      const schoolWideHonorGroups = await prisma.bPUGroup.findMany({
        where: {
          status: "CONFIRMED",
          matchedVendorRuleId: { in: honorRules.map((r) => r.id) },
          bkuImport: { schoolId },
        },
        include: { matchedVendorRule: true },
        orderBy: [{ tanggal: "asc" }, { bpuNumber: "asc" }],
      });
      const names = new Set<string>();
      for (const group of schoolWideHonorGroups) {
        const rule = group.matchedVendorRule!;
        let nama = group.overrideRecipient ?? "";
        if (nama.trim() === "") {
          const bkuRows = await prisma.bKURow.findMany({
            where: { bkuImportId: group.bkuImportId, bpuCode: group.bpuCode },
          });
          nama = computeGroupFields(bkuRows, rule).recipient;
        }
        if (nama.trim() !== "") names.add(nama.trim());
      }
      namePool = [...names];
    }

    const transportGroups = await prisma.bPUGroup.findMany({
      where: {
        status: "CONFIRMED",
        matchedVendorRuleId: { in: transportRules.map((r) => r.id) },
        bkuImport: bkuImportId ? { id: bkuImportId } : { schoolId },
      },
      include: { matchedVendorRule: true, bkuImport: true },
      orderBy: [{ tanggal: "asc" }, { bpuNumber: "asc" }],
    });

    for (const group of transportGroups) {
      const rule = group.matchedVendorRule!;
      const shares = splitTransportShares(group.totalAmount, TRANSPORT_RATE_PER_PERSON);
      if (shares.length === 0) continue;

      const rows: HonorRecapRow[] = [];
      if (namePool.length === 0) {
        // Nobody anywhere in scope to attribute this to -- list it under the
        // treasurer rather than silently dropping a real payment.
        rows.push({
          tanggal: group.tanggal,
          month: group.bkuImport.month,
          year: group.bkuImport.year,
          nama: rule.recipient,
          nominal: group.totalAmount,
        });
      } else {
        const shuffled = seededShuffle(namePool, group.bpuCode);
        shares.forEach((amount, i) => {
          rows.push({
            tanggal: group.tanggal,
            month: group.bkuImport.month,
            year: group.bkuImport.year,
            nama: shuffled[i % shuffled.length],
            nominal: amount,
          });
        });
      }

      transportSheets.push({
        category: rule.paymentPrefix,
        title: `DAFTAR PENERIMAAN ${rule.paymentPrefix.toUpperCase()}`,
        periodLabel: formatFullIndonesianDate(group.tanggal).toUpperCase(),
        showMonthColumn: false,
        rows,
        total: rows.reduce((sum, r) => sum + r.nominal, 0),
      });
    }
  }

  const sheets: HonorRecapSheet[] = [];
  for (const rule of honorRules) {
    const rows = rowsByRule.get(rule.id);
    if (!rows || rows.length === 0) continue; // don't print empty sheets
    sheets.push({
      category: rule.paymentPrefix,
      title: `DAFTAR PENERIMAAN ${rule.paymentPrefix.toUpperCase()}`,
      rows,
      total: rows.reduce((sum, r) => sum + r.nominal, 0),
    });
  }
  sheets.push(...transportSheets);

  const allRows = sheets.flatMap((s) => s.rows);
  let fallback: { month: number; year: number } | null = null;
  if (bkuImportId) {
    const imp = await prisma.bKUImport.findUnique({ where: { id: bkuImportId } });
    if (imp) fallback = { month: imp.month, year: imp.year };
  }

  const lastDate =
    allRows.length > 0
      ? allRows.reduce((a, b) => (a.tanggal > b.tanggal ? a : b)).tanggal
      : null;

  return {
    sheets,
    periodLabel: buildPeriodLabel(allRows, fallback),
    showMonthColumn: !bkuImportId,
    lastDate,
  };
}

/**
 * Builds the school-wide recap as a sequence of individual monthly recaps.
 * Each imported BKU is retained as its own reporting period, so honor paid in
 * January can never be merged into the February (or later) table.
 */
export async function buildMonthlyHonorRecapData(
  schoolId: string
): Promise<MonthlyHonorRecapData[]> {
  const imports = await prisma.bKUImport.findMany({
    where: { schoolId },
    orderBy: [{ year: "asc" }, { month: "asc" }, { importedAt: "asc" }],
    select: { id: true, month: true, year: true },
  });

  const monthlyData = await Promise.all(
    imports.map(async (bkuImport) => ({
      month: bkuImport.month,
      year: bkuImport.year,
      data: await buildHonorRecapData(schoolId, bkuImport.id),
    }))
  );

  // Imports without confirmed honor/transport payments must not create blank
  // pages, but every BKU month that has a payment remains a distinct section.
  return monthlyData.filter(({ data }) => data.sheets.length > 0);
}
