// Ported from the PKBM ABDI PERTIWI VBA workbook's ConvertNumberToText /
// ConvertToIndonesian / ConvertHundredsGroup functions -- same algorithm,
// same singular-form special cases ("seratus", "seribu", "satu juta").

const ONES = [
  "",
  "satu",
  "dua",
  "tiga",
  "empat",
  "lima",
  "enam",
  "tujuh",
  "delapan",
  "sembilan",
];

const TEENS = [
  "sepuluh",
  "sebelas",
  "dua belas",
  "tiga belas",
  "empat belas",
  "lima belas",
  "enam belas",
  "tujuh belas",
  "delapan belas",
  "sembilan belas",
];

const TENS = [
  "",
  "",
  "dua puluh",
  "tiga puluh",
  "empat puluh",
  "lima puluh",
  "enam puluh",
  "tujuh puluh",
  "delapan puluh",
  "sembilan puluh",
];

function convertHundredsGroup(n: number): string {
  if (n === 0) return "";
  let num = n;
  let result = "";

  if (num >= 100) {
    const hundredsDigit = Math.floor(num / 100);
    result += hundredsDigit === 1 ? "seratus " : `${ONES[hundredsDigit]} ratus `;
    num %= 100;
  }

  if (num >= 20) {
    result += `${TENS[Math.floor(num / 10)]} `;
    if (num % 10 > 0) result += `${ONES[num % 10]} `;
  } else if (num >= 10) {
    result += `${TEENS[num - 10]} `;
  } else if (num > 0) {
    result += `${ONES[num]} `;
  }

  return result.trim();
}

const TRILIUN = 1_000_000_000_000;
const MILIAR = 1_000_000_000;
const JUTA = 1_000_000;
const RIBU = 1_000;

function convertToIndonesian(n: number): string {
  if (n === 0) return "";
  let num = n;
  let result = "";

  if (num >= TRILIUN) {
    result += `${convertHundredsGroup(Math.floor(num / TRILIUN))} triliun `;
    num %= TRILIUN;
  }
  if (num >= MILIAR) {
    result += `${convertHundredsGroup(Math.floor(num / MILIAR))} miliar `;
    num %= MILIAR;
  }
  if (num >= JUTA) {
    const jutaCount = Math.floor(num / JUTA);
    result += jutaCount === 1 ? "satu juta " : `${convertHundredsGroup(jutaCount)} juta `;
    num %= JUTA;
  }
  if (num >= RIBU) {
    const ribuCount = Math.floor(num / RIBU);
    result += ribuCount === 1 ? "seribu " : `${convertHundredsGroup(ribuCount)} ribu `;
    num %= RIBU;
  }
  if (num > 0) {
    result += convertHundredsGroup(num);
  }

  return result.trim();
}

/** e.g. 327000 -> "Tiga ratus dua puluh tujuh ribu Rupiah"; 1100000 -> "Satu juta seratus ribu Rupiah". */
export function amountToTerbilang(amount: number): string {
  if (amount === 0) return "Nol Rupiah";
  const words = convertToIndonesian(Math.trunc(Math.abs(amount)));
  const capitalized = words.charAt(0).toUpperCase() + words.slice(1).toLowerCase();
  return `${capitalized} Rupiah`;
}
