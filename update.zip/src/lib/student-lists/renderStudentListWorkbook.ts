import JSZip from "jszip";
import {
  formatStudentBirth,
  studentListSheetName,
  studentListTitle,
  type StudentListDocumentInput,
} from "./report";

function escapeXml(value: string): string {
  return value
    .replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f]/g, "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&apos;");
}

function columnLetter(index: number): string {
  let value = index + 1;
  let result = "";
  while (value > 0) {
    value--;
    result = String.fromCharCode(65 + (value % 26)) + result;
    value = Math.floor(value / 26);
  }
  return result;
}

function numberCell(reference: string, value: number, style: number): string {
  return `<c r="${reference}" s="${style}"><v>${value}</v></c>`;
}

function workbookStylesXml(): string {
  return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
  <fonts count="6">
    <font><sz val="10"/><name val="Arial"/><family val="2"/></font>
    <font><b/><sz val="16"/><name val="Arial"/><family val="2"/></font>
    <font><b/><sz val="14"/><name val="Arial"/><family val="2"/></font>
    <font><b/><sz val="12"/><name val="Arial"/><family val="2"/></font>
    <font><b/><sz val="10"/><name val="Arial"/><family val="2"/></font>
    <font><b/><u/><sz val="10"/><name val="Arial"/><family val="2"/></font>
  </fonts>
  <fills count="2"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill></fills>
  <borders count="2">
    <border><left/><right/><top/><bottom/><diagonal/></border>
    <border><left style="thin"><color auto="1"/></left><right style="thin"><color auto="1"/></right><top style="thin"><color auto="1"/></top><bottom style="thin"><color auto="1"/></bottom><diagonal/></border>
  </borders>
  <cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>
  <cellXfs count="11">
    <xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>
    <xf numFmtId="0" fontId="1" fillId="0" borderId="0" xfId="0" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf>
    <xf numFmtId="0" fontId="2" fillId="0" borderId="0" xfId="0" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf>
    <xf numFmtId="0" fontId="3" fillId="0" borderId="0" xfId="0" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf>
    <xf numFmtId="0" fontId="4" fillId="0" borderId="1" xfId="0" applyAlignment="1"><alignment horizontal="center" vertical="center" wrapText="1"/></xf>
    <xf numFmtId="0" fontId="0" fillId="0" borderId="1" xfId="0" applyAlignment="1"><alignment horizontal="center" vertical="center" wrapText="1"/></xf>
    <xf numFmtId="0" fontId="0" fillId="0" borderId="1" xfId="0" applyAlignment="1"><alignment horizontal="left" vertical="center"/></xf>
    <xf numFmtId="0" fontId="0" fillId="0" borderId="1" xfId="0" applyAlignment="1"><alignment horizontal="left" vertical="center" wrapText="1"/></xf>
    <xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0" applyAlignment="1"><alignment horizontal="center" vertical="center" wrapText="1"/></xf>
    <xf numFmtId="0" fontId="5" fillId="0" borderId="0" xfId="0" applyAlignment="1"><alignment horizontal="center" vertical="center" wrapText="1"/></xf>
    <xf numFmtId="49" fontId="0" fillId="0" borderId="1" xfId="0" applyNumberFormat="1" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf>
  </cellXfs>
  <cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles>
  <dxfs count="0"/>
  <tableStyles count="0" defaultTableStyle="TableStyleMedium2" defaultPivotStyle="PivotStyleLight16"/>
</styleSheet>`;
}

function estimateRowHeight(values: string[]): number {
  const [name, , , , birth, parent, address, keterangan] = values;
  const needsExtraLine =
    name.length > 32 ||
    birth.length > 32 ||
    parent.length > 28 ||
    address.length > 42 ||
    keterangan.length > 20;
  return needsExtraLine ? 40 : 30;
}

export async function renderStudentListWorkbook(
  input: StudentListDocumentInput
): Promise<Buffer> {
  if (input.students.length === 0) throw new Error("Tidak ada siswa untuk dibuat.");

  const title = studentListTitle(input.kind);
  const sheetName = studentListSheetName(input.kind);
  const sharedStrings: string[] = [];
  const sharedStringIndexes = new Map<string, number>();
  let sharedStringReferenceCount = 0;
  const stringCell = (reference: string, value: string, style: number): string => {
    sharedStringReferenceCount++;
    let index = sharedStringIndexes.get(value);
    if (index === undefined) {
      index = sharedStrings.length;
      sharedStrings.push(value);
      sharedStringIndexes.set(value, index);
    }
    return `<c r="${reference}" s="${style}" t="s"><v>${index}</v></c>`;
  };

  const headers = [
    "NO",
    "NAMA",
    "NIK",
    "JK",
    "KELAS",
    "TEMPAT, TANGGAL LAHIR",
    "NAMA ORANG TUA",
    "ALAMAT",
    "KETERANGAN",
  ];
  const widths = [5, 36, 21, 6, 10, 29, 25, 37, 18];
  const lastColumn = columnLetter(headers.length - 1);
  const signatureStartColumn = columnLetter(headers.length - 3);
  const dataStartRow = 6;
  const lastDataRow = dataStartRow + input.students.length - 1;
  const signatureRow = lastDataRow + 3;
  const finalRow = signatureRow + 6;

  const rows: string[] = [
    `<row r="1" ht="24" customHeight="1">${stringCell("A1", title, 1)}</row>`,
    `<row r="2" ht="22" customHeight="1">${stringCell("A2", input.schoolName.toUpperCase(), 2)}</row>`,
    `<row r="3" ht="20" customHeight="1">${stringCell("A3", `TAHUN ${input.year}`, 3)}</row>`,
    `<row r="4" ht="10" customHeight="1"/>`,
    `<row r="5" ht="40" customHeight="1">${headers
      .map((header, index) => stringCell(`${columnLetter(index)}5`, header, 4))
      .join("")}</row>`,
  ];

  input.students.forEach((student, index) => {
    const rowNumber = dataStartRow + index;
    const values = [
      student.name,
      student.nik ?? "",
      student.gender ?? "",
      student.className ?? "",
      formatStudentBirth(student.birthPlace, student.birthDate),
      student.parentName ?? "",
      student.address ?? "",
      input.keterangan,
    ];
    const cells = [numberCell(`A${rowNumber}`, index + 1, 5)];

    values.forEach((value, valueIndex) => {
      const column = valueIndex + 1;
      const style = column === 2 ? 10 : column === 3 || column === 4 ? 5 : 7;
      const reference = `${columnLetter(column)}${rowNumber}`;
      cells.push(
        column === 2 && /^\d+$/.test(value)
          ? stringCell(reference, `\u200B${value}`, style)
          : stringCell(reference, value, style)
      );
    });
    rows.push(
      `<row r="${rowNumber}" ht="${estimateRowHeight(values)}" customHeight="1">${cells.join("")}</row>`
    );
  });

  rows.push(
    `<row r="${signatureRow}">${stringCell(`${signatureStartColumn}${signatureRow}`, "Mengetahui,", 8)}</row>`,
    `<row r="${signatureRow + 1}">${stringCell(`${signatureStartColumn}${signatureRow + 1}`, input.kepalaJabatan || "Kepala Sekolah", 8)}</row>`,
    `<row r="${signatureRow + 2}" ht="18" customHeight="1"/>`,
    `<row r="${signatureRow + 3}" ht="18" customHeight="1"/>`,
    `<row r="${signatureRow + 4}" ht="18" customHeight="1"/>`,
    `<row r="${signatureRow + 5}" ht="18" customHeight="1"/>`,
    `<row r="${signatureRow + 6}">${stringCell(`${signatureStartColumn}${signatureRow + 6}`, input.kepalaName, 9)}</row>`
  );

  const mergeRanges = [
    `A1:${lastColumn}1`,
    `A2:${lastColumn}2`,
    `A3:${lastColumn}3`,
    `${signatureStartColumn}${signatureRow}:${lastColumn}${signatureRow}`,
    `${signatureStartColumn}${signatureRow + 1}:${lastColumn}${signatureRow + 1}`,
    `${signatureStartColumn}${signatureRow + 6}:${lastColumn}${signatureRow + 6}`,
  ];
  const columnsXml = widths
    .map(
      (width, index) =>
        `<col min="${index + 1}" max="${index + 1}" width="${width}" customWidth="1"/>`
    )
    .join("");

  const sheetXml = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
  <sheetPr><pageSetUpPr fitToPage="1"/></sheetPr>
  <dimension ref="A1:${lastColumn}${finalRow}"/>
  <sheetViews><sheetView showGridLines="0" workbookViewId="0"><pane ySplit="5" topLeftCell="A6" activePane="bottomLeft" state="frozen"/><selection pane="bottomLeft" activeCell="A6" sqref="A6"/></sheetView></sheetViews>
  <sheetFormatPr defaultRowHeight="15"/>
  <cols>${columnsXml}</cols>
  <sheetData>${rows.join("")}</sheetData>
  <mergeCells count="${mergeRanges.length}">${mergeRanges
    .map((range) => `<mergeCell ref="${range}"/>`)
    .join("")}</mergeCells>
  <printOptions horizontalCentered="1"/>
  <pageMargins left="0.2" right="0.2" top="0.35" bottom="0.35" header="0.15" footer="0.15"/>
  <pageSetup paperSize="9" orientation="landscape" fitToWidth="1" fitToHeight="0"/>
</worksheet>`;
  const sharedStringsXml = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<sst xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" count="${sharedStringReferenceCount}" uniqueCount="${sharedStrings.length}">${sharedStrings
    .map((value) => `<si><t xml:space="preserve">${escapeXml(value)}</t></si>`)
    .join("")}</sst>`;

  const timestamp = new Date().toISOString();
  const zip = new JSZip();
  zip.file(
    "[Content_Types].xml",
    `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
  <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
  <Default Extension="xml" ContentType="application/xml"/>
  <Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>
  <Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>
  <Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>
  <Override PartName="/xl/sharedStrings.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sharedStrings+xml"/>
  <Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/>
  <Override PartName="/docProps/app.xml" ContentType="application/vnd.openxmlformats-officedocument.extended-properties+xml"/>
</Types>`
  );
  zip.file(
    "_rels/.rels",
    `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>
  <Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/>
  <Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties" Target="docProps/app.xml"/>
</Relationships>`
  );
  zip.file(
    "docProps/core.xml",
    `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:dcterms="http://purl.org/dc/terms/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"><dc:title>${escapeXml(title)}</dc:title><dc:creator>SPM Generator</dc:creator><cp:lastModifiedBy>SPM Generator</cp:lastModifiedBy><dcterms:created xsi:type="dcterms:W3CDTF">${timestamp}</dcterms:created><dcterms:modified xsi:type="dcterms:W3CDTF">${timestamp}</dcterms:modified></cp:coreProperties>`
  );
  zip.file(
    "docProps/app.xml",
    `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Properties xmlns="http://schemas.openxmlformats.org/officeDocument/2006/extended-properties" xmlns:vt="http://schemas.openxmlformats.org/officeDocument/2006/docPropsVTypes"><Application>SPM Generator</Application><DocSecurity>0</DocSecurity><ScaleCrop>false</ScaleCrop><HeadingPairs><vt:vector size="2" baseType="variant"><vt:variant><vt:lpstr>Worksheets</vt:lpstr></vt:variant><vt:variant><vt:i4>1</vt:i4></vt:variant></vt:vector></HeadingPairs><TitlesOfParts><vt:vector size="1" baseType="lpstr"><vt:lpstr>${escapeXml(sheetName)}</vt:lpstr></vt:vector></TitlesOfParts><Company></Company><LinksUpToDate>false</LinksUpToDate><SharedDoc>false</SharedDoc><HyperlinksChanged>false</HyperlinksChanged><AppVersion>1.0</AppVersion></Properties>`
  );
  zip.file(
    "xl/workbook.xml",
    `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><bookViews><workbookView xWindow="0" yWindow="0" windowWidth="24000" windowHeight="12000"/></bookViews><sheets><sheet name="${escapeXml(sheetName)}" sheetId="1" r:id="rId1"/></sheets><definedNames><definedName name="_xlnm.Print_Area" localSheetId="0">'${escapeXml(sheetName)}'!$A$1:$${lastColumn}$${finalRow}</definedName><definedName name="_xlnm.Print_Titles" localSheetId="0">'${escapeXml(sheetName)}'!$1:$5</definedName></definedNames><calcPr calcId="0" fullCalcOnLoad="1"/></workbook>`
  );
  zip.file(
    "xl/_rels/workbook.xml.rels",
    `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/><Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/sharedStrings" Target="sharedStrings.xml"/></Relationships>`
  );
  zip.file("xl/styles.xml", workbookStylesXml());
  zip.file("xl/sharedStrings.xml", sharedStringsXml);
  zip.file("xl/worksheets/sheet1.xml", sheetXml);

  return zip.generateAsync({
    type: "nodebuffer",
    compression: "DEFLATE",
    compressionOptions: { level: 6 },
  });
}

