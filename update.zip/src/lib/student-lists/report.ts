import { monthName } from "@/lib/indonesian/months";

export type StudentListKind = "all" | "poor";
export type StudentListOutputFormat = "xlsx" | "pdf";

export interface StudentListRow {
  name: string;
  nik: string | null;
  gender: string | null;
  className: string | null;
  birthPlace: string | null;
  birthDate: Date | null;
  parentName: string | null;
  address: string | null;
}

export interface StudentListDocumentInput {
  kind: StudentListKind;
  schoolName: string;
  kepalaName: string;
  kepalaJabatan: string;
  year: number;
  keterangan: string;
  students: StudentListRow[];
}

export function studentListTitle(kind: StudentListKind): string {
  return kind === "poor" ? "DAFTAR SISWA MISKIN" : "DAFTAR SISWA";
}

export function studentListSheetName(kind: StudentListKind): string {
  return kind === "poor" ? "Daftar Siswa Miskin" : "Daftar Siswa";
}

export function formatStudentBirth(
  place: string | null,
  date: Date | null
): string {
  const dateText = date
    ? `${String(date.getUTCDate()).padStart(2, "0")} ${monthName(
        date.getUTCMonth() + 1
      )} ${date.getUTCFullYear()}`
    : "";
  return [place?.trim(), dateText].filter(Boolean).join(", ");
}

export function parseStudentListOutputFormat(
  value: FormDataEntryValue | null
): StudentListOutputFormat | null {
  return value === "xlsx" || value === "pdf" ? value : null;
}

