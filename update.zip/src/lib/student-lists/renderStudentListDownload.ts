import { renderStudentListPdf } from "@/lib/pdf-render/renderStudentListPdf";
import { renderStudentListWorkbook } from "./renderStudentListWorkbook";
import {
  studentListSheetName,
  type StudentListDocumentInput,
  type StudentListOutputFormat,
} from "./report";

const XLSX_MIME =
  "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";

export async function renderStudentListDownload(
  input: StudentListDocumentInput,
  format: StudentListOutputFormat
): Promise<{ buffer: Buffer; contentType: string; fileName: string }> {
  const buffer =
    format === "pdf"
      ? await renderStudentListPdf(input)
      : await renderStudentListWorkbook(input);
  const safeSchoolName =
    input.schoolName.replace(/[^a-z0-9]+/gi, "_").replace(/^_|_$/g, "") ||
    "Sekolah";
  const safeTitle = studentListSheetName(input.kind).replace(/\s+/g, "_");

  return {
    buffer,
    contentType: format === "pdf" ? "application/pdf" : XLSX_MIME,
    fileName: `${safeTitle}_${safeSchoolName}_${input.year}.${format}`,
  };
}

