import type { VendorRule } from "@/generated/prisma";
import { prisma } from "@/lib/db";

/**
 * Strips a trailing "(...)" (typically a NIK/account number, e.g.
 * "GALIH WIGUNAWATI (4361763664231063)") from a NAME_FROM_URAIAN row's
 * uraian, leaving just the person's name.
 */
export function extractNameFromUraian(uraian: string): string {
  return uraian.replace(/\s*\([^)]*\)\s*$/, "").trim();
}

/** A rule's `keyword` may hold several comma-separated alternatives. */
function keywordAlternatives(keyword: string): string[] {
  return keyword
    .split(",")
    .map((k) => k.trim().toLowerCase())
    .filter(Boolean);
}

/**
 * Does this rule match the given row? A rule matches when either:
 *  - any of its (comma-separated) keywords is a case-insensitive substring
 *    of the uraian, OR
 *  - its matchKodeKegiatan prefix matches the row's KODE KEGIATAN (used for
 *    honor guru, whose uraian is a bare person name).
 */
export function ruleMatchesRow(
  rule: VendorRule,
  uraian: string,
  kodeKegiatan: string | null
): boolean {
  if (!rule.isActive) return false;

  if (rule.matchKodeKegiatan && kodeKegiatan) {
    const normalized = kodeKegiatan.replace(/\.$/, "");
    const prefix = rule.matchKodeKegiatan.replace(/\.$/, "");
    if (normalized === prefix || normalized.startsWith(prefix + ".")) return true;
  }

  const haystack = uraian.toLowerCase();
  return keywordAlternatives(rule.keyword).some((k) => haystack.includes(k));
}

/** First active rule (by ascending priority) that matches the row. */
export function matchRow(
  uraian: string,
  kodeKegiatan: string | null,
  rules: VendorRule[]
): VendorRule | null {
  for (const rule of rules) {
    if (ruleMatchesRow(rule, uraian, kodeKegiatan)) return rule;
  }
  return null;
}

export interface MatchSummary {
  totalGroups: number;
  matched: number;
  unmatched: number;
  disagreements: string[]; // bpuCodes where rows matched different rules
}

/**
 * Runs keyword/kode-kegiatan matching for every BPUGroup in a given
 * BKUImport and persists the suggestion to BPUGroup.matchedVendorRuleId.
 * This is only ever a suggestion -- the review UI always lets the admin
 * confirm or override it before any SPM is generated.
 */
export async function runMatchingForImport(
  schoolId: string,
  bkuImportId: string
): Promise<MatchSummary> {
  const rules = await prisma.vendorRule.findMany({
    where: { schoolId, isActive: true },
    orderBy: { priority: "asc" },
  });

  const groups = await prisma.bPUGroup.findMany({ where: { bkuImportId } });

  const summary: MatchSummary = {
    totalGroups: groups.length,
    matched: 0,
    unmatched: 0,
    disagreements: [],
  };

  for (const group of groups) {
    const rows = await prisma.bKURow.findMany({
      where: { bkuImportId, bpuCode: group.bpuCode },
    });

    const rowMatches = rows.map((row) => matchRow(row.uraian, row.kodeKegiatan, rules));
    const matchedIds = new Set(
      rowMatches.filter((m): m is VendorRule => m !== null).map((m) => m.id)
    );

    let chosen: VendorRule | null = null;
    if (matchedIds.size === 1) {
      chosen = rowMatches.find((m) => m !== null) ?? null;
    } else if (matchedIds.size > 1) {
      chosen = rowMatches.find((m) => m !== null) ?? null;
      summary.disagreements.push(group.bpuCode);
    }

    if (chosen) summary.matched++;
    else summary.unmatched++;

    await prisma.bPUGroup.update({
      where: { id: group.id },
      data: { matchedVendorRuleId: chosen?.id ?? null },
    });
  }

  return summary;
}
