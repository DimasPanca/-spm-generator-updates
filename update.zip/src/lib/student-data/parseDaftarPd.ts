import JSZip from "jszip";

const MAX_ZIP_ENTRIES = 500;
const MAX_STUDENTS = 5_000;

export interface ParsedStudentRecord {
  sourceNumber: number | null;
  name: string;
  nik: string | null;
  gender: string | null;
  className: string | null;
  birthPlace: string | null;
  birthDate: Date | null;
  parentName: string | null;
  parentRelation: string | null;
  address: string | null;
  isPipEligible: boolean;
  pipReason: string | null;
}

export interface ParsedStudentRoster {
  sourceSchoolName: string | null;
  students: ParsedStudentRecord[];
  warnings: string[];
}

export class DaftarPdParseError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "DaftarPdParseError";
  }
}

function decodeXml(value: string): string {
  return value
    .replace(/&#(x[\da-f]+|\d+);/gi, (_match, code: string) => {
      const numeric = code.toLowerCase().startsWith("x")
        ? Number.parseInt(code.slice(1), 16)
        : Number.parseInt(code, 10);
      return Number.isFinite(numeric) ? String.fromCodePoint(numeric) : "";
    })
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&quot;/g, '"')
    .replace(/&apos;/g, "'")
    .replace(/&amp;/g, "&");
}

function attr(source: string, name: string): string | null {
  const match = new RegExp(`(?:^|\\s)${name}="([^"]*)"`).exec(source);
  return match ? decodeXml(match[1]) : null;
}

function visibleText(xml: string): string {
  return [...xml.matchAll(/<t(?:\s[^>]*)?>([\s\S]*?)<\/t>/g)]
    .map((match) => decodeXml(match[1]))
    .join("");
}

function normalizeHeader(value: string): string {
  return value
    .toLocaleLowerCase("id-ID")
    .replace(/[^a-z0-9]+/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function columnIndex(reference: string): number {
  const letters = /^[A-Z]+/i.exec(reference)?.[0].toUpperCase() ?? "";
  let value = 0;
  for (const letter of letters) value = value * 26 + letter.charCodeAt(0) - 64;
  return value - 1;
}

function parseSharedStrings(xml: string | null): string[] {
  if (!xml) return [];
  return [...xml.matchAll(/<si(?:\s[^>]*)?>([\s\S]*?)<\/si>/g)].map((match) =>
    visibleText(match[1])
  );
}

function parseCells(sheetXml: string, sharedStrings: string[]) {
  const rows = new Map<number, Map<number, string>>();

  for (const rowMatch of sheetXml.matchAll(/<row\b([^>]*)>([\s\S]*?)<\/row>/g)) {
    const rowNumber = Number(attr(rowMatch[1], "r"));
    if (!Number.isInteger(rowNumber) || rowNumber <= 0) continue;
    const cells = new Map<number, string>();

    for (const cellMatch of rowMatch[2].matchAll(/<c\b([^>]*?)(?:\/>|>([\s\S]*?)<\/c>)/g)) {
      const reference = attr(cellMatch[1], "r");
      if (!reference) continue;

      const type = attr(cellMatch[1], "t");
      const body = cellMatch[2] ?? "";
      const raw = /<v(?:\s[^>]*)?>([\s\S]*?)<\/v>/.exec(body)?.[1] ?? "";
      let value = "";

      if (type === "s") {
        const index = Number.parseInt(raw, 10);
        value = Number.isInteger(index) ? sharedStrings[index] ?? "" : "";
      } else if (type === "inlineStr") {
        value = visibleText(body);
      } else {
        value = decodeXml(raw);
      }

      cells.set(columnIndex(reference), value.trim());
    }

    rows.set(rowNumber, cells);
  }

  return rows;
}

function resolveFirstSheetPath(workbookXml: string, relationshipsXml: string): string {
  const sheetTag = /<sheet\b([^>]*)\/>/.exec(workbookXml)?.[1];
  const relationId = sheetTag ? attr(sheetTag, "r:id") : null;
  if (!relationId) throw new DaftarPdParseError("Sheet daftar peserta didik tidak ditemukan.");

  for (const match of relationshipsXml.matchAll(/<Relationship\b([^>]*)\/>/g)) {
    if (attr(match[1], "Id") !== relationId) continue;
    const target = attr(match[1], "Target");
    if (!target) break;
    if (target.startsWith("/")) return target.slice(1);
    return `xl/${target.replace(/^\.\//, "")}`.replace(/\\/g, "/");
  }

  throw new DaftarPdParseError("Relasi sheet daftar peserta didik tidak ditemukan.");
}

function parseDate(value: string): Date | null {
  const clean = value.trim();
  if (clean === "") return null;

  let match = /^(\d{4})-(\d{1,2})-(\d{1,2})/.exec(clean);
  if (match) {
    return new Date(Date.UTC(Number(match[1]), Number(match[2]) - 1, Number(match[3])));
  }

  match = /^(\d{1,2})[\/-](\d{1,2})[\/-](\d{4})$/.exec(clean);
  if (match) {
    return new Date(Date.UTC(Number(match[3]), Number(match[2]) - 1, Number(match[1])));
  }

  const serial = Number(clean);
  if (Number.isFinite(serial) && serial > 10_000 && serial < 100_000) {
    return new Date(Date.UTC(1899, 11, 30) + Math.round(serial) * 86_400_000);
  }

  return null;
}

function optional(value: string): string | null {
  const clean = value.trim();
  return clean === "" ? null : clean;
}

function normalizeClassName(value: string): string | null {
  const clean = value.replace(/^KELAS\s+/i, "").trim();
  return clean === "" ? null : clean;
}

function chooseParent(father: string, mother: string, guardian: string) {
  if (father.trim()) return { name: father.trim(), relation: "Ayah" };
  if (mother.trim()) return { name: mother.trim(), relation: "Ibu" };
  if (guardian.trim()) return { name: guardian.trim(), relation: "Wali" };
  return { name: null, relation: null };
}

export async function parseDaftarPdWorkbook(bytes: Uint8Array): Promise<ParsedStudentRoster> {
  if (bytes.length < 4 || bytes[0] !== 0x50 || bytes[1] !== 0x4b) {
    throw new DaftarPdParseError("File bukan workbook .xlsx yang valid.");
  }

  let zip: JSZip;
  try {
    zip = await JSZip.loadAsync(bytes);
  } catch {
    throw new DaftarPdParseError("File .xlsx rusak atau tidak dapat dibuka.");
  }

  if (Object.keys(zip.files).length > MAX_ZIP_ENTRIES) {
    throw new DaftarPdParseError("Isi workbook terlalu kompleks untuk diproses dengan aman.");
  }

  const workbookFile = zip.file("xl/workbook.xml");
  const relationshipFile = zip.file("xl/_rels/workbook.xml.rels");
  if (!workbookFile || !relationshipFile) {
    throw new DaftarPdParseError("Struktur workbook .xlsx tidak lengkap.");
  }

  const [workbookXml, relationshipsXml, sharedStringsXml] = await Promise.all([
    workbookFile.async("string"),
    relationshipFile.async("string"),
    zip.file("xl/sharedStrings.xml")?.async("string") ?? Promise.resolve(null),
  ]);

  const sheetPath = resolveFirstSheetPath(workbookXml, relationshipsXml);
  const sheetFile = zip.file(sheetPath);
  if (!sheetFile) throw new DaftarPdParseError("Data pada sheet pertama tidak ditemukan.");

  const sharedStrings = parseSharedStrings(sharedStringsXml);
  const rows = parseCells(await sheetFile.async("string"), sharedStrings);
  const sortedRows = [...rows.entries()].sort((a, b) => a[0] - b[0]);

  let headerRowNumber: number | null = null;
  let headerCells: Map<number, string> | null = null;
  for (const [rowNumber, cells] of sortedRows.slice(0, 20)) {
    const normalized = new Set([...cells.values()].map(normalizeHeader));
    const required = ["no", "nama", "jk", "tempat lahir", "tanggal lahir", "nik", "alamat"];
    if (required.every((label) => normalized.has(label))) {
      headerRowNumber = rowNumber;
      headerCells = cells;
      break;
    }
  }

  if (!headerCells || headerRowNumber === null) {
    throw new DaftarPdParseError(
      'Format tidak dikenali. Pastikan file berasal dari ekspor "Daftar Peserta Didik" (daftar_pd).'
    );
  }

  const findColumn = (label: string): number => {
    const expected = normalizeHeader(label);
    for (const [column, value] of headerCells!) {
      if (normalizeHeader(value) === expected) return column;
    }
    return -1;
  };

  const columns = {
    no: findColumn("No"),
    name: findColumn("Nama"),
    gender: findColumn("JK"),
    birthPlace: findColumn("Tempat Lahir"),
    birthDate: findColumn("Tanggal Lahir"),
    nik: findColumn("NIK"),
    address: findColumn("Alamat"),
    father: findColumn("Data Ayah"),
    mother: findColumn("Data Ibu"),
    guardian: findColumn("Data Wali"),
    className: findColumn("Rombel Saat Ini"),
    pipEligible: findColumn("Layak PIP (usulan dari sekolah)"),
    pipReason: findColumn("Alasan Layak PIP"),
  };

  if (Object.values(columns).slice(0, 11).some((column) => column < 0)) {
    throw new DaftarPdParseError("Ada kolom wajib daftar_pd yang tidak ditemukan.");
  }

  const get = (cells: Map<number, string>, column: number) =>
    column < 0 ? "" : cells.get(column) ?? "";

  const students: ParsedStudentRecord[] = [];
  for (const [rowNumber, cells] of sortedRows) {
    if (rowNumber <= headerRowNumber) continue;
    const sourceNumber = Number.parseInt(get(cells, columns.no), 10);
    const name = get(cells, columns.name).trim();
    if (!Number.isInteger(sourceNumber) || sourceNumber <= 0 || name === "") continue;

    const parent = chooseParent(
      get(cells, columns.father),
      get(cells, columns.mother),
      get(cells, columns.guardian)
    );
    const pipEligible = get(cells, columns.pipEligible).toLocaleLowerCase("id-ID") === "ya";

    students.push({
      sourceNumber,
      name,
      nik: optional(get(cells, columns.nik)),
      gender: optional(get(cells, columns.gender)),
      className: normalizeClassName(get(cells, columns.className)),
      birthPlace: optional(get(cells, columns.birthPlace)),
      birthDate: parseDate(get(cells, columns.birthDate)),
      parentName: parent.name,
      parentRelation: parent.relation,
      address: optional(get(cells, columns.address)),
      isPipEligible: pipEligible,
      pipReason: optional(get(cells, columns.pipReason)),
    });

    if (students.length > MAX_STUDENTS) {
      throw new DaftarPdParseError(`Jumlah siswa melebihi batas aman ${MAX_STUDENTS} baris.`);
    }
  }

  if (students.length === 0) {
    throw new DaftarPdParseError("Tidak ada data siswa yang terbaca dari workbook ini.");
  }

  const sourceSchoolName = optional(rows.get(2)?.get(0) ?? "");
  const warnings: string[] = [];
  const missingNik = students.filter((student) => !student.nik).length;
  const missingParent = students.filter((student) => !student.parentName).length;
  if (missingNik > 0) warnings.push(`${missingNik} siswa tidak memiliki NIK.`);
  if (missingParent > 0) warnings.push(`${missingParent} siswa tidak memiliki nama Ayah/Ibu/Wali.`);

  return { sourceSchoolName, students, warnings };
}
