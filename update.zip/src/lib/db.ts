import path from "node:path";
import { PrismaClient } from "@/generated/prisma";
import { PrismaBetterSqlite3 } from "@prisma/adapter-better-sqlite3";

const globalForPrisma = globalThis as unknown as {
  prisma: PrismaClient | undefined;
  prismaSchemaVersion: string | undefined;
};

// Bump this whenever a Prisma migration changes the generated client. In
// development, Turbopack can hot-reload application code while retaining the
// old global client; the version prevents that stale runtime schema from being
// reused after a migration.
const PRISMA_SCHEMA_VERSION = "20260826160000";

function createPrismaClient() {
  const adapter = new PrismaBetterSqlite3({
    url: path.join(process.cwd(), "dev.db"),
  });
  return new PrismaClient({ adapter });
}

export const prisma =
  globalForPrisma.prismaSchemaVersion === PRISMA_SCHEMA_VERSION && globalForPrisma.prisma
    ? globalForPrisma.prisma
    : createPrismaClient();

if (process.env.NODE_ENV !== "production") {
  globalForPrisma.prisma = prisma;
  globalForPrisma.prismaSchemaVersion = PRISMA_SCHEMA_VERSION;
}
