import type { BKURow, BPUGroup, School, VendorRule } from "@/generated/prisma";
import { computeGroupFields } from "@/lib/spm/paymentFormatter";
import { buildNomorSurat, formatFullIndonesianDate } from "@/lib/spm/nomorSurat";
import { amountToTerbilang } from "@/lib/terbilang/terbilang";
import type { SpmTemplateData } from "@/templates/spm";

export type GroupWithRule = BPUGroup & { matchedVendorRule: VendorRule | null };

/**
 * Single source of truth for turning a confirmed BPU group into the data an
 * SPM letter renders from. Used by both the per-file generator and the
 * combined "SPM Keseluruhan" document so the two can never drift apart.
 */
export function buildSpmTemplateData(
  school: School,
  group: GroupWithRule,
  rows: Pick<BKURow, "uraian">[],
  logos: { schoolLogo: Buffer | null; regionalLogo: Buffer | null }
): SpmTemplateData {
  const computed = computeGroupFields(rows, group.matchedVendorRule);

  return {
    schoolName: school.name,
    kopHeaderLine: school.kopHeaderLine,
    schoolAddress: school.address,
    schoolContact: school.contact,
    schoolNpsn: school.npsn,
    schoolLogo: logos.schoolLogo,
    regionalLogo: logos.regionalLogo,
    openingSentence: school.openingSentenceTemplate.replace(
      "{institutionName}",
      school.name
    ),
    atasDasarLine1: school.atasDasarLine1,
    atasDasarLine2: school.atasDasarLine2,
    kepalaJabatan: school.kepalaJabatan,
    kepalaName: school.kepalaName,
    nomorSurat: buildNomorSurat(group.bpuNumber, school.formatCode, group.tanggal),
    amountFormatted: `Rp. ${group.totalAmount.toLocaleString("id-ID")}`,
    terbilang: amountToTerbilang(group.totalAmount),
    recipient: group.overrideRecipient ?? computed.recipient,
    paymentFor: group.overridePaymentFor ?? computed.paymentFor,
    mengetahuiDate: formatFullIndonesianDate(group.tanggal),
  };
}
