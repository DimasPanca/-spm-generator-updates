import type { BKURow, VendorRule } from "@/generated/prisma";
import { extractNameFromUraian } from "@/lib/matching/vendorMatcher";

export interface ComputedFields {
  recipient: string;
  paymentFor: string;
}

const MAX_LISTED_ITEMS = 5;

/** BKU uraian text often ends in a trailing "--" placeholder artifact from the source ledger. */
function cleanUraian(uraian: string): string {
  return uraian.replace(/-+\s*$/, "").trim();
}

function joinList(items: string[]): string {
  if (items.length <= MAX_LISTED_ITEMS) return items.join(", ");
  return items.slice(0, MAX_LISTED_ITEMS).join(", ") + ", dan lain-lain";
}

/**
 * Computes "Kepada" (recipient) and "Untuk Pembayaran" (paymentFor) for a
 * BPU group, given its constituent BKU rows and the vendor rule chosen for
 * it (matched automatically or picked manually in review -- this function
 * doesn't care which).
 *
 * Ported from the CreateSPM logic in the PKBM ABDI PERTIWI VBA workbook:
 * - STANDARD, exactly one distinct uraian: paymentFor is that uraian text
 *   verbatim (not the vendor's payment prefix).
 * - STANDARD, multiple distinct uraian: paymentFor is "{prefix} (uraian1,
 *   uraian2, ...)", capped at 5 items then "dan lain-lain".
 * - NAME_FROM_URAIAN (e.g. honor/tutor payments): the uraian values ARE
 *   people's names; recipient is the joined name list, paymentFor is always
 *   just the prefix as-is.
 */
export function computeGroupFields(
  rows: Pick<BKURow, "uraian">[],
  rule: VendorRule | null
): ComputedFields {
  const distinctUraian = [
    ...new Set(rows.map((r) => cleanUraian(r.uraian)).filter(Boolean)),
  ];

  if (!rule) {
    return { recipient: "", paymentFor: joinList(distinctUraian) };
  }

  if (rule.formatType === "NAME_FROM_URAIAN") {
    const names = [
      ...new Set(rows.map((r) => extractNameFromUraian(r.uraian)).filter(Boolean)),
    ];
    return {
      recipient: names.length === 0 ? "" : joinList(names),
      paymentFor: rule.paymentPrefix,
    };
  }

  // STANDARD
  let paymentFor: string;
  if (distinctUraian.length === 0) {
    paymentFor = rule.paymentPrefix;
  } else if (distinctUraian.length === 1) {
    paymentFor = distinctUraian[0];
  } else {
    paymentFor = `${rule.paymentPrefix} (${joinList(distinctUraian)})`;
  }

  return { recipient: rule.recipient, paymentFor };
}
