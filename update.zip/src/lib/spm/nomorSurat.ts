import { monthToRoman, monthName } from "@/lib/indonesian/months";

/** e.g. bpuNumber=32, formatCode="SPM.PKBM-AP", tanggal=2026-01-30 -> "32/SPM.PKBM-AP/I/2026". */
export function buildNomorSurat(
  bpuNumber: number,
  formatCode: string,
  tanggal: Date
): string {
  const month = tanggal.getUTCMonth() + 1;
  const year = tanggal.getUTCFullYear();
  return `${bpuNumber}/${formatCode}/${monthToRoman(month)}/${year}`;
}

/** e.g. 2026-01-30 -> "30 Januari 2026", for the "Mengetahui {date}" signature line. */
export function formatFullIndonesianDate(date: Date): string {
  const day = date.getUTCDate();
  const month = monthName(date.getUTCMonth() + 1);
  const year = date.getUTCFullYear();
  return `${day} ${month} ${year}`;
}
