import { mkdtemp, writeFile, readFile, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import path from "node:path";
import { spawn } from "node:child_process";

/**
 * Converts a .docx to PDF using the copy of Microsoft Word already installed
 * on the machine.
 *
 * The instrument is filled by editing the government's own .docx, so the only
 * way to get a PDF that still looks exactly like that form is to let Word lay
 * it out. Redrawing a six-page form in a PDF library would drift from the
 * template the moment the dinas changes it.
 *
 * Word is not always present -- a school that only ever prints from Word
 * still gets the .docx -- so a missing installation is reported as a normal
 * outcome rather than a crash.
 */
export class WordNotAvailableError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "WordNotAvailableError";
  }
}

const WD_EXPORT_FORMAT_PDF = 17;

function runPowerShell(script: string, timeoutMs: number): Promise<{ code: number; stderr: string }> {
  return new Promise((resolve, reject) => {
    const child = spawn(
      "powershell.exe",
      ["-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-Command", script],
      { windowsHide: true }
    );

    let stderr = "";
    child.stderr.on("data", (chunk) => {
      stderr += String(chunk);
    });

    const timer = setTimeout(() => {
      child.kill();
      reject(new Error("Konversi PDF timeout -- Microsoft Word tidak merespons."));
    }, timeoutMs);

    child.on("error", reject);
    child.on("close", (code) => {
      clearTimeout(timer);
      resolve({ code: code ?? 1, stderr });
    });
  });
}

export async function convertDocxToPdf(docxBuffer: Buffer): Promise<Buffer> {
  if (process.platform !== "win32") {
    throw new WordNotAvailableError(
      "Konversi ke PDF hanya tersedia di Windows dengan Microsoft Word terpasang."
    );
  }

  const dir = await mkdtemp(path.join(tmpdir(), "spmgen-docx-"));
  const inPath = path.join(dir, "input.docx");
  const outPath = path.join(dir, "output.pdf");

  try {
    await writeFile(inPath, docxBuffer);

    // Word is driven read-only and with alerts off so it can never block on a
    // dialog; the finally block quits it even when the export throws.
    const script = `
$ErrorActionPreference = 'Stop'
try { $word = New-Object -ComObject Word.Application } catch { Write-Error 'WORD_NOT_INSTALLED'; exit 2 }
$word.Visible = $false
$word.DisplayAlerts = 0
try {
  $doc = $word.Documents.Open('${inPath.replace(/'/g, "''")}', $false, $true)
  $doc.ExportAsFixedFormat('${outPath.replace(/'/g, "''")}', ${WD_EXPORT_FORMAT_PDF})
  $doc.Close(0)
} finally {
  $word.Quit()
  [System.Runtime.InteropServices.Marshal]::ReleaseComObject($word) | Out-Null
}
`.trim();

    const { code, stderr } = await runPowerShell(script, 180_000);

    if (code === 2 || /WORD_NOT_INSTALLED/.test(stderr)) {
      throw new WordNotAvailableError(
        "Microsoft Word tidak ditemukan di komputer ini, jadi PDF tidak bisa dibuat otomatis. " +
          "Unduh versi DOCX-nya, buka di Word, lalu simpan sebagai PDF."
      );
    }
    if (code !== 0) {
      throw new Error(`Word gagal mengonversi ke PDF: ${stderr.trim() || `exit ${code}`}`);
    }

    return await readFile(outPath);
  } finally {
    await rm(dir, { recursive: true, force: true });
  }
}
