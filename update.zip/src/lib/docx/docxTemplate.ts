import JSZip from "jszip";

/**
 * Minimal DOCX template filler.
 *
 * The BOSP instrument is a fixed government form, so rather than redrawing it
 * we open the real .docx and write values into it. That keeps the output
 * byte-for-byte identical to the template in every respect we don't touch --
 * fonts, borders, checkbox glyphs, signature blocks, page breaks.
 *
 * Cells are addressed structurally as (table, row, cell) rather than by
 * searching for their text: Word splits a single visible phrase across many
 * <w:r> runs (revision ids, spell-check markers), so text search is
 * unreliable, while the table grid never moves.
 */

const TABLE_OPEN = /<w:tbl(?:\s[^>]*)?>/;
const ROW_OPEN = /<w:tr(?:\s[^>]*)?>/;
const CELL_OPEN = /<w:tc(?:\s[^>]*)?>/;

interface Span {
  start: number;
  end: number;
}

function escapeXml(value: string): string {
  return value
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&apos;");
}

/**
 * Indexes every table/row/cell span in the document by walking the tag
 * stream. Rebuilt after each mutation so offsets never go stale.
 */
function indexCells(xml: string): Map<string, Span> {
  const map = new Map<string, Span>();
  const re =
    /<w:tbl(?:\s[^>]*)?>|<\/w:tbl>|<w:tr(?:\s[^>]*)?>|<\/w:tr>|<w:tc(?:\s[^>]*)?>|<\/w:tc>/g;

  const stack: { tbl: number; row: number; cell: number }[] = [];
  let tbl = -1;
  let row = -1;
  let cell = -1;
  let cellStart = -1;
  let m: RegExpExecArray | null;

  while ((m = re.exec(xml)) !== null) {
    const tag = m[0];
    if (TABLE_OPEN.test(tag) && !tag.startsWith("</")) {
      stack.push({ tbl, row, cell });
      tbl++;
      row = -1;
    } else if (tag === "</w:tbl>") {
      const prev = stack.pop();
      if (prev) {
        row = prev.row;
        cell = prev.cell;
      }
    } else if (ROW_OPEN.test(tag) && !tag.startsWith("</")) {
      row++;
      cell = -1;
    } else if (CELL_OPEN.test(tag) && !tag.startsWith("</")) {
      cell++;
      cellStart = m.index;
    } else if (tag === "</w:tc>") {
      map.set(`${tbl}:${row}:${cell}`, { start: cellStart, end: m.index + tag.length });
    }
  }

  return map;
}

/** Byte span of one whole <w:tr>…</w:tr>, used for row cloning. */
function findRowSpan(xml: string, table: number, row: number): Span | null {
  const re =
    /<w:tbl(?:\s[^>]*)?>|<\/w:tbl>|<w:tr(?:\s[^>]*)?>|<\/w:tr>/g;
  const stack: { tbl: number; row: number }[] = [];
  let tbl = -1;
  let cur = -1;
  let rowStart = -1;
  let m: RegExpExecArray | null;

  while ((m = re.exec(xml)) !== null) {
    const tag = m[0];
    if (TABLE_OPEN.test(tag) && !tag.startsWith("</")) {
      stack.push({ tbl, row: cur });
      tbl++;
      cur = -1;
    } else if (tag === "</w:tbl>") {
      const prev = stack.pop();
      if (prev) cur = prev.row;
    } else if (ROW_OPEN.test(tag) && !tag.startsWith("</")) {
      cur++;
      rowStart = m.index;
    } else if (tag === "</w:tr>") {
      if (tbl === table && cur === row) {
        return { start: rowStart, end: m.index + tag.length };
      }
    }
  }
  return null;
}

export class DocxTemplate {
  private xml: string;

  private constructor(
    private zip: JSZip,
    xml: string
  ) {
    this.xml = xml;
  }

  static async load(buffer: Buffer): Promise<DocxTemplate> {
    const zip = await JSZip.loadAsync(buffer);
    const file = zip.file("word/document.xml");
    if (!file) throw new Error("word/document.xml tidak ditemukan di template.");
    return new DocxTemplate(zip, await file.async("string"));
  }

  private cellSpan(table: number, row: number, cell: number): Span {
    const span = indexCells(this.xml).get(`${table}:${row}:${cell}`);
    if (!span) {
      throw new Error(`Sel T${table} R${row} C${cell} tidak ada di template.`);
    }
    return span;
  }

  private splice(span: Span, replacement: string) {
    this.xml = this.xml.slice(0, span.start) + replacement + this.xml.slice(span.end);
  }

  /**
   * Writes text into a table cell.
   *
   * A cell that already has text keeps its first run (and therefore its exact
   * font) with the text swapped; the remaining runs are emptied. An empty cell
   * has no run to borrow from, so a new one is built using the run properties
   * Word stores on the paragraph mark (<w:pPr><w:rPr>) -- that is what the
   * cell's text would have been formatted with had anyone typed into it.
   */
  setCell(table: number, row: number, cell: number, text: string) {
    const span = this.cellSpan(table, row, cell);
    let inner = this.xml.slice(span.start, span.end);

    const value = escapeXml(text);
    const textTags = [...inner.matchAll(/<w:t(?:\s[^>]*)?>[\s\S]*?<\/w:t>/g)];

    if (textTags.length > 0) {
      // Replace back-to-front so earlier match offsets stay valid.
      for (let i = textTags.length - 1; i >= 1; i--) {
        const t = textTags[i];
        inner =
          inner.slice(0, t.index!) +
          '<w:t xml:space="preserve"></w:t>' +
          inner.slice(t.index! + t[0].length);
      }
      const first = textTags[0];
      inner =
        inner.slice(0, first.index!) +
        `<w:t xml:space="preserve">${value}</w:t>` +
        inner.slice(first.index! + first[0].length);
    } else {
      const paraEnd = inner.indexOf("</w:p>");
      if (paraEnd === -1) throw new Error(`Sel T${table} R${row} C${cell} tidak punya paragraf.`);

      const pPrMatch = /<w:pPr>[\s\S]*?<\/w:pPr>/.exec(inner);
      const rPrMatch = pPrMatch ? /<w:rPr>[\s\S]*?<\/w:rPr>/.exec(pPrMatch[0]) : null;
      const rPr = rPrMatch ? rPrMatch[0] : "";
      const run = `<w:r>${rPr}<w:t xml:space="preserve">${value}</w:t></w:r>`;

      const insertAt = pPrMatch ? pPrMatch.index! + pPrMatch[0].length : inner.indexOf(">", inner.indexOf("<w:p")) + 1;
      inner = inner.slice(0, insertAt) + run + inner.slice(insertAt);
    }

    this.splice(span, inner);
  }

  /** Reads a cell's visible text -- used by tests to verify a fill landed. */
  getCellText(table: number, row: number, cell: number): string {
    const span = this.cellSpan(table, row, cell);
    const inner = this.xml.slice(span.start, span.end);
    return [...inner.matchAll(/<w:t(?:\s[^>]*)?>([\s\S]*?)<\/w:t>/g)]
      .map((m) => m[1])
      .join("")
      .replace(/&amp;/g, "&")
      .replace(/&lt;/g, "<")
      .replace(/&gt;/g, ">")
      .replace(/&quot;/g, '"')
      .replace(/&apos;/g, "'");
  }

  /**
   * Ticks the `optionIndex`-th checkbox inside a cell (0-based), leaving the
   * others empty. Used for "☐ Ya ☐ Tidak" style cells.
   */
  tickCheckboxInCell(table: number, row: number, cell: number, optionIndex: number) {
    const span = this.cellSpan(table, row, cell);
    let inner = this.xml.slice(span.start, span.end);

    let seen = -1;
    inner = inner.replace(/☐/g, () => {
      seen++;
      return seen === optionIndex ? "☒" : "☐";
    });

    this.splice(span, inner);
  }

  /**
   * Replaces a dot-leader placeholder line ("…………") inside a cell, leaving the
   * cell's other paragraphs untouched. Signature blocks are a single cell
   * holding a label, blank spacer lines, the signing line, and "NIP." -- so
   * overwriting the whole cell would flatten the block.
   */
  setDottedLineInCell(table: number, row: number, cell: number, text: string, occurrence = 0) {
    const span = this.cellSpan(table, row, cell);
    let inner = this.xml.slice(span.start, span.end);

    const paras = [...inner.matchAll(/<w:p(?:\s[^>]*)?>[\s\S]*?<\/w:p>/g)];
    let seen = -1;

    for (const para of paras) {
      const paraXml = para[0];
      const textTags = [...paraXml.matchAll(/<w:t(?:\s[^>]*)?>([\s\S]*?)<\/w:t>/g)];
      if (textTags.length === 0) continue;

      const full = textTags.map((t) => t[1]).join("").trim();
      // Dot leaders only -- never the "NIP. ……" line, which carries a label.
      if (full === "" || !/^[….]+$/.test(full)) continue;

      seen++;
      if (seen !== occurrence) continue;

      let updated = paraXml;
      for (let j = textTags.length - 1; j >= 1; j--) {
        const t = textTags[j];
        updated =
          updated.slice(0, t.index!) +
          '<w:t xml:space="preserve"></w:t>' +
          updated.slice(t.index! + t[0].length);
      }
      const first = textTags[0];
      updated =
        updated.slice(0, first.index!) +
        `<w:t xml:space="preserve">${escapeXml(text)}</w:t>` +
        updated.slice(first.index! + first[0].length);

      inner = inner.slice(0, para.index!) + updated + inner.slice(para.index! + paraXml.length);
      this.splice(span, inner);
      return;
    }
  }

  /** Duplicates a table row `copies` times, inserting the copies after it. */
  cloneRow(table: number, row: number, copies: number) {
    if (copies <= 0) return;
    const span = findRowSpan(this.xml, table, row);
    if (!span) throw new Error(`Baris T${table} R${row} tidak ada di template.`);

    const rowXml = this.xml.slice(span.start, span.end);
    // Word tolerates duplicated paraId/textId, but stripping them avoids
    // "repaired document" warnings on stricter readers.
    const cleaned = rowXml
      .replace(/\sw14:paraId="[^"]*"/g, "")
      .replace(/\sw14:textId="[^"]*"/g, "");

    this.xml =
      this.xml.slice(0, span.end) + cleaned.repeat(copies) + this.xml.slice(span.end);
  }

  /**
   * Replaces a run of visible text that may be split across several runs.
   * Word fragments paragraphs, so the search is done on the concatenated
   * text of one paragraph, then written back into that paragraph's first run.
   */
  replaceInParagraph(contains: string, replacer: (fullText: string) => string) {
    const paras = [...this.xml.matchAll(/<w:p(?:\s[^>]*)?>[\s\S]*?<\/w:p>/g)];

    for (let i = paras.length - 1; i >= 0; i--) {
      const para = paras[i];
      const paraXml = para[0];
      const textTags = [...paraXml.matchAll(/<w:t(?:\s[^>]*)?>([\s\S]*?)<\/w:t>/g)];
      if (textTags.length === 0) continue;

      const fullText = textTags
        .map((t) => t[1])
        .join("")
        .replace(/&amp;/g, "&")
        .replace(/&lt;/g, "<")
        .replace(/&gt;/g, ">");

      if (!fullText.includes(contains)) continue;

      const replaced = replacer(fullText);
      if (replaced === fullText) continue;

      let updated = paraXml;
      for (let j = textTags.length - 1; j >= 1; j--) {
        const t = textTags[j];
        updated =
          updated.slice(0, t.index!) +
          '<w:t xml:space="preserve"></w:t>' +
          updated.slice(t.index! + t[0].length);
      }
      const first = textTags[0];
      updated =
        updated.slice(0, first.index!) +
        `<w:t xml:space="preserve">${escapeXml(replaced)}</w:t>` +
        updated.slice(first.index! + first[0].length);

      this.xml = this.xml.slice(0, para.index!) + updated + this.xml.slice(para.index! + paraXml.length);
    }
  }

  /**
   * Same as replaceInParagraph but targets only the `index`-th match in
   * document order -- for repeated placeholders like the three "Nama : ……"
   * lines that name the kepala, bendahara and komite in turn.
   */
  replaceParagraphAt(contains: string, index: number, replacer: (fullText: string) => string) {
    const paras = [...this.xml.matchAll(/<w:p(?:\s[^>]*)?>[\s\S]*?<\/w:p>/g)];
    let seen = -1;

    for (const para of paras) {
      const paraXml = para[0];
      const textTags = [...paraXml.matchAll(/<w:t(?:\s[^>]*)?>([\s\S]*?)<\/w:t>/g)];
      if (textTags.length === 0) continue;

      const fullText = textTags
        .map((t) => t[1])
        .join("")
        .replace(/&amp;/g, "&")
        .replace(/&lt;/g, "<")
        .replace(/&gt;/g, ">");

      if (!fullText.includes(contains)) continue;
      seen++;
      if (seen !== index) continue;

      const replaced = replacer(fullText);
      if (replaced === fullText) return;

      let updated = paraXml;
      for (let j = textTags.length - 1; j >= 1; j--) {
        const t = textTags[j];
        updated =
          updated.slice(0, t.index!) +
          '<w:t xml:space="preserve"></w:t>' +
          updated.slice(t.index! + t[0].length);
      }
      const first = textTags[0];
      updated =
        updated.slice(0, first.index!) +
        `<w:t xml:space="preserve">${escapeXml(replaced)}</w:t>` +
        updated.slice(first.index! + first[0].length);

      this.xml =
        this.xml.slice(0, para.index!) + updated + this.xml.slice(para.index! + paraXml.length);
      return;
    }
  }

  /**
   * Rebuilds the first paragraph whose visible text contains `contains` as one
   * or more lines separated by a soft line break, all sharing the first run's
   * formatting. Used for a KOP title where a small "type" line sits above the
   * bold institution name inside a single centered paragraph.
   */
  setParagraphLines(contains: string, lines: string[]) {
    const paras = [...this.xml.matchAll(/<w:p(?:\s[^>]*)?>[\s\S]*?<\/w:p>/g)];
    for (const para of paras) {
      const paraXml = para[0];
      const runs = [...paraXml.matchAll(/<w:r(?:\s[^>]*)?>[\s\S]*?<\/w:r>/g)];
      if (runs.length === 0) continue;

      const fullText = [...paraXml.matchAll(/<w:t(?:\s[^>]*)?>([\s\S]*?)<\/w:t>/g)]
        .map((t) => t[1])
        .join("")
        .replace(/&amp;/g, "&");
      if (!fullText.includes(contains)) continue;

      // Borrow the first run's run-properties so weight/size/font carry over.
      const rPr = /<w:rPr>[\s\S]*?<\/w:rPr>/.exec(runs[0][0]);
      const rPrXml = rPr ? rPr[0] : "";
      const body = lines
        .map(
          (line, i) =>
            (i > 0 ? `<w:r>${rPrXml}<w:br/></w:r>` : "") +
            `<w:r>${rPrXml}<w:t xml:space="preserve">${escapeXml(line)}</w:t></w:r>`
        )
        .join("");

      // Keep the paragraph's <w:pPr> (alignment etc.), swap only the runs.
      const pPr = /<w:pPr>[\s\S]*?<\/w:pPr>/.exec(paraXml);
      const openTag = /^<w:p(?:\s[^>]*)?>/.exec(paraXml)![0];
      const rebuilt = `${openTag}${pPr ? pPr[0] : ""}${body}</w:p>`;

      this.xml = this.xml.slice(0, para.index!) + rebuilt + this.xml.slice(para.index! + paraXml.length);
      return;
    }
  }

  /** Replaces a bundled media file (e.g. word/media/image1.png) with new
   *  bytes, keeping the same name so existing relationships still resolve. */
  replaceMedia(name: string, data: Buffer) {
    this.zip.file(`word/media/${name}`, data);
  }

  /**
   * Rewrites the label side of a `Label : value` line so labels align in a
   * column and the colon sits at a fixed tab stop. The paragraph's own pPr /
   * numbering / indent is preserved -- only the runs and the tab-stop list
   * are swapped. Font size is Times New Roman 12pt to match the template.
   */
  setLabelColonLine(contains: string, label: string, value: string, tabTwips = 1080, all = false) {
    const paras = [...this.xml.matchAll(/<w:p(?:\s[^>]*)?>[\s\S]*?<\/w:p>/g)];
    // Rewrite back-to-front so earlier match offsets stay valid when `all`.
    const iter = all ? [...paras].reverse() : paras;
    for (const para of iter) {
      const paraXml = para[0];
      const fullText = [...paraXml.matchAll(/<w:t(?:\s[^>]*)?>([\s\S]*?)<\/w:t>/g)]
        .map((t) => t[1]).join("")
        .replace(/&amp;/g, "&").replace(/&lt;/g, "<").replace(/&gt;/g, ">");
      if (!fullText.includes(contains)) continue;

      const openTag = /^<w:p(?:\s[^>]*)?>/.exec(paraXml)![0];
      const pPrMatch = /<w:pPr>[\s\S]*?<\/w:pPr>/.exec(paraXml);
      let pPr = pPrMatch ? pPrMatch[0] : "<w:pPr></w:pPr>";
      // Drop any existing <w:tabs> so our single left tab stop is authoritative
      pPr = pPr.replace(/<w:tabs>[\s\S]*?<\/w:tabs>/, "");
      const tabs = `<w:tabs><w:tab w:val="left" w:pos="${tabTwips}"/></w:tabs>`;
      pPr = pPr.replace(/<w:pPr>/, `<w:pPr>${tabs}`);

      const runFmt = `<w:rPr><w:rFonts w:ascii="Times New Roman" w:hAnsi="Times New Roman" w:cs="Times New Roman"/><w:sz w:val="24"/><w:szCs w:val="24"/></w:rPr>`;
      const runs =
        `<w:r>${runFmt}<w:t xml:space="preserve">${escapeXml(label)}</w:t></w:r>` +
        `<w:r>${runFmt}<w:tab/><w:t xml:space="preserve">: ${escapeXml(value)}</w:t></w:r>`;

      const rebuilt = `${openTag}${pPr}${runs}</w:p>`;
      this.xml = this.xml.slice(0, para.index!) + rebuilt + this.xml.slice(para.index! + paraXml.length);
      if (!all) return;
    }
  }

  /**
   * Rewrites every signature-name paragraph (name1 <tabs> name2) so the
   * underline sits only under the letters, not under the connecting tabs.
   * Matches paragraphs whose visible text (with a small tolerance for
   * whitespace) equals `oldName1 + oldName2` or vice versa. Sig blocks in
   * the template repeat 6× across pages.
   */
  rewriteSignatureNamePairs(oldName1: string, oldName2: string, newLeft: string, newRight: string) {
    const paras = [...this.xml.matchAll(/<w:p(?:\s[^>]*)?>[\s\S]*?<\/w:p>/g)];
    for (let i = paras.length - 1; i >= 0; i--) {
      const para = paras[i];
      const paraXml = para[0];
      const fullText = [...paraXml.matchAll(/<w:t(?:\s[^>]*)?>([\s\S]*?)<\/w:t>/g)]
        .map((t) => t[1]).join("");
      const flat = fullText.replace(/\s+/g, "");
      const glued1 = (oldName1 + oldName2).replace(/\s+/g, "");
      const glued2 = (oldName2 + oldName1).replace(/\s+/g, "");
      if (flat !== glued1 && flat !== glued2) continue;

      const [left, right] = flat === glued1 ? [newLeft, newRight] : [newRight, newLeft];
      const openTag = /^<w:p(?:\s[^>]*)?>/.exec(paraXml)![0];
      const pPrMatch = /<w:pPr>[\s\S]*?<\/w:pPr>/.exec(paraXml);
      const pPr = pPrMatch ? pPrMatch[0] : "";

      const under = `<w:rPr><w:rFonts w:ascii="Times New Roman" w:hAnsi="Times New Roman" w:cs="Times New Roman"/><w:sz w:val="24"/><w:szCs w:val="24"/><w:u w:val="single"/></w:rPr>`;
      const plain = `<w:rPr><w:rFonts w:ascii="Times New Roman" w:hAnsi="Times New Roman" w:cs="Times New Roman"/><w:sz w:val="24"/><w:szCs w:val="24"/></w:rPr>`;
      const runs =
        `<w:r>${under}<w:t xml:space="preserve">${escapeXml(left)}</w:t></w:r>` +
        `<w:r>${plain}<w:tab/><w:tab/><w:tab/><w:tab/></w:r>` +
        `<w:r>${under}<w:t xml:space="preserve">${escapeXml(right)}</w:t></w:r>`;
      const rebuilt = `${openTag}${pPr}${runs}</w:p>`;
      this.xml = this.xml.slice(0, para.index!) + rebuilt + this.xml.slice(para.index! + paraXml.length);
    }
  }

  /** Full visible text of the document -- for verification in tests. */
  getFullText(): string {
    return [...this.xml.matchAll(/<w:t(?:\s[^>]*)?>([\s\S]*?)<\/w:t>/g)]
      .map((m) => m[1])
      .join(" ");
  }

  async toBuffer(): Promise<Buffer> {
    this.zip.file("word/document.xml", this.xml);
    return this.zip.generateAsync({
      type: "nodebuffer",
      compression: "DEFLATE",
      compressionOptions: { level: 6 },
    });
  }
}
