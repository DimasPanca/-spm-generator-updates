import { prisma } from "@/lib/db";
import { parseRkasPdf } from "@/lib/pdf-parse/rkasParser";

export interface PersistedRkas {
  rkasImportId: string;
  programCount: number;
  itemCount: number;
  totalAmount: number;
  warnings: string[];
}

export class RkasImportError extends Error {}

/**
 * Parses one RKAS PDF and stores it with all of its kode program and items.
 * Kept out of the "use server" module so scripts and tests can call it
 * without a Next.js request context.
 */
export async function parseAndStoreRkas(
  schoolId: string,
  fileName: string,
  pdfBytes: Uint8Array
): Promise<PersistedRkas> {
  const rkas = await parseRkasPdf(pdfBytes);

  if (rkas.programs.length === 0) {
    throw new RkasImportError(
      "Tidak ada rincian belanja yang terbaca. Pastikan file ini RKAS " +
        '"Rincian Kertas Kerja perBulan", bukan dokumen lain.'
    );
  }
  if (rkas.month === null || rkas.year === null) {
    throw new RkasImportError(
      'Bulan/tahun tidak terbaca dari header "Bulan : ..." pada RKAS.'
    );
  }
  const month = rkas.month;
  const year = rkas.year;

  const rkasImportId = await prisma.$transaction(async (tx) => {
    const created = await tx.rkasImport.create({
      data: {
        schoolId,
        month,
        year,
        sourceFileName: fileName,
        sourceSchoolName: rkas.schoolName,
        npsn: rkas.npsn,
        kepalaName: rkas.kepalaName ?? "",
        bendaharaName: rkas.bendaharaName ?? "",
      },
    });

    for (const [index, program] of rkas.programs.entries()) {
      await tx.rkasProgram.create({
        data: {
          rkasImportId: created.id,
          urutan: index,
          kodeProgram: program.kodeProgram,
          nama: program.nama,
          standarName: program.standarName,
          kegiatanName: program.kegiatanName,
          items: {
            create: program.items.map((item, itemIndex) => ({
              urutan: itemIndex,
              noUrut: item.noUrut,
              kodeRekening: item.kodeRekening,
              uraian: item.uraian,
              volumeText: item.volumeText,
              tarifHarga: item.tarifHarga,
              jumlah: item.jumlah,
            })),
          },
        },
      });
    }

    return created.id;
  });

  return {
    rkasImportId,
    programCount: rkas.programs.length,
    itemCount: rkas.programs.reduce((n, p) => n + p.items.length, 0),
    totalAmount: rkas.programs.reduce(
      (sum, p) => sum + p.items.reduce((s, i) => s + i.jumlah, 0),
      0
    ),
    warnings: rkas.warnings,
  };
}
