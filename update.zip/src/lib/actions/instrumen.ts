"use server";

import { revalidatePath } from "next/cache";
import { prisma } from "@/lib/db";

function str(formData: FormData, key: string): string {
  return (formData.get(key) as string | null)?.trim() ?? "";
}

function int(formData: FormData, key: string): number {
  const raw = str(formData, key).replace(/[^\d-]/g, "");
  const value = Number.parseInt(raw, 10);
  return Number.isFinite(value) ? value : 0;
}

function optionalInt(formData: FormData, key: string): number | null {
  const raw = str(formData, key).replace(/[^\d-]/g, "");
  if (raw === "") return null;
  const value = Number.parseInt(raw, 10);
  return Number.isFinite(value) ? value : null;
}

function bool(formData: FormData, key: string): boolean {
  return formData.get(key) === "on";
}

/**
 * Collects the repeating rows the user types in. Rows are posted as
 * `${prefix}_${index}_${field}` and a row is kept only once its first column
 * has something in it, so the blank spare rows in the UI don't end up in the
 * document.
 */
function collectRows(
  formData: FormData,
  prefix: string,
  fields: string[],
  requiredField: string
): Record<string, string>[] {
  const rows: Record<string, string>[] = [];
  for (let i = 0; i < 30; i++) {
    const row: Record<string, string> = {};
    let hasAny = false;
    for (const field of fields) {
      const value = str(formData, `${prefix}_${i}_${field}`);
      row[field] = value;
      if (value !== "") hasAny = true;
    }
    if (!hasAny) continue;
    if ((row[requiredField] ?? "") === "") continue;
    rows.push(row);
  }
  return rows;
}

export async function saveInstrumen(
  schoolId: string,
  year: number,
  tahap: number,
  formData: FormData
) {
  const belanjaModal = collectRows(
    formData,
    "modal",
    ["namaBarang", "volume", "hargaSatuan", "jumlah", "kondisi", "keterangan"],
    "namaBarang"
  ).map((r) => ({
    namaBarang: r.namaBarang,
    volume: r.volume,
    hargaSatuan: Number.parseInt(r.hargaSatuan.replace(/[^\d]/g, ""), 10) || 0,
    jumlah: Number.parseInt(r.jumlah.replace(/[^\d]/g, ""), 10) || 0,
    kondisi: r.kondisi,
    keterangan: r.keterangan,
  }));

  const pemeliharaan = collectRows(
    formData,
    "rawat",
    ["namaKegiatan", "jumlahBarang", "biaya", "keterangan"],
    "namaKegiatan"
  ).map((r) => ({
    namaKegiatan: r.namaKegiatan,
    jumlahBarang: r.jumlahBarang,
    biaya: Number.parseInt(r.biaya.replace(/[^\d]/g, ""), 10) || 0,
    keterangan: r.keterangan,
  }));

  // Book rows come from the BKU; only the two columns the BKU cannot supply
  // (quantity and unit price) are editable, kept positionally aligned.
  const bukuOverride: { banyakBuku: string; hargaSatuan: string }[] = [];
  for (let i = 0; i < 30; i++) {
    const banyak = str(formData, `buku_${i}_banyakBuku`);
    const harga = str(formData, `buku_${i}_hargaSatuan`);
    if (banyak === "" && harga === "" && bukuOverride.length === 0 && i > 20) break;
    bukuOverride.push({ banyakBuku: banyak, hargaSatuan: harga.replace(/[^\d]/g, "") });
  }

  const data = {
    jenisSatuan: str(formData, "jenisSatuan") || "TK",
    statusSatuan: str(formData, "statusSatuan") || "Swasta",
    kelurahan: str(formData, "kelurahan"),
    kecamatan: str(formData, "kecamatan"),
    jenisDanaBosp: str(formData, "jenisDanaBosp") || "BOP PAUD Reguler",
    skNomor: str(formData, "skNomor"),
    skTanggal: str(formData, "skTanggal"),
    kepalaName: str(formData, "kepalaName"),
    bendaharaName: str(formData, "bendaharaName"),
    komiteName: str(formData, "komiteName"),
    adaBku: bool(formData, "adaBku"),
    adaBukuPembantuKas: bool(formData, "adaBukuPembantuKas"),
    adaBukuPembantuPajak: bool(formData, "adaBukuPembantuPajak"),
    adaBukuPembantuBank: bool(formData, "adaBukuPembantuBank"),
    adaLaporanRealisasi: bool(formData, "adaLaporanRealisasi"),
    totalAlokasiTahunan: int(formData, "totalAlokasiTahunan"),
    saldoAwalOverride: optionalInt(formData, "saldoAwalOverride"),
    operasionalOverride: optionalInt(formData, "operasionalOverride"),
    honorSesuaiRkas: bool(formData, "honorSesuaiRkas"),
    honorBuktiLengkap: bool(formData, "honorBuktiLengkap"),
    honorPenerimaSesuai: bool(formData, "honorPenerimaSesuai"),
    metodePengadaanBuku: str(formData, "metodePengadaanBuku") || "Pembelian langsung",
    metodePengadaanLain: str(formData, "metodePengadaanLain"),
    belanjaModalJson: JSON.stringify(belanjaModal),
    pemeliharaanJson: JSON.stringify(pemeliharaan),
    bukuOverrideJson: JSON.stringify(bukuOverride),
    tanggalDokumen: str(formData, "tanggalDokumen"),
  };

  await prisma.instrumenBosp.upsert({
    where: { schoolId_year_tahap: { schoolId, year, tahap } },
    create: { schoolId, year, tahap, ...data },
    update: data,
  });

  revalidatePath(`/schools/${schoolId}/instrumen`);
}
