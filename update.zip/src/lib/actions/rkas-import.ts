"use server";

import { revalidatePath } from "next/cache";
import { prisma } from "@/lib/db";
import { parseAndStoreRkas } from "@/lib/rkas/persistRkas";

export interface RkasImportResult {
  fileName: string;
  status: "ok" | "error";
  rkasImportId?: string;
  programCount?: number;
  itemCount?: number;
  totalAmount?: number;
  warnings?: string[];
  error?: string;
}

export async function importRkasFiles(
  schoolId: string,
  formData: FormData
): Promise<RkasImportResult[]> {
  const files = formData
    .getAll("files")
    .filter((f): f is File => f instanceof File && f.size > 0);
  const results: RkasImportResult[] = [];

  for (const file of files) {
    try {
      const bytes = new Uint8Array(await file.arrayBuffer());
      const stored = await parseAndStoreRkas(schoolId, file.name, bytes);

      results.push({
        fileName: file.name,
        status: "ok",
        rkasImportId: stored.rkasImportId,
        programCount: stored.programCount,
        itemCount: stored.itemCount,
        totalAmount: stored.totalAmount,
        warnings: stored.warnings,
      });
    } catch (err) {
      results.push({
        fileName: file.name,
        status: "error",
        error: err instanceof Error ? err.message : String(err),
      });
    }
  }

  revalidatePath(`/schools/${schoolId}/rkas`);
  return results;
}

/** Adapter matching React's useActionState signature. */
export async function importRkasFilesAction(
  schoolId: string,
  _prevState: RkasImportResult[],
  formData: FormData
): Promise<RkasImportResult[]> {
  return importRkasFiles(schoolId, formData);
}

export async function deleteRkasImport(schoolId: string, rkasImportId: string) {
  await prisma.rkasImport.delete({ where: { id: rkasImportId } });
  revalidatePath(`/schools/${schoolId}/rkas`);
}

function str(formData: FormData, key: string): string {
  return (formData.get(key) as string | null)?.trim() ?? "";
}

/**
 * Saves the whole confirmation screen in one go: which kode program are in,
 * which individual items are excluded, and the lampiran's header/signature
 * text. Checkboxes are read against the stored rows rather than the posted
 * keys, because an unchecked box submits nothing at all.
 */
export async function saveRkasConfirmation(
  schoolId: string,
  rkasImportId: string,
  formData: FormData
) {
  const programs = await prisma.rkasProgram.findMany({
    where: { rkasImportId },
    select: { id: true, items: { select: { id: true } } },
  });

  await prisma.$transaction(async (tx) => {
    await tx.rkasImport.update({
      where: { id: rkasImportId },
      data: {
        namaPelaksana: str(formData, "namaPelaksana"),
        programLabel: str(formData, "programLabel"),
        namaKegiatan: str(formData, "namaKegiatan"),
        sumberDana: str(formData, "sumberDana"),
        pekerjaanLabel: str(formData, "pekerjaanLabel"),
        kepalaName: str(formData, "kepalaName"),
        bendaharaName: str(formData, "bendaharaName"),
      },
    });

    for (const program of programs) {
      await tx.rkasProgram.update({
        where: { id: program.id },
        data: { included: formData.has(`program_${program.id}`) },
      });
      for (const item of program.items) {
        await tx.rkasItem.update({
          where: { id: item.id },
          data: { excluded: !formData.has(`item_${item.id}`) },
        });
      }
    }
  });

  revalidatePath(`/schools/${schoolId}/rkas/${rkasImportId}`);
}

/** "Centang semua" / "Kosongkan semua" for the kode program list. */
export async function setAllRkasPrograms(
  schoolId: string,
  rkasImportId: string,
  included: boolean
) {
  await prisma.rkasProgram.updateMany({
    where: { rkasImportId },
    data: { included },
  });
  revalidatePath(`/schools/${schoolId}/rkas/${rkasImportId}`);
}
