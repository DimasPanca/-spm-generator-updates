"use server";

import { revalidatePath } from "next/cache";
import { prisma } from "@/lib/db";
import type { VendorRuleFormatType } from "@/generated/prisma";
import { PKBM_ABDI_PERTIWI_VENDOR_RULES } from "@/lib/vendor-rule-seed";

function str(formData: FormData, key: string): string {
  return (formData.get(key) as string | null)?.trim() ?? "";
}

function optionalStr(formData: FormData, key: string): string | null {
  const value = str(formData, key);
  return value === "" ? null : value;
}

export async function createVendorRule(schoolId: string, formData: FormData) {
  const formatType = str(formData, "formatType") as VendorRuleFormatType;
  const priority = Number(str(formData, "priority") || "100");

  await prisma.vendorRule.create({
    data: {
      schoolId,
      keyword: str(formData, "keyword"),
      recipient: str(formData, "recipient"),
      paymentPrefix: str(formData, "paymentPrefix"),
      matchKodeKegiatan: optionalStr(formData, "matchKodeKegiatan"),
      formatType,
      isHonor: formData.get("isHonor") === "on",
      isTransport: formData.get("isTransport") === "on",
      priority: Number.isFinite(priority) ? priority : 100,
    },
  });

  revalidatePath(`/schools/${schoolId}/vendor-rules`);
}

export async function updateVendorRule(
  schoolId: string,
  ruleId: string,
  formData: FormData
) {
  const formatType = str(formData, "formatType") as VendorRuleFormatType;
  const priority = Number(str(formData, "priority") || "100");

  await prisma.vendorRule.update({
    where: { id: ruleId },
    data: {
      keyword: str(formData, "keyword"),
      recipient: str(formData, "recipient"),
      paymentPrefix: str(formData, "paymentPrefix"),
      matchKodeKegiatan: optionalStr(formData, "matchKodeKegiatan"),
      formatType,
      isHonor: formData.get("isHonor") === "on",
      isTransport: formData.get("isTransport") === "on",
      priority: Number.isFinite(priority) ? priority : 100,
      isActive: formData.get("isActive") === "on",
    },
  });

  revalidatePath(`/schools/${schoolId}/vendor-rules`);
}

export async function deleteVendorRule(schoolId: string, ruleId: string) {
  await prisma.vendorRule.delete({ where: { id: ruleId } });
  revalidatePath(`/schools/${schoolId}/vendor-rules`);
}

export interface ImportVendorRulesResult {
  status: "ok" | "error";
  copied?: number;
  skipped?: number;
  replaced?: number;
  sourceName?: string;
  error?: string;
}

/**
 * Copies vendor rules from another school. Most schools under the same
 * management buy from the same vendors, so this saves re-entering ~20 rules
 * by hand. Two modes:
 *  - "append": add only rules that don't already exist here (dedupe on
 *    keyword + kode kegiatan + recipient + prefix), keeping what's already set up.
 *  - "replace": wipe this school's rules first, then copy everything.
 * Person names in `recipient` are copied too -- for a different school those
 * often need editing afterwards, which the UI warns about.
 */
export async function importVendorRules(
  schoolId: string,
  formData: FormData
): Promise<ImportVendorRulesResult> {
  const sourceSchoolId = str(formData, "sourceSchoolId");
  const mode = str(formData, "mode") === "replace" ? "replace" : "append";

  if (!sourceSchoolId || sourceSchoolId === schoolId) {
    return { status: "error", error: "Pilih sekolah sumber yang berbeda." };
  }

  const source = await prisma.school.findUnique({
    where: { id: sourceSchoolId },
    select: { id: true, name: true },
  });
  if (!source) return { status: "error", error: "Sekolah sumber tidak ditemukan." };

  const sourceRules = await prisma.vendorRule.findMany({
    where: { schoolId: sourceSchoolId },
    orderBy: { priority: "asc" },
  });
  if (sourceRules.length === 0) {
    return {
      status: "error",
      error: `${source.name} belum punya aturan vendor untuk disalin.`,
    };
  }

  let replaced = 0;
  if (mode === "replace") {
    const { count } = await prisma.vendorRule.deleteMany({ where: { schoolId } });
    replaced = count;
  }

  const existing = await prisma.vendorRule.findMany({ where: { schoolId } });
  const fingerprint = (r: {
    keyword: string;
    matchKodeKegiatan: string | null;
    recipient: string;
    paymentPrefix: string;
  }) =>
    [
      r.keyword.trim().toLowerCase(),
      (r.matchKodeKegiatan ?? "").trim().toLowerCase(),
      r.recipient.trim().toLowerCase(),
      r.paymentPrefix.trim().toLowerCase(),
    ].join("||");
  const seen = new Set(existing.map(fingerprint));

  const toCreate = sourceRules.filter((r) => !seen.has(fingerprint(r)));

  if (toCreate.length > 0) {
    await prisma.vendorRule.createMany({
      data: toCreate.map((rule) => ({
        schoolId,
        keyword: rule.keyword,
        recipient: rule.recipient,
        paymentPrefix: rule.paymentPrefix,
        matchKodeKegiatan: rule.matchKodeKegiatan,
        formatType: rule.formatType,
        isHonor: rule.isHonor,
        isTransport: rule.isTransport,
        priority: rule.priority,
        isActive: rule.isActive,
      })),
    });
  }

  revalidatePath(`/schools/${schoolId}/vendor-rules`);
  return {
    status: "ok",
    copied: toCreate.length,
    skipped: sourceRules.length - toCreate.length,
    replaced,
    sourceName: source.name,
  };
}

/** useActionState adapter: (prevState, formData) => newState. */
export async function importVendorRulesAction(
  schoolId: string,
  _prev: ImportVendorRulesResult | null,
  formData: FormData
): Promise<ImportVendorRulesResult> {
  return importVendorRules(schoolId, formData);
}

export async function seedDefaultVendorRules(schoolId: string) {
  await prisma.vendorRule.createMany({
    data: PKBM_ABDI_PERTIWI_VENDOR_RULES.map((rule, index) => ({
      schoolId,
      keyword: rule.keyword,
      recipient: rule.recipient,
      paymentPrefix: rule.paymentPrefix,
      matchKodeKegiatan: rule.matchKodeKegiatan ?? null,
      formatType: rule.formatType,
      isHonor: rule.isHonor ?? false,
      isTransport: rule.isTransport ?? false,
      priority: (index + 1) * 10,
    })),
  });

  revalidatePath(`/schools/${schoolId}/vendor-rules`);
}
