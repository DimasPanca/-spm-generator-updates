"use server";

import { revalidatePath } from "next/cache";
import { prisma } from "@/lib/db";
import { computeGroupFields } from "@/lib/spm/paymentFormatter";

function str(formData: FormData, key: string): string {
  return (formData.get(key) as string | null)?.trim() ?? "";
}

/** Applies a (possibly different) vendor rule suggestion to a group,
 *  clearing any prior manual override so the review screen shows that
 *  rule's freshly computed recipient/paymentFor for the admin to check. */
export async function applyVendorRule(
  schoolId: string,
  bkuImportId: string,
  groupId: string,
  formData: FormData
) {
  const vendorRuleId = str(formData, "vendorRuleId");

  await prisma.bPUGroup.update({
    where: { id: groupId },
    data: {
      matchedVendorRuleId: vendorRuleId === "" ? null : vendorRuleId,
      overrideRecipient: null,
      overridePaymentFor: null,
    },
  });

  revalidatePath(`/schools/${schoolId}/import/${bkuImportId}/review`);
}

/** Finalizes the "Kepada"/"Untuk Pembayaran" text for a group and marks it
 *  reviewed. This is the only path that flips a group to CONFIRMED --
 *  nothing gets generated as an SPM before this. */
export async function confirmBPUGroup(
  schoolId: string,
  bkuImportId: string,
  groupId: string,
  formData: FormData
) {
  await prisma.bPUGroup.update({
    where: { id: groupId },
    data: {
      overrideRecipient: str(formData, "recipient"),
      overridePaymentFor: str(formData, "paymentFor"),
      status: "CONFIRMED",
    },
  });

  revalidatePath(`/schools/${schoolId}/import/${bkuImportId}/review`);
}

/**
 * Bulk-confirms every SUGGESTED group whose auto-suggestion is already
 * complete: it has a matched vendor rule AND the computed "Kepada" is
 * non-empty. Groups that still need a person's name (honor/jasa rules with
 * an empty recipient) or have no match at all are deliberately left alone
 * for manual review -- the review rules stay intact, this only accelerates
 * the unambiguous cases the admin would confirm one by one anyway.
 */
export async function confirmAllComplete(schoolId: string, bkuImportId: string) {
  const groups = await prisma.bPUGroup.findMany({
    where: { bkuImportId, status: "SUGGESTED", matchedVendorRuleId: { not: null } },
    include: { matchedVendorRule: true },
  });

  for (const group of groups) {
    const rows = await prisma.bKURow.findMany({
      where: { bkuImportId, bpuCode: group.bpuCode },
    });
    const computed = computeGroupFields(rows, group.matchedVendorRule);
    const recipient = group.overrideRecipient ?? computed.recipient;
    const paymentFor = group.overridePaymentFor ?? computed.paymentFor;
    if (recipient.trim() === "") continue; // still needs a name -- keep for manual review

    await prisma.bPUGroup.update({
      where: { id: group.id },
      data: {
        overrideRecipient: recipient,
        overridePaymentFor: paymentFor,
        status: "CONFIRMED",
      },
    });
  }

  revalidatePath(`/schools/${schoolId}/import/${bkuImportId}/review`);
}

export async function unconfirmBPUGroup(
  schoolId: string,
  bkuImportId: string,
  groupId: string
) {
  await prisma.bPUGroup.update({
    where: { id: groupId },
    data: { status: "SUGGESTED" },
  });

  revalidatePath(`/schools/${schoolId}/import/${bkuImportId}/review`);
}
