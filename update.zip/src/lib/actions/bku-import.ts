"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { prisma } from "@/lib/db";
import { parseBKUPdf, type ParsedBKURow } from "@/lib/pdf-parse/bkuParser";
import { runMatchingForImport } from "@/lib/matching/vendorMatcher";

function extractBpuNumber(bpuCode: string | null): number | null {
  if (!bpuCode) return null;
  const match = /^BPU(\d+)$/i.exec(bpuCode);
  return match ? Number(match[1]) : null;
}

/** Falls back to the most common month/year among parsed row dates when the
 *  "BULAN : ... TAHUN : ..." header wasn't detected (e.g. a slightly
 *  different template). */
function inferMonthYear(
  rows: ParsedBKURow[],
  detectedMonth: number | null,
  detectedYear: number | null
): { month: number; year: number } | null {
  if (detectedMonth && detectedYear) return { month: detectedMonth, year: detectedYear };
  if (rows.length === 0) return null;

  const counts = new Map<string, number>();
  for (const row of rows) {
    const key = `${row.tanggal.getUTCFullYear()}-${row.tanggal.getUTCMonth() + 1}`;
    counts.set(key, (counts.get(key) ?? 0) + 1);
  }
  const [bestKey] = [...counts.entries()].sort((a, b) => b[1] - a[1])[0];
  const [year, month] = bestKey.split("-").map(Number);
  return { month, year };
}

export interface ImportFileResult {
  fileName: string;
  status: "ok" | "error";
  bkuImportId?: string;
  rowCount?: number;
  bpuGroupCount?: number;
  warnings?: string[];
  error?: string;
}

export async function importBKUFiles(
  schoolId: string,
  formData: FormData
): Promise<ImportFileResult[]> {
  const files = formData.getAll("files").filter((f): f is File => f instanceof File && f.size > 0);
  const results: ImportFileResult[] = [];

  for (const file of files) {
    try {
      const bytes = new Uint8Array(await file.arrayBuffer());
      const { rows, warnings, detectedMonth, detectedYear } = await parseBKUPdf(bytes);

      const monthYear = inferMonthYear(rows, detectedMonth, detectedYear);
      if (!monthYear) {
        results.push({
          fileName: file.name,
          status: "error",
          error: "Tidak ada baris transaksi yang berhasil dibaca dari file ini.",
        });
        continue;
      }

      const bpuRows = rows.filter((r) => r.bpuCode && /^BPU\d+$/i.test(r.bpuCode));
      const groupsByCode = new Map<string, ParsedBKURow[]>();
      for (const row of bpuRows) {
        const code = row.bpuCode!.toUpperCase();
        const list = groupsByCode.get(code) ?? [];
        list.push(row);
        groupsByCode.set(code, list);
      }

      const bkuImportId = await prisma.$transaction(async (tx) => {
        const bkuImport = await tx.bKUImport.create({
          data: {
            schoolId,
            month: monthYear.month,
            year: monthYear.year,
            sourceFileName: file.name,
            status: "PARSED",
          },
        });

        await tx.bKURow.createMany({
          data: rows.map((row) => ({
            bkuImportId: bkuImport.id,
            tanggal: row.tanggal,
            kodeKegiatan: row.kodeKegiatan,
            kodeRekening: row.kodeRekening,
            bpuCode: row.bpuCode,
            bpuNumber: extractBpuNumber(row.bpuCode),
            uraian: row.uraian,
            penerimaan: row.penerimaan,
            pengeluaran: row.pengeluaran,
            saldo: row.saldo,
            pageIndex: row.pageIndex,
          })),
        });

        for (const [bpuCode, groupRows] of groupsByCode) {
          const totalAmount = groupRows.reduce((sum, r) => sum + r.pengeluaran, 0);
          await tx.bPUGroup.create({
            data: {
              bkuImportId: bkuImport.id,
              bpuCode,
              bpuNumber: extractBpuNumber(bpuCode)!,
              tanggal: groupRows[0].tanggal,
              totalAmount,
            },
          });
        }

        return bkuImport.id;
      });

      await runMatchingForImport(schoolId, bkuImportId);

      results.push({
        fileName: file.name,
        status: "ok",
        bkuImportId,
        rowCount: rows.length,
        bpuGroupCount: groupsByCode.size,
        warnings,
      });
    } catch (err) {
      results.push({
        fileName: file.name,
        status: "error",
        error: err instanceof Error ? err.message : String(err),
      });
    }
  }

  revalidatePath(`/schools/${schoolId}/import`);
  return results;
}

/** Adapter so this action's signature matches React's useActionState:
 *  (previousState, formData) => newState. */
export async function importBKUFilesAction(
  schoolId: string,
  _prevState: ImportFileResult[],
  formData: FormData
): Promise<ImportFileResult[]> {
  return importBKUFiles(schoolId, formData);
}

export async function deleteBKUImport(schoolId: string, bkuImportId: string) {
  await prisma.bKUImport.delete({ where: { id: bkuImportId } });
  revalidatePath(`/schools/${schoolId}/import`);
}

export async function goToReview(schoolId: string, bkuImportId: string) {
  redirect(`/schools/${schoolId}/import/${bkuImportId}/review`);
}

/** Re-applies vendor-rule matching to an already-imported BKU -- useful
 *  after editing vendor rules, without needing to re-upload the PDF. */
export async function rerunMatching(schoolId: string, bkuImportId: string) {
  await runMatchingForImport(schoolId, bkuImportId);
  revalidatePath(`/schools/${schoolId}/import/${bkuImportId}/review`);
}
