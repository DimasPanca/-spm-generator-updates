"use server";

import { revalidatePath } from "next/cache";
import { prisma } from "@/lib/db";
import {
  DaftarPdParseError,
  parseDaftarPdWorkbook,
} from "@/lib/student-data/parseDaftarPd";

const MAX_FILE_SIZE = 15 * 1024 * 1024;

export interface StudentDataImportResult {
  status: "ok" | "error";
  importId?: string;
  fileName?: string;
  sourceSchoolName?: string | null;
  studentCount?: number;
  warnings?: string[];
  error?: string;
}

export async function importStudentData(
  schoolId: string,
  formData: FormData
): Promise<StudentDataImportResult> {
  const school = await prisma.school.findUnique({
    where: { id: schoolId },
    select: { id: true },
  });
  if (!school) return { status: "error", error: "Sekolah tidak ditemukan." };

  const file = formData.get("file");
  if (!(file instanceof File) || file.size === 0) {
    return { status: "error", error: "Pilih satu file daftar_pd berformat .xlsx." };
  }
  if (!file.name.toLocaleLowerCase("id-ID").endsWith(".xlsx")) {
    return { status: "error", error: "Format file harus .xlsx (bukan .xls atau .xlsm)." };
  }
  if (file.size > MAX_FILE_SIZE) {
    return { status: "error", error: "Ukuran file melebihi batas aman 15 MB." };
  }

  try {
    const parsed = await parseDaftarPdWorkbook(new Uint8Array(await file.arrayBuffer()));
    const sourceFileName = file.name.replace(/[\u0000-\u001f]/g, "").slice(0, 255);

    const imported = await prisma.$transaction(async (tx) => {
      const created = await tx.studentDataImport.create({
        data: {
          schoolId,
          sourceFileName,
          sourceSchoolName: parsed.sourceSchoolName,
        },
      });

      await tx.studentRecord.createMany({
        data: parsed.students.map((student) => ({
          studentDataImportId: created.id,
          sourceNumber: student.sourceNumber,
          name: student.name,
          nik: student.nik,
          gender: student.gender,
          className: student.className,
          birthPlace: student.birthPlace,
          birthDate: student.birthDate,
          parentName: student.parentName,
          parentRelation: student.parentRelation,
          address: student.address,
          isPipEligible: student.isPipEligible,
          pipReason: student.pipReason,
        })),
      });

      return created;
    });

    revalidatePath(`/schools/${schoolId}/siswa-miskin`);
    revalidatePath(`/schools/${schoolId}/data-siswa`);
    return {
      status: "ok",
      importId: imported.id,
      fileName: sourceFileName,
      sourceSchoolName: parsed.sourceSchoolName,
      studentCount: parsed.students.length,
      warnings: parsed.warnings,
    };
  } catch (error) {
    if (!(error instanceof DaftarPdParseError)) {
      console.error("Gagal mengimpor daftar_pd:", error);
    }
    return {
      status: "error",
      error:
        error instanceof DaftarPdParseError
          ? error.message
          : "Gagal menyimpan data siswa. Coba ulangi atau periksa file sumber.",
    };
  }
}

export async function importStudentDataAction(
  schoolId: string,
  _previousState: StudentDataImportResult | null,
  formData: FormData
): Promise<StudentDataImportResult> {
  return importStudentData(schoolId, formData);
}

export async function deleteStudentDataImport(schoolId: string, importId: string) {
  await prisma.studentDataImport.deleteMany({ where: { id: importId, schoolId } });
  revalidatePath(`/schools/${schoolId}/siswa-miskin`);
  revalidatePath(`/schools/${schoolId}/data-siswa`);
}
