"use server";

import { revalidatePath } from "next/cache";
import { prisma } from "@/lib/db";

function str(formData: FormData, key: string): string {
  return (formData.get(key) as string | null)?.trim() ?? "";
}

function intField(formData: FormData, key: string, fallback: number): number {
  const raw = str(formData, key).replace(/[^\d]/g, "");
  const value = Number.parseInt(raw, 10);
  return Number.isFinite(value) ? value : fallback;
}

export async function saveSk(schoolId: string, year: number, formData: FormData) {
  // Roster rows are posted as team_{i}_{field}; a row is kept once it has a name.
  const team: { nama: string; jabatan: string; keterangan: string }[] = [];
  for (let i = 0; i < 60; i++) {
    const nama = str(formData, `team_${i}_nama`);
    if (nama === "") continue;
    team.push({
      nama,
      jabatan: str(formData, `team_${i}_jabatan`) || "Anggota",
      keterangan: str(formData, `team_${i}_keterangan`),
    });
  }

  const data = {
    nomorUrut: str(formData, "nomorUrut") || "05",
    kodeSurat: str(formData, "kodeSurat") || "SK.PTB",
    tanggalRapat: Math.min(31, Math.max(1, intField(formData, "tanggalRapat", 2))),
    tanggalTetap: Math.min(31, Math.max(1, intField(formData, "tanggalTetap", 4))),
    kecamatan: str(formData, "kecamatan") || "Walantaka",
    kota: str(formData, "kota") || "Kota Serang",
    provinsi: str(formData, "provinsi") || "Banten",
    kepalaName: str(formData, "kepalaName"),
    teamJson: JSON.stringify(team),
  };

  await prisma.skBosp.upsert({
    where: { schoolId_year: { schoolId, year } },
    create: { schoolId, year, ...data },
    update: data,
  });

  revalidatePath(`/schools/${schoolId}/sk`);
}
