"use server";

import { mkdir, writeFile } from "node:fs/promises";
import path from "node:path";
import { redirect } from "next/navigation";
import { revalidatePath } from "next/cache";
import { prisma } from "@/lib/db";
import { clearLogoCache } from "@/lib/pdf-render/loadLogo";

function str(formData: FormData, key: string): string {
  return (formData.get(key) as string | null)?.trim() ?? "";
}

function optionalStr(formData: FormData, key: string): string | null {
  const value = str(formData, key);
  return value === "" ? null : value;
}

const UPLOADS_DIR = path.join(process.cwd(), "public", "uploads");

/** Saves an uploaded image under a fixed name (e.g. "logo.png" or
 *  "regional-logo.png") so re-uploads simply overwrite the old file, and
 *  returns the public path to store on the School record. */
async function saveImageIfPresent(
  schoolId: string,
  formData: FormData,
  fieldName: string,
  baseName: string
): Promise<string | undefined> {
  const file = formData.get(fieldName);
  if (!(file instanceof File) || file.size === 0) return undefined;

  const ext = path.extname(file.name) || ".png";
  const dir = path.join(UPLOADS_DIR, schoolId);
  await mkdir(dir, { recursive: true });

  const fileName = `${baseName}${ext}`;
  const buffer = Buffer.from(await file.arrayBuffer());
  await writeFile(path.join(dir, fileName), buffer);

  const publicPath = `/uploads/${schoolId}/${fileName}`;
  clearLogoCache(publicPath);
  return publicPath;
}

export async function createSchool(formData: FormData) {
  const school = await prisma.school.create({
    data: {
      name: str(formData, "name"),
      kopHeaderLine: optionalStr(formData, "kopHeaderLine"),
      npsn: optionalStr(formData, "npsn"),
      address: str(formData, "address"),
      contact: optionalStr(formData, "contact"),
      formatCode: str(formData, "formatCode"),
      kepalaName: str(formData, "kepalaName"),
      kepalaJabatan: str(formData, "kepalaJabatan"),
      honorRecapTitle: optionalStr(formData, "honorRecapTitle"),
      frazaListrikCustomerId: optionalStr(formData, "frazaListrikCustomerId"),
      frazaInternetCustomerId: optionalStr(formData, "frazaInternetCustomerId"),
    },
  });

  const [logoPath, regionalLogoPath] = await Promise.all([
    saveImageIfPresent(school.id, formData, "logo", "logo"),
    saveImageIfPresent(school.id, formData, "regionalLogo", "regional-logo"),
  ]);
  if (logoPath || regionalLogoPath) {
    await prisma.school.update({
      where: { id: school.id },
      data: {
        ...(logoPath ? { logoPath } : {}),
        ...(regionalLogoPath ? { regionalLogoPath } : {}),
      },
    });
  }

  revalidatePath("/schools");
  redirect(`/schools/${school.id}/setup`);
}

export async function updateSchool(schoolId: string, formData: FormData) {
  const [logoPath, regionalLogoPath] = await Promise.all([
    saveImageIfPresent(schoolId, formData, "logo", "logo"),
    saveImageIfPresent(schoolId, formData, "regionalLogo", "regional-logo"),
  ]);

  await prisma.school.update({
    where: { id: schoolId },
    data: {
      name: str(formData, "name"),
      kopHeaderLine: optionalStr(formData, "kopHeaderLine"),
      npsn: optionalStr(formData, "npsn"),
      address: str(formData, "address"),
      contact: optionalStr(formData, "contact"),
      formatCode: str(formData, "formatCode"),
      kepalaName: str(formData, "kepalaName"),
      kepalaJabatan: str(formData, "kepalaJabatan"),
      openingSentenceTemplate: str(formData, "openingSentenceTemplate"),
      atasDasarLine1: str(formData, "atasDasarLine1"),
      atasDasarLine2: str(formData, "atasDasarLine2"),
      honorRecapTitle: optionalStr(formData, "honorRecapTitle"),
      frazaListrikCustomerId: optionalStr(formData, "frazaListrikCustomerId"),
      frazaInternetCustomerId: optionalStr(formData, "frazaInternetCustomerId"),
      ...(logoPath ? { logoPath } : {}),
      ...(regionalLogoPath ? { regionalLogoPath } : {}),
    },
  });

  revalidatePath("/schools");
  revalidatePath(`/schools/${schoolId}/setup`);
}

export async function deleteSchool(schoolId: string) {
  await prisma.school.delete({ where: { id: schoolId } });
  revalidatePath("/schools");
  redirect("/schools");
}
