"use server";

import path from "node:path";
import { revalidatePath } from "next/cache";
import { prisma } from "@/lib/db";
import { buildSpmTemplateData } from "@/lib/spm/buildSpmData";
import { renderSpmPdf } from "@/lib/pdf-render/renderSpmPdf";
import { loadLogoBuffer } from "@/lib/pdf-render/loadLogo";

const STORAGE_DIR = path.join(process.cwd(), "storage");

export async function generateSPMDocuments(schoolId: string, bkuImportId: string) {
  const school = await prisma.school.findUniqueOrThrow({ where: { id: schoolId } });
  const bkuImport = await prisma.bKUImport.findUniqueOrThrow({ where: { id: bkuImportId } });
  const groups = await prisma.bPUGroup.findMany({
    where: { bkuImportId, status: "CONFIRMED" },
    include: { matchedVendorRule: true },
    orderBy: { bpuNumber: "asc" },
  });

  const [schoolLogo, regionalLogo] = await Promise.all([
    loadLogoBuffer(school.logoPath),
    loadLogoBuffer(school.regionalLogoPath),
  ]);

  for (const group of groups) {
    const rows = await prisma.bKURow.findMany({
      where: { bkuImportId, bpuCode: group.bpuCode },
    });
    const data = buildSpmTemplateData(school, group, rows, { schoolLogo, regionalLogo });

    const fileName = `SPM_${data.nomorSurat.replace(/[/\\:]/g, "_")}.pdf`;
    const outputPath = path.join(
      STORAGE_DIR,
      schoolId,
      String(bkuImport.year),
      String(bkuImport.month).padStart(2, "0"),
      fileName
    );

    await renderSpmPdf(data, outputPath);

    await prisma.sPMDocument.upsert({
      where: { bpuGroupId: group.id },
      create: {
        bpuGroupId: group.id,
        nomorSurat: data.nomorSurat,
        recipient: data.recipient,
        amount: group.totalAmount,
        terbilang: data.terbilang,
        paymentFor: data.paymentFor,
        filePath: outputPath,
      },
      update: {
        nomorSurat: data.nomorSurat,
        recipient: data.recipient,
        amount: group.totalAmount,
        terbilang: data.terbilang,
        paymentFor: data.paymentFor,
        filePath: outputPath,
        generatedAt: new Date(),
      },
    });
  }

  revalidatePath(`/schools/${schoolId}/import/${bkuImportId}/generate`);
}
