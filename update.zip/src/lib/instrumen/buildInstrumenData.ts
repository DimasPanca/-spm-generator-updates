import { prisma } from "@/lib/db";
import { computeGroupFields } from "@/lib/spm/paymentFormatter";
import { monthName } from "@/lib/indonesian/months";

/**
 * A BKU opens every month by restating last month's closing balance as a
 * "penerimaan" row, and moving money between the bank and the cash box shows
 * up as a matching penerimaan/pengeluaran pair. Summing the raw columns
 * therefore counts the same rupiah many times over -- for TK Abdi Pertiwi the
 * raw total came to Rp19,3jt against Rp4,2jt of real money. Both patterns are
 * excluded here so the instrument's figures reconcile to the closing balance.
 */
const CARRY_FORWARD = /^Saldo\s+(Bank|Tunai)\s+Bulan/i;
const INTERNAL_TRANSFER = /Pergeseran|Tarik\s*Tunai|Setor\s*Tunai|Setor\s*Bank/i;

function isBookkeepingNoise(uraian: string): boolean {
  return CARRY_FORWARD.test(uraian.trim()) || INTERNAL_TRANSFER.test(uraian);
}

export interface MonthFigures {
  month: number;
  penerimaan: number;
  pengeluaran: number;
}

export interface PeriodRow {
  label: string; // "Januari–Februari"
  saldoBulanLalu: number;
  penerimaan: number;
  pengeluaran: number;
  saldo: number;
}

export interface HonorRow {
  nama: string;
  jumlahBulan: number;
  honorPerBulan: number;
  jumlahDiterima: number;
}

export interface BukuRow {
  namaPenyedia: string;
  judulBuku: string;
  banyakBuku: number | null;
  hargaSatuan: number | null;
  jumlah: number;
}

export interface InstrumenComputed {
  schoolName: string;
  npsn: string | null;
  address: string;
  kepalaName: string;
  months: MonthFigures[];
  /** Money already in hand when the tahap opened -- the real disbursement. */
  saldoAwal: number;
  /** Same figure as printed on a BKU carry-forward row, when one exists.
   *  Differs from `saldoAwal` only when a monthly file is missing or mis-keyed. */
  saldoAwalTercatat: number | null;
  totalPenerimaan: number;
  totalPengeluaran: number;
  saldoAkhir: number;
  periods: PeriodRow[];
  honor: HonorRow[];
  totalHonor: number;
  buku: BukuRow[];
  totalBuku: number;
  /** Everything that isn't honor or a book purchase. */
  sisaBelanja: number;
  importedMonths: number[];
  missingMonths: number[];
  /** Months uploaded more than once; only the newest import was counted. */
  duplicateMonths: number[];
}

/**
 * Splits a person's payments into a monthly rate and a month count. The rate
 * is the most frequent amount rather than the average, because a rapel (two
 * months paid together) shows up as one doubled row that would otherwise drag
 * the average away from the true monthly figure.
 */
function deriveHonorRate(amounts: number[]): { rate: number; months: number } {
  const total = amounts.reduce((sum, a) => sum + a, 0);
  if (amounts.length === 0 || total === 0) return { rate: 0, months: 0 };

  const counts = new Map<number, number>();
  for (const a of amounts) counts.set(a, (counts.get(a) ?? 0) + 1);

  let rate = amounts[0];
  let best = 0;
  for (const [amount, count] of counts) {
    // Ties break toward the smaller amount: a rapel is a multiple of the
    // real rate, never smaller than it.
    if (count > best || (count === best && amount < rate)) {
      rate = amount;
      best = count;
    }
  }

  if (rate > 0 && total % rate === 0) {
    return { rate, months: total / rate };
  }
  // Amounts don't divide evenly (mid-period rate change): fall back to one
  // month per recorded payment.
  return { rate: Math.round(total / amounts.length), months: amounts.length };
}

export async function buildInstrumenData(
  schoolId: string,
  year: number,
  tahap: 1 | 2
): Promise<InstrumenComputed | null> {
  const school = await prisma.school.findUnique({ where: { id: schoolId } });
  if (!school) return null;

  const startMonth = tahap === 1 ? 1 : 7;
  const endMonth = tahap === 1 ? 6 : 12;

  const allImports = await prisma.bKUImport.findMany({
    where: { schoolId, year, month: { gte: startMonth, lte: endMonth } },
    orderBy: [{ month: "asc" }, { importedAt: "desc" }],
  });
  if (allImports.length === 0) return null;

  // The same month can be uploaded twice (a re-export, a corrected file).
  // Keeping both would double every figure that month, so only the most
  // recent import per month counts -- and the duplicates are reported so the
  // user can clean them up.
  const imports: typeof allImports = [];
  const duplicateMonths: number[] = [];
  for (const imp of allImports) {
    if (imports.some((kept) => kept.month === imp.month)) {
      if (!duplicateMonths.includes(imp.month)) duplicateMonths.push(imp.month);
      continue;
    }
    imports.push(imp);
  }
  imports.sort((a, b) => a.month - b.month);

  const rows = await prisma.bKURow.findMany({
    where: { bkuImportId: { in: imports.map((i) => i.id) } },
    orderBy: [{ tanggal: "asc" }],
  });

  const months: MonthFigures[] = [];
  for (let m = startMonth; m <= endMonth; m++) {
    const imp = imports.find((i) => i.month === m);
    if (!imp) {
      months.push({ month: m, penerimaan: 0, pengeluaran: 0 });
      continue;
    }
    const clean = rows.filter((r) => r.bkuImportId === imp.id && !isBookkeepingNoise(r.uraian));
    months.push({
      month: m,
      penerimaan: clean.reduce((s, r) => s + r.penerimaan, 0),
      pengeluaran: clean.reduce((s, r) => s + r.pengeluaran, 0),
    });
  }

  const totalPenerimaanBaru = months.reduce((s, m) => s + m.penerimaan, 0);
  const totalPengeluaran = months.reduce((s, m) => s + m.pengeluaran, 0);

  // The opening balance is worked BACKWARDS from the closing balance rather
  // than read from the first month's carry-forward row: an idle first month
  // (as in TK Abdi Pertiwi's January) records its carry-forward as zero even
  // though the money was already in the account. Deriving it this way makes
  // the instrument's table reconcile to the BKU's own closing figure by
  // construction, which is the property an auditor checks.
  const lastImport = imports[imports.length - 1];
  const lastMonthRows = rows.filter((r) => r.bkuImportId === lastImport.id);
  const saldoAkhir = lastMonthRows.length > 0 ? lastMonthRows[lastMonthRows.length - 1].saldo : 0;
  const saldoAwal = saldoAkhir - totalPenerimaanBaru + totalPengeluaran;

  // Cross-check against the carry-forward rows the BKU actually prints. A
  // mismatch means one of the monthly files is mis-keyed or missing, which
  // the user needs to know before signing the form.
  // Only the penerimaan column is summed here. `saldo` is a running balance,
  // so a month whose bank and cash carry-forward rows both repeat it would
  // otherwise read as double the money actually carried over.
  const carryCandidates = imports
    .map((imp) =>
      rows
        .filter((r) => r.bkuImportId === imp.id && CARRY_FORWARD.test(r.uraian.trim()))
        .reduce((sum, r) => sum + r.penerimaan, 0)
    )
    .filter((v) => v > 0);
  const saldoAwalTercatat = carryCandidates.length > 0 ? carryCandidates[0] : null;

  const totalPenerimaan = saldoAwal + totalPenerimaanBaru;

  // Three two-month periods, matching the instrument's fixed table.
  const periods: PeriodRow[] = [];
  let running = saldoAwal;
  for (let i = 0; i < 3; i++) {
    const a = months[i * 2];
    const b = months[i * 2 + 1];
    if (!a || !b) break;
    const penerimaan = a.penerimaan + b.penerimaan;
    const pengeluaran = a.pengeluaran + b.pengeluaran;
    const saldoBulanLalu = running;
    running = saldoBulanLalu + penerimaan - pengeluaran;
    periods.push({
      label: `${monthName(a.month)}–${monthName(b.month)}`,
      saldoBulanLalu,
      penerimaan,
      pengeluaran,
      saldo: running,
    });
  }

  // --- Honor, from confirmed BPU groups matched to isHonor vendor rules ---
  const honorGroups = await prisma.bPUGroup.findMany({
    where: {
      status: "CONFIRMED",
      bkuImportId: { in: imports.map((i) => i.id) },
      matchedVendorRule: { isHonor: true },
    },
    include: { matchedVendorRule: true },
    orderBy: [{ tanggal: "asc" }, { bpuNumber: "asc" }],
  });

  // Grouped case-insensitively: the same teacher is keyed differently across
  // months ("GALIH WIGUNAWATI" vs "Galih Wigunawati") and must not be listed
  // twice on a form that caps total honor at 40%.
  const paymentsByName = new Map<string, { display: string; amounts: number[] }>();
  for (const group of honorGroups) {
    let nama = group.overrideRecipient ?? "";
    if (nama.trim() === "") {
      const groupRows = await prisma.bKURow.findMany({
        where: { bkuImportId: group.bkuImportId, bpuCode: group.bpuCode },
      });
      nama = computeGroupFields(groupRows, group.matchedVendorRule).recipient;
    }
    nama = nama.trim();
    if (nama === "") continue;

    const key = nama.toLocaleLowerCase("id-ID");
    const entry = paymentsByName.get(key) ?? { display: nama, amounts: [] };
    entry.amounts.push(group.totalAmount);
    paymentsByName.set(key, entry);
  }

  const tahapMonths = endMonth - startMonth + 1;
  const honor: HonorRow[] = [...paymentsByName.values()].map(({ display, amounts }) => {
    const jumlahDiterima = amounts.reduce((s, a) => s + a, 0);
    const { months: derived } = deriveHonorRate(amounts);
    // A tahap cannot contain more months than it has. Anything above that is
    // someone paid per session rather than per month (an instructor, say), so
    // the count is clamped and the rate restated to keep bulan x rate equal
    // to what was actually received.
    const jumlahBulan = Math.min(Math.max(derived, 1), tahapMonths);
    return {
      nama: display,
      jumlahBulan,
      honorPerBulan: Math.round(jumlahDiterima / jumlahBulan),
      jumlahDiterima,
    };
  });
  const totalHonor = honor.reduce((s, h) => s + h.jumlahDiterima, 0);

  // --- Books (Belanja Modal Aset Tetap Lainnya) ---
  const bookGroups = await prisma.bPUGroup.findMany({
    where: {
      status: "CONFIRMED",
      bkuImportId: { in: imports.map((i) => i.id) },
      matchedVendorRule: { recipient: "A2 Mandiri" },
    },
    include: { matchedVendorRule: true },
    orderBy: [{ tanggal: "asc" }, { bpuNumber: "asc" }],
  });

  const buku: BukuRow[] = [];
  for (const group of bookGroups) {
    const groupRows = await prisma.bKURow.findMany({
      where: { bkuImportId: group.bkuImportId, bpuCode: group.bpuCode },
      orderBy: { tanggal: "asc" },
    });
    for (const row of groupRows) {
      if (row.pengeluaran <= 0) continue;
      buku.push({
        namaPenyedia: group.overrideRecipient ?? group.matchedVendorRule?.recipient ?? "A2 Mandiri",
        judulBuku: row.uraian.replace(/-+\s*$/, "").trim(),
        // The BKU records only a lump sum per purchase, never a unit price
        // and quantity, so these stay blank for the user to complete.
        banyakBuku: null,
        hargaSatuan: null,
        jumlah: row.pengeluaran,
      });
    }
  }
  const totalBuku = buku.reduce((s, b) => s + b.jumlah, 0);

  const importedMonths = imports.map((i) => i.month);
  const missingMonths: number[] = [];
  for (let m = startMonth; m <= endMonth; m++) {
    if (!importedMonths.includes(m)) missingMonths.push(m);
  }

  return {
    schoolName: school.name,
    npsn: school.npsn,
    address: school.address,
    kepalaName: school.kepalaName,
    months,
    saldoAwal,
    saldoAwalTercatat,
    totalPenerimaan,
    totalPengeluaran,
    saldoAkhir,
    periods,
    honor,
    totalHonor,
    buku,
    totalBuku,
    sisaBelanja: totalPengeluaran - totalHonor - totalBuku,
    importedMonths,
    missingMonths,
    duplicateMonths,
  };
}
