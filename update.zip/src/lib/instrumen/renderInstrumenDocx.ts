import { readFile } from "node:fs/promises";
import path from "node:path";
import { prisma } from "@/lib/db";
import { DocxTemplate } from "@/lib/docx/docxTemplate";
import { buildInstrumenData, type InstrumenComputed } from "./buildInstrumenData";
import { monthName } from "@/lib/indonesian/months";

const TEMPLATE_PATH = path.join(
  process.cwd(),
  "src",
  "templates",
  "docx",
  "instrumen-bosp-2026.docx"
);

/**
 * Cell coordinates in the government template, discovered by walking its
 * table grid. They are constants of the form itself, not of our data, so they
 * only change if the dinas issues a new template.
 */
const T = {
  DATA_UMUM: 2,
  ADMINISTRASI: 3,
  RINGKASAN: 4,
  PERIODE: 5,
  HONOR: 6,
  MONITORING_HONOR: 7,
  PEMELIHARAAN: 8,
  BELANJA_MODAL: 9,
  BUKU: 10,
  TTD_1: 12,
  TTD_2: 14,
} as const;

const JENIS_SATUAN_ORDER = ["TK", "KB", "TPA", "SPS", "PKBM", "SKB"];
const PAUD_ORDER = ["BOP PAUD Reguler", "BOP PAUD Kinerja", "BOP PAUD Afirmasi"];
const KESETARAAN_ORDER = [
  "BOP Kesetaraan Reguler",
  "BOP Kesetaraan Kinerja",
  "BOP Kesetaraan Afirmasi",
];

export interface BelanjaModalInput {
  namaBarang: string;
  volume: string;
  hargaSatuan: number;
  jumlah: number;
  kondisi: string;
  keterangan: string;
}
export interface PemeliharaanInput {
  namaKegiatan: string;
  jumlahBarang: string;
  biaya: number;
  keterangan: string;
}
export interface BukuOverrideInput {
  banyakBuku: string;
  hargaSatuan: string;
}

function rupiah(value: number): string {
  return `Rp ${value.toLocaleString("id-ID")}`;
}
function plain(value: number): string {
  return value.toLocaleString("id-ID");
}

function parseJson<T>(raw: string, fallback: T): T {
  try {
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? (parsed as T) : fallback;
  } catch {
    return fallback;
  }
}

/**
 * Fills the tables that hold a variable number of rows. The template ships
 * with a fixed number of blank rows and a JUMLAH row underneath; extra data
 * rows are cloned from the first one so the borders and fonts carry over,
 * and any unused template rows are simply left blank.
 */
function fillVariableTable(
  doc: DocxTemplate,
  table: number,
  templateRows: number,
  firstDataRow: number,
  items: unknown[],
  writeRow: (rowIndex: number, item: unknown, displayNo: number) => void
) {
  const extra = Math.max(0, items.length - templateRows);
  if (extra > 0) {
    // Clone the LAST template data row so the copies land above the JUMLAH row.
    doc.cloneRow(table, firstDataRow + templateRows - 1, extra);
  }
  items.forEach((item, i) => {
    writeRow(firstDataRow + i, item, i + 1);
  });
}

export interface InstrumenRenderResult {
  buffer: Buffer;
  fileName: string;
  computed: InstrumenComputed;
}

export async function renderInstrumenDocx(
  schoolId: string,
  year: number,
  tahap: 1 | 2
): Promise<InstrumenRenderResult | null> {
  const computed = await buildInstrumenData(schoolId, year, tahap);
  if (!computed) return null;

  const form = await prisma.instrumenBosp.findUnique({
    where: { schoolId_year_tahap: { schoolId, year, tahap } },
  });

  const belanjaModal = parseJson<BelanjaModalInput[]>(form?.belanjaModalJson ?? "[]", []);
  const pemeliharaan = parseJson<PemeliharaanInput[]>(form?.pemeliharaanJson ?? "[]", []);
  const bukuOverride = parseJson<BukuOverrideInput[]>(form?.bukuOverrideJson ?? "[]", []);

  const saldoAwal = form?.saldoAwalOverride ?? computed.saldoAwal;
  const totalPenerimaan = saldoAwal + (computed.totalPenerimaan - computed.saldoAwal);
  const totalPengeluaran = computed.totalPengeluaran;
  const saldoAkhir = totalPenerimaan - totalPengeluaran;

  const totalBelanjaModal = belanjaModal.reduce((s, b) => s + (b.jumlah || 0), 0);
  const totalPemeliharaan = pemeliharaan.reduce((s, p) => s + (p.biaya || 0), 0);

  const operasional =
    form?.operasionalOverride ??
    Math.max(0, totalPengeluaran - computed.totalHonor - computed.totalBuku - totalBelanjaModal - totalPemeliharaan);

  const totalAlokasi = form?.totalAlokasiTahunan ?? 0;
  const batasHonor = Math.round(totalAlokasi * 0.4);
  const persenHonor = totalAlokasi > 0 ? (computed.totalHonor / totalAlokasi) * 100 : 0;

  const namaSekolah = computed.schoolName;
  const npsn = computed.npsn ?? "";
  const alamat = computed.address;
  const kepala = (form?.kepalaName || computed.kepalaName || "").trim();
  const bendahara = (form?.bendaharaName ?? "").trim();
  const komite = (form?.komiteName ?? "").trim();
  const kecamatan = form?.kecamatan ?? "";
  const kelurahan = form?.kelurahan ?? "";
  const jenisSatuan = form?.jenisSatuan ?? "TK";
  const statusSatuan = form?.statusSatuan ?? "Swasta";
  const jenisDana = form?.jenisDanaBosp ?? "BOP PAUD Reguler";

  const buffer = await readFile(TEMPLATE_PATH);
  const doc = await DocxTemplate.load(buffer);

  // ---- Bagian 2: Data Umum ----
  doc.setCell(T.DATA_UMUM, 0, 3, namaSekolah);
  doc.setCell(T.DATA_UMUM, 1, 3, npsn);
  const jenisIdx = JENIS_SATUAN_ORDER.indexOf(jenisSatuan);
  if (jenisIdx >= 0) doc.tickCheckboxInCell(T.DATA_UMUM, 2, 3, jenisIdx);
  doc.tickCheckboxInCell(T.DATA_UMUM, 3, 3, statusSatuan === "Negeri" ? 0 : 1);
  doc.setCell(T.DATA_UMUM, 4, 3, alamat);
  doc.setCell(T.DATA_UMUM, 5, 3, kelurahan);
  doc.setCell(T.DATA_UMUM, 6, 3, kecamatan);
  const paudIdx = PAUD_ORDER.indexOf(jenisDana);
  const kesetaraanIdx = KESETARAAN_ORDER.indexOf(jenisDana);
  if (paudIdx >= 0) doc.tickCheckboxInCell(T.DATA_UMUM, 8, 3, paudIdx);
  if (kesetaraanIdx >= 0) doc.tickCheckboxInCell(T.DATA_UMUM, 8, 4, kesetaraanIdx);

  // ---- Bagian 4: checklist administrasi keuangan (kolom Ada / Tidak Ada) ----
  const administrasi: [number, boolean][] = [
    [1, form?.adaBku ?? true],
    [2, form?.adaBukuPembantuKas ?? true],
    [3, form?.adaBukuPembantuPajak ?? true],
    [4, form?.adaBukuPembantuBank ?? true],
    [5, form?.adaLaporanRealisasi ?? false],
  ];
  for (const [row, ada] of administrasi) {
    doc.tickCheckboxInCell(T.ADMINISTRASI, row, ada ? 2 : 3, 0);
  }

  // ---- Bagian 5: ringkasan ----
  doc.setCell(T.RINGKASAN, 0, 1, rupiah(totalPenerimaan));
  doc.setCell(T.RINGKASAN, 1, 1, rupiah(totalPengeluaran));
  doc.setCell(T.RINGKASAN, 2, 1, rupiah(saldoAkhir));

  // ---- Bagian 6: penerimaan & pengeluaran per dua bulan ----
  let running = saldoAwal;
  computed.periods.forEach((period, i) => {
    const row = i + 1;
    const saldoLalu = running;
    running = saldoLalu + period.penerimaan - period.pengeluaran;
    doc.setCell(T.PERIODE, row, 2, plain(saldoLalu));
    doc.setCell(T.PERIODE, row, 3, plain(period.penerimaan));
    doc.setCell(T.PERIODE, row, 4, plain(period.pengeluaran));
    doc.setCell(T.PERIODE, row, 5, plain(running));
  });
  const totalPenerimaanBaru = computed.periods.reduce((s, p) => s + p.penerimaan, 0);
  doc.setCell(T.PERIODE, 4, 2, rupiah(saldoAwal));
  doc.setCell(T.PERIODE, 4, 3, rupiah(totalPenerimaanBaru));
  doc.setCell(T.PERIODE, 4, 4, rupiah(totalPengeluaran));
  doc.setCell(T.PERIODE, 4, 5, rupiah(running));

  // ---- Bagian 7: honor ----
  fillVariableTable(doc, T.HONOR, 3, 1, computed.honor, (row, item, no) => {
    const h = item as InstrumenComputed["honor"][number];
    doc.setCell(T.HONOR, row, 0, String(no));
    doc.setCell(T.HONOR, row, 1, h.nama);
    doc.setCell(T.HONOR, row, 2, String(h.jumlahBulan));
    doc.setCell(T.HONOR, row, 3, plain(h.honorPerBulan));
    doc.setCell(T.HONOR, row, 4, plain(h.jumlahDiterima));
  });
  const honorJumlahRow = 1 + Math.max(3, computed.honor.length);
  doc.setCell(T.HONOR, honorJumlahRow, 4, rupiah(computed.totalHonor));

  // ---- Bagian 8: hasil monitoring belanja honor ----
  doc.setCell(T.MONITORING_HONOR, 1, 2, rupiah(totalAlokasi));
  doc.setCell(T.MONITORING_HONOR, 2, 2, rupiah(batasHonor));
  doc.setCell(T.MONITORING_HONOR, 3, 2, rupiah(computed.totalHonor));
  doc.setCell(T.MONITORING_HONOR, 4, 2, `${persenHonor.toFixed(2).replace(".", ",")} %`);
  doc.tickCheckboxInCell(T.MONITORING_HONOR, 5, 2, form?.honorSesuaiRkas === false ? 1 : 0);
  doc.tickCheckboxInCell(T.MONITORING_HONOR, 6, 2, form?.honorBuktiLengkap === false ? 1 : 0);
  doc.tickCheckboxInCell(T.MONITORING_HONOR, 7, 2, form?.honorPenerimaSesuai === false ? 1 : 0);

  // ---- Bagian 10: pemeliharaan ----
  if (pemeliharaan.length > 0) {
    fillVariableTable(doc, T.PEMELIHARAAN, 3, 1, pemeliharaan, (row, item, no) => {
      const p = item as PemeliharaanInput;
      doc.setCell(T.PEMELIHARAAN, row, 0, String(no));
      doc.setCell(T.PEMELIHARAAN, row, 1, p.namaKegiatan);
      doc.setCell(T.PEMELIHARAAN, row, 2, p.jumlahBarang);
      doc.setCell(T.PEMELIHARAAN, row, 3, plain(p.biaya || 0));
      doc.setCell(T.PEMELIHARAAN, row, 4, p.keterangan);
    });
  }
  doc.setCell(T.PEMELIHARAAN, 1 + Math.max(3, pemeliharaan.length), 3, rupiah(totalPemeliharaan));

  // ---- Bagian 11: belanja modal peralatan & mesin ----
  if (belanjaModal.length > 0) {
    fillVariableTable(doc, T.BELANJA_MODAL, 3, 1, belanjaModal, (row, item, no) => {
      const b = item as BelanjaModalInput;
      doc.setCell(T.BELANJA_MODAL, row, 0, String(no));
      doc.setCell(T.BELANJA_MODAL, row, 1, b.namaBarang);
      doc.setCell(T.BELANJA_MODAL, row, 2, b.volume);
      doc.setCell(T.BELANJA_MODAL, row, 3, plain(b.hargaSatuan || 0));
      doc.setCell(T.BELANJA_MODAL, row, 4, plain(b.jumlah || 0));
      doc.setCell(T.BELANJA_MODAL, row, 5, b.kondisi);
      doc.setCell(T.BELANJA_MODAL, row, 6, b.keterangan);
    });
  }
  doc.setCell(T.BELANJA_MODAL, 1 + Math.max(3, belanjaModal.length), 4, rupiah(totalBelanjaModal));

  // ---- Bagian 12: belanja modal aset tetap lainnya (buku) ----
  fillVariableTable(doc, T.BUKU, 5, 1, computed.buku, (row, item, no) => {
    const b = item as InstrumenComputed["buku"][number];
    const override = bukuOverride[no - 1];
    doc.setCell(T.BUKU, row, 0, String(no));
    doc.setCell(T.BUKU, row, 1, b.namaPenyedia);
    doc.setCell(T.BUKU, row, 2, b.judulBuku);
    doc.setCell(T.BUKU, row, 3, override?.banyakBuku ?? "");
    doc.setCell(
      T.BUKU,
      row,
      4,
      override?.hargaSatuan ? `Rp ${Number(override.hargaSatuan).toLocaleString("id-ID")}` : "Rp"
    );
    doc.setCell(T.BUKU, row, 5, rupiah(b.jumlah));
  });
  doc.setCell(T.BUKU, 1 + Math.max(5, computed.buku.length), 5, rupiah(computed.totalBuku));

  // ---- Tanda tangan (dua halaman) ----
  for (const table of [T.TTD_1, T.TTD_2]) {
    if (kepala) doc.setDottedLineInCell(table, 0, 0, kepala);
    if (bendahara) doc.setDottedLineInCell(table, 1, 0, bendahara);
  }

  // ---- Paragraf di luar tabel ----
  const periodeLabel =
    tahap === 1 ? `Januari – Juni ${year}` : `Juli – Desember ${year}`;

  // The title's "TK/KB/TPA/SPS/PKBM/SKB ......" is a prompt listing the
  // possible jenis, not something to keep once the actual school is known --
  // the filled line should read as a plain name.
  doc.replaceInParagraph("KOTA SERANG", (text) =>
    /TK\/KB\/TPA/.test(text) ? `${namaSekolah} KOTA SERANG` : text
  );

  doc.replaceInParagraph("Tim Manajemen BOSP yang diangkat", (text) => {
    let out = text.replace(/Satuan Pendidikan\s*\.{4,}/, `Satuan Pendidikan ${namaSekolah}`);
    out = out.replace(/Nomor\s*\.{4,}/, `Nomor ${form?.skNomor || "................"}`);
    out = out.replace(/tanggal\s*\.{4,}/, `tanggal ${form?.skTanggal || "................"}`);
    return out;
  });

  doc.replaceInParagraph("telah menunjuk pengelola Dana BOSP", (text) =>
    text.replace(/Pendidikan\s*\.{4,}/, `Pendidikan ${namaSekolah}`)
  );

  // Three bare "Nama : ……" lines appear in document order, each followed by
  // its own "Jabatan :" line: kepala, then bendahara, then ketua komite.
  const namaLines = [kepala, bendahara, komite];
  namaLines.forEach((value, i) => {
    if (!value) return;
    doc.replaceParagraphAt("Nama :", i, (text) => text.replace(/\.{4,}/, value));
  });

  doc.replaceInParagraph("Jumlah Realisasi", (text) =>
    text.replace(/Rp\s*\.{4,}/, rupiah(operasional))
  );

  const metode = form?.metodePengadaanBuku ?? "Pembelian langsung";
  doc.replaceInParagraph("Metode Pengadaan Buku", (text) => {
    let out = text;
    if (metode === "Lainnya" && form?.metodePengadaanLain) {
      out = out.replace(/lainnya:\s*\.{4,}/i, `lainnya: ${form.metodePengadaanLain}`);
    }
    const boxes = ["Pembelian langsung", "SIPLah", "Lainnya"];
    const idx = boxes.indexOf(metode);
    let seen = -1;
    return out.replace(/☐/g, () => {
      seen++;
      return seen === idx ? "☒" : "☐";
    });
  });

  const tanggalDok = form?.tanggalDokumen || "";
  if (tanggalDok) {
    // Only the standalone date line above each signature block. Matching
    // "Serang," anywhere would also hit the body sentence "...Kota Serang,
    // Tim Manajemen BOSP yang diangkat..." and swallow the words after it.
    doc.replaceInParagraph("Serang,", (text) =>
      /^Serang,/.test(text.trim()) ? `Serang, ${tanggalDok}` : text
    );
  }

  // Kuesioner header: the template packs every field into one unbroken
  // paragraph, so each value needs a trailing space or it collides with the
  // next label ("TK ABDI PERTIWINPSN"). The jenis/status checkbox runs are
  // replaced by the answer itself rather than being ticked -- inline prose,
  // unlike the formal Data Umum table above, reads better as a plain value.
  doc.replaceInParagraph("Nama Satuan Pendidikan:", (text) => {
    let out = text.replace(
      /Nama Satuan Pendidikan:\s*\.{4,}/,
      `Nama Satuan Pendidikan: ${namaSekolah} `
    );
    out = out.replace(/NPSN\s*:\s*\.{4,}/, `NPSN : ${npsn} `);
    out = out.replace(/☐\s*TK\s*☐\s*KB\s*☐\s*TPA\s*☐\s*SPS\s*☐\s*PKBM/, `${jenisSatuan} `);
    out = out.replace(/☐\s*Negeri\s*☐\s*Swasta/, `${statusSatuan} `);
    out = out.replace(/Alamat\s*:\s*\.{4,}/, `Alamat : ${alamat} `);
    out = out.replace(/Kecamatan\s*:\s*\.{4,}/, `Kecamatan : ${kecamatan}`);
    return out;
  });

  const safeName = namaSekolah.replace(/[^a-z0-9]+/gi, "_");
  return {
    buffer: await doc.toBuffer(),
    fileName: `Instrumen_BOSP_Tahap_${tahap}_${year}_${safeName}.docx`,
    computed,
  };
}

/** Human-readable period label, reused by the UI. */
export function tahapLabel(tahap: 1 | 2, year: number): string {
  return tahap === 1
    ? `${monthName(1)}–${monthName(6)} ${year}`
    : `${monthName(7)}–${monthName(12)} ${year}`;
}
