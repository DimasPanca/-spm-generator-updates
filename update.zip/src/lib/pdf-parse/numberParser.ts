/** Parses an Indonesian-formatted integer Rupiah amount, e.g. "9.098.500" -> 9098500. */
export function parseIndonesianNumber(raw: string): number {
  const digitsOnly = raw.replace(/\./g, "").trim();
  if (digitsOnly === "") return 0;
  const value = Number.parseInt(digitsOnly, 10);
  return Number.isNaN(value) ? 0 : value;
}
