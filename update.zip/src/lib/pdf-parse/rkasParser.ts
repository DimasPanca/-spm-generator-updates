import { extractPositionedTokens, type PositionedToken } from "./textExtraction";
import { parseIndonesianNumber } from "./numberParser";
import { monthNameToNumber } from "@/lib/indonesian/months";

/**
 * Parser for the "RINCIAN KERTAS KERJA PERBULAN" (RKAS) export.
 *
 * Section B ("BELANJA") is a four-level outline printed as one flat table:
 *
 *   No.  Kode Rekening        Kode Program      Uraian                    Jumlah
 *   1.                        02.               Pengembangan Standar Isi  1.201.900   <- standar
 *   2.                        02. 03.           Pelaksanaan Kegiatan...   1.201.900   <- kegiatan
 *   3.                        02. 03. 01.       Penyusunan Kurikulum      1.201.900   <- KODE PROGRAM
 *   4.   5.1.02.01.01.0024    02. 03. 01.       Kertas HVS A4 75GSM         130.000   <- item
 *
 * Depth is encoded purely by how many of the three "Kode Program" sub-columns
 * are filled, and a row is a real purchase iff it carries a Kode Rekening.
 * Everything is therefore recovered from token x-positions rather than text.
 */

// Column bands, in PDF points. Taken from the real export; generous enough to
// absorb the small per-row jitter that comes from right-aligned cells.
const X_NO_URUT = [28, 62] as const;
const X_KODE_REKENING = [64, 112] as const;
const X_PROGRAM_L1 = [152, 173] as const;
const X_PROGRAM_L2 = [174, 191] as const;
const X_PROGRAM_L3 = [192, 209] as const;
const X_URAIAN = [210, 320] as const;
const X_VOLUME = [545, 675] as const;
const X_TARIF = [680, 795] as const;
const X_JUMLAH = [800, 910] as const;

const NO_URUT_RE = /^\d{1,3}\.$/;
const KODE_PROGRAM_RE = /^\d{1,2}\.$/;
// e.g. "5.1.02.01.01.0024" / "5.2.05.01.01.0001"
const KODE_REKENING_RE = /^\d\.\d\.\d{2}\.\d{2}\.\d{2}\.\d{4}$/;

function inBand(x: number, band: readonly [number, number]): boolean {
  return x >= band[0] && x <= band[1];
}

interface Line {
  page: number;
  y: number;
  tokens: PositionedToken[];
}

/** Groups the flat token stream into visual lines (same page, y within 2pt). */
function toLines(tokens: PositionedToken[]): Line[] {
  const lines: Line[] = [];
  for (const token of tokens) {
    const last = lines[lines.length - 1];
    if (last && last.page === token.page && Math.abs(last.y - token.y) <= 2) {
      last.tokens.push(token);
    } else {
      lines.push({ page: token.page, y: token.y, tokens: [token] });
    }
  }
  return lines;
}

function pick(line: Line, band: readonly [number, number]): PositionedToken[] {
  return line.tokens.filter((t) => inBand(t.x, band));
}

function joinBand(line: Line, band: readonly [number, number]): string {
  return pick(line, band)
    .sort((a, b) => a.x - b.x)
    .map((t) => t.str)
    .join(" ")
    .trim();
}

export interface ParsedRkasItem {
  noUrut: number;
  kodeRekening: string;
  uraian: string;
  volumeText: string;
  tarifHarga: number;
  jumlah: number;
}

export interface ParsedRkasProgram {
  kodeProgram: string; // "02. 03. 01."
  nama: string;
  standarName: string;
  kegiatanName: string;
  items: ParsedRkasItem[];
}

export interface ParsedRkas {
  schoolName: string | null;
  npsn: string | null;
  month: number | null;
  year: number | null;
  sumberDana: string | null;
  kepalaName: string | null;
  bendaharaName: string | null;
  programs: ParsedRkasProgram[];
  warnings: string[];
}

/** Reads the "NPSN : ... / Nama Sekolah : ... / Bulan : Juli 2026" block. */
function parseHeaderFields(lines: Line[]): Map<string, string> {
  const fields = new Map<string, string>();

  for (const line of lines) {
    if (line.page > 1) break;
    const strs = line.tokens.sort((a, b) => a.x - b.x).map((t) => t.str);
    if (strs.length < 2) continue;

    const colonAt = strs.indexOf(":");
    const label = (colonAt > 0 ? strs.slice(0, colonAt) : [strs[0]]).join(" ").trim();
    const value = (colonAt > 0 ? strs.slice(colonAt + 1) : strs.slice(1)).join(" ").trim();
    if (label === "" || value === "") continue;

    const key = label.toLowerCase();
    if (!fields.has(key)) fields.set(key, value);
  }

  return fields;
}

/** "Juli 2026" -> { month: 7, year: 2026 }. */
function parseMonthYear(raw: string | undefined): { month: number | null; year: number | null } {
  if (!raw) return { month: null, year: null };
  const match = /([A-Za-z]+)\s+(\d{4})/.exec(raw);
  if (!match) return { month: null, year: null };
  return { month: monthNameToNumber(match[1]), year: Number(match[2]) };
}

/**
 * Reads the signature page: a row of role labels ("Komite Sekolah / Kepala
 * Sekolah / Bendahara Sekolah") with the names printed underneath, each
 * horizontally centred under its label. Names are matched to roles by
 * nearest x rather than by order, so a missing komite column can't shift them.
 */
function parseSignatories(lines: Line[]): {
  kepalaName: string | null;
  bendaharaName: string | null;
} {
  for (let i = 0; i < lines.length; i++) {
    const labelLine = lines[i];
    const kepala = labelLine.tokens.find((t) => /^kepala\b/i.test(t.str));
    const bendahara = labelLine.tokens.find((t) => /^bendahara\b/i.test(t.str));
    if (!kepala || !bendahara) continue;

    for (let j = i + 1; j < lines.length && lines[j].page === labelLine.page; j++) {
      const candidate = lines[j];
      const usable = candidate.tokens.filter((t) => !/^NIP\b/i.test(t.str));
      if (usable.length === 0) continue;

      const nearest = (targetX: number): string | null => {
        let best: PositionedToken | null = null;
        for (const token of usable) {
          if (!best || Math.abs(token.x - targetX) < Math.abs(best.x - targetX)) best = token;
        }
        return best && Math.abs(best.x - targetX) <= 150 ? best.str : null;
      };

      return { kepalaName: nearest(kepala.x), bendaharaName: nearest(bendahara.x) };
    }
  }
  return { kepalaName: null, bendaharaName: null };
}

interface Anchor {
  line: Line;
  uraianFragments: { y: number; text: string }[];
}

export async function parseRkasPdf(pdfBytes: Uint8Array): Promise<ParsedRkas> {
  const tokens = await extractPositionedTokens(pdfBytes);
  const lines = toLines(tokens);
  const warnings: string[] = [];

  const fields = parseHeaderFields(lines);
  const { month, year } = parseMonthYear(fields.get("bulan"));
  const { kepalaName, bendaharaName } = parseSignatories(lines);

  // Everything before the "B. BELANJA" heading is the receipts section, whose
  // rows must never be mistaken for purchases.
  const belanjaAt = lines.findIndex((l) =>
    l.tokens.some((t) => /^B\.\s*BELANJA/i.test(t.str))
  );
  const body = belanjaAt === -1 ? lines : lines.slice(belanjaAt + 1);
  if (belanjaAt === -1) {
    warnings.push('Judul "B. BELANJA" tidak ditemukan — seluruh halaman dibaca sebagai belanja.');
  }

  // An anchor is a table row proper: it carries the "No. Urut" cell. Lines
  // holding only wrapped Uraian text are orphans, attached afterwards.
  const anchors: Anchor[] = [];
  const orphans: Line[] = [];

  for (const line of body) {
    const hasNoUrut = line.tokens.some(
      (t) => inBand(t.x, X_NO_URUT) && NO_URUT_RE.test(t.str)
    );
    if (hasNoUrut) {
      anchors.push({
        line,
        uraianFragments: pick(line, X_URAIAN)
          .sort((a, b) => a.x - b.x)
          .map((t) => ({ y: line.y, text: t.str })),
      });
    } else if (line.tokens.every((t) => inBand(t.x, X_URAIAN))) {
      orphans.push(line);
    }
  }

  // A tall cell centres its No./Kode/Jumlah on the MIDDLE wrapped line, so a
  // continuation can sit either above or below its own row. Nearest-y wins:
  // wrapped lines are ~5.7pt apart while separate rows are ~14.2pt apart.
  for (const orphan of orphans) {
    let best: Anchor | null = null;
    for (const anchor of anchors) {
      if (anchor.line.page !== orphan.page) continue;
      if (!best || Math.abs(anchor.line.y - orphan.y) < Math.abs(best.line.y - orphan.y)) {
        best = anchor;
      }
    }
    if (!best) continue;
    const text = orphan.tokens
      .sort((a, b) => a.x - b.x)
      .map((t) => t.str)
      .join(" ");
    best.uraianFragments.push({ y: orphan.y, text });
  }

  const programs: ParsedRkasProgram[] = [];
  let standarName = "";
  let kegiatanName = "";
  let current: ParsedRkasProgram | null = null;

  for (const anchor of anchors) {
    const { line } = anchor;

    const uraian = anchor.uraianFragments
      .sort((a, b) => b.y - a.y) // top line first
      .map((f) => f.text)
      .join(" ")
      .replace(/\s+/g, " ")
      .trim();

    const kodeRekening = pick(line, X_KODE_REKENING).find((t) =>
      KODE_REKENING_RE.test(t.str)
    )?.str;

    if (kodeRekening) {
      const noUrutToken = pick(line, X_NO_URUT).find((t) => NO_URUT_RE.test(t.str));
      const item: ParsedRkasItem = {
        noUrut: Number.parseInt(noUrutToken!.str, 10),
        kodeRekening,
        uraian,
        volumeText: joinBand(line, X_VOLUME),
        tarifHarga: parseIndonesianNumber(joinBand(line, X_TARIF)),
        jumlah: parseIndonesianNumber(joinBand(line, X_JUMLAH)),
      };

      if (!current) {
        warnings.push(
          `Baris "${uraian}" muncul sebelum ada kode program — dilewati.`
        );
        continue;
      }
      current.items.push(item);
      continue;
    }

    // Heading row: depth = number of filled "Kode Program" sub-columns.
    const l1 = pick(line, X_PROGRAM_L1).find((t) => KODE_PROGRAM_RE.test(t.str))?.str;
    const l2 = pick(line, X_PROGRAM_L2).find((t) => KODE_PROGRAM_RE.test(t.str))?.str;
    const l3 = pick(line, X_PROGRAM_L3).find((t) => KODE_PROGRAM_RE.test(t.str))?.str;

    if (l1 && l2 && l3) {
      current = {
        kodeProgram: `${l1} ${l2} ${l3}`,
        nama: uraian,
        standarName,
        kegiatanName,
        items: [],
      };
      programs.push(current);
    } else if (l1 && l2) {
      kegiatanName = uraian;
      current = null;
    } else if (l1) {
      standarName = uraian;
      kegiatanName = "";
      current = null;
    }
  }

  const withItems = programs.filter((p) => p.items.length > 0);
  const empty = programs.length - withItems.length;
  if (empty > 0) {
    warnings.push(`${empty} kode program tanpa rincian belanja diabaikan.`);
  }
  if (withItems.length === 0) {
    warnings.push("Tidak ada rincian belanja yang terbaca dari file ini.");
  }

  return {
    schoolName: fields.get("nama sekolah") ?? null,
    npsn: fields.get("npsn") ?? null,
    month,
    year,
    sumberDana: fields.get("sumber dana") ?? null,
    kepalaName,
    bendaharaName,
    programs: withItems,
    warnings,
  };
}
