import { getDocument } from "pdfjs-dist/legacy/build/pdf.mjs";
import * as pdfjsWorker from "pdfjs-dist/legacy/build/pdf.worker.mjs";

// pdfjs-dist normally spins up a real Worker (browser) or dynamically
// imports its worker module at runtime (Node). That dynamic import can't be
// resolved once this module is bundled by Next.js/Turbopack for the server.
// Registering the worker's exports on `globalThis.pdfjsWorker` up front is
// pdfjs-dist's documented escape hatch for bundled Node environments: it
// short-circuits straight to this object instead of attempting the dynamic
// import. See PDFWorker._setupFakeWorkerGlobal in pdf.mjs.
(globalThis as unknown as { pdfjsWorker?: unknown }).pdfjsWorker = pdfjsWorker;

export interface PositionedToken {
  str: string;
  x: number;
  y: number;
  page: number;
}

/**
 * Extracts every non-whitespace text token from the PDF, across all pages,
 * in reading order (top-to-bottom, left-to-right). Reading order is derived
 * purely from (page, y desc, x asc) sort -- there's no need to cluster
 * tokens into discrete visual lines first, since row reconstruction in
 * bkuParser.ts walks this flat stream token-by-token.
 */
export async function extractPositionedTokens(
  pdfBytes: Uint8Array
): Promise<PositionedToken[]> {
  const doc = await getDocument({ data: pdfBytes, useSystemFonts: true }).promise;

  const tokens: PositionedToken[] = [];
  for (let pageNum = 1; pageNum <= doc.numPages; pageNum++) {
    const page = await doc.getPage(pageNum);
    const content = await page.getTextContent();

    for (const item of content.items) {
      if (!("str" in item)) continue;
      const str = item.str.trim();
      if (str === "") continue;
      const x = item.transform[4];
      const y = item.transform[5];
      tokens.push({ str, x, y, page: pageNum });
    }
  }

  tokens.sort((a, b) => {
    if (a.page !== b.page) return a.page - b.page;
    if (Math.abs(a.y - b.y) > 0.5) return b.y - a.y; // top to bottom
    return a.x - b.x; // left to right
  });

  return tokens;
}
