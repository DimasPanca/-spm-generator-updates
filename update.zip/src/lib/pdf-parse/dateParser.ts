const DATE_PATTERN = /^(\d{2})-(\d{2})-(\d{4})$/;

export function isIndonesianDate(token: string): boolean {
  return DATE_PATTERN.test(token.trim());
}

/** Parses "dd-mm-yyyy" (as used throughout the BKU) into a UTC Date at midnight. */
export function parseIndonesianDate(token: string): Date | null {
  const match = DATE_PATTERN.exec(token.trim());
  if (!match) return null;
  const [, day, month, year] = match;
  return new Date(Date.UTC(Number(year), Number(month) - 1, Number(day)));
}
