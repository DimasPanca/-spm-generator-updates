import { extractPositionedTokens, type PositionedToken } from "./textExtraction";
import { isIndonesianDate, parseIndonesianDate } from "./dateParser";
import { parseIndonesianNumber } from "./numberParser";
import { monthNameToNumber } from "@/lib/indonesian/months";

export interface ParsedBKURow {
  tanggal: Date;
  kodeKegiatan: string | null;
  kodeRekening: string | null;
  bpuCode: string | null; // e.g. "BPU67"; also captures "BBU.." (income) rows, filtered out downstream
  uraian: string;
  penerimaan: number;
  pengeluaran: number;
  saldo: number;
  pageIndex: number;
}

export interface ParsedBKU {
  rows: ParsedBKURow[];
  warnings: string[];
  detectedMonth: number | null;
  detectedYear: number | null;
}

// A token at or beyond this x sits in the PENERIMAAN/PENGELUARAN/SALDO zone
// of the table -- confirmed from the real sample PDFs, where those three
// columns' right-aligned digits always land past x=550, well clear of the
// TANGGAL/KODE KEGIATAN/KODE REKENING/NO. BUKTI columns to their left.
const MONEY_ZONE_X_MIN = 550;

const KODE_KEGIATAN_PATTERN = /^\d{2}\.\d{2}\.\d{2}\.?$/;
const BPU_BBU_PATTERN = /^(BPU|BBU)\d+$/i;
const DIGITS_AND_DOTS_PATTERN = /^[\d.]+$/;
// The "1 2 3 4 5 6 7 8" column-index decoration repeats above the table on
// every page. A lone digit 1-8 is never real transaction data in this
// document (the smallest real amounts are in the hundreds/thousands of
// Rupiah), so it's safe to always discard -- "0" is a legitimate value and
// is deliberately excluded from this pattern.
const INDEX_DECORATION_PATTERN = /^[1-8]$/;
const FOOTER_BKU_LINE_PATTERN = /^BKU .+ - NPSN/i;
const FOOTER_HALAMAN_PATTERN = /^Halaman \d+ dari \d+$/i;
const HEADER_MONTH_YEAR_PATTERN = /^BULAN\s*:\s*([A-Za-z]+)\s*TAHUN\s*:\s*(\d{4})$/i;
// "Terima PPN ...", "Setor PPN ...", "Terima PPh ...", "Setor PPh ..." are tax
// reconciliation entries that carry no BPU. They render in a tall multi-line
// cell whose TANGGAL is vertically centered, so the cell's first wrapped
// uraian line is read *before* its date and would otherwise bleed into the
// preceding BPU row's uraian. Treat such a line as a signal to "seal" the
// current row so nothing further attaches to it until the next dated row.
const NOISE_ROW_PREFIX_PATTERN = /^(Terima|Setor)\s/i;
const STOP_TOKEN = "Jumlah";

interface RowAccumulator {
  tanggal: Date;
  kodeKegiatan?: string;
  kodeRekening?: string;
  bpuCode?: string;
  uraianParts: string[];
  numbers: number[];
  pageIndex: number;
  sealed?: boolean;
}

export function parseBKUTokens(tokens: PositionedToken[]): ParsedBKU {
  const rows: ParsedBKURow[] = [];
  const warnings: string[] = [];
  let current: RowAccumulator | null = null;
  let detectedMonth: number | null = null;
  let detectedYear: number | null = null;

  function flush() {
    if (!current) return;
    const row = current;
    current = null;

    if (row.numbers.length < 3) {
      // Sealed rows are tax-reconciliation / income noise we deliberately
      // dropped -- not an anomaly worth surfacing to the user.
      if (!row.sealed) {
        warnings.push(
          `Baris tanggal ${row.tanggal.toISOString().slice(0, 10)} (halaman ${row.pageIndex}) hanya menemukan ${row.numbers.length} dari 3 angka (penerimaan/pengeluaran/saldo) -- baris dilewati.`
        );
      }
      return;
    }

    rows.push({
      tanggal: row.tanggal,
      kodeKegiatan: row.kodeKegiatan ?? null,
      kodeRekening: row.kodeRekening ?? null,
      bpuCode: row.bpuCode ?? null,
      uraian: row.uraianParts.join(" ").replace(/\s+/g, " ").trim(),
      penerimaan: row.numbers[0],
      pengeluaran: row.numbers[1],
      saldo: row.numbers[2],
      pageIndex: row.pageIndex,
    });
  }

  for (const token of tokens) {
    const str = token.str;

    if (str === STOP_TOKEN) {
      flush();
      break;
    }

    if (INDEX_DECORATION_PATTERN.test(str)) continue;
    if (FOOTER_BKU_LINE_PATTERN.test(str) || FOOTER_HALAMAN_PATTERN.test(str)) continue;

    const headerMatch = HEADER_MONTH_YEAR_PATTERN.exec(str);
    if (headerMatch) {
      detectedMonth = monthNameToNumber(headerMatch[1]);
      detectedYear = Number(headerMatch[2]);
      continue;
    }

    if (isIndonesianDate(str)) {
      flush();
      current = {
        tanggal: parseIndonesianDate(str)!,
        uraianParts: [],
        numbers: [],
        pageIndex: token.page,
      };
      continue;
    }

    // Anything before the first date-starting row is page-1 preamble
    // (title, NPSN, address, column-label header) -- nothing to attach it to.
    if (!current) continue;

    // Seal the current row as soon as a tax-reconciliation line appears; its
    // own (centered) date will start a fresh row shortly after. Everything the
    // BPU row needs (uraian, its 3 money columns) has already been read on the
    // higher line above this noise, so there's nothing left to capture.
    if (NOISE_ROW_PREFIX_PATTERN.test(str)) {
      current.sealed = true;
      continue;
    }
    if (current.sealed) continue;

    if (BPU_BBU_PATTERN.test(str)) {
      current.bpuCode = str.toUpperCase();
      continue;
    }

    if (KODE_KEGIATAN_PATTERN.test(str)) {
      current.kodeKegiatan = str;
      continue;
    }

    if (DIGITS_AND_DOTS_PATTERN.test(str)) {
      if (token.x >= MONEY_ZONE_X_MIN) {
        current.numbers.push(parseIndonesianNumber(str));
      } else {
        // Kode rekening, possibly wrapped across a couple of short lines
        // (e.g. "5.1.02.02.01.00" + "13"). Not used by SPM generation --
        // best-effort concatenation is enough for debugging/traceability.
        current.kodeRekening = (current.kodeRekening ?? "") + str;
      }
      continue;
    }

    current.uraianParts.push(str);
  }

  flush();

  return { rows, warnings, detectedMonth, detectedYear };
}

export async function parseBKUPdf(pdfBytes: Uint8Array): Promise<ParsedBKU> {
  const tokens = await extractPositionedTokens(pdfBytes);
  return parseBKUTokens(tokens);
}
