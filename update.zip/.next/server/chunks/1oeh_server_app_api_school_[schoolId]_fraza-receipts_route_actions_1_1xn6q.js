module.exports=[51702,(e,o,d)=>{}];

//# sourceMappingURL=1oeh_server_app_api_school_%5BschoolId%5D_fraza-receipts_route_actions_1_1xn6q.js.map