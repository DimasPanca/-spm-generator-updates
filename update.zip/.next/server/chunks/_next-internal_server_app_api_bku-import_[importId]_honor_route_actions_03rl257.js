module.exports=[45843,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_bku-import_%5BimportId%5D_honor_route_actions_03rl257.js.map