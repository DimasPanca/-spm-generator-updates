module.exports=[67889,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_rkas_%5BrkasId%5D_lampiran_route_actions_1ohu36b.js.map