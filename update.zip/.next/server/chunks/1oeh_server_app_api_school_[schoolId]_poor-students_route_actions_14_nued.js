module.exports=[39458,(e,o,d)=>{}];

//# sourceMappingURL=1oeh_server_app_api_school_%5BschoolId%5D_poor-students_route_actions_14_nued.js.map