module.exports=[65595,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_schools_%5Bid%5D_opname_page_actions_1tfchue.js.map