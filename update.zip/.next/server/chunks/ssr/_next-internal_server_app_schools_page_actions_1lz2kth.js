module.exports=[3925,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_schools_page_actions_1lz2kth.js.map