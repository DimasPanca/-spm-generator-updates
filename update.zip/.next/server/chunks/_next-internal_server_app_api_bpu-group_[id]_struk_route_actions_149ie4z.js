module.exports=[57775,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_bpu-group_%5Bid%5D_struk_route_actions_149ie4z.js.map