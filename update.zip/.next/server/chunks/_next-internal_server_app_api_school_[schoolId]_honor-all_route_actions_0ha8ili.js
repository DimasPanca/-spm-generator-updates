module.exports=[21519,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_school_%5BschoolId%5D_honor-all_route_actions_0ha8ili.js.map