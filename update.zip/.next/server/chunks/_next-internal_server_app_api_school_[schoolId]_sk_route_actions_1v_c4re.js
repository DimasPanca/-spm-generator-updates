module.exports=[1343,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_school_%5BschoolId%5D_sk_route_actions_1v_c4re.js.map