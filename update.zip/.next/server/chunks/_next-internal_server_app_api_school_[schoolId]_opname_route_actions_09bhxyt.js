module.exports=[48412,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_school_%5BschoolId%5D_opname_route_actions_09bhxyt.js.map