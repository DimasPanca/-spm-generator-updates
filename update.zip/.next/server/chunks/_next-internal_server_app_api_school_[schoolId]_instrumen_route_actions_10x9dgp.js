module.exports=[31304,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_school_%5BschoolId%5D_instrumen_route_actions_10x9dgp.js.map