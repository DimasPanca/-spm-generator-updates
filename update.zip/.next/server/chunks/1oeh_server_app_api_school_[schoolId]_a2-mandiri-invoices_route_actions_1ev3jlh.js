module.exports=[81091,(e,o,d)=>{}];

//# sourceMappingURL=1oeh_server_app_api_school_%5BschoolId%5D_a2-mandiri-invoices_route_actions_1ev3jlh.js.map