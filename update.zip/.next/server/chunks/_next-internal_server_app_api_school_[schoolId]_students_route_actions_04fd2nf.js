module.exports=[78884,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_school_%5BschoolId%5D_students_route_actions_04fd2nf.js.map