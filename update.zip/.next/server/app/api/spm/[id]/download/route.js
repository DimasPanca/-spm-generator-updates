var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/spm/[id]/download/route.js")
R.c("server/chunks/[root-of-the-server]__0mww2ph._.js")
R.c("server/chunks/_0dra_px._.js")
R.c("server/chunks/[root-of-the-server]__1y_g68p._.js")
R.c("server/chunks/_next-internal_server_app_api_spm_[id]_download_route_actions_1jhc-1_.js")
R.m(12859)
module.exports=R.m(12859).exports
