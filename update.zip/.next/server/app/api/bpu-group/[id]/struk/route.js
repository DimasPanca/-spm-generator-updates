var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/bpu-group/[id]/struk/route.js")
R.c("server/chunks/[root-of-the-server]__1f9gx4_._.js")
R.c("server/chunks/_0dra_px._.js")
R.c("server/chunks/[root-of-the-server]__1y_g68p._.js")
R.c("server/chunks/_next-internal_server_app_api_bpu-group_[id]_struk_route_actions_149ie4z.js")
R.m(78046)
module.exports=R.m(78046).exports
