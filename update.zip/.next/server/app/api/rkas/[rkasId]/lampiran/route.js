var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/rkas/[rkasId]/lampiran/route.js")
R.c("server/chunks/[root-of-the-server]__0ped07s._.js")
R.c("server/chunks/_0w2wwhn._.js")
R.c("server/chunks/[root-of-the-server]__1y_g68p._.js")
R.c("server/chunks/_0dra_px._.js")
R.c("server/chunks/_next-internal_server_app_api_rkas_[rkasId]_lampiran_route_actions_1ohu36b.js")
R.m(47839)
module.exports=R.m(47839).exports
