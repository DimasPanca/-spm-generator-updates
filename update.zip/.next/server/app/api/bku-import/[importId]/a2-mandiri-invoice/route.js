var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/bku-import/[importId]/a2-mandiri-invoice/route.js")
R.c("server/chunks/[root-of-the-server]__03jxfpx._.js")
R.c("server/chunks/_0dra_px._.js")
R.c("server/chunks/[root-of-the-server]__1y_g68p._.js")
R.c("server/chunks/1oeh_server_app_api_bku-import_[importId]_a2-mandiri-invoice_route_actions_1_b75yb.js")
R.m(43170)
module.exports=R.m(43170).exports
