var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/bku-import/[importId]/download-all/route.js")
R.c("server/chunks/[root-of-the-server]__18rfwvm._.js")
R.c("server/chunks/[root-of-the-server]__1y_g68p._.js")
R.c("server/chunks/[root-of-the-server]__0ikxy9i._.js")
R.c("server/chunks/_0dra_px._.js")
R.c("server/chunks/1oeh_server_app_api_bku-import_[importId]_download-all_route_actions_1rl9k0i.js")
R.m(16259)
module.exports=R.m(16259).exports
