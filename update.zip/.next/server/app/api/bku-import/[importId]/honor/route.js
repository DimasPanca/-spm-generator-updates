var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/bku-import/[importId]/honor/route.js")
R.c("server/chunks/[root-of-the-server]__0nw0ima._.js")
R.c("server/chunks/[root-of-the-server]__1ag65v_._.js")
R.c("server/chunks/[root-of-the-server]__1y_g68p._.js")
R.c("server/chunks/_0dra_px._.js")
R.c("server/chunks/_next-internal_server_app_api_bku-import_[importId]_honor_route_actions_03rl257.js")
R.m(89810)
module.exports=R.m(89810).exports
