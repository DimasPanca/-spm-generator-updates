var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/bku-import/[importId]/combined/route.js")
R.c("server/chunks/[root-of-the-server]__1_cp87x._.js")
R.c("server/chunks/_13-bxbk._.js")
R.c("server/chunks/_0dra_px._.js")
R.c("server/chunks/[root-of-the-server]__1y_g68p._.js")
R.c("server/chunks/1oeh_server_app_api_bku-import_[importId]_combined_route_actions_0ulivbm.js")
R.m(52514)
module.exports=R.m(52514).exports
