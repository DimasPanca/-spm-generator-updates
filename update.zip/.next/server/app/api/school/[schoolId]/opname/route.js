var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/school/[schoolId]/opname/route.js")
R.c("server/chunks/[root-of-the-server]__18plmxw._.js")
R.c("server/chunks/_1bqfsr6._.js")
R.c("server/chunks/[root-of-the-server]__1y_g68p._.js")
R.c("server/chunks/_0dra_px._.js")
R.c("server/chunks/node_modules_1qk4jsn._.js")
R.c("server/chunks/_next-internal_server_app_api_school_[schoolId]_opname_route_actions_09bhxyt.js")
R.m(84611)
module.exports=R.m(84611).exports
