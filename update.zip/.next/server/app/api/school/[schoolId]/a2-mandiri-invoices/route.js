var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/school/[schoolId]/a2-mandiri-invoices/route.js")
R.c("server/chunks/[root-of-the-server]__0wr2_oo._.js")
R.c("server/chunks/_0dra_px._.js")
R.c("server/chunks/[root-of-the-server]__1y_g68p._.js")
R.c("server/chunks/1oeh_server_app_api_school_[schoolId]_a2-mandiri-invoices_route_actions_1ev3jlh.js")
R.m(7590)
module.exports=R.m(7590).exports
