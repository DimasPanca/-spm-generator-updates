var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/school/[schoolId]/sk/route.js")
R.c("server/chunks/_0a93v65._.js")
R.c("server/chunks/[root-of-the-server]__0y3oq13._.js")
R.c("server/chunks/node_modules_1qk4jsn._.js")
R.c("server/chunks/_0dra_px._.js")
R.c("server/chunks/[root-of-the-server]__1y_g68p._.js")
R.c("server/chunks/_next-internal_server_app_api_school_[schoolId]_sk_route_actions_1v_c4re.js")
R.m(5062)
module.exports=R.m(5062).exports
