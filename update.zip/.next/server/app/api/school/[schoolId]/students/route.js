var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/school/[schoolId]/students/route.js")
R.c("server/chunks/[root-of-the-server]__1du8r3k._.js")
R.c("server/chunks/src_1-63p91._.js")
R.c("server/chunks/node_modules_1qk4jsn._.js")
R.c("server/chunks/_0dra_px._.js")
R.c("server/chunks/[root-of-the-server]__1y_g68p._.js")
R.c("server/chunks/_next-internal_server_app_api_school_[schoolId]_students_route_actions_04fd2nf.js")
R.m(29502)
module.exports=R.m(29502).exports
