var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/school/[schoolId]/fraza-receipts/route.js")
R.c("server/chunks/[root-of-the-server]__0rqbomk._.js")
R.c("server/chunks/_0dra_px._.js")
R.c("server/chunks/[root-of-the-server]__1y_g68p._.js")
R.c("server/chunks/1oeh_server_app_api_school_[schoolId]_fraza-receipts_route_actions_1_1xn6q.js")
R.m(6199)
module.exports=R.m(6199).exports
