var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/school/[schoolId]/poor-students/route.js")
R.c("server/chunks/[root-of-the-server]__16mx9fe._.js")
R.c("server/chunks/src_1-63p91._.js")
R.c("server/chunks/node_modules_1qk4jsn._.js")
R.c("server/chunks/_0dra_px._.js")
R.c("server/chunks/[root-of-the-server]__1y_g68p._.js")
R.c("server/chunks/1oeh_server_app_api_school_[schoolId]_poor-students_route_actions_14_nued.js")
R.m(55767)
module.exports=R.m(55767).exports
