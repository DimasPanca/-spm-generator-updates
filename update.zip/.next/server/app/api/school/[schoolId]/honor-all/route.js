var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/school/[schoolId]/honor-all/route.js")
R.c("server/chunks/[root-of-the-server]__1do7y9s._.js")
R.c("server/chunks/[root-of-the-server]__16as0y4._.js")
R.c("server/chunks/[root-of-the-server]__1y_g68p._.js")
R.c("server/chunks/_0dra_px._.js")
R.c("server/chunks/_next-internal_server_app_api_school_[schoolId]_honor-all_route_actions_0ha8ili.js")
R.m(34840)
module.exports=R.m(34840).exports
