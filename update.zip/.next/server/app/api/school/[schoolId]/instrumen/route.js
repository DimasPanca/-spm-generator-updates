var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/school/[schoolId]/instrumen/route.js")
R.c("server/chunks/[root-of-the-server]__001hc7z._.js")
R.c("server/chunks/[root-of-the-server]__1y_g68p._.js")
R.c("server/chunks/[root-of-the-server]__0-v_wrd._.js")
R.c("server/chunks/_0dra_px._.js")
R.c("server/chunks/_next-internal_server_app_api_school_[schoolId]_instrumen_route_actions_10x9dgp.js")
R.m(97215)
module.exports=R.m(97215).exports
