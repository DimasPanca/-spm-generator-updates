-- Mark vendor rules that pay a PERSON (honor/upah), so each becomes its own
-- "DAFTAR PENERIMAAN ..." sheet in the honor recap.
ALTER TABLE "VendorRule" ADD COLUMN "isHonor" BOOLEAN NOT NULL DEFAULT false;

-- Backfill existing rules. Payments routed to "Bendahara" (penyelenggara /
-- pengawas ujian, transport) are left off: their recap sheet would just repeat
-- "Bendahara", so the admin can tick those on manually if ever needed.
UPDATE "VendorRule"
SET "isHonor" = true
WHERE ("formatType" = 'NAME_FROM_URAIAN'
       OR "paymentPrefix" LIKE 'Honor%'
       OR "paymentPrefix" LIKE 'Upah%'
       OR "paymentPrefix" LIKE 'Pemeliharaan Komputer%')
  AND TRIM(LOWER("recipient")) <> 'bendahara';

-- Honor recaps are now rendered on demand from confirmed BPU groups, so the
-- stored registry is obsolete. Generated PDF files on disk are untouched.
DROP TABLE "HonorRecapEntry";
DROP TABLE "HonorRecapDocument";
