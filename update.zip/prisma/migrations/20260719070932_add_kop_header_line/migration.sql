-- AlterTable
ALTER TABLE "School" ADD COLUMN "kopHeaderLine" TEXT;
