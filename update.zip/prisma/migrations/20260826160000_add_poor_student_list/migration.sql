-- Store only the small subset of daftar_pd data needed for the poor-student
-- report. The uploaded source workbook itself is intentionally not retained.
CREATE TABLE "StudentDataImport" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "schoolId" TEXT NOT NULL,
    "sourceFileName" TEXT NOT NULL,
    "sourceSchoolName" TEXT,
    "importedAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "StudentDataImport_schoolId_fkey" FOREIGN KEY ("schoolId") REFERENCES "School" ("id") ON DELETE CASCADE ON UPDATE CASCADE
);

CREATE TABLE "StudentRecord" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "studentDataImportId" TEXT NOT NULL,
    "sourceNumber" INTEGER,
    "name" TEXT NOT NULL,
    "nik" TEXT,
    "gender" TEXT,
    "className" TEXT,
    "birthPlace" TEXT,
    "birthDate" DATETIME,
    "parentName" TEXT,
    "parentRelation" TEXT,
    "address" TEXT,
    "isPipEligible" BOOLEAN NOT NULL DEFAULT false,
    "pipReason" TEXT,
    CONSTRAINT "StudentRecord_studentDataImportId_fkey" FOREIGN KEY ("studentDataImportId") REFERENCES "StudentDataImport" ("id") ON DELETE CASCADE ON UPDATE CASCADE
);

CREATE INDEX "StudentDataImport_schoolId_importedAt_idx" ON "StudentDataImport"("schoolId", "importedAt");
CREATE INDEX "StudentRecord_studentDataImportId_name_idx" ON "StudentRecord"("studentDataImportId", "name");
