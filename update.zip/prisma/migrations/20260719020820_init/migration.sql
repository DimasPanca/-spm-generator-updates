-- CreateTable
CREATE TABLE "School" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "name" TEXT NOT NULL,
    "npsn" TEXT,
    "address" TEXT NOT NULL,
    "contact" TEXT,
    "formatCode" TEXT NOT NULL,
    "kepalaName" TEXT NOT NULL,
    "kepalaJabatan" TEXT NOT NULL,
    "openingSentenceTemplate" TEXT NOT NULL DEFAULT 'Saya yang bertanda tangan dibawah ini selaku kepala {institutionName}',
    "atasDasarLine1" TEXT NOT NULL DEFAULT 'Kuitansi / Bukti Pembelian',
    "atasDasarLine2" TEXT NOT NULL DEFAULT 'Nota / Bukti Penerimaan Barang',
    "honorRecapTitle" TEXT,
    "logoPath" TEXT,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL
);

-- CreateTable
CREATE TABLE "VendorRule" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "schoolId" TEXT NOT NULL,
    "keyword" TEXT NOT NULL,
    "recipient" TEXT NOT NULL,
    "paymentPrefix" TEXT NOT NULL,
    "formatType" TEXT NOT NULL DEFAULT 'STANDARD',
    "priority" INTEGER NOT NULL DEFAULT 100,
    "isActive" BOOLEAN NOT NULL DEFAULT true,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL,
    CONSTRAINT "VendorRule_schoolId_fkey" FOREIGN KEY ("schoolId") REFERENCES "School" ("id") ON DELETE CASCADE ON UPDATE CASCADE
);

-- CreateTable
CREATE TABLE "BKUImport" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "schoolId" TEXT NOT NULL,
    "month" INTEGER NOT NULL,
    "year" INTEGER NOT NULL,
    "sourceFileName" TEXT NOT NULL,
    "status" TEXT NOT NULL DEFAULT 'PARSED',
    "importedAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "BKUImport_schoolId_fkey" FOREIGN KEY ("schoolId") REFERENCES "School" ("id") ON DELETE CASCADE ON UPDATE CASCADE
);

-- CreateTable
CREATE TABLE "BKURow" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "bkuImportId" TEXT NOT NULL,
    "tanggal" DATETIME NOT NULL,
    "kodeKegiatan" TEXT,
    "kodeRekening" TEXT,
    "bpuCode" TEXT,
    "bpuNumber" INTEGER,
    "uraian" TEXT NOT NULL,
    "penerimaan" INTEGER NOT NULL DEFAULT 0,
    "pengeluaran" INTEGER NOT NULL DEFAULT 0,
    "saldo" INTEGER NOT NULL DEFAULT 0,
    "pageIndex" INTEGER,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "BKURow_bkuImportId_fkey" FOREIGN KEY ("bkuImportId") REFERENCES "BKUImport" ("id") ON DELETE CASCADE ON UPDATE CASCADE
);

-- CreateTable
CREATE TABLE "BPUGroup" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "bkuImportId" TEXT NOT NULL,
    "bpuCode" TEXT NOT NULL,
    "bpuNumber" INTEGER NOT NULL,
    "tanggal" DATETIME NOT NULL,
    "totalAmount" INTEGER NOT NULL,
    "matchedVendorRuleId" TEXT,
    "overrideRecipient" TEXT,
    "overridePaymentFor" TEXT,
    "status" TEXT NOT NULL DEFAULT 'SUGGESTED',
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL,
    CONSTRAINT "BPUGroup_bkuImportId_fkey" FOREIGN KEY ("bkuImportId") REFERENCES "BKUImport" ("id") ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT "BPUGroup_matchedVendorRuleId_fkey" FOREIGN KEY ("matchedVendorRuleId") REFERENCES "VendorRule" ("id") ON DELETE SET NULL ON UPDATE CASCADE
);

-- CreateTable
CREATE TABLE "SPMDocument" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "bpuGroupId" TEXT NOT NULL,
    "nomorSurat" TEXT NOT NULL,
    "recipient" TEXT NOT NULL,
    "amount" INTEGER NOT NULL,
    "terbilang" TEXT NOT NULL,
    "paymentFor" TEXT NOT NULL,
    "filePath" TEXT NOT NULL,
    "generatedAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "SPMDocument_bpuGroupId_fkey" FOREIGN KEY ("bpuGroupId") REFERENCES "BPUGroup" ("id") ON DELETE CASCADE ON UPDATE CASCADE
);

-- CreateTable
CREATE TABLE "HonorRecapDocument" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "schoolId" TEXT NOT NULL,
    "month" INTEGER NOT NULL,
    "year" INTEGER NOT NULL,
    "filePath" TEXT NOT NULL,
    "generatedAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "HonorRecapDocument_schoolId_fkey" FOREIGN KEY ("schoolId") REFERENCES "School" ("id") ON DELETE CASCADE ON UPDATE CASCADE
);

-- CreateTable
CREATE TABLE "HonorRecapEntry" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "honorRecapDocumentId" TEXT NOT NULL,
    "no" INTEGER NOT NULL,
    "tanggal" DATETIME NOT NULL,
    "nama" TEXT NOT NULL,
    "nominal" INTEGER NOT NULL,
    CONSTRAINT "HonorRecapEntry_honorRecapDocumentId_fkey" FOREIGN KEY ("honorRecapDocumentId") REFERENCES "HonorRecapDocument" ("id") ON DELETE CASCADE ON UPDATE CASCADE
);

-- CreateIndex
CREATE INDEX "VendorRule_schoolId_priority_idx" ON "VendorRule"("schoolId", "priority");

-- CreateIndex
CREATE INDEX "BKUImport_schoolId_year_month_idx" ON "BKUImport"("schoolId", "year", "month");

-- CreateIndex
CREATE INDEX "BKURow_bkuImportId_bpuCode_idx" ON "BKURow"("bkuImportId", "bpuCode");

-- CreateIndex
CREATE UNIQUE INDEX "BPUGroup_bkuImportId_bpuCode_key" ON "BPUGroup"("bkuImportId", "bpuCode");

-- CreateIndex
CREATE UNIQUE INDEX "SPMDocument_bpuGroupId_key" ON "SPMDocument"("bpuGroupId");

-- CreateIndex
CREATE UNIQUE INDEX "HonorRecapDocument_schoolId_year_month_key" ON "HonorRecapDocument"("schoolId", "year", "month");

-- CreateIndex
CREATE INDEX "HonorRecapEntry_honorRecapDocumentId_idx" ON "HonorRecapEntry"("honorRecapDocumentId");
