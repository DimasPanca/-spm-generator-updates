-- AlterTable
ALTER TABLE "VendorRule" ADD COLUMN "isTransport" BOOLEAN NOT NULL DEFAULT false;

-- Backfill: the existing "Transport" starter rule (recipient = Bendahara,
-- old prefix "Pembayaran Transport") becomes the Transport Kegiatan honor-
-- style recap category.
UPDATE "VendorRule"
SET "isTransport" = true,
    "paymentPrefix" = 'Transport Kegiatan'
WHERE "keyword" = 'Transport'
  AND "recipient" = 'Bendahara'
  AND "paymentPrefix" = 'Pembayaran Transport';
