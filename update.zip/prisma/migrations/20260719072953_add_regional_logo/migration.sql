-- AlterTable
ALTER TABLE "School" ADD COLUMN "regionalLogoPath" TEXT;
