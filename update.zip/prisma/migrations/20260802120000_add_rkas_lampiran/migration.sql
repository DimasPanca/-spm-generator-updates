-- CreateTable
CREATE TABLE "RkasImport" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "schoolId" TEXT NOT NULL,
    "month" INTEGER NOT NULL,
    "year" INTEGER NOT NULL,
    "sourceFileName" TEXT NOT NULL,
    "sourceSchoolName" TEXT,
    "npsn" TEXT,
    "namaPelaksana" TEXT NOT NULL DEFAULT '',
    "programLabel" TEXT NOT NULL DEFAULT 'Belanja Operasional Satuan Pendidikan',
    "namaKegiatan" TEXT NOT NULL DEFAULT 'Belanja Tunai',
    "sumberDana" TEXT NOT NULL DEFAULT 'BOSP',
    "pekerjaanLabel" TEXT NOT NULL DEFAULT 'Belanja BOSP',
    "kepalaName" TEXT NOT NULL DEFAULT '',
    "bendaharaName" TEXT NOT NULL DEFAULT '',
    "importedAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL,
    CONSTRAINT "RkasImport_schoolId_fkey" FOREIGN KEY ("schoolId") REFERENCES "School" ("id") ON DELETE CASCADE ON UPDATE CASCADE
);

-- CreateIndex
CREATE INDEX "RkasImport_schoolId_year_month_idx" ON "RkasImport"("schoolId", "year", "month");

-- CreateTable
CREATE TABLE "RkasProgram" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "rkasImportId" TEXT NOT NULL,
    "urutan" INTEGER NOT NULL,
    "kodeProgram" TEXT NOT NULL,
    "nama" TEXT NOT NULL,
    "standarName" TEXT NOT NULL DEFAULT '',
    "kegiatanName" TEXT NOT NULL DEFAULT '',
    "included" BOOLEAN NOT NULL DEFAULT false,
    CONSTRAINT "RkasProgram_rkasImportId_fkey" FOREIGN KEY ("rkasImportId") REFERENCES "RkasImport" ("id") ON DELETE CASCADE ON UPDATE CASCADE
);

-- CreateIndex
CREATE INDEX "RkasProgram_rkasImportId_urutan_idx" ON "RkasProgram"("rkasImportId", "urutan");

-- CreateTable
CREATE TABLE "RkasItem" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "rkasProgramId" TEXT NOT NULL,
    "urutan" INTEGER NOT NULL,
    "noUrut" INTEGER NOT NULL,
    "kodeRekening" TEXT NOT NULL,
    "uraian" TEXT NOT NULL,
    "volumeText" TEXT NOT NULL,
    "tarifHarga" INTEGER NOT NULL,
    "jumlah" INTEGER NOT NULL,
    "excluded" BOOLEAN NOT NULL DEFAULT false,
    CONSTRAINT "RkasItem_rkasProgramId_fkey" FOREIGN KEY ("rkasProgramId") REFERENCES "RkasProgram" ("id") ON DELETE CASCADE ON UPDATE CASCADE
);

-- CreateIndex
CREATE INDEX "RkasItem_rkasProgramId_urutan_idx" ON "RkasItem"("rkasProgramId", "urutan");
