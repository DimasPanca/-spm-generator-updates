-- AlterTable
ALTER TABLE "VendorRule" ADD COLUMN "matchKodeKegiatan" TEXT;
