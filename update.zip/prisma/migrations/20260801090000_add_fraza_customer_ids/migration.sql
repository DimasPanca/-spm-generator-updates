-- Customer IDs shown on the respective Fraza Cell utility receipts.
ALTER TABLE "School" ADD COLUMN "frazaListrikCustomerId" TEXT;
ALTER TABLE "School" ADD COLUMN "frazaInternetCustomerId" TEXT;
