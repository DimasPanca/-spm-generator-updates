-- CreateTable
CREATE TABLE "SkBosp" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "schoolId" TEXT NOT NULL,
    "year" INTEGER NOT NULL,
    "nomorUrut" TEXT NOT NULL DEFAULT '05',
    "kodeSurat" TEXT NOT NULL DEFAULT 'SK.PTB',
    "tanggalRapat" INTEGER NOT NULL DEFAULT 2,
    "tanggalTetap" INTEGER NOT NULL DEFAULT 4,
    "kecamatan" TEXT NOT NULL DEFAULT 'Walantaka',
    "kota" TEXT NOT NULL DEFAULT 'Kota Serang',
    "provinsi" TEXT NOT NULL DEFAULT 'Banten',
    "kepalaName" TEXT NOT NULL DEFAULT '',
    "teamJson" TEXT NOT NULL DEFAULT '[]',
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL,
    CONSTRAINT "SkBosp_schoolId_fkey" FOREIGN KEY ("schoolId") REFERENCES "School" ("id") ON DELETE CASCADE ON UPDATE CASCADE
);

-- CreateIndex
CREATE UNIQUE INDEX "SkBosp_schoolId_year_key" ON "SkBosp"("schoolId", "year");
